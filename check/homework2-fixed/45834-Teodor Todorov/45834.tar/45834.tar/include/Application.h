// Header Guard
#ifndef rAXmOmsDvzQkhRToybvH
#define rAXmOmsDvzQkhRToybvH

#include "Database.h"

class Application {
	Database db;
public:
	void load(const char * path);
	void start();
};

#endif
