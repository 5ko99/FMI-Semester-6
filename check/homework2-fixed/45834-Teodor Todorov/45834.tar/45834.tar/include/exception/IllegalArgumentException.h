// Header Guard
#ifndef mZYZOTKnYcSxsOjbSsBF
#define mZYZOTKnYcSxsOjbSsBF

#include "RuntimeException.h"

class IllegalArgumentException : public RuntimeException {
public:
	IllegalArgumentException() : RuntimeException() {

	}

	IllegalArgumentException(std::string message) : RuntimeException(message) {

	}

	const char * what() const noexcept override {
		return RuntimeException::what();
	}
};

#endif