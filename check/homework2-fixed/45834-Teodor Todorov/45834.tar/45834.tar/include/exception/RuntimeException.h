// Header Guard
#ifndef EmCezhXJgYDNvyyvKpIX
#define EmCezhXJgYDNvyyvKpIX

#include <string>
#include <exception>

class RuntimeException : public std::exception {
protected:
	std::string message;
public:
	RuntimeException() {

	}

	RuntimeException(std::string message) {
		this->message = std::move(message);
	}

	const char * what() const noexcept override {
		return message.c_str();
	}
};

#endif