// Header Guard
#ifndef itGNiYHxTehRRMbZSMUR
#define itGNiYHxTehRRMbZSMUR

#include <string>
#include "RuntimeException.h"

class IllegalStateException : public RuntimeException {
public:
	IllegalStateException() : RuntimeException() {

	}

	IllegalStateException(std::string message) : RuntimeException(message) {

	}

	const char * what() const noexcept override {
		return RuntimeException::what();
	}
};

#endif
