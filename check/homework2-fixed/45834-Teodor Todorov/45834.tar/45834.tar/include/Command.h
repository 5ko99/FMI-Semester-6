// Header Guard
#ifndef ndBnvaLZmGoLLJCTGTKL
#define ndBnvaLZmGoLLJCTGTKL

#include <string>
#include <vector>

class Command {
	std::string cmd;
	std::vector<std::string> args;

public:
	Command(const std::string & toParse);

	const std::string & getCommand() const;
	const std::vector<std::string> & getArgs() const;
};

#endif
