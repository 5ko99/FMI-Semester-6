// Header Guard
#ifndef vAZnCwUakKMwbpDgRnVi
#define vAZnCwUakKMwbpDgRnVi

#include <string>

#include "Registration.h"
#include "Person.h"

class Person;

class Vehicle {
	friend class Person;
	friend class Database;

	Registration reg;
	std::string desc;
	Person * owner;

public:
	Vehicle(const Registration & reg, const std::string & desc);

	~Vehicle() = default;
	Vehicle(const Vehicle & other);
	Vehicle & operator=(const Vehicle & other);
	Vehicle(Vehicle && other) noexcept;
	Vehicle & operator=(Vehicle && other) noexcept;

	const Registration & getReg() const;
	const std::string & getDesc() const;
	const Person * getOwner() const;

	bool operator==(const Vehicle & v) noexcept;
	bool operator==(const Vehicle & v) const noexcept;

	friend std::ostream & operator<<(std::ostream & out, const Vehicle & v);
};

#endif
