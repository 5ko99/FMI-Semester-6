// Header Guard
#ifndef ggSPxrFYTTIJzdbZXrqV
#define ggSPxrFYTTIJzdbZXrqV

#include <iostream>

class Registration {
	char id[9] {};

	void clear();

	static bool isShortFormat(const char * const id);
	static bool isLongFormat(const char * const id);
	static bool isArraySane(const char * const id);


public:
	Registration();
	/**
	 * Constructor
	 * @param id
	 * @throws IllegalArgumentException
	 */
	Registration(const char id[9]);

	/**
	 * Copy constructor
	 * @param registration
	 */
	Registration(const Registration & registration) noexcept;

	/**
	 * Copy assignment
	 * @param registration
	 * @return
	 */
	Registration & operator=(const Registration & registration) noexcept;

	const char * getId() const;

	bool operator==(const Registration & reg) noexcept;
	bool operator==(const Registration & reg) const noexcept;

	friend std::ostream & operator<<(std::ostream & out, const Registration & r);

	static bool isValid(const std::string & s);
};

#endif
