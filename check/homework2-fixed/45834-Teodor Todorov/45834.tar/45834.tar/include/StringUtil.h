#include <string>
#include <vector>

class StringUtil {
public:
	static bool isLowerCase(char c) {
		return c >= 'a' && c <= 'z';
	}

	static bool isUpperCase(char c) {
		return c >= 'A' && c <= 'Z';
	}

	static char toLowerCase(char c) {
		static int upperLowerDifference = 'A' - 'a';
		if (isUpperCase(c)) {
			return c - upperLowerDifference;
		}
		return c;
	}

	static char toUpperCase(char c) {
		static int upperLowerDifference = 'A' - 'a';
		if (isLowerCase(c)) {
			return c + upperLowerDifference;
		}
		return c;
	}

	static std::string toLowerCase(std::string s) {
		const std::size_t size = s.size();
		for (std::size_t i = 0; i < size; i++) {
			s[i] = toLowerCase(s[i]);
		}
		return s;
	}

	static std::string toUpperCase(std::string s) {
		const std::size_t size = s.size();
		for (std::size_t i = 0; i < size; i++) {
			s[i] = toUpperCase(s[i]);
		}
		return s;
	}

	static std::vector<std::string> split(std::string str, std::string delimiter, std::size_t limit = -1) {
		const std::size_t delimiterSize = delimiter.size();
		std::vector<std::string> splitStrings;

		if (delimiterSize == 0) {
			const std::size_t size = str.size();
			for (std::size_t i = 0; i < size; i++) {
				if (splitStrings.size() < limit) {
					splitStrings.push_back(std::string() + str[i]);
				}
				else {
					splitStrings.push_back(str.substr(i));
					break;
				}
			}
			return splitStrings;
		}
		else {
			std::size_t pos;
			while ((pos = str.find(delimiter)) != -1) {
				std::string extracted = str.substr(0, pos);
				str = str.substr(pos + delimiterSize);

				if (splitStrings.size() < limit) {
					splitStrings.push_back(extracted);
				}
				else {
					splitStrings.push_back(extracted + delimiter + str);
					return splitStrings;
				}
			}

			splitStrings.push_back(str);
			return splitStrings;
		}
	}
};
