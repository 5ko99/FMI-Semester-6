// Header Guard
#ifndef poFBvODNbDjVTjzrYmsl
#define poFBvODNbDjVTjzrYmsl

#include <string>
#include <vector>

#include "Vehicle.h"

class Vehicle;

class Person {
	friend class Vehicle;
	friend class Database;

	unsigned int id;
	std::string name;
	std::vector<Vehicle *> vehicles;

public:
	Person(unsigned int id, std::string name);

	~Person() = default;
	Person(const Person & other);
	Person & operator=(const Person & other);
	Person(Person && other) noexcept;
	Person & operator=(Person && other) noexcept;

	unsigned int getId() const;
	const std::string & getName() const;
	const std::vector<Vehicle *> & getVehicles() const;
	const Vehicle * getVehicle(const Registration & reg) const;

	void addVehicle(Vehicle * v);
	void removeVehicle(const Registration & reg);
	void clearVehicles();

	bool operator==(const Person & p) noexcept;
	bool operator==(const Person & p) const noexcept;

	friend std::ostream & operator<<(std::ostream & out, const Person & p);

	static bool isValid(const std::string & s);
};

#endif
