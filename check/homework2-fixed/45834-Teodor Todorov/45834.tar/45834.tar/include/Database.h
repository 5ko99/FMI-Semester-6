// Header Guard
#ifndef hhrJwcFwgNgDiGOZPjzp
#define hhrJwcFwgNgDiGOZPjzp

#include "Person.h"
#include "Vehicle.h"
#include "Command.h"

class Database {
	static const char COMMAND_SEPARATOR = '\n';

	std::vector<Person> people;
	std::vector<Vehicle> vehicles;

	Person * getPerson(unsigned int id);
	Vehicle * getVehicle(const Registration & reg);

	std::size_t getPersonIndex(unsigned int id);
	std::size_t getVehicleIndex(const Registration & reg);

	void printPeople() const;
	void printVehicles() const;

	void processCommandVehicle(const std::vector<std::string> & args, bool verbose);
	void processCommandPerson(const std::vector<std::string> & args, bool verbose);
	void processCommandAcquire(const std::vector<std::string> & args, bool verbose);
	void processCommandRelease(const std::vector<std::string> & args, bool verbose);
	void processCommandRemove(const std::vector<std::string> & args, bool verbose);
	void processCommandSave(const std::vector<std::string> & args, bool verbose) const;
	void processCommandShow(const std::vector<std::string> & args, bool verbose);
	void processCommandLoad(const std::vector<std::string> & args, bool verbose);

	std::string toCommandString() const;
	static Database fromCommandString(const std::string & s);

public:
	void addPerson(const Person & p);
	void addVehicle(const Vehicle & v);

	void doAcquire(unsigned int id, const Registration & reg);
	void doRelease(unsigned int id, const Registration & reg);

	void removePerson(unsigned int id);
	void removeVehicle(const Registration & reg);

	void save(const char * path) const;

	void processCommand(const Command & c, bool verbose = false);

	friend std::ostream & operator<<(std::ostream & out, const Database & db);
	static Database load(const char * path);
};

#endif
