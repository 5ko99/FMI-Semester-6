#include <iostream>
#include <utility>

#include "../include/Person.h"
#include "../include/exception/IllegalArgumentException.h"

Person::Person(unsigned int id, std::string name) {
	this->id = id;
	this->name = std::move(name);

//	std::cout << "New person " << getId() << " " << getName() << " " << this << std::endl;
}

Person::Person(const Person & other) {
	*this = other;
}

Person & Person::operator=(const Person & other) {
	if (*this == other) {
		return *this;
	}

	this->id = other.id;
	this->name = other.name;
	this->vehicles = other.vehicles;

	for (Vehicle * v : this->vehicles) {
		v->owner = this;
	}

	return *this;
}

Person::Person(Person && other) noexcept {
	*this = std::move(other);
}

Person & Person::operator=(Person && other) noexcept {
	if (*this == other) {
		return *this;
	}

	this->id = other.id;
	this->name = std::move(other.name);
	this->vehicles = std::move(other.vehicles);

	for (Vehicle * v : this->vehicles) {
		v->owner = this;
	}

	return *this;
}

unsigned int Person::getId() const {
	return id;
}

const std::string & Person::getName() const {
	return name;
}

const std::vector<Vehicle *> & Person::getVehicles() const {
	return vehicles;
}

const Vehicle * Person::getVehicle(const Registration & reg) const {
	for (const Vehicle * v : vehicles) {
		if (v->getReg() == reg) {
			return v;
		}
	}
	return nullptr;
}

void Person::addVehicle(Vehicle * v) {
	if (v == nullptr) {
		throw IllegalArgumentException("nullptr passed");
	}
	if (getVehicle(v->reg) == nullptr) {
		v->owner = this;
		vehicles.push_back(v);
	}
}

void Person::removeVehicle(const Registration & reg) {
	bool found = false;
	std::size_t index = 0;
	const std::size_t size = vehicles.size();

	for (std::size_t i = 0; i < size; i++) {
		if (vehicles[i]->reg == reg) {
			found = true;
			index = i;
			break;
		}
	}

	if (found) {
		vehicles[index]->owner = nullptr;
		std::swap(vehicles[index], vehicles[size - 1]);
		vehicles.pop_back();
	}
}

void Person::clearVehicles() {
	const std::size_t size = vehicles.size();
	for (std::size_t i = 0; i < size; i++) {
		vehicles[i]->owner = nullptr;
	}
	vehicles.clear();
}

std::ostream & operator<<(std::ostream & out, const Person & p) {
	out << "{id: " << p.getId() << ", name: \"" << p.getName() << "\"}";
	return out;
}

bool Person::operator==(const Person & p) noexcept {
	return this->id == p.id && this->name == p.name;
}

bool Person::operator==(const Person & p) const noexcept {
	return this->id == p.id && this->name == p.name;
}

bool Person::isValid(const std::string & s) {
	try {
		std::stoi(s);
		return true;
	}
	catch (std::exception &) {
		return false;
	}
}
