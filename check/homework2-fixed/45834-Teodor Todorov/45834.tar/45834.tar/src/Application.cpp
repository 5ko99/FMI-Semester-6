#include "../include/Application.h"

void Application::load(const char * path) {
	db = Database::load(path);
}

void Application::start() {
	std::string s;
	while (true) {
		std::getline(std::cin, s);
		if (s == "exit") {
			break;
		}
		try {
			db.processCommand(Command(s), true);
		}
		catch (std::exception & e) {
			std::cout << "Exception encountered: " << e.what() << std::endl;
		}
	}
}
