#include <cstring>
#include <cctype>

#include "../include/Registration.h"
#include "../include/exception/IllegalArgumentException.h"
#include "../include/StringUtil.h"

void Registration::clear() {
	for (int i = 0; i < 9; i++) {
		id[i] = 0;
	}
}

bool Registration::isShortFormat(const char * const id) {
	return strlen(id) == 7;
}

bool Registration::isLongFormat(const char * const id) {
	return strlen(id) == 8;
}

bool Registration::isArraySane(const char * const id) {
	bool b = true;

	if (isShortFormat(id)) {
		b &= bool(std::isalpha(id[0]));

		b &= bool(std::isdigit(id[1]));
		b &= bool(std::isdigit(id[2]));
		b &= bool(std::isdigit(id[3]));
		b &= bool(std::isdigit(id[4]));

		b &= bool(std::isalpha(id[5]));
		b &= bool(std::isalpha(id[6]));
	}
	else if (isLongFormat(id)) {
		b &= bool(std::isalpha(id[0]));
		b &= bool(std::isalpha(id[1]));

		b &= bool(std::isdigit(id[2]));
		b &= bool(std::isdigit(id[3]));
		b &= bool(std::isdigit(id[4]));
		b &= bool(std::isdigit(id[5]));

		b &= bool(std::isalpha(id[6]));
		b &= bool(std::isalpha(id[7]));
	}
	else {
		return false;
	}

	return b;
}

Registration::Registration() {
	clear();
}

Registration::Registration(const char id[9]) {
	if (id == nullptr) {
		throw IllegalArgumentException("nullptr passed");
	}

	size_t len = strlen(id);
	if (len != 7 && len != 8) {
		throw IllegalArgumentException("Invalid array length");
	}

	if (!isArraySane(id)) {
		clear();
		throw IllegalArgumentException("Incorrect array format");
	}

	for (int i = 0; i < len; i++) {
		this->id[i] = StringUtil::toUpperCase(id[i]);
	}
}

Registration::Registration(const Registration & registration) noexcept {
	*this = registration;
}

Registration & Registration::operator=(const Registration & registration) noexcept {
//	if (*this == registration) {
//		return *this;
//	}
	for (int i = 0; i < 9; i++) {
		id[i] = registration.id[i];
	}
	return *this;
}

const char * Registration::getId() const {
	return id;
}

bool Registration::operator==(const Registration & reg) noexcept {
	for (int i = 0; i < 9; i++) {
		if (id[i] != reg.id[i]) {
			return false;
		}
	}
	return true;
}

bool Registration::operator==(const Registration & reg) const noexcept {
	for (int i = 0; i < 9; i++) {
		if (id[i] != reg.id[i]) {
			return false;
		}
	}
	return true;
}

std::ostream & operator<<(std::ostream & out, const Registration & r) {
	out << r.id;
	return out;
}

bool Registration::isValid(const std::string & s) {
	try {
		Registration(s.c_str());
		return true;
	}
	catch (std::exception &) {
		return false;
	}
}

//Registration Registration::fromString(const std::string & s) {
//	return Registration(s.c_str());
//}
