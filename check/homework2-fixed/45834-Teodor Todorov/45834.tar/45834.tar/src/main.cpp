#include <iostream>

#include "../include/Database.h"
#include "../include/StringUtil.h"
#include "../include/Application.h"

int main(int argc, char ** argv) {
	Application app;

	if (argc == 2) {
		std::string path = argv[1];
		app.load(path.c_str());
	}

	std::cout << "Available commands:" << '\n'
			  << '\t' << "vehicle <vehicle-id> <vehicle-description>" << '\n'
			  << '\t' << "person <person-name> <person-id>" << '\n'
			  << '\t' << "acquire <person-id> <vehicle-registration>" << '\n'
			  << '\t' << "release <person-id> <vehicle-id>" << '\n'
			  << '\t' << "remove [<person-id> | <vehicle-id>]" << '\n'
			  << '\t' << "save <file-path>" << '\n'
			  << '\t' << "show [people | vehicles | <person-id> | <vehicle-id>]" << '\n'
			  << '\t' << "load <file-path>" << '\n';

	app.start();
	return 0;
}
