#include <fstream>
#include "../include/Database.h"
#include "../include/exception/IllegalArgumentException.h"
#include "../include/exception/IllegalStateException.h"
#include "../include/StringUtil.h"

Person * Database::getPerson(unsigned int id) {
	for (Person & p : people) {
		if (p.getId() == id) {
			return &p;
		}
	}
	return nullptr;
}

Vehicle * Database::getVehicle(const Registration & reg) {
	for (Vehicle & v : vehicles) {
		if (v.getReg() == reg) {
			return &v;
		}
	}
	return nullptr;
}

std::size_t Database::getPersonIndex(unsigned int id) {
	const std::size_t size = people.size();
	for (std::size_t i = 0; i < size; i++) {
		if (people[i].getId() == id) {
			return i;
		}
	}
	throw IllegalArgumentException("Person with specified id could not be found");
}

std::size_t Database::getVehicleIndex(const Registration & reg) {
	const std::size_t size = vehicles.size();
	for (std::size_t i = 0; i < size; i++) {
		if (vehicles[i].getReg() == reg) {
			return i;
		}
	}
	throw IllegalArgumentException("Vehicle with specified reg could not be found");
}

void Database::printPeople() const {
	bool first = true;
	for (const Person & p : people) {
		if (first) {
			first = false;
			std::cout << p;
		}
		else {
			std::cout << ", " << p;
		}
	}
}

void Database::printVehicles() const {
	bool first = true;
	for (const Vehicle & v : vehicles) {
		if (first) {
			first = false;
			std::cout << v;
		}
		else {
			std::cout << ", " << v;
		}
	}
}


void Database::processCommandVehicle(const std::vector<std::string> & args, bool verbose) {
	if (args.size() != 2) {
		throw IllegalArgumentException("Command \"vehicle\" should have 2 args");
	}

	const Registration reg(args[0].c_str());
	const std::string & desc = args[1];

	Vehicle v = Vehicle(reg, desc);
	addVehicle(v);

	if (verbose) {
		std::cout << "Added vehicle: " << v << std::endl;
	}
}

void Database::processCommandPerson(const std::vector<std::string> & args, bool verbose) {
	if (args.size() != 2) {
		throw IllegalArgumentException("Command \"person\" should have 2 args");
	}

	const std::string & name = args[0];
	const unsigned int id = std::stoi(args[1]);

	Person p = Person(id, name);
	addPerson(p);

	if (verbose) {
		std::cout << "Added person: " << p << std::endl;
	}
}

void Database::processCommandAcquire(const std::vector<std::string> & args, bool verbose) {
	if (args.size() != 2) {
		throw IllegalArgumentException("Command \"acquire\" should have 2 args");
	}

	if (!Person::isValid(args[0])) {
		throw IllegalArgumentException("Person id string is not valid");
	}
	if (!Registration::isValid(args[1])) {
		throw IllegalArgumentException("Registration string is not valid");
	}

	const unsigned int ownerId = std::stoi(args[0]);
	const Registration vehicleId(args[1].c_str());

	doAcquire(ownerId, vehicleId);

	if (verbose) {
		std::cout << "Person with id " << ownerId << " acquired vehicle with id " << vehicleId << std::endl;
	}
}

void Database::processCommandRelease(const std::vector<std::string> & args, bool verbose) {
	if (args.size() != 2) {
		throw IllegalArgumentException("Command \"release\" should have 2 args");
	}

	const unsigned int ownerId = std::stoi(args[0]);
	const Registration vehicleId(args[1].c_str());

	doRelease(ownerId, vehicleId);

	if (verbose) {
		std::cout << "Person with id " << ownerId << " released vehicle with id " << vehicleId << std::endl;
	}
}

void Database::processCommandRemove(const std::vector<std::string> & args, bool verbose) {
	if (args.size() != 1) {
		throw IllegalArgumentException("Command \"remove\" should have 1 arg");
	}

	const std::string & someId = args[0];

	if (Registration::isValid(someId)) {
		const Registration reg(someId.c_str());
		const Vehicle * v = getVehicle(reg);

		if (v == nullptr) {
			throw IllegalArgumentException("Vehicle with specified id could not be found");
		}

		if (v->getOwner() != nullptr) {
			bool userInput;
			std::cout << "This vehicle has an owner, are you sure you want to remove? Enter 0 for no, 1 for yes ";
			std::cin >> userInput;
			std::cin.ignore(); // Ignore the enter

			if (!userInput) {
				if (verbose) {
					std::cout << "Did not remove vehicle with id " << reg << std::endl;
				}
				return;
			}
		}

		removeVehicle(reg);
		if (verbose) {
			std::cout << "Removed vehicle with id " << reg << std::endl;
		}
	}
	else if (Person::isValid(someId)) {
		const unsigned int id = std::stoi(someId);
		const Person * p = getPerson(id);

		if (p == nullptr) {
			throw IllegalArgumentException("Person with specified id could not be found");
		}

		if (!p->getVehicles().empty()) {
			bool userInput;
			std::cout << "This person has vehicles, are you sure you want to remove? Enter 0 for no, 1 for yes ";
			std::cin >> userInput;
			std::cin.ignore(); // Ignore the enter

			if (!userInput) {
				if (verbose) {
					std::cout << "Did not remove person with id " << id << std::endl;
				}
				return;
			}
		}

		removePerson(id);
		if (verbose) {
			std::cout << "Removed person with id " << id << std::endl;
		}
	}
	else {
		throw IllegalArgumentException("Could not resolve argument as either possible registration or person id");
	}
}

void Database::processCommandSave(const std::vector<std::string> & args, bool verbose) const {
	if (args.size() != 1) {
		throw IllegalArgumentException("Command \"save\" should have 1 arg");
	}

	save(args[0].c_str());

	if (verbose) {
		std::cout << "Saved database to path " << args[0].c_str() << std::endl;
	}
}

void Database::processCommandShow(const std::vector<std::string> & args, bool verbose) {
	if (args.size() != 1) {
		throw IllegalArgumentException("Command \"show\" should have 1 arg");
	}
	std::string arg = args[0];
	std::string lowerCaseArg = StringUtil::toLowerCase(arg);

	if (lowerCaseArg == "people") {
		std::cout << '[';
		printPeople();
		std::cout << ']' << std::endl;
	}
	else if (lowerCaseArg == "vehicles") {
		std::cout << '[';
		printVehicles();
		std::cout << ']' << std::endl;
	}
	else {
		if (Registration::isValid(arg)) {
			const Registration reg(arg.c_str());
			const Vehicle * v = getVehicle(reg);

			if (v == nullptr) {
				throw IllegalArgumentException("Could not find vehicle");
			}
			else {
				std::cout << "vehicle: " << *v << std::endl << "owner: ";
				if (v->getOwner() == nullptr) {
					std::cout << "none" << std::endl;
				}
				else {
					std::cout << *v->getOwner() << std::endl;
				}
			}
		}
		else if (Person::isValid(arg)) {
			const unsigned int id = std::stoi(arg);
			const Person * p = getPerson(id);

			if (p == nullptr) {
				throw IllegalArgumentException("Could not find person");
			}
			else {
				std::cout << "person: " << *p << std::endl << "vehicles: ";
				std::cout << "[";
				bool first = true;
				for (const Vehicle * v : p->getVehicles()) {
					if (first) {
						first = false;
						std::cout << *v;
					}
					else {
						std::cout << ", " << *v;
					}
				}
				std::cout << "]" << std::endl;
			}
		}
		else {
			throw IllegalArgumentException("Could not resolve argument as either possible registration or person id");
		}
	}
}

void Database::processCommandLoad(const std::vector<std::string> & args, bool verbose) {
	if (args.size() != 1) {
		throw IllegalArgumentException("Command \"load\" should have 1 arg");
	}
	Database db = load(args[0].c_str());
	*this = db;

	if (verbose) {
		std::cout << "Loaded database from file " << args[0] << std::endl;
	}
}

std::string Database::toCommandString() const {
	std::vector<std::string> commands;
	for (const Person & p : people) {
		std::string cmd;
		cmd += "person ";
		cmd += '"' + p.getName() + '"';
		cmd += " ";
		cmd += std::to_string(p.getId());
		commands.push_back(cmd);
	}
	for (const Vehicle & v : vehicles) {
		std::string cmd;
		cmd += "vehicle ";
		cmd += v.getReg().getId();
		cmd += " ";
		cmd += '"' + v.getDesc() + '"';
		commands.push_back(cmd);
	}
	for (const Vehicle & v : vehicles) {
		if (v.getOwner() == nullptr) {
			continue;
		}
//		std::cout << "DEBUG " << v.getOwner() << " " << v.getOwner()->getId() << std::endl;
		std::string cmd;
		cmd += "acquire ";
		cmd += std::to_string(v.getOwner()->getId());
		cmd += " ";
		cmd += v.getReg().getId();
		commands.push_back(cmd);
	}

	std::string s;
	const std::size_t size = commands.size();
	for (std::size_t i = 0; i < size; i++) {
		s += commands[i] + COMMAND_SEPARATOR;
	}
	return s;
}

Database Database::fromCommandString(const std::string & s) {
	Database db;

	std::string buffer;
	const std::size_t size = s.size();
	for (std::size_t i = 0; i < size; i++) {
		if (s[i] == COMMAND_SEPARATOR) {
			Command c(buffer);

			db.processCommand(c);
			buffer = "";
		}
		else {
			buffer += s[i];
		}
	}

	return db;
}

void Database::addPerson(const Person & p) {
	if (getPerson(p.getId()) != nullptr) {
		throw IllegalArgumentException("Person with same id already exists");
	}
	people.push_back(p);
}

void Database::addVehicle(const Vehicle & v) {
	if (getVehicle(v.getReg()) != nullptr) {
		throw IllegalArgumentException("Vehicle with same registration already exists");
	}
	vehicles.push_back(v);
}

void Database::doAcquire(unsigned int id, const Registration & reg) {
	Person * p = getPerson(id);
	Vehicle * v = getVehicle(reg);

	if (p == nullptr) {
		throw IllegalArgumentException("Person not found");
	}
	if (v == nullptr) {
		throw IllegalArgumentException("Vehicle not found");
	}

	if (v->getOwner() != nullptr) {
		if (v->getOwner()->getId() == p->getId()) {
			throw IllegalArgumentException("Same owner already has this vehicle");
		}
//		throw IllegalArgumentException("Different owner already has this vehicle");
	}

	p->addVehicle(v);

}

void Database::doRelease(unsigned int id, const Registration & reg) {
	Vehicle * v = getVehicle(reg);
	Person * p = getPerson(id);

	if (v == nullptr) {
		throw IllegalArgumentException("Vehicle not found");
	}
	if (p == nullptr) {
		throw IllegalArgumentException("Person not found");
	}

	const Vehicle * checkedVehicle = p->getVehicle(reg);
	const Person * checkedOwner = v->getOwner();

	if (checkedVehicle == nullptr) {
		throw IllegalArgumentException("Vehicle is nullptr");
	}
	if (checkedOwner == nullptr) {
		throw IllegalArgumentException("Owner is nullptr");
	}

	bool vehiclesMatch = (*checkedVehicle == *v);
	bool ownersMatch = (*checkedOwner == *p);

	if (!vehiclesMatch) {
		throw IllegalArgumentException("Vehicle does not match");
	}
	if (!ownersMatch) {
		throw IllegalArgumentException("Owner does not match");
	}

	p->removeVehicle(reg);
}

void Database::removePerson(unsigned int id) {
	std::size_t size = people.size();
	std::size_t index = getPersonIndex(id); // throws

	people[index].clearVehicles();

	std::swap(people[index], people[size - 1]);
	people.pop_back();
}

void Database::removeVehicle(const Registration & reg) {
	std::size_t size = vehicles.size();
	std::size_t index = getVehicleIndex(reg); // throws

	Person * owner = vehicles[index].owner;
	if (owner == nullptr) {
		throw IllegalArgumentException("Owner is nullptr");
	}
	owner->removeVehicle(reg);

	std::swap(vehicles[index], vehicles[size - 1]);
	vehicles.pop_back();
}

void Database::save(const char * path) const {
	std::ofstream out;
	out.open(path);
	if (!out) {
		throw IllegalArgumentException("File could not be opened");
	}

	std::string cmds = toCommandString();
	out << cmds;
	out.close();
}

void Database::processCommand(const Command & c, bool verbose) {
	const std::string & cmd = c.getCommand();
	const std::vector<std::string> & args = c.getArgs();

//	std::cout << cmd << std::endl;

	if (cmd == "vehicle") {
		processCommandVehicle(args, verbose);
	}
	else if (cmd == "person") {
		processCommandPerson(args, verbose);
	}
	else if (cmd == "acquire") {
		processCommandAcquire(args, verbose);
	}
	else if (cmd == "release") {
		processCommandRelease(args, verbose);
	}
	else if (cmd == "remove") {
		processCommandRemove(args, verbose);
	}
	else if (cmd == "save") {
		processCommandSave(args, verbose);
	}
	else if (cmd == "show") {
		processCommandShow(args, verbose);
	}
	else if (cmd == "load") {
		processCommandLoad(args, verbose);
	}
	// Others may exist
	else {
		throw IllegalArgumentException("Unknown command \"" + cmd + "\"");
	}
}

std::ostream & operator<<(std::ostream & out, const Database & db) {
	out << "{people: [";
	bool b = true;
	for (const Person & p : db.people) {
		if (!b) {
			out << ", ";
		}
		b = false;
		out << p;
	}
	out << "], vehicles: [";
	b = true;
	for (const Vehicle & v : db.vehicles) {
		if (!b) {
			out << ", ";
		}
		b = false;
		out << v;
	}
	out << "]}";
	return out;
}

Database Database::load(const char * path) {
	std::ifstream in;
	in.open(path);
	if (!in) {
		throw IllegalArgumentException("Could not open file");
	}

	std::string cmds;
	while (!in.eof()) {
		char c = in.get();
		cmds += c;
	}

	in.close();
//	std::cerr << cmds << std::endl;
	return Database::fromCommandString(cmds);
}
