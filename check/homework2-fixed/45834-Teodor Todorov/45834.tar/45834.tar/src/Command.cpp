#include "../include/Command.h"
#include "../include/StringUtil.h"

Command::Command(const std::string & toParse) {
	std::string buffer;
	const std::size_t size = toParse.size();

	std::size_t i;
	for (i = 0; i < size; i++) {
		if (toParse[i] == ' ') {
			i++;
			cmd = buffer;
			buffer = "";
			break;
		}
		buffer += toParse[i];
	}

	bool ignoreWhitespace = false;
	for (; i < size; i++) {
		if (toParse[i] == '"') {
			ignoreWhitespace = !ignoreWhitespace;
			continue;
		}
		else if (!ignoreWhitespace && toParse[i] == ' ') {
			args.push_back(buffer);
			buffer = "";
			continue;
		}
		buffer += toParse[i];
	}

	if (cmd.empty()) {
		cmd = StringUtil::toLowerCase(buffer);
	}
	else if (!buffer.empty()) {
		args.push_back(buffer);
	}

	cmd = StringUtil::toLowerCase(cmd);
}

const std::string & Command::getCommand() const {
	return cmd;
}

const std::vector<std::string> & Command::getArgs() const {
	return args;
}
