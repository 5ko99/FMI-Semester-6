#include <iostream>

#include "../include/Vehicle.h"
#include "../include/exception/IllegalArgumentException.h"
#include "../include/exception/IllegalStateException.h"

Vehicle::Vehicle(const Registration & reg, const std::string & desc) {
	this->reg = reg;
	this->desc = desc;
	this->owner = nullptr;

//	std::cout << "New vehicle " << getReg() << " " << getOwner() << " " << this << std::endl;
}

Vehicle::Vehicle(const Vehicle & other) {
	*this = other;
}

Vehicle & Vehicle::operator=(const Vehicle & other) {
	if (*this == other) {
		return *this;
	}

	this->reg = other.reg;
	this->desc = other.desc;
	this->owner = other.owner;

	if (this->owner != nullptr) {
		for (std::size_t i = 0; i < this->owner->vehicles.size(); i++) {
			if (this->owner->vehicles[i] == &other) {
				this->owner->vehicles[i] = this;
			}
		}
	}

	return *this;
}

Vehicle::Vehicle(Vehicle && other) noexcept {
	*this = std::move(other);
}

Vehicle & Vehicle::operator=(Vehicle && other) noexcept {
	if (*this == other) {
		return *this;
	}

	this->reg = other.reg;
	this->desc = other.desc;
	this->owner = other.owner;

	if (this->owner != nullptr) {
		for (std::size_t i = 0; i < this->owner->vehicles.size(); i++) {
			if (this->owner->vehicles[i] == &other) {
				this->owner->vehicles[i] = this;
			}
		}
	}

	return *this;
}

const Registration & Vehicle::getReg() const {
	return reg;
}

const std::string & Vehicle::getDesc() const {
	return desc;
}

const Person * Vehicle::getOwner() const {
	return owner;
}

std::ostream & operator<<(std::ostream & out, const Vehicle & v) {
	out << "{reg: \"" << v.getReg() << "\", desc: \"" << v.getDesc() << "\"}";
	return out;
}

bool Vehicle::operator==(const Vehicle & v) noexcept {
	return this->reg == v.reg && this->desc == v.desc;
}

bool Vehicle::operator==(const Vehicle & v) const noexcept {
	return this->reg == v.reg && this->desc == v.desc;
}
