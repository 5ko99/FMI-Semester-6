#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "Registration.test.cpp"
#include "Person.test.cpp"
#include "Vehicle.test.cpp"
#include "StringUtil.test.cpp"
#include "Command.test.cpp"