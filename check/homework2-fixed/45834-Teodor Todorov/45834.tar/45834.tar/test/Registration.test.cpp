#include "doctest.h"

#include <cstring>
#include "../include/Registration.h"

TEST_CASE("Registration_Constructor_GoodParamsLength7_GoodArray") {
	// Arrange
	char chars[] = "A1234AA";

	// Act
	Registration registration(chars);

	// Assert
	int result = strcmp(chars, registration.getId());
	REQUIRE(0 == result);
}

TEST_CASE("Registration_Constructor_GoodParamsLength8_GoodArray") {
	// Arrange
	char chars[] = "AA1234AA";

	// Act
	Registration registration(chars);

	// Assert
	int result = strcmp(chars, registration.getId());
	REQUIRE(0 == result);
}

TEST_CASE("Registration_Constructor_NullptrPassed_ExceptionThrown") {
    // Arrange
	char * chars = nullptr;

    // Act and Assert
    REQUIRE_THROWS(Registration(chars));
}

TEST_CASE("Registration_Constructor_InvalidLength1_ExceptionThrown") {
	// Arrange
	char chars[] = "AA1234AAA";

	// Act and Assert
	REQUIRE_THROWS(Registration(chars));
}

TEST_CASE("Registration_Constructor_InvalidLength2_ExceptionThrown") {
	// Arrange
	char chars[] = "AA1234";

	// Act and Assert
	REQUIRE_THROWS(Registration(chars));
}

TEST_CASE("Registration_Constructor_EmptyString_ExceptionThrown") {
	// Arrange
	char chars[] = "";

	// Act and Assert
	REQUIRE_THROWS(Registration(chars));
}

TEST_CASE("Registration_Constructor_InvalidFormat1_ExceptionThrown") {
	// Arrange
	char chars[] = "AAA123AA";

	// Act and Assert
	REQUIRE_THROWS(Registration(chars));
}