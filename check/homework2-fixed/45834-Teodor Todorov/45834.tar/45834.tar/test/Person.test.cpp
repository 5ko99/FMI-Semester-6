#include <string>
#include "doctest.h"
#include "../include/Person.h"

TEST_CASE("Person_Constructor_GoodParams_GoodGetters") {
	// Arrange
	unsigned int id = 0;
	std::string name = "asd";

	// Act
	Person p(id, name);

	// Assert
	REQUIRE(id == p.getId());
	REQUIRE(name == p.getName());
	REQUIRE(0 == p.getVehicles().size());
}

TEST_CASE("Person_addVehicle(Vehicle * v)_GoodParam_VehicleAdded") {
	// Arrange
	unsigned int id = 0;
	std::string name = "ASd";

	Registration reg = Registration("A1234AA");
	std::string desc = "Mercedes SLS AMG";

	Person p(id, name);
	Vehicle v(reg, desc);

	// Act
	p.addVehicle(&v);

	// Assert
	REQUIRE(1 == p.getVehicles().size());
	REQUIRE(v == *p.getVehicles()[0]);
}

TEST_CASE("Person_addVehicle(Vehicle * v)_NullptrPassed_Throws") {
	// Arrange
	unsigned int id = 0;
	std::string name = "ASd";

	Person p(id, name);

	// Act and Assert
	REQUIRE_THROWS(p.addVehicle(nullptr));
}
