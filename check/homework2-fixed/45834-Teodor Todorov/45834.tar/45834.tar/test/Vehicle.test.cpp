#include "doctest.h"
#include "../include/Vehicle.h"

TEST_CASE("Vehicle_Constructor_GoodParamsShortReg_GoodGetters") {
    // Arrange
    Registration reg = Registration("A1234AA");
	std::string desc = "Mercedes SLS AMG";

    // Act
	Vehicle v(reg, desc);

    // Assert
	REQUIRE(nullptr == v.getOwner());
	REQUIRE(reg == v.getReg());
	REQUIRE(desc == v.getDesc());
}

TEST_CASE("Vehicle_Constructor_GoodParamsLongReg_GoodGetters") {
	// Arrange
	Registration reg = Registration("AA1234AA");
	std::string desc = "Mercedes SLS AMG";

	// Act
	Vehicle v(reg, desc);

	// Assert
	REQUIRE(nullptr == v.getOwner());
	REQUIRE(reg == v.getReg());
	REQUIRE(desc == v.getDesc());
}

TEST_CASE("Vehicle_operator==_TwoEqualVehicles_IsTrue") {
	// Arrange
	Registration reg = Registration("AA1234AA");
	std::string desc = "Mercedes SLS AMG";

	Vehicle v(reg, desc);

	// Act
	bool result = v == v;

	// Assert
	REQUIRE(true == result);
}

TEST_CASE("Vehicle_operator==_TwoEqualVehicles_IsTrue") {
    // Arrange
	Registration reg = Registration("AA1234AA");
	std::string desc = "Mercedes SLS AMG";

    Vehicle v1(reg, desc);
	Vehicle v2(reg, desc);

    // Act
    bool result = v1 == v2;

    // Assert
	REQUIRE(true == result);
}

TEST_CASE("Vehicle_operator==_DifferentRegistrations_IsFalse") {
	// Arrange
	Registration reg1 = Registration("AA1234AA");
	Registration reg2 = Registration("A1234AA");
	std::string desc = "Mercedes SLS AMG";

	Vehicle v1(reg1, desc);
	Vehicle v2(reg2, desc);

	// Act
	bool result = v1 == v2;

	// Assert
	REQUIRE(false == result);
}

TEST_CASE("Vehicle_operator==_DifferentDescriptions_IsTrue") {
	// Arrange
	Registration reg = Registration("AA1234AA");
	std::string desc1 = "Mercedes SLS AMG";
	std::string desc2 = "Mercedes SLS AMG";

	Vehicle v1(reg, desc1);
	Vehicle v2(reg, desc2);

	// Act
	bool result = v1 == v2;

	// Assert
	REQUIRE(true == result);
}
