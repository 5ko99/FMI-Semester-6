#include "doctest.h"
#include "../include/StringUtil.h"

TEST_CASE("StringUtil_split_UnLimited_FullySplit") {
	// Arrange
	std::string str = "a b c";
	std::string delimiter = " ";

	// Act
	std::vector<std::string> cmds = StringUtil::split(str, delimiter);

	// Assert
	REQUIRE(3 == cmds.size());
	REQUIRE("a" == cmds[0]);
	REQUIRE("b" == cmds[1]);
	REQUIRE("c" == cmds[2]);
}

TEST_CASE("StringUtil_split_Limited_NotFullySplit") {
    // Arrange
    std::string str = "cp, 00, Ivan";
    std::string delimiter = ", ";
    std::size_t limit = 1;

    // Act
	std::vector<std::string> cmds = StringUtil::split(str, delimiter, limit);

    // Assert
	REQUIRE(2 == cmds.size());
	REQUIRE("cp" == cmds[0]);
	REQUIRE("00, Ivan" == cmds[1]);
}

TEST_CASE("StringUtil_split_Limited_FullySplit") {
	// Arrange
	std::string str = "cp 00, Ivan";
	std::string delimiter = ", ";
	std::size_t limit = 1;

	// Act
	std::vector<std::string> cmds = StringUtil::split(str, delimiter, limit);

	// Assert
	REQUIRE(2 == cmds.size());
	REQUIRE("cp 00" == cmds[0]);
	REQUIRE("Ivan" == cmds[1]);
}