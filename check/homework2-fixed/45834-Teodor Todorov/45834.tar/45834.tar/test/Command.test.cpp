#include <string>
#include "doctest.h"
#include "../include/Command.h"

TEST_CASE("Command_Command(const std::string &)_NoArguments_GoodObject") {
	// Arrange
	const std::string cmdString("command");
	const std::string entireCmdString = cmdString;

	// Act
	Command cmd(entireCmdString);

	// Assert
	REQUIRE(cmd.getCommand() == cmdString);
	REQUIRE(cmd.getArgs().size() == 0);
}

TEST_CASE("Command_Command(const std::string &)_1Argument_GoodObject") {
	// Arrange
	const std::string cmdString("command");
	const std::string arg1String("arg1");
	const std::string entireCmdString = cmdString + " " + arg1String;

	// Act
	Command cmd(entireCmdString);

	// Assert
	REQUIRE(cmd.getCommand() == cmdString);
	REQUIRE(cmd.getArgs().size() == 1);
	REQUIRE(cmd.getArgs()[0] == arg1String);
}

TEST_CASE("Command_Command(const std::string &)_2Arguments_GoodObject") {
    // Arrange
    const std::string cmdString("command");
	const std::string arg1String("arg1");
	const std::string arg2String("arg2");
	const std::string entireCmdString = cmdString + " " + arg1String + " " + arg2String;

    // Act
    Command cmd(entireCmdString);

    // Assert
	REQUIRE(cmd.getCommand() == cmdString);
	REQUIRE(cmd.getArgs().size() == 2);
	REQUIRE(cmd.getArgs()[0] == arg1String);
	REQUIRE(cmd.getArgs()[1] == arg2String);
}

TEST_CASE("Command_Command(const std::string &)_2ArgumentsWithQuotes_GoodObject") {
	// Arrange
	const std::string cmdString("command");
	const std::string arg1String("arg1");
	const std::string arg2String("arg 2");
	const std::string entireCmdString = cmdString + " " + arg1String + " " + "\"" + arg2String + "\"";

	// Act
	Command cmd(entireCmdString);

	// Assert
	REQUIRE(cmd.getCommand() == cmdString);
	REQUIRE(cmd.getArgs().size() == 2);
	REQUIRE(cmd.getArgs()[0] == arg1String);
	REQUIRE(cmd.getArgs()[1] == arg2String);
}