# Домашна работа №2
За тестване се използва "doctest", който е доста подобен на "catch2", но е в пъти по-бърз.
https://github.com/onqtam/doctest

Компилатори използвани:
- Linux: gcc 11.1.0
- Linux: clang 11.1.0 с цел x86_64-pc-linux-gnu

Теодор Тодоров / ФН 45834
