
#ifndef OOP_KONTROLNO_2_EDITOR_H
#define OOP_KONTROLNO_2_EDITOR_H

#include <fstream>
class editor {
private:
    std::size_t file_size;
public:
    editor(std::string& file);
    ~editor();
    void open(std::string& file);
    void close(std::ifstream& file);
    std::size_t size();
    void edit(std::size_t offset, std::uint8_t value);
    void display(std::ostream& out, std::size_t offset, std::size_t limit);
};


#endif //OOP_KONTROLNO_2_EDITOR_H
