//
// Created by User on 5/29/2021.
//

#include "command.h"
#include <iostream>
command::command(std::string &str) {
    std::string command="EDIT";
    std::string command2="SHOW";
    std::string push_string="";
    for(int i=0;i<command.size();i++){
        if(str[i]==command[i] && i<command.size()){
            push_string+=command[i];
            if(i==command.size()-1)text.push_back(push_string);
        }else if(str[i]==command2[i] && i<command2.size()){
            push_string+=command2[i];
            if(i==command.size()-1)text.push_back(push_string);
        }

        if(i==command.size()-1){
            push_string.clear();
            str.erase(str.begin(),str.begin()+i+1);
        }
    }



    int iterator=0;
    while(str[iterator]==' '){// 123
        iterator++;           // 123
    }
    while (str[iterator]!=' '){
        push_string+=str[iterator];
        iterator++;

    }
    text.push_back(push_string);
    push_string.clear();


    while(str[iterator]==' '){
        iterator++;
    }

    while (str[iterator]!=' ' || iterator!=str.size()){
        push_string+=str[iterator];
        iterator++;
        if(iterator==str.size())break;
    }
    text.push_back(push_string);

}

std::size_t command::size() {
    return text.size();
}

std::string& command::operator[](std::size_t pos) {
    return text[pos];
}
