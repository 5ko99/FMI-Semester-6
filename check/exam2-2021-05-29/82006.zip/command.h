#ifndef OOP_KONTROLNO_2_COMMAND_H
#define OOP_KONTROLNO_2_COMMAND_H
#include <string>
#include <vector>

class command {
    std::vector<std::string> text;
public:
    command(std::string& str);
    std::size_t size();
    std::string& operator[](std::size_t);
};


#endif //OOP_KONTROLNO_2_COMMAND_H
