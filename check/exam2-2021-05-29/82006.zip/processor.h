
#ifndef OOP_KONTROLNO_2_PROCESSOR_H
#define OOP_KONTROLNO_2_PROCESSOR_H
#include "command.h"

class processor {
public:
    bool is_valid(command& command);
    void execute(command& command);
};


#endif //OOP_KONTROLNO_2_PROCESSOR_H
