//
// Created by User on 5/29/2021.
//

#include "editor.h"

std::size_t editor::size() {
    return this->file_size;
}

editor::editor(std::string &file) {
std::ifstream read(file.c_str(),std::ios::in|std::ios::binary);
if(!read.is_open()){
    throw std::invalid_argument("Wrong file name");
}
read.seekg(0,std::ios::end);
std::size_t size=read.tellg();
this->file_size=size;

}

void editor::open(std::string& file) {
    std::ifstream read(file.c_str(),std::ios::in|std::ios::binary);
    read.seekg(0,std::ios::end);
    std::size_t size=read.tellg();
    this->file_size=size;

}

void editor::close(std::ifstream& file) {
file.close();
}

editor::~editor() {
//file.close
}

void editor::edit(std::size_t offset, std::uint8_t value) {
    std::ofstream file("filename.bin",std::ios::in|std::ios::binary);
    if (offset>file_size)throw std::invalid_argument("value is outside of file bytes");
    file.seekp(0+offset);
    file.write((char*)&value, sizeof(value));
}
