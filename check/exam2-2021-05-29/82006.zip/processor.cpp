//
// Created by User on 5/29/2021.
//

#include "processor.h"
bool is_int(std::string& str){
    /*
    char* endptr=0;
    std::strtod(str.c_str(),&endptr);
    if(*endptr !='\0' || endptr==str)
        return false;
    return true;*/
    for(int i=0;i<str.size();i++){
        if (str[i]<'0' || str[i]>'9')return false;
    }
    return true;
}

bool processor::is_valid(command &command) {
    bool valid=false;
    if(command[0]=="SHOW" || command[0]=="EDIT"){
        valid=true;
    }else valid=false;
    if(is_int(command[1]))valid= true;
    else valid= false;
    if (is_int(command[2]))valid=true;
    else valid=false;
    return valid;

}

void processor::execute(command &command) {
    if(command[0]=="SHOW"){
        //display(editor)
    }
}
