#pragma once
#include"Command.h"

class Processor
{
	bool execute_cmd;
	bool isValid(Command cmd);

public:
	void execute(Command cmd);
};

