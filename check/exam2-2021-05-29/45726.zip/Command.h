#pragma once
#include<string>
#include<iostream>
#include<vector>
using namespace std;

class Command
{
	vector<string> commands;

public:
	Command(string cmd);
	vector<string> separate_str(string command_is);
	size_t size() const;
	string operator[](size_t pos);
};

