#include "Command.h"

Command::Command(string command_is) 
{
	commands = separate_str(command_is);
}

size_t Command::size() const
{
	return commands.size();
}

string Command::operator[](size_t pos)
{
	return commands[pos];
}

vector<string> Command::separate_str(string command_is)
{
	vector<string> sep_cmd;
	size_t current_start = 0;
	for (size_t i = 0; i < command_is.size(); i++)
	{
		if (command_is[i] == ' ')
		{
			sep_cmd.push_back(command_is.substr(current_start, i - current_start));
			i++;
			current_start = current_start + i;
		}
	}

	sep_cmd.push_back(command_is.substr(current_start, command_is.size() - current_start));

	return sep_cmd;
}


