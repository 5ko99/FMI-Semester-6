#include "command.h"

//constructor
Command::Command(std::string commands){
    trim(commands);

}

//public
std::size_t Command::size() const{
    return command.size() - 1;
}
std::string Command::operator[](std::size_t index){
    return command[index];
}


//private
void Command::trim(std::string sentence){
    //Task: разбива низа на отделни низове
    //===================================
    //Notes: Всяка команда се състои от една или повече думи, 
    //разделени помежду си с произволен брой празни (whitespace) символи. 

    
    //
    std::string word = "";
    int index = 0;


    for(int i = 0; i < sentence.size(); i++){

        if(sentence[i] == ' '){
            //сложи думата досега в command
            //command[index++] = word; //проблемно
            command.push_back(word);
            
            word = "";
        } 
        else{
            word = word + sentence[i];
        }
    }
    command.push_back(word);


    

}