#include "processor.h"
#include <exception>

bool Processor::is_valid(Command &com){
    //проверява дали е валидна командата
    //EXIT
    //SIZE
    //EDIT <offset> <byte>
    //SHOW <offset> <limit> 

    if(com.size() == 1){
        if(com[0] == "EXIT") return true;
        if(com[0] == "SIZE") return true;
        return false;
    }
    else if(com.size() == 3){
        if(com[0] == "EDIT") return true;
        if(com[0] == "SHOW") return true;
        return false;
    }
    return false;

}

void Processor::execute(Command &com){
    //note: Класът да не изпълнява командите директно, 
    //нито да работи директно с файла, 
    //а вместо това да работи с обект от класа editor.

    try{

    }catch(std::invalid_argument){
        std::cerr << "invalid argument";
    }

}