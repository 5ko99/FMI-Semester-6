// 
// СУ "Св. Климент Охридски"
// Факултет по математика и информатика
// Курс Обектно-ориентирано програмиране 2020/21
// Контролно 2
// 
// Име: Силвия Петрова
// ФН: 82201
// Специалност: Компютърни науки
// Курс: 1
// Административна група: 3
// Ден, в който се явявате на контролното: 29/5/21
// Начален час на контролното: 9
// Кой компилатор използвате: GCC
//
#include <iostream>
#include <fstream>
#include <cassert>
#include <cstring>
#include <string>
#include <exception>

#include "command.h"
#include "editor.h"
#include "processor.h"

using std::cin;
using std::cout;
using std::endl;

int main()
{



    //1. test for Class command passed :)
    /*
    std::string commands = "helo mr bean";
    Command com(commands);

    cout << "size: " << com.size() << endl;
    cout << "[]: " << com[1]<< endl;
    */

	return 0;
}