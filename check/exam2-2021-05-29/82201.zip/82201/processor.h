#pragma once
#include "command.h"
#include "editor.h"

//TODO Класът трябва да прихваща възможни изключения хвърлени от editor и когато е нужно да извежда съобщение за грешка.
class Processor{

public:
    //предикат is_valid, връща true или false, в зависимост дали командата е коректна или в нея има грешка.
    bool is_valid(Command &com);

    //получава команда и я изпълнява.
    void execute(Command &com);

    //изпълнява файл
    //void executeEditor(Editor &edi);


private:


};