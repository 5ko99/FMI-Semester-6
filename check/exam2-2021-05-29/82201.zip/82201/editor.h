#pragma once
#include <string>
#include <fstream>
#include <exception>
#include <cassert>
#include <ostream>

//ноте // Функциите на класа, чрез които се работи с файл, могат да работят само ако има успешно отворен файл.

class Editor{

public:
    //конструктор, който получава път до файл и го отваря
     //Файлът да се отваря в двоичен режим
    Editor(std::string file);
    //и да се държи отворен до извикване на close или до унищожаване на обекта от тип editor.
    ~Editor();

    void open(); //отваря файл
    void close(); //затваря файл

    std::size_t size(); // връща размера на файла

    void edit(std::size_t offset, std::uint8_t value); // записва стойността value на позиция offset спрямо началото на файла.
    void display(std::ostream& out, std::size_t offset, std::size_t limit);

private:

    std::ifstream file;
    std::size_t sizeFile;


};

