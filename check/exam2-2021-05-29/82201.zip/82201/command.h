#pragma once
#include <string>
#include <vector>

#include <iostream>

// Class: Command
// ===============
// input a string of commands
// splits commands into command name and arguments
class Command{

public:

    //конструктор, в който да получава символен низ -- текстът на командата.
    Command(std::string commands);

    //връща броя на аргументите.
    std::size_t size() const;
    //извличат частите на командата. Операторът ще получава стойност от тип std::size_t. Тази стойност указва индекса на дума в командата (т.е. 0 - името на командата, 1 - първият ѝ аргумент и т.н.).
    std::string operator[](std::size_t index);

private:
    std::vector<std::string> command;

    //Вътрешно разбиите низа на части -- името на командата и нейните аргументи.
    void trim(std::string commands);

};

