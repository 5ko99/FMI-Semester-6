#include "editor.h"

Editor::Editor(std::string file){
    this->file.open(file,std::ios::in | std::ios_base::binary);
    //TODO size
}
    
Editor::~Editor(){
    file.close();
}

void Editor::open(){
    //отваря файл
    file.open("textFile.txt",std::ios::in | std::ios_base::binary );
    if(!file)
    {
        throw std::invalid_argument("file did not open");
    }
    sizeFile = 0;
} 

void Editor::close(){
    file.close();
} 

std::size_t Editor::size(){
    return sizeFile;
}

//
void Editor::edit(std::size_t offset, std::uint8_t value){
/*
Записва стойността value на позиция offset спрямо началото на файла. 
*/
    if(offset > size()){
        throw std::invalid_argument("offset out of file");
    }



}

void Editor::display(std::ostream& out, std::size_t offset, std::size_t limit){
/*
Извежда, на потока <out>, подобно на шестнадесетичен редактор, 
съдържанието на файла, започвайки от позиция <offset>. 
Извежданато да приключи или когато се изведат точно <limit> на брой байта, 
или се достигне краят на файла. 
*/
    if(offset > size()){
        throw std::invalid_argument("offset out of file");
    }

    for(size_t i = 0; i < limit; i++){
        if(offset + i > size()) break;
        //out << seekp(offset + i);
    }
}