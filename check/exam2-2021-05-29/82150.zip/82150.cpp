//
// СУ "Св. Климент Охридски"
// Факултет по математика и информатика
// Курс Обектно-ориентирано програмиране 2020/21
// Контролно 2
//
// Име: Петър Георгиев Петров
// ФН: 82150
// Специалност: Компютърни науки
// Курс: 1
// Административна група: 2
// Ден, в който се явявате на контролното:  29.05.2021
// Начален час на контролното: 9:00
// Кой компилатор използвате: clang
//

#include <cassert>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include "editor.h"
#include "command.h"
#include "processor.h"

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "Incorrect count of arguments!" << std::endl;
        std::cout << "The program accepts one argument for the file path to load from." << std::endl;
        return 1;
    } else {
        try {
            std::fstream file(argv[1]);
        } catch (std::fstream::failure& error) {
            std::cerr << "Problem opening file: ";
            std::cerr << error.what() << std::endl;
        }
    }

    editor edit(argv[1]);
    processor process(edit);
    std::string line;
    std::cout << "> ";
    std::getline(std::cin, line);

    while (std::cin) {
        command curr_command(line);
        process.execute(curr_command);

        std::cout << "> ";
        std::getline(std::cin, line);
    }
}
