//
// Created by pgpetrov on 29.05.21 г..
//

#ifndef OOP_KONTROLNO2_PROCESSOR_H
#define OOP_KONTROLNO2_PROCESSOR_H


#include <istream>
#include "command.h"
#include "editor.h"

class processor {
public:
    processor(editor&);
    static bool is_valid(const command& cmd);
    void execute(const command& cmd);

private:
    editor& edit;
};


#endif //OOP_KONTROLNO2_PROCESSOR_H
