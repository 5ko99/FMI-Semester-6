//
// Created by pgpetrov on 29.05.21 г..
//

#include <iostream>
#include "processor.h"

bool processor::is_valid(const command &cmd) {
    if (cmd[0] == "EXIT" || cmd[0] == "SIZE") {
        if (cmd.size() == 0) {
            return true;
        }
    } else if (cmd[0] == "EDIT" || cmd[0] == "SHOW") {
        if (cmd.size() == 2) {
            try {
                std::stoul(cmd[1]);
                std::stoul(cmd[2]);
                return true;
            } catch (std::exception& error) {}
        }
    }
    return false;
}

void processor::execute(const command &cmd) {
    if (processor::is_valid(cmd)) {
        if (cmd[0] == "EXIT") {
            exit(0);
        } else if (cmd[0] == "SIZE") {
            std::cout << edit.size() << std::endl;
        } else if (cmd[0] == "EDIT") {
            try {
                edit.edit(std::stoul(cmd[1]), std::stoul(cmd[2]));
                std::cout << "OK" << std::endl;
            } catch (std::invalid_argument& error) {
                std::cerr << "ERROR: ";
                std::cerr << error.what() << std::endl;
            }
        } else if (cmd[0] == "SHOW") {
            try {
                edit.display(std::cout, std::stoul(cmd[1]), std::stoul(cmd[2]));
            } catch (std::invalid_argument& error) {
                std::cerr << "ERROR: ";
                std::cerr << error.what() << std::endl;
            }
        }
    } else {
        std::cerr << "ERROR: ";
        std::cerr << "Command is invalid, try again!" << std::endl;
    }
}

processor::processor(editor &edit) : edit(edit) {}
