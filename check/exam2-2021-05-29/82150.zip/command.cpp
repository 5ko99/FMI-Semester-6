//
// Created by pgpetrov on 29.05.21 г..
//

#include <sstream>
#include "command.h"

command::command(const std::string &str) {
    std::istringstream ss(str);

    std::string cmd;
    ss >> cmd;
    this->cmd = cmd;

    std::string arg;
    while (ss >> arg) {
        arguments.push_back(arg);
    }
}

std::size_t command::size() const {
    return arguments.size();
}

std::string command::operator[](std::size_t idx) const {
    if (idx == 0) {
        return cmd;
    }
    return arguments[idx-1];
}
