//
// Created by pgpetrov on 29.05.21 г..
//

#ifndef OOP_KONTROLNO2_COMMAND_H
#define OOP_KONTROLNO2_COMMAND_H


#include <string>
#include <vector>

class command {
public:
    command(const std::string&);
    std::size_t size() const;
    std::string operator[](std::size_t) const;
private:
    std::string cmd;
    std::vector<std::string> arguments;
};


#endif //OOP_KONTROLNO2_COMMAND_H
