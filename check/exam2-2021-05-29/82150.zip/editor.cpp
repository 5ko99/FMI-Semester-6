//
// Created by pgpetrov on 29.05.21 г..
//

#include <iomanip>
#include "editor.h"

editor::editor(const std::string &file_path) : file(file_path, std::fstream::binary) {
    file_size = 0;
}

void editor::close() {
    file.close();
}

void editor::open(const std::string &file_path) {
    file = std::fstream(file_path);
}

std::size_t editor::size() const {
    return file_size;
}

void editor::edit(std::size_t offset, std::uint8_t value) {
    if (offset >= size()) {
        //throw std::invalid_argument("Too large offset, file size is " + std::to_string(size()));
    }
    file.seekg(offset);
    char to_write = static_cast<char>(value);
    file.write(&to_write, 1);
}

void editor::display(std::ostream &out, std::size_t offset, std::size_t limit) {
    if (offset >= size()) {
        //throw std::invalid_argument("Too large offset, file size is " + std::to_string(size()));
    }
    std::size_t end_offset = offset+limit;
    for (; offset < end_offset; offset += 16) {
        out << std::setfill('0') << std::setw(8) << std::hex << offset << " ";

        char bytes[16];
        std::size_t count = std::min((std::size_t)16, end_offset-offset);
        file.seekg(offset);
        file.read(bytes, count);
        for (std::size_t b = 0; b < count; ++b) {
            out << std::setfill('0') << std::setw(2) << std::hex << (unsigned int)(unsigned char)bytes[b] << " ";
        }
        out << std::endl;
    }
}
