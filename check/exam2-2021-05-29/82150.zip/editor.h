//
// Created by pgpetrov on 29.05.21 г..
//

#ifndef OOP_KONTROLNO2_EDITOR_H
#define OOP_KONTROLNO2_EDITOR_H


#include <string>
#include <fstream>

class editor {
public:
    explicit editor(const std::string& file_path);
    void open(const std::string& file_path);
    void close();
    std::size_t size() const;
    void edit(std::size_t offset, std::uint8_t value);
    void display(std::ostream& out, std::size_t offset, std::size_t limit);

private:
    std::size_t file_size;
    std::fstream file;
    // no need for explicit call to file.close(), implictly defined destructor already does it
};


#endif //OOP_KONTROLNO2_EDITOR_H
