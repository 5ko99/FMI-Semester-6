#pragma once
#include <fstream>
#include <string>

class Editor {

private:
    std::fstream file;
    size_t fileSize;

public:
    Editor (const std::string& path);
    ~Editor (); //closes the file

    void open (const std::string& path);
    void close ();
    size_t size() const;
    void edit(std::size_t offset, std::uint8_t value);
    void display(std::ostream& out, std::size_t offset, std::size_t limit);

};