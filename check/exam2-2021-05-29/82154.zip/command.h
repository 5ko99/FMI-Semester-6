#pragma once
#include <string>
#include <vector>

class Command {

private:
    std::vector <std::string> cmd_parts;

public:
    Command (const std::string& cmd);
    size_t size() const;
    std::string operator[] (size_t pos) const;

private:
    void separateArgs(const std::string& cmd);

};