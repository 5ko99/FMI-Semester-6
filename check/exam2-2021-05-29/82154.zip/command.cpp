#include "command.h"
#include <iostream>


Command::Command (const std::string& cmd)
{
    separateArgs(cmd);
}

size_t Command::size() const
{
    return cmd_parts.size() - 1; //should return number of args, not all parts of the command
}


std::string Command::operator[] (size_t pos) const
{
    if (pos >= cmd_parts.size()){
        throw std::out_of_range("Unexisting cmd part!");
    }
    return cmd_parts[pos];
}


void Command::separateArgs(const std::string& cmd)
{
    for (size_t i=0; i<cmd.size(); ++i){
        
        while (cmd[i] == ' ' && i<cmd.size()){
            ++i;
        }

        std::string part;
        while (cmd[i] != ' ' && i<cmd.size()){
            part.push_back(cmd[i]);
            ++i;            
        }
        cmd_parts.push_back(part);
    
    }
}