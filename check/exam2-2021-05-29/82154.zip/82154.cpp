// 
// СУ "Св. Климент Охридски"
// Факултет по математика и информатика
// Курс Обектно-ориентирано програмиране 2020/21
// Контролно 2
// 
// Име: Радослав Иванов
// ФН: 82154
// Специалност: КН
// Курс: 1
// Административна група: 2
// Ден, в който се явявате на контролното: 29.05.2021 
// Начален час на контролното: 9:00
// Кой компилатор използвате: GCC
//

#include <cassert>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>

#include "processor.h"

int main(int argc, char* argv[])
{
	if (argc != 2){
		std::cerr << "Invalid number of arguments!" << std::endl;
		return 1;
	}

	try {
		Processor p(argv[1]);
	
	while (true){
		std::string cmd;
		getline (std::cin, cmd);
		try {
			p.execute(cmd);
		} catch (std::out_of_range e){
			return 0;
		} catch (const std::exception e){
			std::cerr << e.what() << std::endl;
		}
	}

	} catch (std::exception& e){
		std::cerr << e.what() << std::endl;
		return 1;
	}


	return 0;
}