#include "editor.h"
#include <iostream>
#include <iomanip>

Editor::Editor (const std::string& path)
{
    open(path);
    file.seekp(0, std::ios::end);
    fileSize = (size_t) file.tellp();
}


Editor::~Editor ()
{
    close();
}


void Editor::open (const std::string& path)
{
    file.open(path, std::ios::binary | std::ios::in | std::ios::out);
    if (!file.is_open()){
        throw std::runtime_error("Error opening file");
    }
}


void Editor::close ()
{
    file.close();
    fileSize = 0;
}


size_t Editor::size() const
{
    return fileSize;
}

void Editor::edit(std::size_t offset, std::uint8_t value)
{
    if (offset >= fileSize)
        throw std::invalid_argument("ERROR: Out of file range!");
    
    file.seekp(offset, std::ios::beg);
    char x[1];
    x[0] = value;
    file.write(x, sizeof(uint8_t));
}

void Editor::display(std::ostream& out, std::size_t offset, std::size_t limit)
{
    if (offset >= fileSize)
        throw std::invalid_argument("ERROR: Out of file range!");

    file.seekg(offset, std::ios::beg);
    size_t read = offset;
    size_t alreadyRead = 0;
    while (read < fileSize && alreadyRead < limit){
        char value[1];
        file.read(value, sizeof(char));
        out << std::setfill('0') << std::setw(2) << std::hex << value[0];
        ++read;
        ++alreadyRead;
    }
}