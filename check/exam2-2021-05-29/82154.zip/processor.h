#pragma once
#include "command.h"
#include "editor.h"

class Processor {

private:
    Editor editor;

public:
    Processor (const std::string& path);
    bool is_valid (const Command& cmd);
    void execute (const Command& cmd);

};