#include "processor.h"
#include <iostream>


Processor::Processor (const std::string& path) : editor(path){}


bool Processor::is_valid (const Command& cmd)
{
    if (cmd.size() == 0 || cmd.size() > 2)
        return false;
    
    if (cmd.size() == 1 && cmd[0] != "EXIT" && cmd[0] != "SIZE")
        return false;
    else if (cmd.size() == 1)
        return true;

    //if the count of cmd parts is 2
    if (cmd[0] != "SHOW" && cmd[0] != "EDIT")
        return false;

    //check if the first arg is really a size_t
    try {
        size_t offset = stoi(cmd[1]);
    } catch (const std::exception& e){
        return false;
    }

    if (cmd[0] == "EDIT" && sizeof(cmd[2]) != sizeof(uint8_t))
        return false;
    else if (cmd[0] == "EDIT")
        return true;

    //cmd[0] == "SHOW" for sure
    try {
        size_t limit = stoi(cmd[2]);
    } catch (const std::exception& e){
        return false;
    }

    return true;
}


void Processor::execute (const Command& cmd)
{
    //these exceptions gotta be catched in main
    if (!is_valid(cmd))
        throw std::invalid_argument("Invalid command");

    if (cmd[0] == "EXIT")
        throw std::out_of_range("Exiting the program");
    
    else if (cmd[0] == "SIZE"){
        std::cout << editor.size() << std::endl;
    }

    else if (cmd[0] == "SHOW"){
        try {
            editor.display(std::cout, stoi(cmd[1]), stoi(cmd[2]));
        } catch (const std::exception& e){
            std::cerr << e.what() << std::endl;
        }
    }

    else if (cmd[0] == "EDIT"){
        try {
            editor.edit(stoi(cmd[1]), stoi(cmd[2]));
            std::cout << "OK\n";
        } catch (const std::exception& e){
            std::cout << "ERROR: File size is: " << editor.size();
            std::cout << "Fail\n";
        }
    }

}