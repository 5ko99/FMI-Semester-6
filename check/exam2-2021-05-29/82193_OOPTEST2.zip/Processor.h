#ifndef PROCESSOR_H
#define PROCESSOR_H
#include"Command.h"
#include"Editor.h"
#include<iostream>

class Processor {
    private:
        Editor editor;
    public:
        Processor();
        bool is_valid(Command command);
        // Executes a command and returns true when everything is OK (Result assertion)
        bool execute(Command command);
};

#endif