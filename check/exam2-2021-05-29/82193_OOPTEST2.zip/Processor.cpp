#include"Processor.h"

Processor::Processor() : editor() {}

bool Processor::is_valid(Command command) {
    if(command.size() < 1) {
        return false;
    }

    return true;
}

bool Processor::execute(Command command) {
    std::string commandText = command.getCommand();
    std::vector<std::string> argumentsText = command.getArguments();

    if(commandText == "EXIT") {
        if(argumentsText.size() != 0 || !is_valid(command)) {
            throw std::exception();
        }

        std::exit(0);
    }
    else if(commandText == "SIZE") {
        if(argumentsText.size() != 0 || !is_valid(command)) {
            throw std::exception();
        }

        std::cout << "The size of the file is " << this->editor.size();
    }
    else if(commandText == "EDIT") {
        if(argumentsText.size() != 2 || !is_valid(command)) {
            throw std::exception();
        }

        editor.edit(std::stoi(argumentsText[0]), std::stoi(argumentsText[1]));
    }
    else if(commandText == "SHOW") {
        if(argumentsText.size() != 2 || !is_valid(command)) {
            throw std::exception();
        }
    }
    else {
        // Throws exception because the given command was not recognized
        throw std::exception();
    }
}