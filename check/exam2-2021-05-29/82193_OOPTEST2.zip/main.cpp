// 
// СУ "Св. Климент Охридски"
// Факултет по математика и информатика
// Курс Обектно-ориентирано програмиране 2020/21
// Контролно 2
// 
// Име: Емил Йорданов Йорданов  
// ФН: 82193
// Специалност: Компютърни науки
// Курс: 1-ви курс
// Административна група: 3-та група
// Ден, в който се явявате на контролното: 29.05.2021
// Начален час на контролното: 9:00
// Кой компилатор използвате: GCC
//

// (Можете да изтриете този коментар след като го прочетете)
// Редът по-долу е специфичен за Visual C++.
// Ако използвате друг компилатор, можете да го изтриете.
// Тъй като strlen, strcmp и т.н. са дефинирани като deprecated,
// имате две възможности:
//
// * да използвате безопасните версии на тези функции
//   (strlen_s, strcmp_s и т.н.). В този случай можете да
//   изтриете дадената по-долу #define директива.
//
// * да дефинирате _CRT_SECURE_NO_WARNINGS преди да
//   включите съответните header файлове от стандартната
//   библиотека.
//
#define _CRT_SECURE_NO_WARNINGS 

#include <cassert>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>

// 'argv' is Arguments' values
// 'argc' is Arguments count - the number of arguments. 1 at least!
int main(int argc, char * argv[])
{
	if(argc > 2) {
		// Too much arguments
		throw std::exception();
	}
	else if(argc == 2) {
		// In this case the user have given a filePath from the start of the program
		std::string filePath = argv[1];
	} 
	else {
		// In this case we just start the program normally
	}

	return 0;
}