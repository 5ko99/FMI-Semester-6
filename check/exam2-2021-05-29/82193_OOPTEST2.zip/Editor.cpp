#include"Editor.h"

Editor::Editor() : filePath(), currentText() {
    this->fileSize = 0;
}

Editor::Editor(std::string filePath) : filePath(filePath), currentText() {
    this->open(this->filePath);
}

void Editor::open(std::string filePath) {
    try {
        if(this->filePath != filePath) {
            this->filePath = filePath;
        }

        std::ifstream iFileStream(filePath);
        iFileStream >> this->currentText;
        this->isFileOpened = true;

        // TODO : Implement seek/tell technique to tell file size
    }
    catch(...) {
        throw std::exception();
    }
}

void Editor::close(std::string filePath) {
    try {
        if(!this->isFileOpened) {
            throw std::exception();
        }

        std::ofstream oFileStream(filePath);
        oFileStream << this->currentText;
        this->isFileOpened = false;
        this->fileSize = 0;
    }
    catch(...) {
        throw std::exception();
    }
}

size_t Editor::size() {
    return this->fileSize;
}

void Editor::edit(std::size_t offset, std::uint8_t value) {
    // TODO : Implement file editing
}

void Editor::display(std::ostream& out, std::size_t offset, std::size_t limit) {
    // TODO : Implement file displaying
}
