#ifndef EDITOR_H
#define EDITOR_H
#include<string>
#include<fstream>

class Editor {
    private:
        std::size_t fileSize;
        std::string filePath;
        std::string currentText;
        bool isFileOpened = false;
    public:
        Editor();
        // Using this constructor ensures that when the Editor.cpp object is instantiated a file with the given path will be opened
        Editor(std::string filePath);
        // Used to open and close files. On an execution problem, an exception is thrown
        void open(std::string filePath);
        void close(std::string filePath);
        // Throws std::invalid_argument when offset is after the file's end
        void edit(std::size_t offset, std::uint8_t value);
        // Throws std::invalid_argument when offset is after the file's end
        void display(std::ostream& out, std::size_t offset, std::size_t limit);
        std::size_t size();
};

#endif