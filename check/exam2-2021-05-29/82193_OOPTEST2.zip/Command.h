#ifndef COMMAND_H
#define COMMAND_H
#include<string>
#include<vector>

class Command {
    private:
        std::string command;
        std::vector<std::string> arguments;
    public:
        Command(std::string commandText);
        // The count of the arguments plus the command - It is arguments.size() + 1
        std::size_t size() const;
        std::string getCommand();
        std::vector<std::string> getArguments();
};

#endif