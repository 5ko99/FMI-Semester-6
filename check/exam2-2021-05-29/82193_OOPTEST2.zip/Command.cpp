#include"Command.h"

std::string getCommandFromText(std::string commandText, char separator = ' ') {
    std::string commandResult = std::string("");

    for (size_t iterator = 0; iterator < commandText.size(); iterator++)
    {
        if(commandText[iterator] == separator) {
            break;
        }

        commandResult += commandText[iterator];
    }

    if(commandResult.size() == 0) {
        throw std::invalid_argument("The given command text is invalid and the command could not be found!");
    }

    return commandResult;
}

std::vector<std::string> getArgumentsFromText(std::string commandText, char separator = ' ') {
    std::vector<std::string> argumentsResult = std::vector<std::string>();
    int argumentsCount = -1;

    for (size_t iterator = 0; iterator < commandText.size(); iterator++)
    {
        std::string currentArgument = std::string("");

        while(commandText[iterator] != separator) {
            currentArgument += commandText[iterator];
            iterator++;
        }

        argumentsCount++;
        if(argumentsCount > 0) {
            argumentsResult.push_back(currentArgument);
        }
    }

    if(argumentsCount <= 0) {
        throw std::invalid_argument("The given command text is invalid and there are no arguments!");
    }

    return argumentsResult;
}

Command::Command(std::string commandText) {
    std::string command = getCommandFromText(commandText);
    std::vector<std::string> arguments = getArgumentsFromText(commandText);

    this->command = command;
    this->arguments = arguments;
}

std::size_t Command::size() const {
    return this->arguments.size() + 1;
}

std::vector<std::string> Command::getArguments() {
    return this->arguments;
}

std::string Command::getCommand() {
    return this->command;
}