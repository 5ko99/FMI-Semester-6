#ifndef TEST2_PROCESSOR_H
#define TEST2_PROCESSOR_H

#include "Command.h"

class Processor{
public:
    bool is_valid(const Command& command) const;
    void execute(const Command& command);
};

#endif //TEST2_PROCESSOR_H
