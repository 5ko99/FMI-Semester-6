#include "Command.h"

Command::Command(const std::string &command) : rawCommand(command) {

}

std::size_t Command::size() const {
    return parsedCommand.size();
}

std::string Command::operator[](std::size_t index) {
    return parsedCommand[index];
}

void Command::parse() {
    std::string token;
    size_t len = rawCommand.length();
    std::string copyRawCommand = rawCommand;
    std::size_t lastIndex = 0;
    //asad   sad asd

    for (int i = 1; i < len; i++) {
        if(copyRawCommand[i] == ' '){
            token = copyRawCommand.substr(lastIndex, i-1);
            parsedCommand.push_back(token);
        }
    }
}
