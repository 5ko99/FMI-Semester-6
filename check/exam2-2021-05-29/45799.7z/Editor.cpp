#include "Editor.h"

Editor::Editor(const std::string &filePath) : filePath(filePath), fileLen(0) {
    openFile(filePath);
}

Editor::~Editor() {
    closeFile();
}

void Editor::openFile(const std::string &filePath) {
    if (!fileIn.is_open() || !fileOut.is_open()) {

        fileIn.open(filePath, std::ios::app | std::ios::binary);
        fileOut.open(filePath, std::ios::app | std::ios::binary);

        if (!fileIn.is_open() || !fileOut.is_open()) {
            throw std::invalid_argument("There is a problem while opening the file!");
        }
    }
}

void Editor::closeFile() {
    if (fileOut.is_open()) {
        fileOut.close();
    }
    if (fileIn.is_open()) {
        fileIn.close();
    }
}

std::size_t Editor::size() {
    getLen();
    return fileLen;
}

std::size_t Editor::getLen() {
    if (!fileIn.is_open()) {
        throw std::invalid_argument("File not open");
    }

    fileIn.seekg(0, std::ios::end);
    fileLen = fileIn.tellg();

    return fileLen;
}

void Editor::edit(std::size_t offset, std::uint8_t value) {

}

void Editor::display(std::ostream &out, std::size_t offset, std::size_t limit) {
    if(!fileIn.is_open() || !fileOut.is_open()){
        throw std::invalid_argument("File is not open");
    }
    if(offset > fileLen || offset+limit > fileLen){
        throw std::invalid_argument("Invalid offset'");
    }

    char buff[33];
    buff[32] = '\0';

    if(offset <= 32){
        fileIn.read(buff, offset);
        if(limit <= 32){
            buff[limit] == '\0';
            out << buff;
        }else {
            while(1){
                if((offset - fileIn.tellg()) < 32){
                    fileIn.read(buff, offset - fileIn.tellg());
                    buff[32] = '\0';
                    out << buff;
                    break;
                }
                buff[32] = '\0';
                out << buff;
            }
        }
    }else {
        //todo
    }




}

