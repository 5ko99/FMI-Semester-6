#ifndef TEST2_COMMAND_H
#define TEST2_COMMAND_H
#include <string>
#include <vector>

class Command{
private:
    std::string rawCommand;
    std::vector<std::string> parsedCommand;

    void parse();
public:
    Command(const std::string& command);

    std::size_t size() const;

    std::string operator[](std::size_t index);
};

#endif //TEST2_COMMAND_H
