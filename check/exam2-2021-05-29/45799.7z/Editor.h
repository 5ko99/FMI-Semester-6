#ifndef TEST2_EDITOR_H
#define TEST2_EDITOR_H

#include <string>
#include <iostream>
#include <fstream>

class Editor{
private:
    std::ifstream fileIn;
    std::ofstream fileOut;

    std::size_t fileLen;
    std::string filePath;

    std::size_t getLen();
public:
    Editor(const std::string& filePath);

    ~Editor();

    void openFile(const std::string& filePath);

    void closeFile();

    std::size_t size();

    void edit(std::size_t offset, std::uint8_t value);

    void display(std::ostream& out, std::size_t offset, std::size_t limit);


};

#endif //TEST2_EDITOR_H
