#include "Processor.h"
#include <cstring>
#include <iostream>

bool Processor::isValid(const Command& command)
{
    const short allCommands = 4;
    const char* availableCommands[allCommands] = {"exit",
                                                  "size",
                                                  "edit",
                                                  "show"};
    for (short i = 0; i < allCommands; ++i) {
        if (strcmp(command[0].c_str(), availableCommands[i]) == 0) {
            switch (i) {
                case 0: {
                    cmdType = COMMAND_TYPE::EXIT;
                    return command.size() == 0;
                }
                case 1: {
                    cmdType = COMMAND_TYPE::SIZE;
                    return command.size() == 0;
                }
                case 2: {
                    cmdType = COMMAND_TYPE::EDIT;
                    return command.size() == 2;
                }
                case 3: {
                    cmdType = COMMAND_TYPE::SHOW;
                    return command.size() == 2;
                }
                default: // Unreachable
                    return false;
            }
        }
    }
    return false;
}

bool Processor::execute(const Command& command, Editor& editor)
{
    if (!isValid(command))
        throw std::invalid_argument("Invalid command or arguments");
    switch (cmdType) {
        case COMMAND_TYPE::EXIT:
            return true;
        case COMMAND_TYPE::SIZE: {
            std::cout << editor.size() << '\n';
            break;
        }
        case COMMAND_TYPE::EDIT: {
            editor.edit(strToUnsigned(command[1]), strToUnsigned(command[2]));
            break;
        }
        case COMMAND_TYPE::SHOW: {
            editor.display(std::cout, strToUnsigned(command[1]), strToUnsigned(command[2]));
            std::cout << '\n';
            break;
        }
    }
    return false;
}

unsigned Processor::strToUnsigned(const std::string& str)
{
    size_t len = str.length();
    unsigned result = 0;
    for (size_t i = 0; i < len; ++i) {
        if (isDigit(str[i]))
            result = result * 10 + str[i] - '0';
        else
            throw std::invalid_argument("String is not a number");
    }
    return result;
}

bool Processor::isDigit(char c)
{
    return '0' <= c && c <= '9';
}

Processor& Processor::get()
{
    static Processor instance;
    return instance;
}
