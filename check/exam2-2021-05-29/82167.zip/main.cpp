// 
// СУ "Св. Климент Охридски"
// Факултет по математика и информатика
// Курс Обектно-ориентирано програмиране 2020/21
// Контролно 2
// 
// Име: Владимир Илиев
// ФН: 82167
// Специалност: КН
// Курс: 1
// Административна група: 2
// Ден, в който се явявате на контролното: 29.05.2021
// Начален час на контролното: 9:00
// Кой компилатор използвате: GCC
//

#include <cassert>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>

#include "Editor.h"
#include "Command.h"
#include "Processor.h"

int main(int argc, char* argv[])
{
    if (argc != 2) {
        std::cerr << "Invalid arguments when starting the program.\n";
        return 1;
    }

    Editor editor(argv[1]);

    bool exit = false;

    while (!exit) {
        std::string cmd;
        std::getline(std::cin, cmd, '\n');
        try {
            exit = Processor::get().execute(Command(cmd.c_str()), editor);
        } catch (std::invalid_argument& e) {
            std::cerr << e.what() << '\n';
        } catch (std::runtime_error& e) {
            std::cerr << e.what() << '\n';
            return 1;
        }
    }

    return 0;
}