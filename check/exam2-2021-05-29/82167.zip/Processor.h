#pragma once

#include "Command.h"
#include "Editor.h"

enum class COMMAND_TYPE {
    EXIT,
    SIZE,
    EDIT,
    SHOW
};

class Processor {
    COMMAND_TYPE cmdType;

    static bool isDigit(char c);
    static unsigned strToUnsigned(const std::string& str);

    Processor() = default;

public:
    Processor(const Processor&) = delete;
    Processor(Processor&&) = delete;
    Processor& operator=(const Processor&) = delete;
    Processor& operator=(Processor&&) = delete;

    static Processor& get();

    bool isValid(const Command& command);
    bool execute(const Command& command, Editor& editor); // Returns true if command is EXIT
};
