#pragma once

#include <vector>
#include <string>

class Command {
    std::vector<std::string> arguments = {};

    void separateArguments(const char* command);

    static char toLowerCase(char a);

public:
    explicit Command(const char* command);

    size_t size() const;
    const std::string& operator[](size_t idx) const;
};