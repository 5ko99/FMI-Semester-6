#pragma once

#include <fstream>

class Editor {
    std::fstream file;
    size_t file_size = 0;

    void findSize();

public:
    Editor() = default;
    explicit Editor(const char* path);

    void open(const char* path);
    void close();
    size_t size() const;
    void edit(std::size_t offset, std::uint8_t value);
    void display(std::ostream& out, std::size_t offset, std::size_t limit);

};
