#include <stdexcept>
#include <cassert>
#include "Command.h"
#include <cstring>

char Command::toLowerCase(char a)
{
    return ('A' <= a && a <= 'Z' ? (char) (a - 'A' + 'a') : a);
}

Command::Command(const char* command)
{
    separateArguments(command);
}

void Command::separateArguments(const char* command)
{
    if (!command)
        throw std::invalid_argument("Invalid command");
    size_t len = strlen(command);
    if (len < 4)
        throw std::invalid_argument("Invalid command");
    for (size_t i = 0; i < len; ++i) {
        while (i < len && command[i] == ' ')
            ++i;
        std::string argument;
        while (i < len && command[i] != ' ')
            argument.push_back(toLowerCase(command[i++]));
        if (!argument.empty())
            arguments.push_back(argument);
    }
}


size_t Command::size() const
{
    return arguments.size() - 1;
}

const std::string& Command::operator[](size_t idx) const
{
    assert(idx < size() + 1);
    return arguments[idx];
}
