#include "Editor.h"
#include <iomanip>

Editor::Editor(const char* path)
{
    open(path);
}

void Editor::open(const char* path)
{
    if (file.is_open())
        throw std::runtime_error("File is already opened");
    file.open(path, std::ios::out | std::ios::in | std::ios::binary | std::ios::ate);
    if (!file.is_open())
        throw std::runtime_error("Error in opening the file");
    findSize();
}

void Editor::close()
{
    file.close();
    file_size = 0;
}

void Editor::findSize()
{
    long long curPosition = file.tellg();
    file.seekg(0, file.end);
    file_size = file.tellg();
    file.seekg(curPosition, file.beg);
}

size_t Editor::size() const
{
    return file_size;
}

void Editor::edit(std::size_t offset, std::uint8_t value)
{
    if (!file.is_open())
        throw std::runtime_error("No file opened");
    if (offset > file_size)
        throw std::invalid_argument("Editor::edit() out of bounds offset");

    file.seekp(offset, file.beg);
    file.write((const char*) &value, sizeof(std::uint8_t));
    if (!file.good())
        throw std::runtime_error("Writing error in Editor::edit()");
    findSize();
}

static size_t min(size_t a, size_t b)
{
    return a < b ? a : b;
}

void Editor::display(std::ostream& out, std::size_t offset, std::size_t limit)
{
    if (!file.is_open())
        throw std::runtime_error("No file opened");
    if (offset > file_size)
        throw std::invalid_argument("Invalid offset in Editor::display()");
    long long curPosition = file.tellg();
    file.seekg(0, file.beg);
    for (size_t j = 0; j < file_size; ++j) {
        out << file.tellg() << ": ";
        for (short i = 0; i < 16 && j < min(file_size, limit); ++i, ++j) {
            std::uint8_t value;
            file.read((char*) &value, sizeof(std::uint8_t));
            if (!file.good())
                throw std::runtime_error("Error in reading in Editor::display()");
            out << std::setfill('0') << std::setw(2) << std::hex << value << ' ';
        }
    }
    file.seekg(curPosition, file.beg);
}


