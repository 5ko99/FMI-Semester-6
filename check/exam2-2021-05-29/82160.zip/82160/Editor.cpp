#include "Editor.h"

Editor::Editor(const std::string& fileName)
    : m_fileName(fileName), m_file(m_fileName, std::ios::binary) {}

Editor::~Editor()
{
    m_file.close();
}

void Editor::open(const std::string& fileName)
{
    m_file.open(fileName, std::ios::binary);
}

void Editor::close()
{
    m_file.close();
}
