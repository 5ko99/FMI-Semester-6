#ifndef EDITOR_H
#define EDITOR_H

#include <string>
#include <fstream>

class Editor
{
    std::string m_fileName;
    std::fstream m_file;
    std::size_t fileSize;

public:
    Editor() = default;
    Editor(const std::string& fileName);
    ~Editor();

    void open(const std::string& fileName);
    void close();
};

#endif
