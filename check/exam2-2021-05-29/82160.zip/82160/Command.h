#ifndef COMMAND_H
#define COMMAND_H

#include <iostream>
#include <string>
#include <vector>

class Command
{
    std::string m_text = "";
    std::string m_command = "";
    std::vector<std::string> m_arguments;

public:
    Command() = default;
    Command(const std::string& text);

    void interpretCommand();
    std::size_t size() const;
    std::string& operator[](std::size_t index);
};


#endif
