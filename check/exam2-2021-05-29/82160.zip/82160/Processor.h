#ifndef PROCESSOR_H
#define PROCESSOR_H

#include "Command.h"
#include "Editor.h"

class Processor
{
    Editor m_editor;

public:
    Processor() = default;

    bool is_valid(Command& command);
    void execute(const Command& command);

};

#endif
