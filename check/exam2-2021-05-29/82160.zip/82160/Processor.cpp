#include "Processor.h"

bool Processor::is_valid(Command& command)
{
    if(command[0] == "EXIT" || command[0] == "SIZE" ||
       command[0] == "SHOW" || command[0] == "EDIT")
    {
       std::size_t numOfArg = command.size();
       if(numOfArg == 0)
            return true;
       else if(numOfArg == 1)
            return false;
       else if(numOfArg == 2) {

       }
    }
    else
        return false;
}
