#include "Command.h"

Command::Command(const std::string& text)
    : m_text(text) {}

void Command::interpretCommand()
{

}

std::size_t Command::size() const
{
    return m_arguments.size();
}

std::string& Command::operator[](std::size_t index)
{
    if(index == 0)
        return m_command;
    else
        return m_arguments[index];
}
