#pragma once
#include <iostream>
#include <cstring>
#include <cassert>
#include "Editor.h"
#include "Command.h"
using namespace std;
class Processor
{
	Command com;
public:
	Processor();
	friend bool isValid(Command& com);
	void execute(Command& com);


};
