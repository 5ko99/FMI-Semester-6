#include <iostream>
#include <fstream>
#include <cassert>
#include "Editor.h"

Editor::Editor()
{
	cin >> path;
}
std::fstream Editor::open(std::fstream file)
{
	try
	{
		cout << "The file opened";
		fstream file(path, ios::binary);
	}
	catch (const bool !(file.is_open))
	{
		cout << "File failed to open";
	}
}
std::fstream Editor::close(std::fstream file)
{
	file.close();
}