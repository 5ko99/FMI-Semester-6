#include <iostream>
using namespace std;

char *name;
char *arg;
class Command
{
	char *text;
public:
	Command();
	size_t size() const;
	int operator[](size_t index);
};