#include <iostream>
#include <cstring>
#include <cassert>
#include <fstream>
#include "Editor.h"
#include "Processor.h"
#include "Command.h"
using namespace std;

Processor::Processor()
{
	
}
bool Processor::isValid(Command& com) 
{
	if (com.is_valid)
	{
		return true;
	}
	return false;
}


