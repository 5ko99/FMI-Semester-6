#pragma once
#include <iostream>
#include <fstream>
#include <cassert>
#include "Command.h"
using namespace std;
class Editor
{
	char *path;
public:
	Editor();
	std::fstream open(std::fstream file);
	std::fstream close(std::fstream file);
};