#include <iostream>
#include <cstring>
#include <cassert>
#include "Command.h"
using namespace std;

Command::Command()
{
	cin >> text;
}
size_t Command::size() const
{
	int c;
	for (int i = 0; i < strlen(text); i++)
	{
		if (text[i] = ' ')
		{
			for (int j = 0; j < i-1 ; j++)
			{
				*name = text[j];
			}
			c++;
			break;
		}
	}
	return --c;
}
int Command::operator[](size_t index)
{
	assert(index < strlen(text));
	return text[index];
}
