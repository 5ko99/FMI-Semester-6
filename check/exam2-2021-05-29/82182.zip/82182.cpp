// 
// СУ "Св. Климент Охридски"
// Факултет по математика и информатика
// Курс Обектно-ориентирано програмиране 2020/21
// Контролно 2
// 
// Име: Димитър Николаев Дамянов
// ФН: 82182
// Специалност: КН
// Курс: 1
// Административна група:
// Ден, в който се явявате на контролното: 29.05.2001
// Начален час на контролното: 9:00
// Кой компилатор използвате: g++
//

// #define _CRT_SECURE_NO_WARNINGS 

#include <cassert>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <algorithm>

using std::cin;
using std::cout;
using std::endl;
using std::string;
using std::vector;
using std::ios;
using std::ios_base;

class command{

    string _command;
    vector<string> arguments;

public:
    command(string str)
    {
        size_t i = 0;
        for (; str[i] && str[i] != ' '; i++)
        {
            _command += str[i];
        }

        string buffer;
        while (str[i])
        {
            for (; str[i] == ' ' || str[i] == '\t' || str[i] == '\n'; i++);
            for (; str[i] && str[i] != ' '; i++)
            {
                buffer += str[i];
            }

            arguments.push_back(buffer);
            buffer.clear();
        }

    }

    std::size_t size() const
    {
        return arguments.size();
    }

    string operator[](size_t index)
    {
        if(index < 0 || index > size() ) throw std::out_of_range("index out of range");
        if(index == 0) return _command;
        return arguments[index-1];
    }
};

class editor
{
    size_t filesize = 0;
    std::fstream file;

public:
    void open(string path)
    {
        file.open(path, ios::in | ios::out | ios::binary);

        if(!file.good())
        {
            throw std::invalid_argument("can't open file");
        }
        else
        {
            char c;
            file.seekg(c, std::ios_base::end);
            filesize = file.tellg();
        }
    }

    void close()
    {
        filesize = 0;
        file.close();
        file.clear();
    }

    editor(string path)
    {
        try
        {
            open(path);
        }
        catch(std::exception& e)
        {
            std::cerr << e.what() << '\n';
        }
    }

    ~editor()
    {
        if(file.is_open()) close();
    }

    void edit(std::size_t offset, std::uint8_t value)
    {
        if(filesize < (offset + sizeof(value)))
        {
            throw std::invalid_argument("file size is " + filesize);
        }

        file.seekp(offset, ios::beg);
        file.write((char*)& value, sizeof(value));
    }

    void display(std::ostream& out, std::size_t offset, size_t limit)
    {
        uint8_t buff;
        size_t readSize = sizeof(buff);

        if(filesize <= (offset + readSize))
        {
            throw std::invalid_argument("file size is " + filesize);
        }

        size_t s = 0;

        while(offset + readSize <= filesize && s < limit)
        {
            file.seekg(offset, ios::beg);
            file.read((char*)&buff, readSize);

            cout << std::setfill('0') << std::setw(2) << std::hex << (unsigned int)buff << ' ';

            offset += readSize;
            s += readSize;
        }
        cout << endl;
    }

    size_t size()
    {
        return filesize;
    }

    bool good()
    {
        return file.good();
    }
};

class processor
{
    editor* _editor;
    bool is_valid(command c);

public:
    static processor getInstance()
    {
        static processor p;
        return p;
    }

    void setEditor(editor* e)
    {
        this->_editor = e;
    }

    bool execute(command _command)
    {
        string _c = _command[0];
        std::transform(_c.begin(), _c.end(), _c.begin(), ::toupper);

        if(_c == "EXIT")
        {
            _editor->close();
            return false;
        }
        else if(_c == "SIZE")
        {
            cout << _editor->size() << " byte(s)" << endl;
        }
        else if(_c == "EDIT")
        {
            try
            {
                _editor->edit(std::stoi(_command[1]), std::stoi(_command[2]));
                cout << "OK" << endl;
            }
            catch(const std::exception& e)
            {
                std::cerr << e.what() << '\n';
            }
        }
        else if(_c == "SHOW")
        {
            _editor->display(cout, std::stoi(_command[1]), std::stoi(_command[2]));
        }
        else
        {
            cout << "invalid command" << endl;
        }

        return true;
    }
};

int main(int argc, char* argv[])
{

    editor e(argv[1]);
    string buff;

    processor p = processor::getInstance();

    if(e.good())
    {
        bool proceed = true;
        p.setEditor(&e);

        while(cin && proceed)
        {
            getline(cin, buff);
            command c(buff);
            proceed = p.execute(c);
        }
    }
    else
    {
        cout << "Couldn't open file " << argv[1] << endl;
    }

	return 0;
}