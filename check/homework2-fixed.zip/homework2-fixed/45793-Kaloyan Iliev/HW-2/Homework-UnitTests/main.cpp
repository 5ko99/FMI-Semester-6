#define CATCH_CONFIG_MAIN
#include "RegistrationTests.h"
#include "PersonTests.h"
#include "VehicleTests.h"
//#include "CommandTests.h"

// members vector<Person> People and vector<Vehicle> Vehicles in Command.h need to be set to public for CommandTests to work
