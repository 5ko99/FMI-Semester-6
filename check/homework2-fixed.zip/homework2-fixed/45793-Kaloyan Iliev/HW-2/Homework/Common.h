#ifndef COMMON_H
#define COMMON_H

#include "Registration.h"
#include "Person.h"
#include "Vehicle.h"

#endif
