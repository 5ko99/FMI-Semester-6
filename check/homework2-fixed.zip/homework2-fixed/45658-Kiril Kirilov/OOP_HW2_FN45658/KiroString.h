#pragma once

#include <vector>;
#include <string>;

std::vector<std::string> tokenizer(std::string str);
void toUpperCase(std::string& str);
