#pragma once
#include <string>

bool isEqualString(std::string str_1, std::string str_2);

unsigned strToInt(const std::string str);
std::string intToStr(const unsigned num);
