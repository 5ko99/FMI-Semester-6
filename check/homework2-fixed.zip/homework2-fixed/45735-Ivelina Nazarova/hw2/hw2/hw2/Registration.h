#pragma once
class Registration
{
	char registration[8];
public:
	Registration();
};
