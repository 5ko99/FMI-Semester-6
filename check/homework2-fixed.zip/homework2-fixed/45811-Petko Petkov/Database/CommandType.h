#pragma once
enum CommandType {
	VEHICLE,
	PERSON,
	ACQUIRE,
	RELEASE,
	REMOVE,
	SAVE,
	SHOW,
	EXIT,
	NOCOMMAND
};
