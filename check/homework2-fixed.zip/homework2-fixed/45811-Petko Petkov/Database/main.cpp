#include<iostream>
#include "Database.h"

int main() {
	Database::getInstance().exe();

	return 0;
}
