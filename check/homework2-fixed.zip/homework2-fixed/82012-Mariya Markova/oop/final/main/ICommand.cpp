#include "ICommand.h"

ICommand::~ICommand()
{

}
