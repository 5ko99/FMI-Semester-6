//
// Created by Yani Drenchev on 18.05.21.
//
//#include "../Source/DataBase.cpp"
//#include "single_include/catch2/catch.hpp"
//
//TEST_CASE("DataBase add command valid", "[add command id valid]") {
////    std::string command = "person yani 1";
////    DataBase::get_instance().addCommand(command);
////    REQUIRE(DataBase::get_instance().getCommands().size() == 1);
//
//}
