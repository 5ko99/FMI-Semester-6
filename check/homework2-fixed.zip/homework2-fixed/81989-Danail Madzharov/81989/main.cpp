#include <iostream>
#include <regex>
#include "UserInterface.h"
using namespace std;

int main() {
    UserInterface ui;
    ui.start();
    return 0;
}
