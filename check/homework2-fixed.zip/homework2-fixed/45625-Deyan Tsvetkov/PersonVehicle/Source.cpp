#include "Database.h"

int main()
{
    Database::i().run();

    return 0;
}
