#include <iostream>
#include "Commands.h"
int main()
{
	Commands com;
	com.run();
	return 0;
}
