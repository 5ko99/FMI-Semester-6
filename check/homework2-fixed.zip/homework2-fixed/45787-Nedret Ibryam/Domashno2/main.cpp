#include <iostream>

#include <string>
#include <cstring>
#include <stdio.h>
#include <stdlib.h>

#include <SomeFeatures.h>
#include <Registration.h>
#include <Person.h>
#include <Vehicle.h>
#include <Commands.h>

// РўРµСЃС‚РѕРІРµС‚Рµ СЃСЉРј РіРѕ СЃР»РѕР¶РёР» РІ РѕС‚РґРµР»РЅР° РїР°РїРєР°
// РќР• РЎРЄРњ РќРђРџР РђР’РР› Р¤РЈРќРљР¦РРЇРўРђ SAVE
// РєРѕРјР°РЅРґР°С‚Р° REMOVE <WHAT> | <what> Рµ СЂРµРіРёСЃС‚СЂР°С†РёРѕРЅРµРЅ РЅРѕРјРµСЂ РЅРµ СЂР°Р±РѕС‚Рё РєРѕСЂРµРєС‚РЅРѕ, Р·Р°С‰РѕС‚Рѕ РЅРµ РёСЃРєР° РґР° РјР°С…РЅРµ РµР»РµРјРµРЅС‚Р° РѕС‚ РІРµРєС‚РѕСЂР°

int main(int argc, char *argv[])
{
    console();
    return 0;
}
