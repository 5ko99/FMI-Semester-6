#pragma once
#include "Message.h"
#include <iostream>
#include <string>
#include <fstream>

//class Logger
//--------------
//позволява на потребителя да записва (или да "log-ва") 
//съобщения в текстов файл (т.нар. log file).
class Logger{
public:
    Logger();
    Logger(std::string filename);  //конструктор
    Logger& operator=(const Logger& other); 
    ~Logger(); //деструктор
    //предефинира оператора << така, че потребителят да може да записва с него съобщения.
    friend std::istream& operator>>(std::istream in, Logger& log);

    //предоставя колко съобщения от всеки вид са били логнати през неговите обекти на потребителя
    int getInfo();
    int getWarning();
    int getError();
    int getCritical();


private:
    static inline int info = 0;
    static inline int warning = 0;
    static inline int error = 0;
    static inline int critical = 0;

    std::string filename;
    std::fstream out;

    void countErrors(Type type);

};