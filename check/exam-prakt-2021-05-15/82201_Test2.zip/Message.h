#pragma once
#include <iostream>
#include <string>

using std::cin;
using std::cout;
using std::endl;

enum Type{
	INFO, //информативно
	WARNING, //предупреждение
	ERROR, //грешка 
	CRITICAL // критична грешка
};

//class Messege
//-------------
//представя съобщение
class Message{
public:
    Message(Type type, std::string description); //constructor

    //подходяща версия на оператора за изход при работа с потоци (<<)
	friend std::ostream& operator<<(std::ostream &out, const Message& other);

private:
	Type type; // вид на съобщението. То може да бъде информативно (info), предупреждение (warning), грешка (error), критична грешка (critical error). За представяне на вида използвайте изброим тип (enum).
	std::string description; // текст на съобщението.
};
