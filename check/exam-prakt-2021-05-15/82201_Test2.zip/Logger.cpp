#include "Message.h"
#include "Logger.h"
#include <fstream>
#include <string>

Logger::Logger(){
}
//конструктор
Logger::Logger(std::string filename){
    this->filename = filename;
}

Logger& Logger::operator=(const Logger& other){
    filename = other.filename;
}
//деструктор
Logger::~Logger(){
}

//предефинира оператора << така, че потребителят да може да записва с него съобщения.
std::istream& operator>>(std::istream in, Logger& log){
    
    //input from user
    Type type;
    //
    std::string text;
    in >> text;
    if(text == "INFO") type == 0;
    else if(text == "WARNING") type == 1;
    else if(text == "ERROR") type == 2;
    else if(text == "CRITICAL") type == 3;
    else{
        throw std::invalid_argument("not recognised command");
    }
    //

    std::string des;
    in >> des;

    //file input
    std::fstream file(log.filename , std::ios::app);
        if(!file)
        {
            throw std::overflow_error("file didnt open");
        }
    file << type << " " << des << "\n";
    file.close();

    //count errors
    log.countErrors(type);

    return in;
}


//предоставя колко съобщения от всеки вид са били логнати през неговите обекти на потребителя
int Logger::getInfo(){
    return info;
}
int Logger::getWarning(){
    return warning;
}
int Logger::getError(){
    return error;
}
int Logger::getCritical(){
    return critical;
}


//private
void Logger::countErrors(Type type)
{
    if(type == 0){
        this->info++;  
    }
    else if(type == 1){
        this->warning++;
    }
    else if(type == 2){
        this->error++;
    }
    else if(type == 3){
        this->error++;
    }
}