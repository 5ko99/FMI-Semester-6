#pragma once
#include <string>
#include "Logger.h"
#include "Message.h"

class Configuration{
public:
    Configuration(std::string file);

private:
    std::string filename; // Файл, от който е била прочетена конфигурацията (символен низ)
    Logger log; //Logger обект

};