#include "Message.h"

//constructor
Message::Message(Type type, std::string description){
    this->type = type;
    this->description = description;
}

//подходяща версия на оператора за изход при работа с потоци (<<)
std::ostream& operator<<(std::ostream &out, const Message& other){
    out << other.type << ": " << other.description;
    return out;
}

