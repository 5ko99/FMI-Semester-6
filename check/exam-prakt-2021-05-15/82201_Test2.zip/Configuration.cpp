#include "Configuration.h"


Configuration::Configuration(std::string filename)
{
    this->filename = filename;
    Logger loge(filename);
    log = loge;

    
    
 
}
