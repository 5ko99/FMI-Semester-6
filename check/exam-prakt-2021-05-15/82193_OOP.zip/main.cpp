// 
// СУ "Св. Климент Охридски"
// Факултет по математика и информатика
// Курс Обектно-ориентирано програмиране 2020/21
// Контролно по ООП-практикум
// 
// Име: Емил Йорданов
// ФН: 82193
// Специалност: Компютърни науки
// Курс: 1-ви
// Административна група: 3-та
// Ден, в който се явявате на контролното: 15.05.2021
// Начален час на контролното: 9:00
// Кой компилатор използвате: GCC
//

// (Можете да изтриете този коментар след като го прочетете)
// Редът по-долу е специфичен за Visual C++.
// Ако използвате друг компилатор, можете да го изтриете.
// Тъй като strlen, strcmp и т.н. са дефинирани като deprecated,
// имате две възможности:
//
// * да използвате безопасните версии на тези функции
//   (strlen_s, strcmp_s и т.н.). В този случай можете да
//   изтриете дадената по-долу #define директива.
//
// * да дефинирате _CRT_SECURE_NO_WARNINGS преди да
//   включите съответните header файлове от стандартната
//   библиотека.
//
#define _CRT_SECURE_NO_WARNINGS 

#include <cassert>
#include <cstring>
#include <iostream>
#include <string>
#include <fstream>
#include <ostream>

#include "Configuration.h"
#include "Logger.h"
#include "Message.h"

/* ERROR CODES:
 * [1] Unhandled exception
 * [2] Invalid argument exception
*/
int main()
{
    try {
        Logger programLogger = Logger();
        Configuration programConfig = Configuration("sample-config.txt", &programLogger);

        while (true) {
            std::string userCMD;
            std::cin >> userCMD;

            if(userCMD == "Exit") {
                std::cout << "You exited the program ;)" << std::endl;

                break;
            }
            else if(userCMD == "Save") {
                // Saves the text (the messages) to the given file in the config
                programConfig.Save();
            }
            else if(userCMD == "Message") {
                std::string firstArgument; // The MessageType
                std::string secondArgument; // The Message text

                std::cin >> firstArgument >> secondArgument;

                if(firstArgument == "INFO:") {
                    Message newMessage = Message(secondArgument, INFO);
                    programConfig.AppendNewMessage(newMessage);
                }
                else if(firstArgument == "WARNING:") {
                    Message newMessage = Message(secondArgument, WARNING);
                    programConfig.AppendNewMessage(newMessage);
                }
                else if(firstArgument == "ERROR:") {
                    Message newMessage = Message(secondArgument, ERROR);
                    programConfig.AppendNewMessage(newMessage);
                }
                else if(firstArgument == "CRITICAL ERROR:") {
                    Message newMessage = Message(secondArgument, CRITICALERROR);
                    programConfig.AppendNewMessage(newMessage);
                }
                else {
                    // Terminates the program execution because such message type is not existent
                    throw std::invalid_argument("Cannot add message with such message type: '" + firstArgument + "'");
                }
            }
        }

        return 0;
    }
    catch(std::invalid_argument iaex) {
        std::cout << "Invalid argument exception: " << iaex.what() << std::endl;
 
        // Returns '2' because there was an invalid argument
        return 2;
    }
    // Catches all exceptions and tells the user that something went wrong
    catch (...) {
        std::cout << "Unhandled exception: An unexpected error was thrown. Exiting the program..." << std::endl;
        
        // Returns '1' because there was a runtime error
        return 1;
    }
}