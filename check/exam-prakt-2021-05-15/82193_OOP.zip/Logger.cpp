// 
// СУ "Св. Климент Охридски"
// Факултет по математика и информатика
// Курс Обектно-ориентирано програмиране 2020/21
// Контролно по ООП-практикум
// 
// Име: Емил Йорданов
// ФН: 82193
// Специалност: Компютърни науки
// Курс: 1-ви
// Административна група: 3-та
// Ден, в който се явявате на контролното: 15.05.2021
// Начален час на контролното: 9:00
// Кой компилатор използвате: GCC
//

#include "Logger.h"

#include <string>
#include <exception>
#include "Message.h"

Logger::Logger() : loggerText() { }

void Logger::AppendLoggerText(std::string text) {
    if(text.size() == 0) {
        throw std::invalid_argument("Cannot append an empty text to logger!");
    }

    if(this->loggerText.size() > 0) {
        // Appends a new line symbol if there is already some text in the logger
        this->loggerText.append("\n");
    }

    this->loggerText.append(text);
}

std::string Logger::ToString() {
    return this->loggerText;
}