// 
// СУ "Св. Климент Охридски"
// Факултет по математика и информатика
// Курс Обектно-ориентирано програмиране 2020/21
// Контролно по ООП-практикум
// 
// Име: Емил Йорданов
// ФН: 82193
// Специалност: Компютърни науки
// Курс: 1-ви
// Административна група: 3-та
// Ден, в който се явявате на контролното: 15.05.2021
// Начален час на контролното: 9:00
// Кой компилатор използвате: GCC
//

#ifndef CONFIGURATION_H
#define CONFIGURATION_H

#include <iostream>
#include <string>
#include "Logger.h"
#include "Message.h"

class Configuration {
    private:
        std::string filePath;
        Logger* fileLogger;
    public:
        Configuration(std::string path, Logger* logger);
        void Save();
        // Appends new message to the fileLogger by calling message.ToString()
        void AppendNewMessage(Message message);
};

#endif
