// 
// СУ "Св. Климент Охридски"
// Факултет по математика и информатика
// Курс Обектно-ориентирано програмиране 2020/21
// Контролно по ООП-практикум
// 
// Име: Емил Йорданов
// ФН: 82193
// Специалност: Компютърни науки
// Курс: 1-ви
// Административна група: 3-та
// Ден, в който се явявате на контролното: 15.05.2021
// Начален час на контролното: 9:00
// Кой компилатор използвате: GCC
//

#include "Configuration.h"

#include <exception>
#include <iostream>
#include <string>
#include <fstream>
#include <ostream>
#include "Logger.h"
#include "Message.h"

Configuration::Configuration(std::string path, Logger* logger) : fileLogger(logger) {
    std::ifstream inputFile(path);
    std::string outputFilePath;
    inputFile >> outputFilePath;

    this->filePath = outputFilePath;
}

void Configuration::Save() {
    std::ofstream outputFile(this->filePath);
    outputFile << this->fileLogger->ToString();
}

void Configuration::AppendNewMessage(Message message) {
    if(message.ToString().size() == 0) {
        throw std::invalid_argument("Cannot append an empty message!");
    }

    this->fileLogger->AppendLoggerText(message.ToString());
}