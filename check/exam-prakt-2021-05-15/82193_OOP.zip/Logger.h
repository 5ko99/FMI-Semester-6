// 
// СУ "Св. Климент Охридски"
// Факултет по математика и информатика
// Курс Обектно-ориентирано програмиране 2020/21
// Контролно по ООП-практикум
// 
// Име: Емил Йорданов
// ФН: 82193
// Специалност: Компютърни науки
// Курс: 1-ви
// Административна група: 3-та
// Ден, в който се явявате на контролното: 15.05.2021
// Начален час на контролното: 9:00
// Кой компилатор използвате: GCC
//

#ifndef LOGGER_H
#define LOGGER_H

#include <string>
#include "Message.h"

class Logger {
    private:
        std::string loggerText;
    public:
        Logger();
        // Adds text to the loggerText property;
        void AppendLoggerText(std::string text); 
        // Returns loggerText (used when saving the text to a file)
        std::string ToString();
};

#endif
