// 
// СУ "Св. Климент Охридски"
// Факултет по математика и информатика
// Курс Обектно-ориентирано програмиране 2020/21
// Контролно по ООП-практикум
// 
// Име: Емил Йорданов
// ФН: 82193
// Специалност: Компютърни науки
// Курс: 1-ви
// Административна група: 3-та
// Ден, в който се явявате на контролното: 15.05.2021
// Начален час на контролното: 9:00
// Кой компилатор използвате: GCC
//

#ifndef MESSAGE_H
#define MESSAGE_H

#include <iostream>
#include <string>
#include <ostream>

// An ENUM used for Message Types (INFO, WARNING, ERROR, CRITICALERROR)
enum messageType {
    INFO,
    WARNING,
    ERROR,
    CRITICALERROR
};

class Message {
    private:
        std::string messageDescription;
        messageType mType;  
    public:
        Message(std::string description, messageType type);
        std::string ToString();
};

#endif