// 
// СУ "Св. Климент Охридски"
// Факултет по математика и информатика
// Курс Обектно-ориентирано програмиране 2020/21
// Контролно по ООП-практикум
// 
// Име: Емил Йорданов
// ФН: 82193
// Специалност: Компютърни науки
// Курс: 1-ви
// Административна група: 3-та
// Ден, в който се явявате на контролното: 15.05.2021
// Начален час на контролното: 9:00
// Кой компилатор използвате: GCC
//

#include "Message.h"

#include <iostream>
#include <string>
#include <ostream>

Message::Message(std::string description, messageType type) {
    this->messageDescription = description;
    this->mType = type;
}

std::string Message::ToString() {
    std::string typeToString;
    switch (this->mType)
    {
    case INFO:
        typeToString = "INFO:";
        break;
    case ERROR:
        typeToString = "ERROR:";
        break;
    case WARNING:
        typeToString = "WARNING:";
        break;
    case CRITICALERROR:
        typeToString = "CRITICAL ERROR:";
        break;
    default:
        throw std::invalid_argument("This message's type is not recognised!");
        break;
    }

    return typeToString + " " + this->messageDescription;
}