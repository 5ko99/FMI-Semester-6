#include <iostream>
#include <string>
#include <fstream>
#include "Message.h"
using namespace std;

Message::Message()
{
	char c;
	cin >> c;
	switch (c)
	{
	case 1:error = INFO; break;
	case 2:error = WARNING; break; 
	case 3:error = ERROR; break;
	case 4:error = CRITICAL; break;
	default:
		break;
	}
	cin >> description;
}
Message::~Message()
{
	delete[] description;
}
std::ostream &operator << (std::ostream out, const Message& mes) 
{
	out << mes.error << ": " << mes.description;
	
	return out;
}