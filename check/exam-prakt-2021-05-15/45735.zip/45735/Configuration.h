#pragma once
#include "Logger.h"
#include <fstream>
class Configuration
{
	Logger log;
	std::istream in;
public:
	Configuration();

};