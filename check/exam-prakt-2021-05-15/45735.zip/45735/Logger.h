#pragma once
#include "Message.h"
class Logger
{
	Message *mes;
	unsigned size;
	unsigned cap;
public:
	Logger();
	~Logger();
	Logger &add(const Logger& log);
	friend std::ostream &operator <<(std::ostream out, const Logger &log);
	
};