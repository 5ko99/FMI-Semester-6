#pragma once
#include <fstream>
enum type { INFO, WARNING, ERROR, CRITICAL };
class Message
{
	type error;
	char *description;
public:
	Message();
	~Message();
	friend std::ostream &operator <<(std::ostream out, const Message &message);
};