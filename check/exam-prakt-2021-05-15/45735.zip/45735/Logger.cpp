#include <iostream>
#include <string>
#include <fstream>
#include <cassert>
#include "Message.h"
#include "Logger.h"
using namespace std;
Logger::Logger()
{
	cap = 2;
	size = 0;
	mes = new Message;
}
Logger::~Logger()
{
	delete[] mes;
}
std::ostream &operator << (std::ostream out, const Logger& log)
{
	out << log.mes;
	return out;
}
Logger & Logger::add(const Logger &log)
{
	if (size=cap)
	{
		cap *= 2;
	}
	log[size] = mes;
	size++;
	return *this;

}
