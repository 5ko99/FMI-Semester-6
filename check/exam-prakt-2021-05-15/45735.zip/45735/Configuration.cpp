#include <iostream>
#include <fstream>
#include "Configuration.h"
#include "Logger.h"
Configuration::Configuration()
{
	std::istream in("log.txt", ios::in);
}