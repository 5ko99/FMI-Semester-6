﻿// 
// СУ "Св. Климент Охридски"
// Факултет по математика и информатика
// Курс Обектно-ориентирано програмиране 2020/21
// Контролно 1
// 
// Име: Петър Стоянов Овчаров
// ФН: 45805
// Специалност: информатика
// Курс: 1
// Административна група: 5
// Ден, в който се явявате на контролното: 15.05.2021
// Начален час на контролното: <9:00>
// Кой компилатор използвате: <Visual C++>
//

// (Можете да изтриете този коментар след като го прочетете)
// Редът по-долу е специфичен за Visual C++.
// Ако използвате друг компилатор, можете да го изтриете.
// Тъй като strlen, strcmp и т.н. са дефинирани като deprecated,
// имате две възможности:
//
// * да използвате безопасните версии на тези функции
//   (strlen_s, strcmp_s и т.н.). В този случай можете да
//   изтриете дадената по-долу #define директива.
//
// * да дефинирате _CRT_SECURE_NO_WARNINGS преди да
//   включите съответните header файлове от стандартната
//   библиотека.
//
#define _CRT_SECURE_NO_WARNINGS 

#include <cassert>
#include <cstring>
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
class Message
{
private:
	const string typeArr[4] = { "INFO", "WARNING", "ERROR ", "CRITICAL" };
	int type = 0;
	string description;
public:
	Message(size_t type, string description)
		: description(description)
	{
		if (type < 4)
		{
			this->type = type;
		}
		else
		{
			throw invalid_argument("Invalid type");
		}
	}

	friend ostream& operator<<(ostream& out, const Message& m)
	{
		out << m.typeArr[m.type] << " " << m.description;
		return out;
	}
};

class Logger
{
private:
	string fileName;
	size_t messageCnt[4];//{ "INFO", "WARNING", "ERROR ", "CRITICAL" }
	void updateCnt()
	{
		ifstream file(this->fileName.c_str());
		if (file.is_open())
		{
			string str;
			while (getline(file, str))
			{
				if (strstr(str.c_str(), "INFO"))
				{
					this->messageCnt[0]++;
				}
				else if (strstr(str.c_str(), "WARNING"))
				{
					this->messageCnt[1]++;
				}
				else if (strstr(str.c_str(), "ERROR"))
				{
					this->messageCnt[1]++;
				}
				else if (strstr(str.c_str(), "CRITICAL"))
				{
					this->messageCnt[1]++;
				}
			}
			file.close();
		}
	}
public:
	Logger(string fileName)
		:fileName(fileName)
	{
		for (size_t i = 0; i < 4; i++)
		{
			this->messageCnt[i] = 0;
		}
	}

	void operator<<(const Message& m)
	{
		ofstream file(this->fileName.c_str(), ios::app | ios::ate);
		if (file.is_open())
		{
			file << m << endl;
			this->updateCnt();
			file.close();
		}
	}
	size_t getInfoCount()const { return this->messageCnt[0]; }
	size_t getWarningCount()const { return this->messageCnt[1]; }
	size_t getErrorCount()const { return this->messageCnt[2]; }
	size_t getCriticalCount()const { return this->messageCnt[3]; }
};

class Configuration
{
private:
	string fileName;
	Logger* log;
	Configuration(string fileName)
		:fileName(fileName)
	{
		ifstream file(this->fileName.c_str());
		if (file)
		{
			string str;
			getline(file, str);
			this->log = new Logger(str);
		}
		else
		{
			throw exception("Failed to open log file!");
		}
	}
public:
	~Configuration()
	{
		delete this->log;
	}
	static Configuration& init(string fileName)
	{
		static Configuration conf(fileName);
		return conf;
	}
	void addLog(string type, string description)
	{
		size_t typeNum;
		if (type == "INFO")
		{
			typeNum = 0;
		}
		else if (type == "WARNING")
		{
			typeNum = 1;
		}
		else if (type == "ERROR")
		{
			typeNum = 2;
		}
		else if (type == "CRITICAL")
		{
			typeNum = 3;
		}
		else
		{
			throw invalid_argument("Invalid message type!");
		}
		Message m(typeNum, description);
		*(this->log) << m;
	}
};

int main()
{
	try
	{
		string configFileName = "config.txt";
		Configuration conf = Configuration::init(configFileName);
		cout << "Enter the nuber of messages you want to log: " << endl;
		int num = 0;
		do
		{
			cin >> num;
		} while (num < 0);
		for (size_t i = 0; i < num; i++)
		{
			cout << "Enter the type of the message: " << endl;
			string type;
			cin >> type;
			cout << "Enter the description of the message: " << endl;
			string desc;
			cin >> desc;
			conf.addLog(type, desc);
		}
	}
	catch (const exception& ex)
	{
		cout << ex.what() << endl;
	}
	return 0;
}
