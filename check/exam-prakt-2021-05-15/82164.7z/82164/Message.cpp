#include "Message.h"

Message::Message(MessageTypes type,std::string description)
:type(type),description(description){}

std::ostream& operator<<(std::ostream& ost,const Message& msg)
{

    (msg.type == INFO)? ost<<"INFO" :
    (msg.type == WARNING)? ost<<"WARNING":
    (msg.type == ERROR)? ost<<"ERROR":
    (msg.type == CRITICAL)? ost<<"CRITICAL":
    ost<<"UNKNOWN";
    ost<<": "<<msg.description<<std::endl;
    return ost;
}

short Message::getType() const
{
    return (short)type;
}