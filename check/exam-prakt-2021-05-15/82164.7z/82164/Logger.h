#pragma once

#include "Message.h"
#include <fstream>


class Logger{
    std::ofstream log;
    static std::size_t counter[4];
public:

    explicit Logger(std::string logFileName);
    ~Logger();
    friend Logger& operator<<(Logger& obj,const Message& msg);
    std::ofstream& getLog();
    static std::size_t INFO_count();
    static std::size_t WARNING_count();
    static std::size_t ERROR_count();
    static std::size_t CRITICAL_count();
    static void increase_counter(const Message& msg);
};


