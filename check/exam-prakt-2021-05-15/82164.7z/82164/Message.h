#pragma once
#include <iostream>
#include <string>

enum MessageTypes{
    UNKNOWN,
    INFO,
    WARNING,
    ERROR,
    CRITICAL
};

class Message{

    const MessageTypes type;
    const std::string description;

public:

    Message(MessageTypes type,std::string description);
    friend std::ostream& operator<<(std::ostream& ost,const Message& msg);
    short getType() const;
};