#pragma once
#include "Logger.h"

class Configuration{
    Configuration(std::string file);
    std::string file;
    Logger log;
public:
    Configuration(const Configuration& other) = delete;
    Configuration& operator=(const Configuration& other) = delete;
    static Configuration& getInstance(std::string path = "config.txt");
    Logger& getLogger();
};