#include "Logger.h"

std::size_t Logger::counter[4] = {0,};

Logger::Logger(std::string logFileName)
: log(logFileName,std::ios::app)
{}

Logger::~Logger(){
    log.close();
}

std::ofstream& Logger::getLog(){
    return log;
}

Logger& operator<<(Logger& obj,const Message& msg){
    obj.getLog()<<msg;
    Logger::increase_counter(msg);
    return obj;
}

std::size_t Logger::INFO_count()
{
    return counter[INFO - 1];
}

std::size_t Logger::WARNING_count()
{
    return counter[WARNING - 1];
}

std::size_t Logger::ERROR_count()
{
    return counter[ERROR - 1];
}

std::size_t Logger::CRITICAL_count()
{
    return counter[CRITICAL - 1];
}

void Logger::increase_counter(const Message& msg)
{
    counter[msg.getType() - 1]++;
}