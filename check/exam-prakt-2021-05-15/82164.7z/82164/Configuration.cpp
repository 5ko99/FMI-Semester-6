#include "Configuration.h"

Configuration::Configuration(std::string file)
: file(file),log(file){}

Configuration& Configuration::getInstance(std::string path)
{
    static Configuration singleton(path);
    return singleton;
}

Logger& Configuration::getLogger()
{
    return log;
}