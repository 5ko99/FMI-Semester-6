#include "Message.h"
#include "Logger.h"
#include <iostream>
Message::Message(Type _type, const std::string _description)
{
	type = _type;
	description = _description;
}

Type Message::get_type() const
{
	return type;
}

std::string Message::get_description() const
{
	return description;
}

std::ostream& operator<<(std::ostream& out, Message &rhs)
{
	out << rhs.type << " " << rhs.description << std::endl;
	return out;
}
