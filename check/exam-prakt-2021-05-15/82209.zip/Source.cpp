﻿// 
// СУ "Св. Климент Охридски"
// Факултет по математика и информатика
// Курс Обектно-ориентирано програмиране 2020/21
// Контролно по ООП-практикум
// 
// Име: Делчо Дичев
// ФН: 82209
// Специалност: КН
// Курс: Първи
// Административна група: 4
// Ден, в който се явявате на контролното: 15.05.2021
// Начален час на контролното: 09:00
// Кой компилатор използвате: Visual C++
//

#define _CRT_SECURE_NO_WARNINGS 

#include <cassert>
#include <cstring>
#include <string>
#include <fstream>
#include <iostream>

#include "Configuration.h"
int main(int argc,char* argv[])
{
	if (argc==1)
	{
		
		try
		{
			std::ifstream file(argv[0]);
		}
		catch (std::exception&)
		{
			std::cout << "The file can not be opened";
		}
		catch (...)
		{
			std::cout << "There are problems with opening the file, please try again!";
		}
	}
	else
	{
		try
		{
			std::ifstream file("config.txt");
		}
		catch (std::exception&)
		{
			std::cout << "The file can not be opened";
		}
		catch (...)
		{
			std::cout << "There are problems with opening the file, please try again!";
		}
	}

	//Configuration* fileConfig = Configuration::getIstance();
	Configuration* fileConfig;
	return 0;
}