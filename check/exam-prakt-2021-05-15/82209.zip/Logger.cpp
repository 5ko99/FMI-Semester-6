#include "Logger.h"
#include <iostream>
#include <fstream>
int Logger::genErrors = 0;
int Logger::genWarrings = 0;
int Logger::genCritical = 0;
int Logger::genInfo = 0;

int Logger::getNUmberOfError()
{
	return genErrors;
}

int Logger::getNumberOfInfo()
{
	return genInfo;
}

int Logger::getNumberOfCritical()
{
	return genCritical;
}

int Logger::getNUmberOfWarnings()
{
	return genWarrings;
}

void Logger::readFromfile(std::string fileName)
{
	std::fstream file(fileName,std::ios::app);
	if (!file.is_open())
	{
		std::cerr << "There is a problem in opening the file";
	}
	while (!file.eof())
	{
		file << text << std::endl;
	}
}

std::ostream& operator<<(std::ostream& out, Logger& rhs)
{
	out << rhs.text<<std::endl;
	return out;
}

