#pragma once
#include "Message.h"
#include "Logger.h"
#include <string>
#include <fstream>
class Configuration
{
private:
	static Configuration* istance;
	std::string fileName;
	Logger log;

	Configuration() = default;
	~Configuration()
	{
		delete istance;
	}
public:
	Configuration& operator=(const Configuration& rhs) = delete;
	Configuration(const Configuration& rhs) = delete;
	Configuration* getIstance()
	{
		if (istance==nullptr)
		{
			//istance = new Configuration();
		}
		return istance;
	}
};

