#include "Configuration.h"

//Configuration*::istance = nullptr;

