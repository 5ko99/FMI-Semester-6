#pragma once
#include <string>
//enum class for displaying the words not the numbers
enum Type {
	INFO,
	WARNING,
	ERROR,
	CRITICAL
};

class Message
{
private:
	Type type;
	std::string description;
public:
	Message(Type _type, const std::string _description);
	Type get_type() const;
	std::string get_description() const;
	friend std::ostream& operator<<(std::ostream& out, Message & rhs);
};

