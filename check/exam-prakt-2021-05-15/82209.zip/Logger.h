#pragma once
#include "Message.h"
#include <vector>
class Logger
{
private:
	static int genWarrings;
	static int genErrors;
	static int genInfo;
	static int genCritical;
	//std::vector<Message> messages;
	Message text;
public:
	Logger(Message& message):text(message)
	{
		//messages.push_back(message);
		if (message.get_type()==Type::WARNING)
		{
			genWarrings++;
		}
		else if (message.get_type() == Type::ERROR)
		{
			genErrors++;
		}
		else if (message.get_type() == Type::CRITICAL)
		{
			genCritical++;
		}
		else if (message.get_type() == Type::INFO)
		{
			genInfo++;
		}
	}
	static int getNUmberOfError();
	static int getNumberOfInfo();
	static int getNumberOfCritical();
	static int getNUmberOfWarnings();
	friend std::ostream& operator<<(std::ostream& out, Logger& rhs);
	void readFromfile(std::string fileName);
};