#pragma once
#include <iostream>

class Message{
private:
    const short type;
    const std::string description;
public:
    char typesAsString[4][10] = {"INFO","WARNING","ERROR","CRITICAL"};
    enum types{INFO,WARNING,ERROR,CRITICAL};

    const short getType() const;

    const std::string &getDescription() const;

    Message(short type, std::string description);
    friend std::ostream& operator<<(std::ostream& out, const Message& msg);
};