#pragma once
#include <iostream>
#include <fstream>
#include "Message.h"

class Logger{
private:
    static int errorTypes[4];
    std::string file;
public:
    Logger(std::string file);
    Logger& operator<<(const Message& msg);
};