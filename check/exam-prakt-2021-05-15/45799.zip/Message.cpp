#include "Message.h"

Message::Message(short type, std::string description) : type(type),description(description) {

}

std::ostream &operator<<(std::ostream &out, const Message &msg) {

    if(out.good()){
        out << msg.type << ": " << msg.description << std::endl;
    }else {
        throw std::invalid_argument("File stream is closed.");
    }

    return out;
}

const short Message::getType() const {
    return type;
}

const std::string &Message::getDescription() const {
    return description;
}

