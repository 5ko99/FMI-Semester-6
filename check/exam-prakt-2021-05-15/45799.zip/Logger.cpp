#include <cstring>
#include "Logger.h"

int Logger::errorTypes[4] = {0,0,0,0};

Logger::Logger(std::string file) : file(file) {
}

Logger &Logger::operator<<(const Message &msg) {

    std::ofstream out(this->file, std::ios::out | std::ios::app);
    std::string res = "";
    std::size_t writeSize = 0;
    if(out.good()){
        res.append(msg.typesAsString[msg.getType()]);
        res.append(": ");
        res.append(msg.getDescription().c_str());
        res.append("\n");

        writeSize = 2*sizeof(char) + strlen(msg.typesAsString[msg.getType()])*sizeof(char) + strlen(msg.getDescription().c_str())*sizeof(char) + 1;

        out.write(res.c_str(), writeSize);
        errorTypes[msg.getType()]++;
    }else {
       throw std::invalid_argument("File stream closed.");
    }

    out.close();
    return *this;
}


