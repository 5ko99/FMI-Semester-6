#include "Configuration.h"
#include <fstream>

Configuration::Configuration(std::string& fileName) : file(fileName)  {

}

const char *Configuration::getLogFile(std::string& fileName) {
    std::ifstream in(fileName.c_str(), std::ios::in | std::ios::beg);
    //todo find file len with seekg and tellg
    //todo allocate space for char*
    //todo call this func in ctor ...
}
