// 
// СУ "Св. Климент Охридски"
// Факултет по математика и информатика
// Курс Обектно-ориентирано програмиране 2020/21
// Контролно по ООП-практикум
// 
// Име: Teodor Hristov
// ФН: 45799
// Специалност: Informatics
// Курс: 1
// Административна група:4
// Ден, в който се явявате на контролното: 15.05
// Начален час на контролното: 09:00
// Кой компилатор използвате: Clang
//

// (Можете да изтриете този коментар след като го прочетете)
// Редът по-долу е специфичен за Visual C++.
// Ако използвате друг компилатор, можете да го изтриете.
// Тъй като strlen, strcmp и т.н. са дефинирани като deprecated,
// имате две възможности:
//
// * да използвате безопасните версии на тези функции
//   (strlen_s, strcmp_s и т.н.). В този случай можете да
//   изтриете дадената по-долу #define директива.
//
// * да дефинирате _CRT_SECURE_NO_WARNINGS преди да
//   включите съответните header файлове от стандартната
//   библиотека.
//
#define _CRT_SECURE_NO_WARNINGS

#include <cassert>
#include <cstring>
#include <iostream>
#include <string>

#include "Message.h"
#include "Logger.h"

int main()
{
    Message msg(Message::types(1),"asdasdasd");
    Message msg1(Message::types(2),"asdasdasd");
    Logger log("/home/tedo3637/CLionProjects/untitled6/cmake-build-debug/temp");
    log << msg << msg1;

    

    return 0;
}