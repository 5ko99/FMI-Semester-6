#pragma once
#include <iostream>
#include "Logger.h"

class Configuration{
private:
    std::string file;
    Logger log;

    Configuration(std::string);
    const char* getLogFile();
public:
    static Configuration& getInstance();

};