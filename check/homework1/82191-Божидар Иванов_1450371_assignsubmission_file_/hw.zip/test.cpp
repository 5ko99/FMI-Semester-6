#include "robinhood.h"

int main () {
    hash_table<std::string, std::string> table;
    for (uint32_t i = 0; i < 1024; i++) {
        table.insert(std::to_string(i), std::to_string(i));
    }
    std::cout << table.average_probe_count() << " " << table.capacity << std::endl;
}