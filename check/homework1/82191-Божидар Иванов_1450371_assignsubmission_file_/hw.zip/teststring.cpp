#define CATCH_CONFIG_MAIN
#include "catch2.hpp"
#include <string>
#include "string.h"

#define STREQUAL(str1, str2) REQUIRE((str1.capacity() >= str1.size() && str2.capacity() >= str2.size() && std::strcmp(str1.data(), str2.data()) == 0 && str1.size() == str2.size()));

// Coverage ~90%

TEST_CASE( "String tests", "[string]" ) {
    SECTION("test construction") {
        SECTION("char*") {
            SECTION("small") {
                String test("12345");
                std::string result("12345");
                STREQUAL(test, result);
            }
            SECTION("large") {
                std::string result(128, '1');
                String test(result.c_str());
                STREQUAL(test, result);
            }
        }
        SECTION("count, char") {
            SECTION("small") {
                String test(2, '1');
                std::string result(2, '1');
                STREQUAL(test, result);
            }
            SECTION("large") {
                String test(128, '1');
                std::string result(128, '1');
                STREQUAL(test, result);
            }
        }
        SECTION("move") {
            String test("1234");
            String test2 = std::move(test);
            REQUIRE((test.size() == 0 && test2.size() == 4 && std::strcmp(test2.c_str(), "1234") == 0));
        }
        SECTION("copy") {
            String test1("1234");
            String test2 = test1;
            STREQUAL(test1, test2);
            REQUIRE(test1.c_str() != test2.c_str());
        }
        SECTION("concat constructor") {
            SECTION("small") {
                String left("12345");
                const char* right = "6";
                String test(left, left.c_str(), left.size(), right, 1);
                std::string result("123456");
                STREQUAL(test, result);
            }
            SECTION("large") {
                String left(128, '1');
                const char* right = "6";
                String test(left, left.c_str(), left.size(), right, 1);
                std::string result = std::string(128, '1') + "6";
                STREQUAL(test, result);
            }
        }
        
    }
    SECTION("operators") {
        SECTION("==") {
            REQUIRE(String("1234") == String("1234"));
            REQUIRE(String("1234") == "1234");
            REQUIRE("1234" == String("1234"));
        }
        SECTION("<") {
            REQUIRE(String("1234") < String("1235"));
            REQUIRE(String("1234") < "1235");
            REQUIRE("1234" < String("1235"));
        }
        SECTION(">") {
            REQUIRE(String("1236") > String("1235"));
            REQUIRE(String("1236") > "1235");
            REQUIRE("1236" > String("1235"));
        }
        SECTION("+") {
            STREQUAL((String("1234") + "5"), (std::string("1234") + "5"));
            STREQUAL((String("1234") + '5'), (std::string("1234") + '5'));
            STREQUAL((String("1234") + String("5")), (std::string("1234") + std::string("5")));
        }
        SECTION("[]") {
            bool fl = true;
            String test(16, '1');
            for (uint32_t i = 0; i < 16; i++) {
                fl = test[i] != '1' ? false : true;
            }
            REQUIRE(fl);
        }
        SECTION("move") {
            String test("1234");
            String test2 = "123";
            test2 = std::move(test);
            REQUIRE((test.size() == 0 && test2.size() == 4 && std::strcmp(test2.c_str(), "1234") == 0));
        }
        SECTION("copy") {
            String test1("1234");
            String test2 = "123";
            test2 = test1;
            STREQUAL(test1, test2);
            REQUIRE(test1.c_str() != test2.c_str());
        }
    }
    SECTION("small String append") {
        SECTION("char") {
            String test = String("12345").append('6');
            std::string result = "12345"; result += "6";
            STREQUAL(test, result);
        }
        SECTION("char*") {
            String test = String("12345").append("6");
            std::string result = "12345"; result += "6";
            STREQUAL(test, result);
        }
        SECTION("string") {
            String test = String("12345").append(String("6"));
            std::string result = "12345"; result += "6";
            STREQUAL(test, result);
        }
    }
    SECTION("large String append") {
        SECTION("char") {
            String test = String(128, '1'); test.append("6");
            std::string result = std::string(128, '1'); result += "6";
            STREQUAL(test, result);
        }
        SECTION("char*") {
            String test = String(128, '1'); test.append('6');
            std::string result = std::string(128, '1'); result += "6";
            STREQUAL(test, result);
        }
        SECTION("string") {
            String test = String(128, '1'); test.append(String("6"));
            
            std::string result = std::string(128, '1'); result += "6";
            
            STREQUAL(test, result);
        }
    }
    SECTION("append transition") {
        String test(String::BUFF_SIZE - 1, '1'); test.append('1');
        std::string result(String::BUFF_SIZE, '1');
        STREQUAL(test, result);
    }
    SECTION("functions") {
        SECTION("clear") {
            String test = "12345";
            std::string result = "12345";
            test.clear(); result.clear();
            STREQUAL(test, result);
        }
        SECTION("push_back") {
            String test = "12345";
            std::string result = "12345";
            test.push_back(6); result.push_back(6);
            STREQUAL(test, result);
        }
        SECTION("pop_back") {
            String test = "12345";
            std::string result = "12345";
            test.pop_back(); result.pop_back();
            STREQUAL(test, result);
        }
        SECTION("front") {
            REQUIRE(std::string("1234").front() == String("1234").front());
        }
        SECTION("back") {
            REQUIRE(std::string("1234").back() == String("1234").back());
        }
        SECTION("empty") {
            REQUIRE(String().empty());
            REQUIRE(!String("123").empty());
        }
        SECTION("at") {
            SECTION("normal") {
                String test = "12345";
                std::string result = "12345";
                REQUIRE(test.at(3) == result.at(3));
            }
            SECTION("throw") {
                REQUIRE_THROWS(String().at(1));
            }
        }
    }
}