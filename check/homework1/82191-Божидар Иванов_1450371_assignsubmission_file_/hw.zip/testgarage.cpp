#define CATCH_CONFIG_MAIN
#include "catch2.hpp"
#include "Garage.h"

TEST_CASE("Vehicle") {
    SECTION("Vehicle") {
        Vehicle test("test1", "test", 1);
        REQUIRE(std::strcmp(test.registration(), "test1") == 0);
        REQUIRE(std::strcmp(test.description(), "test") == 0);
        REQUIRE(test.space() == 1);
    }
    SECTION("Registry") {
        SECTION("Basic") {
            Vehicle& test = VehicleRegistry::construct("test1", "test", 1);
            REQUIRE(std::strcmp(test.registration(), "test1") == 0);
            REQUIRE(std::strcmp(test.description(), "test") == 0);
            REQUIRE(test.space() == 1);
        }
        SECTION("Grow") { // this probably means DumbVector works
            for (uint32_t i = 0; i < 256; i++) {
                Vehicle& test = VehicleRegistry::construct("test1", "test", 1);
                REQUIRE_NOTHROW(std::strcmp(test.registration(), "test1") == 0);
                REQUIRE_NOTHROW(std::strcmp(test.description(), "test") == 0);
                REQUIRE_NOTHROW(test.space() == 1);
            }
        }
    }
}

/*
Garage(std::size_t size);
	~Garage();
    void insert(Vehicle& v);
	void erase(const char* registration);
	const Vehicle& at(std::size_t pos) const;
	const Vehicle& operator[](std::size_t pos) const { assert(pos < m_Allocated); return *m_Vehicles[pos]; }
    bool empty() const { return m_TakenCapacity == 0; }
    std::size_t size() const { return m_TakenCapacity; }
	void clear();
    const Vehicle* find(const char* registration) const;
*/

TEST_CASE("Garage") {
    Garage g(256);
    Vehicle v1("test1", "test", 123);
    Vehicle v2("test2", "test", 123);
    SECTION("insert") {
        SECTION("unique") {
            g.insert(v1);
            REQUIRE(g.size() == 1);
            REQUIRE(g.at(0) == v1);
            REQUIRE(g[0] == v1);
            g.clear();
        }
        SECTION("duplicate") {
            g.insert(v1);
            REQUIRE_THROWS(g.insert(v1));
            g.clear();
        }
    }
    SECTION("at") {
        g.insert(v1);
        REQUIRE(g.at(0) == v1);
        REQUIRE_THROWS(g.at(1));
        g.clear();
    }
    SECTION("clear") {
        g.insert(v1);
        g.clear();
        REQUIRE(g.size() == 0);
        REQUIRE_THROWS(g.at(0));
    }
    SECTION("empty") {
        g.clear();
        REQUIRE(g.empty());
    }
    SECTION("size") {
        g.clear();
        g.insert(v1);
        g.insert(v2);
        REQUIRE(g.size() == 2);
    }
    SECTION("find") {
        g.clear();
        g.insert(v1);
        g.insert(v2);
        REQUIRE(g.find("test1") == &v1);
        REQUIRE(g.find("test2") == &v2);
        REQUIRE(g.find("does not exist") == nullptr);
    }
    SECTION("move ctor") {
        Garage g(256);
        g.insert(v1);
        g.insert(v2);
        Garage g2 = std::move(g);
        REQUIRE(g2.size() == 2);
        REQUIRE((g2[0] == v1));
        REQUIRE((g2[1] == v2));
    }
    SECTION("move=") {
        Garage g(256);
        g.insert(v1);
        g.insert(v2);
        Garage g2(256);
        g2 = std::move(g);
        REQUIRE(g2.size() == 2);
        REQUIRE((g2[0] == v1));
        REQUIRE((g2[1] == v2));
        REQUIRE(g.size() == 0);
    }    
}