#pragma once

#include "Vehicle.h"

// Trqbvashe da e s robinhood hashing nooo....
// za hash na char* bez izpolzvane na std::string
// Assumes we are on 64-bit
// Prime and initial offset from http://www.isthe.com/chongo/tech/comp/fnv/index.html
class fnv1a
{
private:
  size_t m_State {};
public:
	constexpr fnv1a() noexcept
		: m_State(14695981039346656037UL) {} // initial offset
	
	constexpr void add(const void * const data, const std::size_t size) noexcept
	{
		auto acc = this->m_State;
		const auto* dat = static_cast<const unsigned char*>(data);
		for (size_t i = 0; i < size; ++i)
		{
			// signed char xd.....
			const auto next = std::size_t {dat[i]};
			acc = (acc ^ next) * 1099511628211UL; // prime
		}
		m_State = acc;
	}

	constexpr size_t digest() const noexcept
	{
		return m_State;
	}
};


static constexpr size_t hash(const char* data, const std::size_t size) noexcept {
	fnv1a hash;
	hash.add(data, size);
	return hash.digest();
}

class Garage {
public:
    Garage(std::size_t size);
	Garage(const Garage& other);
	Garage(Garage&& other);
	
	~Garage();
    void insert(Vehicle& v);
	void erase(const char* registration);
	const Vehicle& at(std::size_t pos) const;
	const Vehicle& operator[](std::size_t pos) const { assert(pos < m_VehicleCount); return *m_Vehicles[pos]; }
    bool empty() const { return m_TakenCapacity == 0; }
    std::size_t size() const { return m_VehicleCount; }
	void clear();
    const Vehicle* find(const char* registration) const;
	
	friend std::ostream& operator<<(std::ostream& stream, const Garage& garage);
	
	Garage& operator=(const Garage& other);
	Garage& operator=(Garage&& other);
    
    static constexpr size_t INITIAL_SIZE = 4;
private:
    std::size_t m_VehicleCount, m_Allocated, m_Capacity, m_TakenCapacity;
    size_t* m_Hashes;
    Vehicle** m_Vehicles;
};