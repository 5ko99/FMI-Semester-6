#pragma once

/*
Tazi implementaciq izpolzva Small String Optimization
Mislq che e podobno na tova v MSVC, no MSVC implementaciqtq ne e mnogo dobra
V Clang sizeof(String)=24, a small String e do 22 bytes
Pri men sizeof(String)=32, a small String e 16 bytes
TODO: iterators, operator>>, erase, insert, starts_with, ends_with, replace, find, reserve, shrink, copy, substr, resize
hash, allocators?, templated with type_traits, constexpr like c++20?
*/

#include <algorithm>
#include <cstddef>
#include <climits>
#include <cstring>
#include <cstdint>
#include <ostream>
#include <istream>
#include <iostream>
#include <assert.h>

class String
{
public:
	
	String()
	{
		m_Capacity = BUFF_SIZE - 1;
		m_Size = 0;
		m_Data.buf[0] = '\0';
	}
	
	String(const char* str)
	{
		assign(str, std::strlen(str));
	}
	
	String(size_t count, char c)
	{
		m_Capacity = BUFF_SIZE - 1;
		m_Size = 0;
		m_Data.buf[0] = '\0';
		
		char* const oldPtr = myPtr();
		if (count <= m_Capacity) {
            m_Size = count;
			memset(oldPtr, c, count);
            oldPtr[count] = '\0';
        }
		else
		{
			const std::size_t oldCapacity = m_Capacity;
			const std::size_t newCapacity = std::max(count, oldCapacity + oldCapacity / 2);
			try {
				char* const newPtr = new char[newCapacity + 1];m_Size = count;
				m_Capacity = newCapacity;
				memset(newPtr, c, count);
				newPtr[count] = '\0';
				m_Data.ptr = newPtr;
			} catch(std::bad_alloc& ex) {
				std::cerr << "could not allcoate string" << std::endl;
				throw;
			}
		}
	}
	
	String(const String& other) {
		assign(other.c_str(), other.size());
	}
	
	String(String&& other) {
		if (isLarge())
			delete[] m_Data.ptr;
		steal_content(other);
	}
	
	// concat constructor for operator+
	String(const String& left, const char* const leftPtr, const std::size_t leftSize, const char* const rightPtr, const std::size_t rightSize) : m_Data{}
	{
		size_t newSize = leftSize + rightSize;
		size_t newCapacity = BUFF_SIZE - 1;
		char* ptr = m_Data.buf;
		bool makeLarge = newCapacity < newSize;
		if (makeLarge) {
			newCapacity = std::max(newSize, BUFF_SIZE + BUFF_SIZE / 2);
			try {
				ptr = new char[newCapacity + 1];
				m_Data.ptr = ptr;
			}
			catch(std::bad_alloc& ex) {
				std::cerr << "could not allocate string" << std::endl;
				throw;
			}
		}
		
		m_Size = newSize;
		m_Capacity = newCapacity;
		std::strncpy(ptr, leftPtr, leftSize);
		std::strncpy(ptr + leftSize, rightPtr, rightSize);
		ptr[newSize] = '\0';
	}
	
	~String()
	{
        if (isLarge()) {
            delete[] m_Data.ptr;
        }
	}
	
	String& operator+=(const String& rhs) { return append(rhs); }	
	String& operator+=(const char* rhs) { return append(rhs, std::strlen(rhs)); }
	String& operator+=(char c) { return append(c); }
	String& operator+=(std::initializer_list<char> list) {
		return append(list.begin(), list.size());
	}
	// Copy operator
	String& operator=(const String& rhs) {
		if (this != &rhs)
			return assign(rhs.c_str(), rhs.size());
		return *this;
	}
	
	String& operator=(const char* rhs) {
		return assign(rhs, std::strlen(rhs));
	}
	
	String& operator=(std::initializer_list<char> list) {
		return assign(list.begin(), list.size());
	}
	
	String& operator=(String&& rhs) {
		if (isLarge())
			delete[] m_Data.ptr;
		steal_content(rhs);
		return *this;
	}

	char& operator[](const std::size_t pos) noexcept { assert(m_Size > pos); return myPtr()[pos]; }
	const char& operator[](const std::size_t pos) const noexcept { assert(m_Size > pos); return myPtr()[pos]; }
	
	String& append(const String& other)
	{
		return append(other.c_str(), other.size());
	}
	
	String& append(char c)
	{
		return append(&c, 1);
	}
	
	String& append(const char* str, std::size_t len)
	{
		// String fits
		size_t oldSize = m_Size;
		char* const oldPtr = myPtr();
        if (len <= m_Capacity - oldSize) {
            m_Size = oldSize + len;
            std::strncpy(oldPtr + oldSize, str, len);
            oldPtr[oldSize + len] = '\0';
            return *this;
        }
		// grow the String
        // String bigger than address space
		assert(PTRDIFF_MAX - oldSize > len);

        const std::size_t newSize = oldSize + len;
        const std::size_t oldCapacity = m_Capacity;
		// Grow to max size if too big?
        const std::size_t newCapacity = std::max(newSize, oldCapacity + oldCapacity / 2); // MSVC growth - factor 1.5
		char* newPtr = nullptr;
		try {
			newPtr = new char[newCapacity + 1];
		} catch(std::bad_alloc& ex) {
			std::cerr << "could not allocate string" << std::endl;
			throw;
		}
		
        m_Size = newSize;
		m_Capacity = newCapacity;
        char* newRaw = newPtr;
		if (BUFF_SIZE <= oldCapacity) {
			std::strncpy(newPtr, oldPtr, oldSize);
			std::strncpy(newPtr + oldSize, str, len);
			newPtr[oldSize + len] = '\0';
			delete[] oldPtr;
			m_Data.ptr = newPtr;
		}
		else
		{
			std::strncpy(newPtr, oldPtr, oldSize);
			std::strncpy(newPtr + oldSize, str, len);
			newPtr[oldSize + len] = '\0';
			m_Data.ptr = newPtr;
		}
		return *this;
	}
	
private:
	void steal_content(String& other) noexcept {
		//steal rhs
		if (other.isLarge()) {
			m_Data.ptr = other.m_Data.ptr;
			other.m_Data.ptr = nullptr;
		} else {
			std::strncpy(m_Data.buf, other.m_Data.buf, other.m_Size + 1);
		}
		m_Size = other.m_Size;
		m_Capacity = other.m_Capacity;
		// fix rhs
		other.m_Capacity = BUFF_SIZE - 1;
		other.m_Size = 0;
		other.m_Data.buf[0] = '\0';
	}
	
	const char* myPtr() const noexcept {
        const char* res = m_Data.buf;
        if (isLarge()) {
            res = m_Data.ptr;
        }
        return res;
    }
	
	char* myPtr() noexcept {
        char* res = m_Data.buf;
        if (isLarge()) {
            res = m_Data.ptr;
        }
        return res;
    }
	
	String& assign(const char* str, std::size_t len) {
		m_Capacity = BUFF_SIZE - 1;
		m_Size = 0;
		m_Data.buf[0] = '\0';
		
		char* const oldPtr = myPtr();
		if (len <= m_Capacity) {
            m_Size = len;
			std::strncpy(oldPtr, str, len);
            oldPtr[len] = '\0';
        }
		else
		{
			const std::size_t oldCapacity = m_Capacity;
			const std::size_t newCapacity = std::max(len, oldCapacity + oldCapacity / 2);
			try {
				char* const newPtr = new char[newCapacity + 1];
				m_Size = len;
				m_Capacity = newCapacity;
				std::strncpy(newPtr, str, len);
				newPtr[len] = '\0';
				m_Data.ptr = newPtr;
			} catch(std::bad_alloc& ex) {
				std::cerr << "could not allocate string" << std::endl;
				throw;
			}
		}
		return *this;
	}
	
	bool isLarge() const
	{
		return BUFF_SIZE <= m_Capacity;
	}
	
public:
	size_t size() const noexcept { return m_Size; }
	size_t length() const noexcept { return m_Size; }
	size_t capacity() const noexcept { return m_Capacity; }
	char* data() noexcept { return myPtr(); }
	bool empty() const noexcept { return m_Size == 0; }
	void push_back(char c) noexcept { append(c); }
	void clear() noexcept { myPtr()[m_Size = 0] = '\0'; }
	void pop_back() noexcept {
		assert(m_Size > 0);
		myPtr()[--m_Size] = '\0'; 
	}
	
	char& at(std::size_t pos) {
		if (m_Size <= pos)
			throw std::out_of_range("invlaid String position");
		return myPtr()[pos]; 
	}
	char& front() noexcept { return myPtr()[0]; }
	char& back() noexcept  { return myPtr()[m_Size - 1]; }
	
	const char* c_str() const noexcept { return myPtr(); }
	const char* data() const noexcept { return myPtr(); }
	const char& at(size_t pos) const noexcept { return myPtr()[pos]; }
	const char& front() const noexcept { return myPtr()[0]; }
	const char& back() const noexcept { return myPtr()[m_Size - 1]; }
	
	friend std::ostream& operator<<(std::ostream& os, const String& dt);
	
	static constexpr std::size_t BUFF_SIZE = 16;
private:
	union Data {
        char buf[BUFF_SIZE];
        char* ptr;
    } m_Data;
	
	size_t m_Size = 0, m_Capacity = 0;
};

inline String operator+(const String& lhs, const String& rhs) {
	return String(lhs, lhs.c_str(), lhs.size(), rhs.c_str(), rhs.size());
}

inline String operator+(const String& lhs, const char* rhs) {
	return String(lhs, lhs.c_str(), lhs.size(), rhs, strlen(rhs));
}

inline String operator+(const char* lhs, const String& rhs) {
	return String(rhs, lhs, strlen(lhs), rhs.c_str(), rhs.size());
}

inline String operator+(const String& lhs, char c) {
	return String(lhs, lhs.c_str(), lhs.size(), &c, 1); 
}

inline String operator+(char c, const String& rhs) {
	return String(rhs, &c, 1, rhs.c_str(), rhs.size());
}

inline bool operator==(const String& lhs, const String& rhs) noexcept {
	return std::strcmp(lhs.c_str(), rhs.c_str()) == 0;
}
inline bool operator==(const char* lhs, const String& rhs) noexcept {
	return std::strcmp(lhs, rhs.c_str()) == 0; 
}

inline bool operator==(const String& lhs, const char* rhs) noexcept {
	return std::strcmp(lhs.c_str(), rhs) == 0; 
}

inline bool operator!=(const String& lhs, const String& rhs) noexcept {
	return !(lhs==(rhs)); 
}

inline bool operator!=(const char* lhs, const String& rhs) noexcept {
	return !(lhs==(rhs)); 
}

inline bool operator!=(const String& lhs, const char* rhs) noexcept {
	return !(lhs==(rhs)); 
}

inline bool operator<(const String& lhs, const String& rhs) { return std::strcmp(lhs.c_str(), rhs.c_str()) < 0; }
inline bool operator<(const char* lhs, const String& rhs) { return std::strcmp(lhs, rhs.c_str()) < 0; }
inline bool operator<(const String& lhs, const char* rhs) { return std::strcmp(lhs.c_str(), rhs) < 0; }

inline bool operator>(const String& lhs, const String& rhs) { return std::strcmp(lhs.c_str(), rhs.c_str()) > 0; }
inline bool operator>(const char* lhs, const String& rhs) { return std::strcmp(lhs, rhs.c_str()) > 0; }
inline bool operator>(const String& lhs, const char* rhs) { return std::strcmp(lhs.c_str(), rhs) > 0; }

inline bool operator<=(const String& lhs, const String& rhs) { return !(rhs < lhs); }
inline bool operator<=(const char* lhs, const String& rhs) { return !(rhs < lhs); }
inline bool operator<=(const String& lhs, const char* rhs) { return !(rhs < lhs); }

inline bool operator>=(const String& lhs, const String& rhs) { return !(rhs > lhs); }
inline bool operator>=(const char* lhs, const String& rhs) { return !(rhs > lhs); }
inline bool operator>=(const String& lhs, const char* rhs) { return !(rhs > lhs); }

inline std::ostream& operator<<(std::ostream& os, const String& str)
{
	os << str.myPtr();
    return os;
}

#include <cctype>
//TODO: stream width
inline std::istream& operator>>(std::istream& is, String& str)
{	std::istream::iostate state = std::istream::goodbit;
	bool changed = false;
	std::size_t size;
	str.clear();
	char s;
	int iter = 10;
	for (; 0 < size; size--) {
		is.get(s);
		if (s == ' ' || s == '\r' || s == '\n') {
			break; // whitespace, quit
		} else { // add character to string
			str.push_back(s);
			changed = true;
		}
	}
	return is;
}