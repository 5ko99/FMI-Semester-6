#include "Vehicle.h"

Vehicle& VehicleRegistry::construct(const char* registration, const char* desc, std::size_t space) {
    return getInstance().m_Vehicles.push_back(new Vehicle(registration, desc, space));
}