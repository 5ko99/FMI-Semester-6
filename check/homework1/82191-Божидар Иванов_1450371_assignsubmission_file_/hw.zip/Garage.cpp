#include <iostream>

#include "Garage.h"

Garage::Garage(std::size_t size) : m_Capacity(size), m_VehicleCount(0), m_TakenCapacity(0), m_Allocated(INITIAL_SIZE) {
    m_Vehicles = new Vehicle*[INITIAL_SIZE];
    m_Hashes = new size_t[INITIAL_SIZE];
}

Garage::Garage(const Garage& other) {
    m_TakenCapacity = other.m_TakenCapacity;
    m_VehicleCount = other.m_VehicleCount;
    m_Capacity = other.m_Capacity;
    m_Allocated = other.m_Allocated;
    
    m_Vehicles = new Vehicle*[other.m_Allocated];
    m_Hashes = new size_t[other.m_Allocated];    
    std::memcpy(m_Vehicles, other.m_Vehicles, sizeof(Vehicle*) * m_Allocated);
    std::memcpy(m_Hashes, other.m_Hashes, sizeof(size_t) * m_Allocated);
}

Garage::Garage(Garage&& other) {
    m_TakenCapacity = other.m_TakenCapacity;
    m_VehicleCount = other.m_VehicleCount;
    m_Capacity = other.m_Capacity;
    m_Allocated = other.m_Allocated;
    
    m_Vehicles = other.m_Vehicles;
    m_Hashes = other.m_Hashes;
    other.m_Hashes = nullptr;
    other.m_Vehicles = nullptr;
    
    other.m_TakenCapacity = 0;
    other.m_VehicleCount = 0;
    other.m_Capacity = 0;
    other.m_Allocated = INITIAL_SIZE;
}

Garage& Garage::operator=(const Garage& other) {
    if (this != &other) {
        if (m_Vehicles != nullptr) {
            delete[] m_Vehicles;
        }
        if (m_Hashes != nullptr) {
            delete[] m_Hashes;
        }
        m_TakenCapacity = other.m_TakenCapacity;
        m_VehicleCount = other.m_VehicleCount;
        m_Capacity = other.m_Capacity;
        m_Allocated = other.m_Allocated;

        m_Vehicles = new Vehicle * [other.m_Allocated];
        m_Hashes = new size_t[other.m_Allocated];
        std::memcpy(m_Vehicles, other.m_Vehicles, sizeof(Vehicle*) * m_Allocated);
        std::memcpy(m_Hashes, other.m_Hashes, sizeof(size_t) * m_Allocated);
    }
    return *this;
}

Garage& Garage::operator=(Garage&& other) {
    if (m_Vehicles != nullptr) {
        delete[] m_Vehicles;
    }
    if (m_Hashes != nullptr) {
        delete[] m_Hashes;
    }
    m_TakenCapacity = other.m_TakenCapacity;
    m_VehicleCount = other.m_VehicleCount;
    m_Capacity = other.m_Capacity;
    m_Allocated = other.m_Allocated;

    m_Vehicles = other.m_Vehicles;
    m_Hashes = other.m_Hashes;
    other.m_Hashes = nullptr;
    other.m_Vehicles = nullptr;

    other.m_TakenCapacity = 0;
    other.m_VehicleCount = 0;
    other.m_Capacity = 0;
    other.m_Allocated = INITIAL_SIZE;
    return *this;
}

Garage::~Garage() {
    delete[] m_Hashes;
    delete[] m_Vehicles;
}

void Garage::insert(Vehicle& v) {
    const Vehicle* veh = find(v.registration());
    if (veh != nullptr) {
        throw std::runtime_error("Vehicle already in garage!");
    }
    if (m_Capacity < m_TakenCapacity + v.space()) {
        throw std::runtime_error("Garage capacity exceeded!");
    }

    for (uint32_t i = 0; i < m_VehicleCount; i++) {
        if (m_Hashes[i] == 0) {
            m_Hashes[i] = hash(v.registration(), std::strlen(v.registration()));
            m_Vehicles[i] = &v;
            m_VehicleCount += 1;
            m_TakenCapacity += v.space();
            return;
        }
    }
    
    if (m_VehicleCount >= m_Allocated) {
        try {
            size_t* tempHashes = new size_t[m_Allocated * 2];
            std::memcpy(tempHashes, m_Hashes, sizeof(size_t) * m_Allocated);
            delete[] m_Hashes;
            m_Hashes = tempHashes;
            
            Vehicle** tempVehicles = new Vehicle*[m_Allocated * 2];
            std::memcpy(tempVehicles, m_Vehicles, sizeof(Vehicle*) * m_Allocated);
            delete[] m_Vehicles;
            m_Vehicles = tempVehicles;
            m_Allocated *= 2;
        }
        catch(std::bad_alloc& ba) {
            std::cerr << "bad_alloc: " << ba.what() << std::endl;
            throw;
        }
    }
    m_Hashes[m_VehicleCount] = hash(v.registration(), std::strlen(v.registration()));
    m_Vehicles[m_VehicleCount] = &v;
    m_VehicleCount += 1;
    m_TakenCapacity += v.space();
}

void Garage::erase(const char* registration) {
    size_t hh = hash(registration, strlen(registration));
    for (uint32_t i = 0; i < m_VehicleCount; i++)
        if (m_Hashes[i] == hh) {
            m_Hashes[i] = m_Hashes[m_VehicleCount - 1];
            m_Vehicles[i] = m_Vehicles[m_VehicleCount - 1];
        }
    m_VehicleCount--;
}

// size in here?
const Vehicle* Garage::find(const char* registration) const {
    size_t hh = hash(registration, strlen(registration));
    for (uint32_t i = 0; i < m_VehicleCount; i++)
        if (m_Hashes[i] == hh) return m_Vehicles[i];
    
    return nullptr;
}

void Garage::clear() {
    for (uint32_t i = 0; i < m_VehicleCount; i++) {
        m_Vehicles[i] = nullptr;
        m_Hashes[i] = 0;
    }
    m_TakenCapacity = 0; m_VehicleCount = 0;
}

const Vehicle& Garage::at(std::size_t pos) const {
    if (pos >= m_VehicleCount) {
        throw std::out_of_range("index out of range");
    }
    return *m_Vehicles[pos];
}
