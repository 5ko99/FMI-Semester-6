#pragma once

#include <cstdint>
#include "string.h"

class Vehicle {
    public: 
        Vehicle(const char* registration, const char* description, std::size_t space)
            : m_Registration(registration), m_Description(description), m_Space(space) {
        }
        
        const char* registration() const { return m_Registration.c_str(); }
        const char* description() const { return m_Description.c_str(); }
        std::size_t space() const { return m_Space; }
        
        bool operator==(const Vehicle& other) const {
            return m_Registration == other.m_Registration && m_Description == other.m_Description && m_Space == other.m_Space;
        }
        
    private:
        String m_Registration;
        String m_Description;
        std::size_t m_Space;
};

// Tozi class go priemame che raboti
// ama si pritejava neshtata
// Mola vi sa vector
class DumbVector {
    public:
        DumbVector() : m_Capacity(8), m_Size(0) { m_Data = new Vehicle*[m_Capacity]; }
        ~DumbVector() { for (uint32_t i = 0; i < m_Size; i++) { delete m_Data[i]; } delete[] m_Data; }
        Vehicle& push_back(Vehicle* data) {
            if (m_Capacity == m_Size) {
                m_Capacity *= 2;
                Vehicle** tmp = new Vehicle*[m_Capacity];
                memcpy(tmp, m_Data, sizeof(Vehicle*) * m_Size);
                delete[] m_Data;
                m_Data = tmp;
            }
            m_Data[m_Size++] = data;
            return *m_Data[m_Size - 1];
        }
    private:
        std::size_t m_Size, m_Capacity;
        Vehicle** m_Data;
};

class VehicleRegistry {
    public:
        static VehicleRegistry& getInstance()
        {
            static VehicleRegistry instance;
            return instance;
        }
    private:
        VehicleRegistry() {}
        
        DumbVector m_Vehicles;
    public:
        VehicleRegistry(VehicleRegistry const&) = delete;
        void operator=(VehicleRegistry const&) = delete;
        
        static Vehicle& construct(const char* registartion, const char* desc, std::size_t space);
};