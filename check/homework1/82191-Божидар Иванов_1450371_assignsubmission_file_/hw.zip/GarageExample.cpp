#include <iostream>

#include "string.h"
#include "Garage.h"

#define GARAGE_LINES 3

std::ostream& operator<<(std::ostream& stream, const Garage& garage) {
    std::cout << "|";
    for (int i = 0; i < GARAGE_LINES; i++) {
        for (int j = 0; j < garage.m_VehicleCount; j++) {
            if (garage.m_Vehicles[j])
                std::cout << garage.m_Vehicles[j]->registration() << "|";
            else
                std::cout << "empty" << "|";
        }
        std::cout << std::endl << (i != GARAGE_LINES - 1 ? "|" : "");
    }
    return stream;
}

int main () {
    std::cout << "USAGE: " << std::endl;
    std::cout << "IMPROPER USE OF COMMANDS MAY LEAD TO PROBLEMS" << std::endl;
    std::cout << "garage [capacity] - creates a garage with the specified capacity and switches our current garage to it." << std::endl;
    std::cout << "insert [registration, description, space] - inserts a vehicle into the garage we are using." << std::endl;
    std::cout << "print - prints the garage we are using." << std::endl;
    std::cout << "find [registration] - finds the car(if it exists) in the garage we are using." << std::endl;
    std::cout << "erase [registration] - removes the car(if it exists) from the garage we are using." << std::endl;
    std::cout << "size - prints the size of the garage we are using." << std::endl;
    
    String cmd;
    Garage* garage = nullptr;
    while (cmd != "exit" && cmd != "quit") {
        std::cin >> cmd;
        if (cmd == "") continue;
        if (cmd == "garage") {
            if (garage != nullptr) {
                delete garage;
            }
            String tmp;
            std::cin >> tmp;
            try {
                garage = new Garage(std::atoi(tmp.c_str()));
                std::cout << "new garage created" << std::endl;
            }
            catch(std::bad_alloc& ex) {
                std::cout << "could not create new garage" << std::endl;
                throw;
            }            
        } else if (cmd == "insert") {
            if (garage == nullptr) {
                std::cout << "garage not created" << std::endl;
                continue;
            }
            String reg, desc;
            std::size_t size;
            std::cin >> reg >> desc >> size;
            try {
                Vehicle& v = VehicleRegistry::construct(reg.c_str(), desc.c_str(), size);
                garage->insert(v);
            } catch(std::runtime_error& ex) {
                std::cout << ex.what() << std::endl;
                std::cin.clear();
            }
        } else if (cmd == "print") {
            if (garage == nullptr) {
                std::cout << "garage not created" << std::endl;
                continue;
            }
            std::cout << *garage;
        } else if (cmd == "find") {
            if (garage == nullptr) {
                std::cout << "garage not created" << std::endl;
                continue;
            }
            String reg;
            std::cin >> reg;
            const Vehicle* v = garage->find(reg.c_str());
            if (v == nullptr)
                std::cout << "vehicle not in garage" << std::endl;
            std::cout << "registration: " << v->registration() << ", description: " << v->description() << ", space" << v->space() << std::endl;
        } else if (cmd == "erase") {
            if (garage == nullptr) {
                std::cout << "garage not created" << std::endl;
                continue;
            }
            String reg;
            std::cin >> reg;
            garage->erase(reg.c_str());
            std::cout << "I did my best to remove the vehicle but due to the signature of the desired funciton we will never know what happened" << std::endl;
        } else if (cmd == "size") {
            if (garage == nullptr) {
                std::cout << "garage not created" << std::endl;
                continue;
            }
            std::cout << garage->size() << std::endl;
        } else {
            std::cout << "unknown command. see usage" << std::endl;
        }
    }
    if (garage)
        delete garage;
}