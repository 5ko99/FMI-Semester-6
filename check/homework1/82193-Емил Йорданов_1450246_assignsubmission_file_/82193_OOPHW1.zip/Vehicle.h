#include "MyString.h"

#ifndef VEHICLE_H
#define VEHICLE_H

class Vehicle{
    private:
        MyString vehicleRegistration;
        MyString vehicleDescription;
        size_t vehicleSpaces = 0;
    public:
        Vehicle(const char* registration, const char* description, std::size_t space);
        const char* registration() const;
        const char* description() const;
        std::size_t space() const;
};

#endif