#define CATCH_CONFIG_MAIN 
#include<cstring>

#include "catch2.hpp"
#include "MyString.h"
#include "Vehicle.h"
#include "Garage.h"
#include "VehicleAllocator.h"

TEST_CASE("MyString", "[myString]"){
    SECTION("[1] Copy constructor test") {
        MyString firstString("Sentence for test");
        MyString secondString(firstString);

        REQUIRE(secondString.size() == firstString.size());
        REQUIRE(secondString.at(1) == firstString.at(1));
        REQUIRE(secondString.empty() == false);
    }

    SECTION("[2] Constructor test with parameters") {
        MyString firstString("Sentence for test");
        
        REQUIRE(firstString.size() == 17);
        REQUIRE(firstString.front() == 'S');
        REQUIRE(firstString.empty() == false);
    }

    SECTION("[3] '=' operator test") {
        MyString firstString("Sentence for test");
        MyString secondString;

        secondString = firstString;

        REQUIRE(firstString.size() == secondString.size());
        REQUIRE(secondString.back() == 't');
        REQUIRE(secondString.empty() == false);
    }

    SECTION("[4] at() test") {
        MyString firstString("Sentence for test");

        REQUIRE(firstString.at(5) == 'n');
        REQUIRE_THROWS(firstString.at(20));
        REQUIRE_THROWS(firstString.at(-10));
    }

    SECTION("[5] operator[]() test") {
        MyString firstString("Sentence for test");

        REQUIRE(firstString[5] == 'n');
    }

    SECTION("[6] front() test") {
        MyString firstString("Sentence for test");

        REQUIRE(firstString.front() == 'S');
        REQUIRE(firstString.empty() == false);
    }

    SECTION("[7] back() test") {
        MyString firstString("Sentence for test");

        REQUIRE(firstString.back() == 't');
        REQUIRE(firstString.empty() == false);
    }

    SECTION("[8] empty() test") {
        MyString firstString("Sentence for test");
        MyString secondString("");

        REQUIRE(firstString.empty() == false);
        REQUIRE(secondString.empty() == true);
    }

    SECTION("[9] size() test") {
        MyString firstString("Sentence for test");

        REQUIRE(firstString.size() == 17);
    }

    SECTION("[10] clear() test") {
        MyString firstString("Sentence for test");

        firstString.clear();

        REQUIRE(firstString.at(0) == '\0');
    }

    SECTION("[11] push_back() test") {
        MyString firstString("Sentence for test");

        firstString.push_back('a');

        REQUIRE(firstString.size() == 18);
        REQUIRE(firstString.back() == 'a');
    }

    SECTION("[12] pop_back() test") {
        MyString firstString("Sentence for test");

        firstString.pop_back();

        REQUIRE(firstString.back() == 's');
        REQUIRE(firstString.size() == 16);
    }

    SECTION("[13] += operator with char test") {
        MyString firstString("Sentence for test");

        firstString += '?';

        REQUIRE(firstString.size() == 18);
        REQUIRE(firstString.back() == '?');
    }

    SECTION("[14] += operator with object test") {
        MyString firstString("Sentence for test");
        MyString secondString("Hello World");
  
        firstString += secondString;

        REQUIRE(firstString.back() == 'd');
        REQUIRE(firstString.size() == 29);
    }

    SECTION("[15] + operator with char test") {
        MyString firstString;
        MyString secondString("Hello World");

        firstString = secondString + '.';

        REQUIRE(firstString.size() == 12);
        REQUIRE(firstString.back() == '.');
    }

    SECTION("[16] + operator with object test") {
        MyString firstString("Sentence for test");
        MyString secondString;
        MyString thirdString("Hello World");

        secondString = firstString + thirdString;

        REQUIRE(secondString.back() == 'd');
        REQUIRE(secondString.size() == 20);
    }

    SECTION("[17] c_str() test") {
        MyString firstString("Sentence for test");
        const char* pointerTest;

        pointerTest = firstString.c_str();

        REQUIRE(pointerTest[strlen(pointerTest)] == '\0');

        delete[] pointerTest;
    }

    SECTION("[18] == operator test") {
        MyString firstString("Sentence for test");
        MyString secondString("Sentence for test");

        REQUIRE(firstString == secondString);
    }

    SECTION("[19] < operator test") {
        MyString firstString("Sentence for test");
        MyString secondString("Sentence for test!");

        REQUIRE(firstString < secondString);
    }
}

TEST_CASE("Vehicle", "[Vehicle]") {
    Vehicle vehicle("BT4347BT", "The car is Opel Astra 1.6", 1);

    SECTION("[1] registration() test") {
        REQUIRE(strcmp(vehicle.registration(), "BT4347BT") == 0);
    }

    SECTION("[2] description() test") {
        REQUIRE(strcmp(vehicle.description(), "The car is Opel Astra 1.6") == 0);
    }

    SECTION("[3] space() test") {
        REQUIRE(vehicle.space() == 1);
    }
}

TEST_CASE("Garage", "[Garage]") {
    SECTION("[1] Constructor test") {
        Garage garage(10);

        REQUIRE(garage.size() == 0);
        REQUIRE(garage.empty() == true);
    }

    SECTION("[2] Copy constructor test") {
        VehicleAllocator vehicle(10);
        Garage garage1(10);
        
        garage1.insert(*(vehicle.allocate("BT4347BT", "Opel Astra 1.6", 1)));

        Garage garage2(garage1);

        REQUIRE(garage1.size() == garage2.size());
        REQUIRE(strcmp(garage1.at(0).description(), garage2.at(0).description()) == 0);
        REQUIRE(strcmp(garage1.at(0).registration(), garage2.at(0).registration()) == 0);
        REQUIRE(garage1.at(0).space() == garage2.at(0).space());
        REQUIRE(garage2.empty() == false);
    }
}

TEST_CASE("VehicleAllocator", "[vehicleAllocator]") {

    SECTION("[1] Constructor test") {
        VehicleAllocator vehicle(10);

        REQUIRE(vehicle.size() == 10);
        REQUIRE(vehicle.count() == 0);
        REQUIRE(vehicle.empty() == true);
    }

    SECTION("[2] allocate() test") {
        Garage garage(10);
        VehicleAllocator vehicle(10);

        const char* registration = "EB1396BA";
        const char* description = "Renault Scenic 2.0";
        size_t spaces = 2;
        
        garage.insert(*(vehicle.allocate(registration, description, spaces)));   

        REQUIRE(vehicle.size() == 10);
        REQUIRE(vehicle.count() == 1);
        REQUIRE(vehicle.empty() == false);  
    }
}