#include<iostream>

#include "VehicleAllocator.h"
#include "Vehicle.h"

VehicleAllocator::VehicleAllocator(std::size_t size) {
    arraySize = size;
    vehiclesCount = 0;

    vehicles = new Vehicle*[arraySize];

    for(int iterator = 0; iterator < arraySize; iterator++) {
        vehicles[iterator] = nullptr;
    }
}

void VehicleAllocator::copy(const VehicleAllocator& other) {
    arraySize = other.arraySize;
    vehiclesCount = other.vehiclesCount;

    vehicles = new Vehicle*[arraySize];

    for(int iterator = 0; iterator < vehiclesCount; iterator++) {
        vehicles[iterator] = new Vehicle(*(other.vehicles[iterator]));
    }
}

VehicleAllocator::VehicleAllocator(const VehicleAllocator& other) {
    copy(other);
}

VehicleAllocator& VehicleAllocator::operator =(const VehicleAllocator& other) {
    if(this != &other) {
        copy(other);
    }

    return *this;
}

Vehicle* VehicleAllocator::allocate(const char* registration, const char* description, std::size_t spaces) {
    if(arraySize <= vehiclesCount) {
        Vehicle** newArray = new Vehicle*[arraySize * 2];

        for(int iterator = 0; iterator < vehiclesCount; iterator++) {
            newArray[iterator] = vehicles[iterator];
        }

        delete[] vehicles;

        vehicles = newArray;
        arraySize *= 2;
    }

    vehicles[vehiclesCount] = new Vehicle(registration, description, spaces);
    arraySize++;

    return vehicles[vehiclesCount - 1];
}

std::size_t VehicleAllocator::size() const {
    return arraySize;
}

bool VehicleAllocator::empty() const {
    if(vehicles[0] == nullptr) {
        return true;
    }

    return false;
}

std::size_t VehicleAllocator::count() const {
    return vehiclesCount;
}

VehicleAllocator::~VehicleAllocator(){
    for(int iterator = 0; iterator < vehiclesCount; iterator++) {
        delete[] vehicles[iterator];
    }

    delete[] vehicles;
}