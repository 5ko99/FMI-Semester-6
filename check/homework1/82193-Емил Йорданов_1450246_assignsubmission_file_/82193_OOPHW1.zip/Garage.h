#include "MyString.h"
#include "Vehicle.h"

#ifndef GARAGE_H
#define GARAGE_H

class Garage {
    private:
        size_t usedSpaces = 0;
        size_t garageCapacity = 0;
        int vehiclesCount = 0;
        Vehicle **vehicles = nullptr;
        void copy(const Garage& other);
    public:
        Garage(std::size_t size);
        Garage(const Garage& other);
        Garage& operator =(const Garage& other);
        ~Garage();
        void insert(Vehicle& v);
        void erase(const char* registration);
        const Vehicle& at(std::size_t pos) const;
        const Vehicle& operator [](std::size_t pos) const;
        bool empty() const;
        std::size_t size() const;
        void clear();
        const Vehicle* find(const char* registration) const;
};

#endif