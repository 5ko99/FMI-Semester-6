#include<iostream>
#include<cstring>
#include<cassert>
#include<exception>

#include"Garage.h"

Garage::Garage(std::size_t size) {
    garageCapacity = size;
    
    usedSpaces = 0;
    vehiclesCount = 0;

    vehicles = new Vehicle*[garageCapacity];

    // Fills array with 'null' vehicles
    for(int iterator = 0; iterator < garageCapacity; iterator++) {
        vehicles[iterator] = nullptr;
    }
}

void Garage::copy(const Garage& other) {
    this->garageCapacity = other.garageCapacity;
    this->vehiclesCount = other.vehiclesCount;
    this->usedSpaces = other.usedSpaces;

    this->vehicles = new Vehicle*[this->garageCapacity];

    if(this->vehicles) {
        for(int iterator = 0; iterator < vehiclesCount; iterator++) {
            this->vehicles[iterator] = other.vehicles[iterator];
            if(!this->vehicles[iterator]) {
                std::cout << "Not enough memory for next vehicle. " << iterator - 1 << " vehicles were added." << std::endl;
                // Stops cycle if there is not enough memory for the next vehicle
                return;
            }
        }
    }
}

Garage& Garage::operator = (const Garage& other) {
    if(this != &other) {
        copy(other);
    }

    return *this;
}

Garage::Garage(const Garage& other) {
    copy(other);
}

void Garage::insert(Vehicle& v) {
    try {
        if(v.space() == 0) {
            throw std::invalid_argument("Spaces cannot be 0.");
        }

        usedSpaces += v.space();

        if(usedSpaces > garageCapacity) {
            // Revert 'usedSpaces' variable
            usedSpaces -= v.space();
            throw std::invalid_argument("Garage is already full.");
        }
                
        for(int iterator = 0; iterator < vehiclesCount; iterator++) {
            if(strcmp(vehicles[iterator]->registration(), v.registration()) == 0) {
                throw std::invalid_argument("There is already a vehicle with the same registration in the garage.");
            }
        }   

        vehicles[vehiclesCount] = &v;
        vehiclesCount++;
    }
    catch (const char* exMsg) {
        std::cout<< exMsg << std::endl;
    }
}

void Garage::erase(const char* registration) {
    for(int iterator = 0 ; iterator < vehiclesCount; iterator++) {
        if(strcmp(vehicles[iterator]->registration(), registration) == 0) {
            usedSpaces -= vehicles[iterator]->space();
            vehicles[iterator] = vehicles[vehiclesCount - 1];

            vehiclesCount--;
        }
    }
}

const Vehicle& Garage::at(std::size_t pos) const {
    if(pos < 0 || pos >= vehiclesCount) {
        throw std::out_of_range("Invalid position for the object from the class Garage!");
    }

    return *vehicles[pos];
}

const Vehicle& Garage::operator[](std::size_t pos) const {
    assert(pos >= 0 && pos <= vehiclesCount - 1);

    return *vehicles[pos];
}

bool Garage::empty() const {
    if(vehicles[0] == nullptr) {
        return true;
    }

    return false;
}

std::size_t Garage::size() const {
    return vehiclesCount;
}

void Garage::clear() {
    for(int iterator = 0; iterator < vehiclesCount; iterator++) {
        vehicles[iterator] = nullptr;
    }

    vehiclesCount = 0;
}

const Vehicle* Garage::find(const char* registration) const {
    for(int iterator = 0 ; iterator < vehiclesCount; iterator++) {
        if(strcmp(vehicles[iterator]->registration(), registration) == 0) {
            return vehicles[iterator];
        }
    }

    return nullptr;
}

Garage::~Garage(){
    delete[] vehicles;
}