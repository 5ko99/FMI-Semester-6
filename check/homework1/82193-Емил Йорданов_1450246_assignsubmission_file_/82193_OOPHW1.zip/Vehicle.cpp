#include<iostream>
#include<cstring>

#include"Vehicle.h"

Vehicle::Vehicle(const char* registration, const char* description, std::size_t space){
    vehicleRegistration.instanceData = new char[strlen(registration) + 1];
    vehicleDescription.instanceData = new char[strlen(description) + 1];

    if(vehicleRegistration.instanceData){
        strCpy(vehicleRegistration.instanceData, registration);
    }
    if(vehicleDescription.instanceData) {
        strCpy(vehicleDescription.instanceData, description);
    }

    vehicleSpaces = space;
}

const char* Vehicle::registration() const {
   return vehicleRegistration.instanceData;
}

const char* Vehicle::description() const {
    return vehicleDescription.instanceData;
}

std::size_t Vehicle::space() const {
    return vehicleSpaces;
}