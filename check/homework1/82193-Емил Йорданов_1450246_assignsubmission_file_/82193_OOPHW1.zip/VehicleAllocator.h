#include "MyString.h"
#include "Vehicle.h"
#include "Garage.h"

#ifndef VEHICLE_ALLOCATOR_H
#define VEHICLE_ALLOCATOR_H

// This class's purpose is to allocate vehicles with ease
class VehicleAllocator {
    private:
        Vehicle** vehicles = nullptr;
        int vehiclesCount;
        size_t arraySize;
        void copy(const VehicleAllocator& other);
    public:
        VehicleAllocator(std::size_t size);
        VehicleAllocator(const VehicleAllocator& other);            
        VehicleAllocator& operator =(const VehicleAllocator& other);
        ~VehicleAllocator();
        Vehicle* allocate(const char* registration, const char* description, std::size_t spaces);
        // Returns the capacity of the array (for unit testing purposes)
        std::size_t size() const;
        // Returns the count of vehicles (for unit testing purposes)
        std::size_t count() const;
        bool empty() const;
};

#endif