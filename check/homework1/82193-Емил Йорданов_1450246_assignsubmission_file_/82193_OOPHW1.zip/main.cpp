#include<iostream>
#include<cstring>
#include<exception>

#include"MyString.h"
#include"Vehicle.h"
#include"Garage.h"
#include"VehicleAllocator.h"

#define NDEBUG

void inspectGarage(Garage garage) {
    for(int iterator = 0 ; iterator < garage.size(); iterator++) {
        std::cout << "[VEHICLE " << iterator + 1 << "]" << std::endl;
        std::cout << "[VEHICLE REGISTRATION] " << garage[iterator].registration() << std::endl;
        std::cout << "[VEHICLE DESCRIPTION] " << garage[iterator].description() << std::endl;
        std::cout << "[VEHICLE SPACES] " << garage[iterator].space() << std::endl;
        std::cout << "[END OF VEHICLE]" << std::endl;
    }
}

void removeVehicle(const int& FIRST_LIMIT, char*& registrationPlate, Garage& garage) {
    std::cout << "[ENTER VEHICLE REGISTRATION]" << std::endl;

    char buffer[FIRST_LIMIT];
    std::cin.getline(buffer, sizeof(buffer));
    std::cin.clear();

    registrationPlate = new char[strlen(buffer) + 1];
    strCpy(registrationPlate, buffer);

    garage.erase(registrationPlate);

    delete[] registrationPlate;
}

void parkVehicle(const int FIRST_LIMIT, char* registrationPlate, const int SECOND_LIMIT, char* description, size_t spacesCount, VehicleAllocator& vehicle, Garage& garage) {
    std::cout << "[NEW VEHICLE]" << std::endl;

    char firstBuffer[FIRST_LIMIT];
    std::cout << "[ENTER VEHICLE REGISTRATION]" << std::endl;

    std::cin.getline(firstBuffer, sizeof(firstBuffer));
    std::cin.clear();

    registrationPlate = new char[strlen(firstBuffer) + 1];

    strCpy(registrationPlate, firstBuffer);

    char secondBuffer[SECOND_LIMIT];
    std::cout << "[ENTER VEHICLE DESCRIPTION]" << std::endl;

    std::cin.getline(secondBuffer, sizeof(secondBuffer));
    std::cin.clear();

    description = new char[strlen(secondBuffer) + 1];

    strCpy(description, secondBuffer);

    std::cout << "[ENTER VEHICLE SPACES]" << std::endl;
    std::cin >> spacesCount;

    garage.insert(*(vehicle.allocate(registrationPlate, description, spacesCount)));

    std::cout << "[GARAGE SIZE]: " << garage.size() << std::endl;
    std::cout << "[VEHICLE COUNT]: " << vehicle.count() << std::endl;

    delete[] registrationPlate;
    delete[] description;
}

void printMenu() {
    std::cout << "================ M E N U ================" << std::endl;                      
    std::cout << "|[1]   Park a Vehicle in your Garage    |" << std::endl;
    std::cout << "|[2]  Get a Vehicle out of your Garage  |" << std::endl;
    std::cout << "|[3]         Inspect your Garage        |" << std::endl;
    std::cout << "|[4]          Quit the program!         |" << std::endl;
    std::cout << "=========================================" << std::endl;                      
    std::cout << std::endl;
}


int main(){
    // Buffer size limit constants
    const int FIRST_LIMIT = 10;          
    const int SECOND_LIMIT = 1024;

    // Variable holding current menu selection        
    int menuSelection;
    
    // Garage capacity variable
    size_t garageCapacity;
    
    // Variable holding the number of spaces a vehicle takes up in the garage
    size_t spacesCount;
    
    // Variable holding vehicle's registration plate
    char* registrationPlate;

    // Variable holding vehicle's description
    char* description;

    try {

        std::cout << "Hello Mister! Please insert the capacity of your Garage: ";
        std::cin >> garageCapacity;
        std::cin.ignore();
        
        VehicleAllocator vehicle(garageCapacity);
        Garage garage(garageCapacity);

        while (menuSelection != 4) {
            printMenu();

            std::cout << "Select an option from the menu by inserting its number: ";
            std::cin >> menuSelection;
            std::cin.ignore();
       
            if (menuSelection == 1) {        // New vehicle parking
                parkVehicle(FIRST_LIMIT, registrationPlate, SECOND_LIMIT, description, spacesCount, vehicle, garage);
            }
            else if (menuSelection == 2) {     // Removing a vehicle
                removeVehicle(FIRST_LIMIT, registrationPlate, garage);
            }
            else if (menuSelection == 3) {   // Inspecting garage
                inspectGarage(garage);
            }      
        }
    }
    catch (std::bad_alloc& baex) {      // Exception handling
        std::cout << "Bad Allocation exception was caught with the message \"" << baex.what() << "\"." << std::endl;
    }
    catch (std::out_of_range& oorex) {
        std::cout << "Out Of Range exception was caught with the message \"" << oorex.what() << "\"." << std::endl;
    }
    catch (std::exception ex) {
        std::cout << "An unhandled exception was caught with the message \"" << ex.what() << "\"." << std::endl;
    }

    return 0;
}