#include<iostream>
#include<cstring>
#include<cassert>
#include<stdexcept>

#include"MyString.h"

char* MyString::allocateArray(std::size_t size) const {
    try {
        char* pointerArray = nullptr;
        pointerArray = new char[size + 1];
        
        return pointerArray;
    }
    catch(std::bad_alloc& baex){
        std::cout << "Bad Allocation exception was caught with the message \"" << baex.what() << "\"." << std::endl;
    }

    return nullptr;
}

void MyString::copy(const MyString& other) {
    size_t length = strlen(other.instanceData);
    this->instanceData = allocateArray(length);

    if(this->instanceData) {
       strCpy(this->instanceData, other.instanceData);

    }
}

MyString::MyString() {
    instanceData = nullptr;
}

MyString::MyString(const MyString& other) {
    copy(other);
}

MyString& MyString::operator=(const MyString& other) {
    if(this != &other) {
        copy(other);
    }

    return *this;
}

MyString::MyString(const char* str) {
    size_t length = strlen(str);
    instanceData = allocateArray(length);

    if(instanceData) {
        strCpy(instanceData, str);
    }
}

char& MyString::at(std::size_t pos) {
    if(pos < 0 || pos > strlen(instanceData) - 1) {
        throw std::out_of_range("Index is out of range.");
    }   

    return instanceData[pos]; 
}

const char& MyString::at(std::size_t pos) const {
    if(pos < 0 || pos > strlen(instanceData) - 1) {
        throw std::out_of_range("Index is out of range.");
    }

    return instanceData[pos];
}

char& MyString::operator[](std::size_t pos) {
    assert(pos >= 0 && pos <= strlen(instanceData) - 1);

    return instanceData[pos];
}

const char& MyString::operator[](std::size_t pos) const {
    assert(pos >= 0 && pos <= strlen(instanceData) - 1);

    return instanceData[pos];
}

char& MyString::front() {
    assert(instanceData[0] != '\0');

    return instanceData[0];
}

const char& MyString::front() const {
    assert(instanceData[0] != '\0');

    return instanceData[0];
}

char& MyString::back() {
    assert(instanceData[0] != '\0');

    return instanceData[strlen(instanceData) - 1];
}

const char& MyString::back() const {
    assert(instanceData[0] != '\0');

    return instanceData[strlen(instanceData) - 1];
}


bool MyString::empty() const {
    if(instanceData[0] == '\0') {
        return true;
    }

    return false;
}

std::size_t MyString::size() const {
    return strlen(instanceData);
}

void MyString::clear() {
    instanceData[0] = '\0';  
}

void MyString::push_back(char c) {
    size_t length = size() + 1;
    char* tempData = allocateArray(length);

    if(tempData) {
        strCpy(tempData, instanceData);
        append(tempData, c);

        delete[] this->instanceData;
        instanceData = tempData;
    }
}

void MyString::pop_back() {
    assert(instanceData[0] != '\0');

    instanceData[size() - 1] = '\0';
}

MyString& MyString::operator+=(char c) {
    this->push_back(c);

    return *this;
}

MyString& MyString::operator+=(const MyString& rhs) {
    size_t firstLength = this->size();
    size_t secondLength = rhs.size();

    char* tempData = allocateArray(firstLength + secondLength);

    if(tempData) {
        strCpy(tempData, this->instanceData);
        strcat(tempData, rhs.instanceData);

        delete[] this->instanceData;
        instanceData = tempData;
    }
    
    return *this;
}

MyString MyString::operator+(char c) const {
    MyString stringInstance;
    size_t length = this->size() + 1;
    stringInstance.instanceData = allocateArray(length);

    if(stringInstance.instanceData) {
        strCpy(stringInstance.instanceData, this->instanceData);
        append(stringInstance.instanceData, c);
    }

    return stringInstance;  
}

MyString MyString::operator+(const MyString& rhs) const {
    MyString stringInstance;
    size_t firstLength = this->size();
    size_t secondLength = rhs.size();
    stringInstance.instanceData = allocateArray(firstLength + secondLength);

    if(stringInstance.instanceData) {
        strCpy(stringInstance.instanceData, this->instanceData);
        strcat(stringInstance.instanceData, rhs.instanceData);
    }

    return stringInstance;
}

const char* MyString::c_str() const {
    size_t length = this->size();
    char* pointerArray = allocateArray(length);

    if(pointerArray) {
        strCpy(pointerArray, instanceData);
        pointerArray[this->size()] = '\0';
    }

    return pointerArray;
}

bool MyString::operator==(const MyString& rhs) const {
    if(strcmp(rhs.instanceData, this->instanceData) == 0) {
        return true;
    }

    return false;
}

bool MyString::operator<(const MyString& rhs) const {
    if(strcmp(rhs.instanceData, this->instanceData) < 0) {
        return false;
    }

    return true;
}

void strCpy(char* dest, const char* src) {
    int currentPosition = 0;
    
    while(src[currentPosition]) {
        dest[currentPosition] = src[currentPosition];
        currentPosition++;
    }

    dest[currentPosition] = '\0';
}

void append(char* dest, char c) {
    int len = strlen(dest);
    
    dest[len] = c;
    dest[len+1] = '\0';
}