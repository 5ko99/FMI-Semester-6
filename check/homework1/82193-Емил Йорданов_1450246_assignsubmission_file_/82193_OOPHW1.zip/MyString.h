#ifndef MYSTRING_H
#define MYSTRING_H

class MyString {
    private:
        char* instanceData;
        void copy(const MyString& other);
        char* allocateArray(std::size_t size) const;
    public:
        MyString();
        MyString(const MyString& other);
        MyString& operator = (const MyString& other);
        MyString(const char* str);
        MyString& operator += (char c);
        MyString& operator += (const MyString& rhs);
        MyString operator +(char c) const;
        MyString operator +(const MyString& rhs) const;
        char& at(std::size_t pos);
        const char& at(std::size_t pos) const;
        char& operator[](std::size_t pos);
        const char& operator[](std::size_t pos) const;
        char& front();
        const char& front() const;
        char& back();
        const char& back() const;
        bool empty() const;
        std::size_t size() const;
        const char* c_str() const;
        bool operator ==(const MyString& rhs) const;
        bool operator <(const MyString& rhs) const;
        void clear();
        void push_back(char c);
        void pop_back();

        friend class Vehicle;
};

void strCpy(char* dest, const char* src);
// 'append' concatenates a character to the end of the given string
void append(char* s, char c);

#endif