#include <cassert>
#include <cstring>
#include <iostream>
#include "mystring.h"

MyString::MyString() : string(nullptr), sizeOfString(0), capacity(0) {}

MyString::MyString(const char *string, int size, int capacity) : string(nullptr)
{
    this->string = new char[capacity];
    strcpy(this->string, string);
    this->capacity = capacity;
    this->sizeOfString = size;
}
MyString::MyString(const MyString &other) : string(nullptr)
{
    this->string = new char[other.capacity];
    strcpy(this->string, other.string);
    this->capacity = other.capacity;
    this->sizeOfString = other.sizeOfString;
}
MyString::MyString(const char *string)
{
    this->string = new char[strlen(string) + 1];
    strcpy(this->string, string);
    this->capacity = strlen(string) + 1;
    this->sizeOfString = strlen(string);
}
MyString &MyString::operator=(const MyString &other)
{
    if (this != &other)
    {
        delete[] this->string;
        this->string = new char[other.capacity];
        strcpy(this->string, other.string);
        this->capacity = other.capacity;
        this->sizeOfString = other.sizeOfString;
    }
    return *this;
}
MyString::~MyString()
{
    delete[] string;
    string = nullptr;
}

const char *MyString::getString() const
{
    return string;
}
int MyString::getSizeOfString() const
{
    return sizeOfString;
}
int MyString::getCapacity() const
{
    return capacity;
}

char &MyString::at(std::size_t pos)
{
    if (pos < 0 || pos > this->sizeOfString - 1)
    {
        throw std::out_of_range("There is no such position");
    }
    return this->string[pos];
}
const char &MyString::at(std::size_t pos) const
{
    if (pos < 0 || pos > this->sizeOfString - 1)
    {
        throw std::out_of_range("There is no such position");
    }
    return this->string[pos];
}

char &MyString::operator[](std::size_t pos)
{
    return this->string[pos];
}
const char &MyString::operator[](std::size_t pos) const
{
    return this->string[pos];
}

char &MyString::front()
{
    return this->string[0];
}
const char &MyString::front() const
{
    return this->string[0];
}

char &MyString::back()
{
    return this->string[this->sizeOfString - 1];
}
const char &MyString::back() const
{
    return this->string[this->sizeOfString - 1];
}

bool MyString::empty() const
{
    return this->string == nullptr;
}
std::size_t MyString::size() const
{
    return this->sizeOfString;
}

void MyString::clear()
{
    delete[] this->string;
    this->sizeOfString = 0;
}
void MyString::pushBack(char c)
{
    if (this->capacity > this->sizeOfString + 1)
    {
        this->string[this->sizeOfString + 1] = c;
        this->sizeOfString += 1;
    }
    else
    {
        std::size_t newCapacity;
        if (this->sizeOfString == 0)
        {
            newCapacity = 2;
            this->string = new char[newCapacity];
            this->string[0] = c;
            this->string[1] = '\0';
            this->sizeOfString++;
            this->capacity = newCapacity;
        }
        else
        {
            newCapacity = this->capacity * 2;
            char *newString = new char[newCapacity];
            strcpy(newString, string);
            delete[] string;
            newString[this->sizeOfString] = c;
            newString[this->sizeOfString + 1] = '\0';
            strcpy(string, newString);
            this->sizeOfString++;
            this->capacity = newCapacity;
        }
    }
}
void MyString::popBack()
{
    assert(this->string != nullptr);
    this->string[this->sizeOfString - 1] = '\0';
    this->sizeOfString--;
}

MyString &MyString::operator+=(char c)
{
    pushBack(c);
    return *this;
}

MyString &MyString::operator+=(const MyString &rhs)
{
    strcat(string, rhs.getString());
    this->capacity += rhs.getCapacity();
    this->sizeOfString += rhs.getSizeOfString();
    return *this;
}
MyString MyString::operator+(char c) const
{
    MyString newString(this->getString(), this->getSizeOfString(), this->getCapacity());
    newString.pushBack(c);
    return newString;
}
MyString MyString::operator+(const MyString &rhs) const
{
    MyString newString(this->getString(), this->getSizeOfString(), this->getCapacity());
    newString += rhs;
    return newString;
}
const char *MyString::c_str() const
{
    char *newString = new char[this->sizeOfString + 1];
    strcpy(newString, this->string);
    newString[this->sizeOfString] = '\0';
    return newString;
}
bool MyString::operator==(const MyString &rhs) const
{
    return this->getSizeOfString() == rhs.getSizeOfString() &&
           strcmp(this->getString(), rhs.getString()) == 0;
}
bool MyString::operator<(const MyString &rhs) const
{
    if (*this == rhs)
        return false;
    std::size_t size = (this->sizeOfString <= rhs.getSizeOfString()) ? this->sizeOfString : rhs.getSizeOfString();
    for (int i = 0; i < size; i++)
    {
        if (this->string[i] > rhs.getString()[i])
            return false;
    }
    if (this->sizeOfString > rhs.getSizeOfString())
        return false;
    return true;
}