#include<iostream>
#include "garage.h"

int main()
{
    MyString m("lmp");
    std::cout << m.getString() << " " << m.getSizeOfString() << " " << m.getCapacity() << std::endl;

    Vehicle v("mi","sol",5);
    Garage g;
    
    return 0;
}