#define CATCH_CONFIG_MAIN
#include "catch2.hpp"
#include "vehicle.h"

TEST_CASE("Test functions part1")
{
    MyString string("MyString");

    SECTION("Test the functions at and operator []")
    {
        REQUIRE(string[5] == 'i');
        REQUIRE(string.at(5) == 'i');
    }

    SECTION("Test the functions front and back")
    {
        REQUIRE(string.front() == 'M');
        REQUIRE(string.back() == 'g');
    }

    SECTION("Test the functions empty and size")
    {
        REQUIRE(string.empty() == 0);
        REQUIRE(string.size() == 8);
    }
}

TEST_CASE("Test functions part2")
{
    MyString string("MyString");

    SECTION("Test the function clear")
    {
        string.clear();
        REQUIRE(string == nullptr);
    }

    SECTION("Test the function pushBack")
    {
        string.pushBack('E');
        REQUIRE(string.size() == 9);
        REQUIRE(strcmp(string.getString(), "MyStringE") == 0);
    }

    SECTION("Test the function popBack")
    {
        string.popBack();
        REQUIRE(string.size() == 8);
        REQUIRE(strcmp(string.getString(), "MyString") == 0);
    }
}

TEST_CASE("Test functions part3")
{
    MyString string("Rhythmic");

    SECTION("Test the function += and + with a symbol")
    {
        string += 'G';
        REQUIRE(strcmp(string.getString(), "RhythmicG") == 0);

        string + 'i';
        REQUIRE(strcmp(string.getString(), "RhythmicGi") == 0);
    }

    SECTION("Test the function += and + with other string")
    {
        MyString string2("Rhythmic");
        MyString string3("Gymnastics");
        string2 += string3;

        REQUIRE(strcmp(string2.getString(), "RhythmicGymnastics") == 0);
        string.popBack();
        string.popBack();
        string2 = string;
        string2 + string3;

        REQUIRE(strcmp(string2.getString(), "RhythmicGymnastics") == 0);
    }
}
TEST_CASE("Test functions part4")
{
    MyString string("Rhythmic");
    MyString string2(string);
    MyString string3("Gymnastics");
    SECTION("Test the function ==")
    {
        REQUIRE((string == string2) == 1);
        REQUIRE((string == string3) == 0);
    }

    SECTION("Test the function <")
    {
        REQUIRE((string < string2) == 0);
        REQUIRE((string < string3) == 0);
        REQUIRE((string3 < string) == 1);
    }
}


TEST_CASE("Test functions of class Vehicle")
{
    Vehicle vehicle("123","description",3);

    SECTION("Test the getters")
    {
        REQUIRE(strcmp(vehicle.getDescription(),"description") == 0);
        REQUIRE(strcmp(vehicle.getRegistration(),"123") == 0);
        REQUIRE(vehicle.space() == 3);  
    }
}