#ifndef GARAGE_H
#define GARAGE_H
#include"vehicle.h"

class Garage
{
private:
    Vehicle **vehicles;
    std::size_t size;

public:
    Garage();
    Garage(Vehicle**, std::size_t);
    Garage(const Garage&);
    Garage(std::size_t size);
    Garage& operator=(const Garage&);
    ~Garage();

    void insert(Vehicle& v);
    void erase(const char* registration);
    //const Vehicle& at(std::size_t pos) const;
    //const Vehicle& operator[](std::size_t pos) const;
    bool empty() const;
    std::size_t sizeOfVehicles() const;
    void clear();
    const Vehicle* find(const char* registration) const;
};

#endif