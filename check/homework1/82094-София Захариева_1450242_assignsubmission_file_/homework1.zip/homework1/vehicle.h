#ifndef VEHICLE_H
#define VEHICLE_H
#include"mystring.h"

class Vehicle
{
private:
    MyString registrationNumber;
    MyString description;
    std::size_t numberOfPlaces;

public:
    Vehicle(const char*, const char*, std::size_t);
    const char* getRegistration()const;
    const char* getDescription()const;
    std::size_t space()const;
};

#endif