#include<iostream>
#include "vehicle.h"

Vehicle::Vehicle(const char *registration, const char *description, std::size_t space)
    : registrationNumber(registration), description(description), numberOfPlaces(space)
{
}

const char* Vehicle::getRegistration()const
{
    return this->registrationNumber.getString();
}
const char* Vehicle::getDescription()const
{
    return this->description.getString();
}

std::size_t Vehicle::space() const
{
    return this->numberOfPlaces;
}