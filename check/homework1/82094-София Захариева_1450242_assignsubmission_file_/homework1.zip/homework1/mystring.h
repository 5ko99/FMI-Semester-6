#ifndef MYSTRING_H
#define MYSTRING_H

class MyString
{
private:
    char *string;
    int sizeOfString;
    int capacity;

public:
    MyString();
    MyString(const char *, int, int);
    MyString(const MyString &);
    MyString(const char *);
    MyString &operator=(const MyString &);
    ~MyString();

    const char *getString() const;
    int getSizeOfString() const;
    int getCapacity() const;
    
    char &at(std::size_t pos);
    const char &at(std::size_t pos) const;

    char &operator[](std::size_t pos);
    const char &operator[](std::size_t pos) const;

    char &front();
    const char &front() const;

    char &back();
    const char &back() const;

    bool empty() const;
    std::size_t size() const;

    void clear();
    void pushBack(char c);
    void popBack();

    MyString &operator+=(char c);
    MyString &operator+=(const MyString &rhs);
    MyString operator+(char c) const;
    MyString operator+(const MyString &rhs) const;
    const char *c_str() const;
    bool operator==(const MyString &rhs) const;
    bool operator<(const MyString &rhs) const;
};

#endif