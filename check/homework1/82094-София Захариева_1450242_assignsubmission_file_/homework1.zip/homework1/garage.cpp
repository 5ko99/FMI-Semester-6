#include <cstring>
#include <iostream>
#include "garage.h"

Garage::Garage() : vehicles(nullptr), size(0)
{
}
Garage::Garage(Vehicle **vehicles, std::size_t size)
{
    this->vehicles = new Vehicle *[size];
    for (int i = 0; i < size; i++)
    {
        this->vehicles[i] = vehicles[i];
    }
    this->size = size;
}
Garage::Garage(const Garage &other)
{
    this->vehicles = new Vehicle *[other.size];
    for (int i = 0; i < size; i++)
    {
        this->vehicles[i] = other.vehicles[i];
    }
    this->size = other.size;
}
Garage::Garage(std::size_t size)
{
    for (int i = 0; i < size; i++)
    {
        vehicles[i] = nullptr;
    }
    this->size = size;
}
Garage &Garage::operator=(const Garage &other)
{
    if (this != &other)
    {
        clear();
        this->vehicles = new Vehicle *[other.size];
        for (int i = 0; i < size; i++)
        {
            this->vehicles[i] = other.vehicles[i];
        }
        this->size = other.size;
    }
    return *this;
}

Garage::~Garage()
{
    clear();
}

void Garage::insert(Vehicle &v)
{
    //if (this->size)
    for (int i = 0; i < size; i++)
    {
        if (strcmp(this->vehicles[i]->getRegistration(), v.getRegistration()) == 0)
        {
            throw std::out_of_range("This car is already in the garage");
        }
    }
    //this->vehicles[size] = v;
    size += v.space();
}

void Garage::erase(const char *registration)
{
    for (int i = 0; i < size; i++)
    {
        if (strcmp(this->vehicles[i]->getRegistration(), registration) == 0)
        {
            this->vehicles[i] = this->vehicles[size - 1];
            size--;
        }
    }
}
//const Vehicle &Garage::at(std::size_t pos) const
//{
//    if(pos < 0 || pos > size)
//    {
//        throw std::out_of_range("There is no such position");
//    }
//}
//const Vehicle &Garage::operator[](std::size_t pos) const
//{
//}
bool Garage::empty() const
{
    return this->vehicles == nullptr;
}
std::size_t Garage::sizeOfVehicles() const
{
    return this->size;
}
void Garage::clear()
{
    for (int i = 0; i < size; i++)
    {
        delete[] vehicles[i];
    }
    delete[] this->vehicles;
}
const Vehicle *Garage::find(const char *registration) const
{
    for (int i = 0; i < size; i++)
    {
        if (strcmp(this->vehicles[i]->getRegistration(), registration) == 0)
        {
            return this->vehicles[i];
        }
    }
    return nullptr;
}