#include"MyString.h"

int main()
{
	MyString a,b("abcD");
	MyString c(b);

	std::cout <<"\n .at funtion: "<< b.at(1);
	std::cout << "\n .at funtion: "<< b.at(5);

	std::cout<<"\n operator []: "<<b[2];
	std::cout << "\n .front function: " << b.front();
	std::cout << "\n .back function: " << b.back();
	std::cout << "\n .empty function: " << c.empty();
	std::cout << "\n .empty function: " << a.empty();
	std::cout << "\n .size function: " << b.size();
	std::cout << "\n .size function: " << a.size();

	//std::cout << "\n .clear function! "; c.clear();
	std::cout << "\n .empty function: " << c.empty();

	std::cout << "\n .push_back function! "; b.push_back('H');
	std::cout << "\n .size function: " << b.size();
	std::cout << "\n .pop_back function! "; b.pop_back();
	std::cout << "\n .size function: " << b.size();
	b += 'S';
	//b += c;
	//c + b;
	std::cout << "\n"<<b.c_str();

	return 0;
}