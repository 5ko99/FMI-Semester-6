#ifndef MYSTRING
#define MYSTRING

#include<iostream>
#include<cstring>
#include<stdexcept>
class MyString
{
private:
	char* str;
public:
	MyString();
	MyString(const MyString&);
	~MyString();
	MyString(const char*);
	MyString(char* );
	void copy(const char*);
	void copy(char);
	char& at(std::size_t);
	const char& at(std::size_t ) const;
	char& front();
	const char& front() const;
	char& back();
	const char& back() const;
	bool empty() const;
	std::size_t size() const;
	void clear();
	void push_back(char);
	void pop_back();

	char& operator[](std::size_t);
	const char& operator[](std::size_t) const;
	MyString& operator+=(char);
	MyString& operator+=(const MyString&);
	MyString operator+(char c) const;
	MyString operator+(const MyString& rhs) const;
	const char* c_str() const;
	bool operator==(const MyString& rhs) const;
	bool operator<(const MyString& rhs) const;

};

#endif // !MYSTRING

