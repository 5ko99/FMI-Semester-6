#include "MyString.h"

MyString::MyString()
{
	copy("");
}
MyString::MyString(const MyString& other)
{
	copy(other.str);
}
MyString::~MyString()
{
	str=nullptr;
}
MyString::MyString(const char* str)
{
	copy(str);
}
MyString::MyString(char* str)
{
	copy(str);
}

void MyString::copy(const char* c)
{	
	if (!str)
	{
		str = new char[strlen(c + 1)];
	}
	strcpy_s(str, strlen(c) + 1, c);
}
void MyString::copy(char c)
{
	this->str[0] = c;
	this->str[1] = 0;
}
char& MyString::at(std::size_t pos)
{
	try
	{
		if (pos >= strlen(str))
		{
			throw std::out_of_range("out of range");
		}
	}
	catch (const std::exception & e)
	{

		std::cout << "Exception was caught in at() function with message: " << e.what() << "\n";
	}
	return str[pos];
}
const char& MyString::at(std::size_t pos) const
{
	try 
	{
		if (pos >= strlen(str))
		{
			throw std::out_of_range("out of range");
		}
	}
	catch (const std::exception & e)
	{

		std::cout << "Exception was caught in at() function with message: " << e.what() << "\n";
	}
	return str[pos];
}
char& MyString::operator[](std::size_t pos)
{
	return str[pos];
}
const char& MyString::operator[](std::size_t pos) const
{
	return str[pos];
}
char& MyString::front()
{
	return str[0];
}
const char& MyString::front() const
{
	return str[0];
}

char& MyString::back()
{
	return str[strlen(str)-1];
}
const char& MyString::back() const
{
	return str[strlen(str)-1];
}
bool MyString::empty() const
{
	return strlen(str) == 0;
}
std::size_t MyString::size() const
{
	return strlen(str);
}
void MyString::clear()
{
	copy("");
}
void MyString::push_back(char c)
{
	try 
	{
		size_t length = strlen(str);
		str[length] = c;
		str[length + 1] = 0;
	}
	catch (const std::exception& e)
	{
		std::cout << "Exception was caught in push_back function with message: "<<e.what()<<"\n";
	}
}
void MyString::pop_back()
{
	str[strlen(str)-1] = 0;
}
MyString& MyString::operator+=(char c)
{
	try
	{
		this->push_back(c);
		return *this;
	}
	catch (const std::exception& e)
	{
		std::cout << "Exception was caught in += operator with message: " << e.what() << "\n";
	}
}
MyString& MyString::operator+=(const MyString& rhs)
{
	for (size_t i = 0; i < strlen(rhs.str); i++)
	{
		push_back(rhs.str[i]);
	}
	return *this;
}
MyString MyString::operator+(char c) const
{
	MyString MyStr2;
	MyStr2.copy(this->str);
	size_t length = strlen(MyStr2.str);
	MyStr2.str[length] = c;
	MyStr2.str[length+1] = 0;
	return MyStr2;
}
MyString MyString::operator+(const MyString& rhs) const
{
	MyString MyStr2;
	for (size_t i = 0; i < strlen(str); i++)
	{
		MyStr2.push_back(str[i]);
	}
	for (size_t i = 0; i < strlen(rhs.str); i++)
	{
		MyStr2.push_back(rhs.str[i]);
	}
	size_t lgt = strlen(MyStr2.str);
	MyStr2.str[lgt + 1] = 0;
	return MyStr2;
}
const char* MyString::c_str() const
{
	size_t length = strlen(str);
	char c_str[255];
	strncpy_s(c_str,255,str, strlen(str));
	c_str[length] = 0;
	char* c = c_str;
	return c;
}
bool MyString::operator==(const MyString& rhs) const
{
	if (strlen(str) != strlen(rhs.str))
	{
		return false;
	}
	return strcmp(str,rhs.str);
}
bool MyString::operator<(const MyString& rhs) const
{
	if (strlen(str) != strlen(rhs.str))
	{
		return false;
	}
	for (size_t i = 0; i < strlen(str); i++)
	{
		if (str[i] != rhs.str[i])
		{
			return false;
		}
	}
	return true;
}