 #ifndef GARAGE_H
 #define GARAGE_H

 class Garage{


public:

     Garage(std::size_t size);
     void insert(Vehicle& v);
     void erase(const char* registration);
     const Vehicle& at(std::size_t pos) const ;
     bool empty() const;
    const Vehicle& operator[](std::size_t pos) ;
     std::size_t size() const;
     void clear();
     const Vehicle* find(const char* registration) const;

private:



 };

 #endif // GARAGE_H
