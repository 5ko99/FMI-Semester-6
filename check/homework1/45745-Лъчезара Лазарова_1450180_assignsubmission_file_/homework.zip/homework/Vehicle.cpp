#include "Vehicle.hpp"
#include <iostream>

using namespace std;


 const char *Vehicle::registration() const
{
 return char regNum;
}
const char* Vehicle:: description() const
{
     return char description;
}
std::size_t  Vehicle :: space() const
{
    return int space;
}

