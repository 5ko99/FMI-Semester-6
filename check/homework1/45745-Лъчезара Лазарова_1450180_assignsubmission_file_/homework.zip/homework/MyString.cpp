#include <iostream>
#include "MyString.hpp"
 using namespace std;


 char MyString::at(std::size_t pos) const
 {
     try
     {
         pos;
         throw 0;
     }
     catch (int i)
     {
         cout<<out_of_range;
     }
 }
  char& MyString:: at(std::size_t pos) const
  {
      try
     {
         pos;
         throw 0;
     }
     catch (const int i)
     {
         cout<<out_of_range;
     }
  }
  char& MyString :: front()

  {
     return str[0];
  }
  char& MyString :: const front() const

  {
     return const str[0];
  }
  char& MyString:: back()
{
    char &str;
     for (int i=0; i<str; i++)
        {return str[i];}
}
  char& MyString:: const  back() const
{
     for (int i=0; i<str; i++)
        {return  const str[i];}
}
bool MyString::empty() const
{
    return str==0;
}
void MyString:: push_back(char c)
{
    for (int i=0; i< str; i++)
    {    c = str[i+1];
        try
        {
            str[i];
        }
        catch (c)
    }
}
void MyString::pop_back()
{
    for (int i=0; i< str; i++)
    {
        return str[i-1];
    }
}

