#pragma once
#include <iostream>
#include "Vehicle.h"

class Garage
{
public:
	Garage(std::size_t size);
	~Garage();
	void Insert(Vehicle& v);
	void Erase(const char* registration);
	void Print();
	const Vehicle& at(std::size_t pos) const;
	const Vehicle& operator[](std::size_t pos) const;
	bool empty() const;
	std::size_t GetSize() const;
	void clear();
	const Vehicle* find(const char* registration) const;

private:
	std::size_t size;
	Vehicle* vehicles;
	std::size_t spaceTaken;
	std::size_t vehiclesCount;
};
