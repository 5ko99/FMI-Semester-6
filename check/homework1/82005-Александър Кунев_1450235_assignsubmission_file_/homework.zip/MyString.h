#pragma once

#include <iostream>
#include <cstring>
using namespace std;
class MyString
{
public:
	MyString();
	MyString(const char* str); // constructor
	MyString(const MyString& other); // copy-constructor
	MyString& operator=(const MyString& other); // operator=
	~MyString(); // destructor

	char& at(std::size_t pos);
	const char& at(std::size_t pos) const;

	char& front();
	const char& front() const;

	bool empty() const;
	std::size_t size() const;

	char& operator[](std::size_t pos);
	const char& operator[](std::size_t pos) const;

	char& back();
	const char& back() const;

	void clear();

	void push_back(char c);

	void print();

	MyString& operator+=(char c);

	const char* c_str() const;

	void pop_back();

	MyString& operator+=(const MyString& rhs);

	MyString operator+(char c) const;
	MyString operator+(const MyString& rhs) const;

	bool operator==(const MyString& rhs) const;
	bool operator<(const MyString& rhs) const;

private:
	char* str;
};




