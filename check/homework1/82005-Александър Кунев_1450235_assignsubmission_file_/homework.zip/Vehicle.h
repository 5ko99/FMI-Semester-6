#pragma once

using namespace std;
#include "MyString.h"
class Vehicle
{
public:
	Vehicle(const char* registration, const char* description, std::size_t space);
	~Vehicle();

	void print();
	const char* getRegistration() const;
	const char* getDescription() const;
	std::size_t getSpace() const;

private:
	MyString registration;
	MyString description;
	size_t space;
};