#include "MyString.h"
#include <algorithm> 

MyString::MyString() {}

MyString::MyString(const char* str)
{
	this->str = new char[strlen(str) + 1];
	strcpy_s(this->str, strlen(str) + 1, str);

} // constructor


MyString::MyString(const MyString& other)
{
	this->str = new char[strlen(other.str) + 1];
	strcpy_s(this->str, other.size() + 1, other.str);
} // copy-constructor

MyString& MyString::operator=(const MyString& other)
{
	if (this != &other)
	{
		//delete[] str; todo
		this->str = new char[strlen(other.str) + 1];
		strcpy_s(this->str, strlen(other.str) + 1, other.str);
	}
	return *this;
} // operator=

MyString::~MyString()
{
	delete[] str;
} // destructor

char& MyString::at(std::size_t pos)
{
	if (pos > size() - 1 || pos < 0) {
		throw std::out_of_range("out of range");
	}
	return str[pos];
}

const char& MyString::at(std::size_t pos) const
{
	if (pos > size() - 1 || pos < 0) {
		throw std::out_of_range("out of range");
	}
	return str[pos];
}

char& MyString::front()
{
	return str[0];
}
const char& MyString::front() const
{
	return str[0];
}

bool MyString::empty() const
{
	if (size() < 1)
		return true;
	return false;
}
std::size_t MyString::size() const
{
	if (str)
		return strlen(str);
	else
		return 0;
}


char& MyString::operator[](std::size_t pos)
{
	return str[pos];
}
const char& MyString::operator[](std::size_t pos) const
{
	return str[pos];
}

char& MyString::back()
{
	return str[size() - 1];
}
const char& MyString::back() const
{
	return str[size() - 1];
}

void MyString::clear()
{
	delete[] str;
}

void MyString::push_back(char c)
{
	char* temp = new char[size() + 1];
	for (unsigned i = 0; i < size(); i++)
		temp[i] = str[i];
	temp[size()] = c;
	str = &(*temp);
	for (unsigned i = 0; i < size(); i++)
		if (str[i] < ' ' || str[i]>'}')
			str[i] = NULL;

}

void MyString::print()
{
	for (unsigned i = 0; i <= size(); ++i)
	{
		cout << str[i];
	}
	cout << endl;
}
MyString& MyString::operator+=(char c)
{
	str[size()] = c;
	return *this;
}

const char* MyString::c_str() const
{
	const char* result = str;
	return result;

}

void MyString::pop_back()
{
	str[size() - 1] = NULL;
}

MyString& MyString::operator+=(const MyString& rhs)//greshka
{
	for (unsigned i = 0; i < strlen(rhs.str); i++)
	{

		this->push_back(rhs[i]);
	}
	return *this;
}

MyString MyString::operator+(char c) const
{
	MyString *result = new MyString(str);
	result->push_back(c);
	return *result;
}

MyString MyString::operator+(const MyString& rhs) const
{
	MyString* result = new MyString(str);
	for (unsigned i = 0; i < rhs.size(); i++)
	{
		result->push_back(rhs[i]);
	}
	return *result;
}

bool MyString::operator==(const MyString& rhs) const
{
	if (size() == rhs.size())
	{
		for (unsigned i = 0; i < size(); i++)
		{
			if (str[i] != rhs[i])
				return false;
		}

	}
	else
	{
		return false;
	}
	return true;

}

bool MyString::operator<(const MyString& rhs) const
{
	for (unsigned i = 0; i < min(size(), rhs.size()); i++)
	{
		if (str[i] < rhs[i])
			return true;
		else if (str[i] > rhs[i])
			return false;
	}
	if (size() > rhs.size())
		return true;
	else if (size() < rhs.size())
		return false;

	return false;

}