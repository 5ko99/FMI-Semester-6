#include "MyString.h"

#include "Vehicle.h"

#include "Garage.h"

#include <iostream>

using namespace std;

int main()
{
	int capacity = -1, input = -1;

	cout << "Enter capacity for garage: ";
	do {

		cin >> capacity;
		if (capacity <= 0)
			cout << "Capacity must be positive number"<<endl;
	
	} while (capacity <= 0);

	Garage garage(capacity);

	char *registration1 = new char(), *description = new char(), *registration = new char();

	do {
		cout << endl << "1.Add a vehicle" << endl << "2.Remove Vehicle" << endl << "3.Print Garage" << endl << "0.Exit" << endl;
		cin >> input;

		if (input == 0)		//Exit 
		{
			break;
		}
		else if (input == 1)	//Add a vehicle
		{
			size_t space;

			cout << "Enter vehicle registration: ";
			cin >> registration1;
			cout << "Enter vehicle description: ";
			cin >> description;
			cout << "Enter vehicle space: ";
			cin >> space;

			Vehicle v1(registration1, description, space);
			try {
				garage.Insert(v1);
			}
			catch (out_of_range) {
				cout << "A vehicle with that registration is already in that garage or the capacity is not enough" << endl;
			}
		}
		else if (input == 2)	//Remove a vehicle
		{
			cout << "Remove a vehicle by registration: ";
			cin >> registration;
			garage.Erase(registration);
		}
		else if (input == 3)	//Print all vehicles
		{
			cout << endl;
			garage.Print();
			cout << endl;
		}
		else 
		{
			cout << "Enter a number between 0 and 3" << endl;
		}
	} while (input != 0);
	
	cout << endl;
	//system("pause");
	return 0;
}