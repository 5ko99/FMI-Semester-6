#include "Garage.h"

Garage::Garage(std::size_t size)
{
	this->size = size;
	spaceTaken = 0;
	vehiclesCount = 0;
}

Garage::~Garage()
{
	//delete[] vehicles;
}

void Garage::Insert(Vehicle& v)
{
	for (unsigned i = 0; i < vehiclesCount; i++)
	{
		if(vehicles[vehiclesCount].getRegistration() == v.getRegistration())
			throw std::out_of_range("A vehicle with the same register already exists.");
	}

	if (size - spaceTaken >= v.getSpace())
	{
		spaceTaken += v.getSpace();
		Vehicle* temp = (Vehicle*)malloc(sizeof(Vehicle) * (vehiclesCount + 1));
		for (unsigned i = 0; i < vehiclesCount; i++)
		{
			temp[i] = vehicles[i];
		}
		temp[vehiclesCount] = v;
		vehiclesCount++;
		vehicles = temp;
	}
	else
	{
		throw std::out_of_range("Not enough space for this vehicle.");
	}
}

void Garage::Print()
{
	for (unsigned i = 0; i < vehiclesCount; i++)
	{
		cout << "Vehicle:{reg: " << vehicles[i].getRegistration() << ", desc: " <<
			vehicles[i].getDescription() << ", space: " << vehicles[i].getSpace() << "}" << endl;
	}
}

void Garage::Erase(const char* registration)
{
	bool isRemoved = false;
	for (unsigned i = 0; i < vehiclesCount; i++)
	{
		MyString ms1(vehicles[i].getRegistration()), ms2(registration);
		if (ms1 == ms2)
		{
			isRemoved = true;
			spaceTaken -= vehicles[i].getSpace();
			vehicles[i] = vehicles[vehiclesCount - 1];
			break;
		}
	}
	if (isRemoved)
	{
		vehicles[vehiclesCount - 1].~Vehicle();
		vehiclesCount--;
	}
}

const Vehicle& Garage::at(std::size_t pos) const
{
	if (pos > vehiclesCount - 1 || pos < 0) {
		throw std::out_of_range("out of range");
	}
	return vehicles[pos];
}

const Vehicle & Garage::operator[](std::size_t pos) const
{
	return vehicles[pos];
}

bool Garage::empty() const
{
	if (vehicles <= 0)
		return false;
	return true;
}

std::size_t Garage::GetSize() const
{
	return vehiclesCount;
}

void Garage::clear()
{
	Garage newGarage(size);
	*this = newGarage;

	//for (int i = GetSize() - 1; i >= 0; i--)
	//{
	//	spaceTaken -= vehicles[i].getSpace();
	//	vehicles[i].~Vehicle();
	//	vehiclesCount--;
	//}
}

const Vehicle * Garage::find(const char * registration) const
{
	for (int i = 0; i < vehiclesCount; i++)
	{
		MyString s1(vehicles[i].getRegistration()), s2(registration);
		if (s1 == s2)
		{
			return &(vehicles[i]);
		}
	}
	return nullptr;
}
