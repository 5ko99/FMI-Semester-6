/*#include "Vehicle.h"

int main()
{
	Vehicle seat("CM3717BA","My car",8);
	std::cout << seat.get_registration()<<" ";
	std::cout << seat.get_description()<<" ";
	std::cout << seat.get_space();
}*/