/*#include "MyString.h"

int main()
{
	MyString test("Hello"),copy(test);
	std::cout << test.c_str() <<" 123 "<< std::endl;
	std::cout << copy.c_str() << std::endl;
}*/