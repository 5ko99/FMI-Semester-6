#include "Interface.h"

Interface::Interface(size_t cap)
{
	vehicles = new Vehicle[cap];
	capacity = cap;
	curr = 0;
//	std::cout << "Memmory for Interface CREATED \n";
}
Interface::Interface(const Interface& other)
{
	vehicles = new Vehicle [other.capacity];
//	std::cout << "Memmory for Interface CREATED \n";
	capacity = other.capacity;
	curr = other.curr;
}
Interface& Interface::operator=(const Interface& other)
{
	if (this != &other)
	{
		Vehicle* buffer = new Vehicle[other.capacity];
	//	std::cout << "Memmory for Interface CREATED \n";
		for (size_t i = 0; i < other.capacity; i++)
		{
			buffer[i] = vehicles[i];
		}

		delete[] vehicles;
	//	std::cout << "Memmory for Interface DELETED\n";
		vehicles = buffer;

		capacity = other.capacity;
		curr = other.curr;
	}

	return *this;
}
Interface::~Interface()
{
	delete[] vehicles;
	//std::cout << "Memmory for Interface DELETED \n";
}
void Interface::createVehicle(const char* vreg, const char* vdesc, size_t vspace)
{
	if (curr < capacity)
	{
		Vehicle cvehicle(vreg, vdesc, vspace);
		vehicles[curr] = cvehicle;
		curr++;

	}
	else
	{
		Vehicle* buffer = new Vehicle[capacity * 2];
	//	std::cout << "Memmory for Interface CREATED \n";
		for (size_t i = 0; i < capacity; i++)
		{
			buffer[i] = vehicles[i];
		}
		delete[] vehicles;
	//	std::cout << "Memmory for Interface DELETED \n";
		vehicles = buffer;
		capacity = capacity * 2;
		curr++;
	}
}
void Interface::printVehicles()
{
	for (size_t i = 0; i < curr; i++)
	{
		std::cout << "Car No_" << i + 1 << "Registratio: " << vehicles[i].registration() << "\n Description: " << vehicles[i].description() << "\n Spaces taken: " << vehicles[i].space() << '\n';
	}
}
Vehicle& Interface::vehicleAt(size_t pos)
{
	if (pos < curr)
		return vehicles[pos];
	else { throw std::out_of_range("out of range"); }
}




