#include "VehicleAllocator.h"
#include "Vehicle.h"
#include <iostream>


VehicleAllocator::VehicleAllocator(size_t _cap)
{
	pos = 0;
	cap = _cap;
	arr = new Vehicle*[_cap];
//	std::cout << "Memmory for VehicleAllocator CREATED \n";
	for (int i = 0; i < cap; i++)
	{
		arr[i] = nullptr;
	}
}
VehicleAllocator::~VehicleAllocator()
{
	delete[] arr;
	//std::cout << "Memmory for VehicleAllocator DELETED \n";

}
void VehicleAllocator::set_cap(size_t _cap)
{
	cap = _cap;
	delete[] arr;
	//std::cout << "Memmory for VehicleAllocator DELETED \n";
	arr = new Vehicle * [cap];
	//std::cout << "Memmory for VehicleAllocator CREATED \n";
	for (int i = 0; i < cap; i++)
	{
		arr[i] = nullptr;
	}
	
}
Vehicle** VehicleAllocator::allocate(Vehicle& car)
{
	if (pos >= cap)
		return nullptr;
	arr[pos] = &car;
	pos += 1;
	return arr;
}
const Vehicle& VehicleAllocator::position(size_t pos) const
{
	if (pos >= cap)
		throw std::out_of_range("Out of range");
	return *arr[pos];
}
size_t VehicleAllocator::eraseVehicle(const char* reg)
{
	bool hasreg = 0;
	size_t i = 0;
	size_t space = 0;
	while (i < cap) {
		if (arr[i] == nullptr)
		{
			i++;
			continue;
		}
		if (!strcmp(arr[i]->registration(), reg))
		{
			hasreg = 1;
			pos = i;
			space = arr[i]->space();
			arr[i] = nullptr;
			break;
		}
		i++;
	}
	return space;



	
}

