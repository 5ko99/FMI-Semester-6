#include "Vehicle.h"
#include "MyString.h"

Vehicle::Vehicle(const char* _reg, const char* _desc,size_t _space)

{
	park = _space;
	MyString A(_reg), B(_desc);
	reg = A;
	desc = B;

}
const char* Vehicle::registration() const
{

	return reg.give_string();
}
const char* Vehicle::description() const
{
	return desc.give_string();
}
size_t Vehicle::space() const
{
	return park;
}