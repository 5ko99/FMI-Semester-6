#pragma once
#include <iostream>
class MyString
{
private:
	char* str;
    size_t len;
    size_t secretlen; //because i forgot about current and capacity
public:
    MyString(const char* = "");
    MyString(const MyString&);
    MyString& operator=(const MyString&);
    ~MyString();

    const char* give_string() const;
    //char* set_string(const char*);
    void PrintString();
    char& at(std::size_t pos);
    const char& at(std::size_t pos) const;
    char& operator[](std::size_t pos);
    const char& operator[](std::size_t pos) const;
    char& front();
    const char& front() const;
    char& back();
    const char& back() const;
    bool empty() const;
    std::size_t size() const;
    void clear();
    void push_back(char c);
    void pop_back();
    MyString& operator+=(char c);
    MyString& operator+=(const MyString& rhs);
    MyString operator+(char c) const;
    MyString operator+(const MyString& rhs) const;
    const char* c_str() const;
    bool operator==(const MyString& rhs) const;
    bool operator<(const MyString& rhs) const;
    
};

