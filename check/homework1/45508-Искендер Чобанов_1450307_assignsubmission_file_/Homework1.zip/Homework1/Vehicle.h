#pragma once
#include "MyString.h"
#include <iostream>

class Vehicle
{
private:
	MyString reg;
	MyString desc;
	size_t park;
public:
	Vehicle(const char* = "", const char* = "",size_t=0);
	const char* registration() const;
	const char* description() const;
	size_t space() const;


};

