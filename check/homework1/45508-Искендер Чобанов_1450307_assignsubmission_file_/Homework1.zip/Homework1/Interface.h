#pragma once
#include <iostream>
#include "Garage.h"

class Interface
{
	Vehicle* vehicles;
	size_t capacity;
	size_t curr;

public:
	Interface(size_t);
	Interface(const Interface&);
	Interface& operator=(const Interface&);
	~Interface();
	void createVehicle(const char* vreg, const char* vdesc, size_t vspace);
	void printVehicles();
	Vehicle& vehicleAt(size_t pos);

};

