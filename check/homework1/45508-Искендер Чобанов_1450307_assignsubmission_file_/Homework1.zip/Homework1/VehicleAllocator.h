#pragma once
#include "Vehicle.h"
#include "MyString.h"

class VehicleAllocator
{
	Vehicle** arr;
	size_t pos;
	size_t cap;
public:
	void set_cap(size_t);
	VehicleAllocator(size_t=0);
	VehicleAllocator(const VehicleAllocator&) = delete;
	VehicleAllocator& operator=(const VehicleAllocator&) = delete;
	Vehicle** allocate(Vehicle&);
	const Vehicle& position(size_t) const;
	size_t eraseVehicle(const char*);
	~VehicleAllocator();
	
};

