#include "Garage.h"
#include "Vehicle.h"
#include "MyString.h"
#include <iostream>


Garage::Garage(std::size_t size)
{
	cap = size;
	pointer = nullptr;
	gar.set_cap(size);
}
//
void Garage::insert(Vehicle& v)
{
	if (v.space() >= cap)
	{
		std::cout << "Error not enough space \n";
			return;
	}
	cap -= v.space();
	pointer=gar.allocate(v);
	
}
void Garage::erase(const char* registration)
{
	
	cap+=gar.eraseVehicle(registration);

}
const Vehicle& Garage::at(std::size_t pos) const
{
	if (pos<0 || pos>=cap || pointer[pos]==nullptr)
		throw std::out_of_range("error");
	return **(pointer + pos);
}
size_t Garage::size() const
{
	return cap;
}
const Vehicle& Garage::operator[](std::size_t pos) const
{
	return **(pointer + pos);
}
bool Garage::empty() const
{
	if ((pointer[0]==nullptr))
		return 1;
	return 0;
}
void Garage::clear()
{
	for (size_t i = 0;i < cap; i++)
	{
		pointer[i] = nullptr;
	}
	pointer == nullptr;
}
const Vehicle* Garage::find(const char* reg) const
{
	bool hasreg = 0;
	size_t i = 0;
	size_t space = 0;
	while (i < cap) {
		if (pointer[i] == nullptr)
		{
			i++;
			continue;
		}
		if (!strcmp(pointer[i]->registration(), reg))
		{
			hasreg = 1;
			break;
		}
		i++;
	}
	if (hasreg)
		return pointer[i];
	else return nullptr;
}