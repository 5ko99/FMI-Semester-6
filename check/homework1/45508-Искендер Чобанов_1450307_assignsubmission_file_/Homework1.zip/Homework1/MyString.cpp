#include "MyString.h"
#include <iostream>
#include <cstring>

MyString::MyString(const char* _str)
{
	len = strlen(_str)+1;
	str = new char[len];
	strcpy_s(str, len,_str);
	secretlen = len;
//	std::cout << "Memmory for MyString CREATED \n";
}
MyString::MyString(const MyString& other)
{
	len = other.len;
	str = new char[other.len];
	strcpy_s(str, len,other.str);
//	std::cout << "Memmory for MyString CREATED \n";

}
MyString& MyString::operator=(const MyString& other)
{
	if (this != &other)
	{
		char* buffer = new char[other.len];
	//	std::cout << "Memmory for MyString buffer CREATED \n";
		strcpy_s(buffer,other.len,other.str);

		delete[] str;
	//	std::cout << "Memmory for MyString DELETED \n";
		str = buffer;

		len = other.len;
	}

	return *this;
}
MyString::~MyString()
{
	delete[] str;
	//std::cout << "Memmory for MyString DELETED \n";
	len = 0;

}
char& MyString::at(std::size_t pos)
{
	if (pos >= len || pos<0)
		throw std::out_of_range("Index out of range");
	else { return str[pos]; }
}
const char& MyString::at(std::size_t pos) const
{
	if (pos >= len || pos < 0)
	{
		throw std::out_of_range("Index out of range");
	}
	else { return str[pos]; }
}
char& MyString::operator[](std::size_t pos)
{
	if (pos >= len || pos < 0)
	{
		throw std::out_of_range("Index out of range");
	}

	return str[pos];
}
char& MyString::front()
{
	if (len<2)
	{
		throw std::out_of_range("Index out of range");
	}
	return str[0];
}
const char& MyString::front() const
{
	if (len<2)
	{
		throw std::out_of_range("Index out of range");
	}
	return str[0];
}
// char& back();
char& MyString::back()
{
	if (len<2)
	{
		throw std::out_of_range("Index out of range");
	}
	return str[len- 2];
}

const char& MyString::back() const
{
	if (len<2)
	{
		throw std::out_of_range("Index out of range");
	}
	return str[len-2];
}
bool MyString::empty() const
{
	return !bool(len);
}
//std::size_t size() const;
size_t MyString::size() const
{
	return len - 1;
}
//void clear();
void MyString::clear()
{
	delete[] str;
	//std::cout << "Memmory for MyString DELETED \n";
	str = nullptr;
	len = 0;
}
void MyString::PrintString()
{
	std::cout << str << std::endl;
}
//void push_back(char c);
void MyString::push_back(char c)
{
	if (len >= secretlen)
	{
		char* buffer = new char[len * 2];
		//	std::cout << "Memmory for MyString buffer CREATED \n";
		int i = 0;
		while (str[i] != '\0')
		{
			buffer[i] = str[i];
			i++;
		}
		buffer[i] = c;
		buffer[i + 1] = '\0';
		delete[] str;
		//	std::cout << "Memmory for MyString DELETED \n";

		secretlen = len*2;
		len += 1;
		str = buffer;
		//	std::cout << "Memmory for MyString DELETED \n";
		return;
	}
	str [len - 1] = c;
	str[len] = '\0';
	len++;
}
void MyString::pop_back()
{
	if (len<2)
	{
		throw std::out_of_range("Index out of range");
	}
	str[len - 2] = '\0';
	len = len - 1;
}

const char* MyString::give_string() const
{
	return str;
}

 MyString& MyString::operator+=(char c)
{
	this->push_back(c);
	return *this;
}
 MyString& MyString::operator+=(const MyString& rhs)
 {
	 int i = 0;
	while(i<rhs.at(i)!='\0')
	{ this->push_back(rhs.at(i));
	i++;
	 }
	 return *this;
 }
 MyString MyString::operator+(const MyString& rhs) const
 {
	 MyString A(str);
	 for (size_t i = 0; i < rhs.len; i++)
	 {
		 A.push_back(rhs.at(i));
	 }
	 return A;
}
 MyString MyString:: operator+(char c) const
 {
	 MyString A(str);
	 A.push_back(c);
	 return A;
 }
//const char* c_str() const;
 bool MyString::operator==(const MyString& rhs) const
 {
	 return (!strcmp(str, rhs.str));
}
 bool MyString::operator<(const MyString& rhs) const
 {
	 return (strcmp(str, rhs.str) == -1);
 }
 const char& MyString::operator[](std::size_t pos) const
 {
	 if (pos >= strlen(str)) {
		 throw std::out_of_range("out of range");
	 }
	 return str[pos];

 }
