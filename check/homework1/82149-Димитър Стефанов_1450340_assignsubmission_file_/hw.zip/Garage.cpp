#include "Garage.h"

Garage::Garage(std::size_t size)
{
    garage = new Vehicle*[size];
    used = 0;
    capacity = size;
    free = 0;
    alloc = 0;
}

void Garage::insert(Vehicle& v)
{
    if(used == alloc)
    {
        alloc*=2;
        Vehicle** ng = new Vehicle*[alloc];
        for(size_t i=0; i<used; ++i)
        {
            ng[i] = garage[i];
        }
        delete[] garage;
        garage = ng;
    }
    if (free < v._space) {
        throw std::exception("not enough space for vehicle");
    }
    garage[used] = *v;
    used++;
    free -= v._space;
}

void Garage::erase(const char* registration)
{
    for(size_t i=0; i<used; i++)
    {
        if(garage[i]->_registration == registration)
        {
            free += garage[i]->space();
            std::swap(garage[i], garage[used-1]);
            used--;
        }
    }
}

const Vehicle& Garage::at(std::size_t pos) const
{
    return *garage[pos];
}

const Vehicle& Garage::operator[](std::size_t pos) const
{
    return *garage[pos];
}

bool Garage::empty() const
{
    if(used == 0)
    {
        return true;
    }
    else
    {
    return false;
    }
}

std::size_t Garage::size() const
{
    return used;
}

void Garage::clear()
{
    delete[] garage;
    used = 0;
    free = capacity;
}

const Vehicle* Garage::find(const char* registration) const
{
    for(size_t i=0; i<used; i++)
    {
        if(garage[i]->_registration == registration)
        {
            return garage[i];
        }
    }
    return nullptr;
}

