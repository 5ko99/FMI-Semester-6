#include "Vehicle.h"
#include "MyString.h"

Vehicle::Vehicle(MyString registration, MyString description, size_t space) {
    _registration = registration;
    _description = description;
    _space = space;
}

const char* Vehicle::registration() const {
    return _registration;
}

const char* Vehicle::description() const {
    return _description;
}

size_t Vehicle::space() const {
    return _space;
}
