#include"MyString.h"
#include<cstring>
#include<cassert>

MyString::MyString(size_t size)
{
    capacity = size;
    str = new char[capacity];
    used = 0;
}

MyString::MyString(const char* str)
{
    used = 0;
    char* p = str;
    while (*(p++))
        used++;
    capacity = used;
    this->str = new char[capacity];
    for(size_t i=0;i<used;++i)
    {
        this->str[i] = str[i];
    }
}

const char* MyString::c_str() const {
    char* newstr = new char[used+1];
    for(size_t i=0;i<used;++i)
    {
        newstr[i] = str[i];
    }
    newstr[used] = '\0';
    return newstr;
}


char& MyString::at(size_t index)
{
    if(pos < 0 || pos > used)
    {
        throw "u stoopid";
    }
    else
    {
        return str[index];
    }
}

const char& MyString::at(size_t index) const
{
    if(pos < 0 || pos > used)
    {
        throw "u stoopid";
    }
    else
    {
        return str[index];
    }
}

char& MyString::operator[](size_t index)
{
    return str[index];
}

char& MyString::front()
{
    return str[0];
}

const char& MyString::front() const
{
    return str[0];
}

char& MyString::back()
{
    return str[used-1];
}

const char& MyString::back() const
{

}

bool MyString::empty() const;
{
    if(used == 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}

std::size_t MyString::size() const
{
    return used;
}

void MyString::clear()
{
    delete[] str;
}

void MyString::push_back(char c)///strong exception guarantee
{
    if(used == capacity)
    {
        capacity*=2;
        char* newstr = new char[capacity*2];
        for(size_t i=0;i<used;++i)
        {
            newstr[i] = str[i];
        }
        delete[] str;
        str = newstr;
    }
    newstr[used] = c;
    ++used;
}

void MyString::pop_back()
{
    if(used != 0)
    {
        --used;
    }
}

MyString& MyString::operator+=(char c)
{
    if(used == capacity)
    {
        capacity*=2;
        char* newstr = new char[capacity];
        for(size_t i=0;i<used;++i)
        {
            newstr[i] = str[i];
        }
        delete[] str;
        str = newstr;
    }
    newstr[used] = c;
    ++used;
    return *this;
}

MyString& MyString::operator+=(const MyString& rhs)
{
    if(used + rhs.used >= capacity)
    {
        capacity = 2*(used + rhs.used);
        char* newstr = new char[capacity];
        for(size_t i=0; i<used; ++i)
        {
            newstr[i] = str[i];
        }
        for(size_t i=used; i<(used + rhs.used); ++i)
        {
            newstr[i] = rhs[i-used];
        }
        delete[] str;
        str = newstr;
    }
    else
    {
        for(size_t i=used; i<(used + rhs.used); ++i)
        {
            str[i] = rhs[i-used];
        }
    }

    return *this;
}

MyString MyString::operator+(char c) const
{
    MyString newstr(*this);
    newstr.push_back(c);
    return newstr;
}

MyString MyString::operator+(const MyString& str)
{
    MyString newstr(*this);
    newstr += str;
    return newstr;
}

MyString::MyString(const MyString& a)
{
    str = new char[a.capacity];
    for(size_t i=0; i<a.used; i++)
    {
        str[i] = a[i];
    }
    used = a.used;
    capacity = a.capacity;

}
MyString& MyString::operator=(const Mystring& a)
{
    if(capacity <= a.used)
    {
        capacity = a.capacity;
        char* newstr = new char[capacity];
        for(size_t i=0; i<a.used; i++)
        {
            newstr[i] = a[i];
        }
        delete[] str;
        str = newstr;
        used = a.used;
    }
    else
    {
        delete[] str;
        for(size_t i=0; i<a.used; i++)
        {
            str[i] = a[i];
        }
        used = a.used;
        capacity = a.capacity;
    }
    return str;
}

bool MyString::operator<(const MyString &rhs) const
{
    return strcmp(str, rhs.str) < 0;
}

