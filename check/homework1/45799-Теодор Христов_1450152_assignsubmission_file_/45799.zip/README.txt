git repo if there is a problem
https://github.com/teodor-hristov/University/tree/main/Object%20Oriented%20programming/Hw1
