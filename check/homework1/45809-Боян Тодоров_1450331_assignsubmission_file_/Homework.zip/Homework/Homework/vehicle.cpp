#include "vehicle.h"
#include <string.h>
//constructor with char*, char*, size_t arguments
Vehicle::Vehicle(const char* registration, const char* description, size_t space) {
	if (space == 0) {
		throw invalid_argument("invalid argument");
	}
	this->license_plate.MyString::MyString(registration);

	this->info.MyString::MyString(description);

	this->places_filled = space;
}

//returns license plate as a string
const char* Vehicle::registration() const {
	return this->license_plate.c_str();

}

//returns information as a string
const char* Vehicle::description()const {
	return this->info.c_str();
}

//returns the space
size_t Vehicle::space() const {
	return this->places_filled;
}


