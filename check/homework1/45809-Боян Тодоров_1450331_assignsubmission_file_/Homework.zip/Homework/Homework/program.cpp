﻿#include"garage.h"
#include <iostream>
using namespace std;



void display() {
	cout << "Press 1 to add a vehicle: " << endl;
	cout << "Press 2 to remove a vehicle:" << endl;
	cout << "Press 3 to see cars in garage: " << endl;
	cout << "Press 4 to exit" << endl;
}

int main() {

	size_t gar_space;
	cout << "Enter capacity for the garage:" << endl;
	cin >> gar_space;
	Garage garage(gar_space);
	int choice;


	do {
		display();
		cin >> choice;
		switch (choice) {
		case 1: {

			Vehicle* car = nullptr;


			char registration[10];
			char description[50];
			size_t size;

			cout << "Enter registration: " << endl;
			cin >> registration;

			cout << endl << "Enter description: " << endl;
			cin >> description;

			cout << endl << "Enter the size that the car takes: " << endl;
			cin >> size;
			try {
				car = new Vehicle(registration, description, size);
			}
			catch (invalid_argument& e) {
				cout << e.what() << endl;
			}
			try {
				garage.insert(*car);
			}

			catch (const invalid_argument& e) {
				cout << e.what() << endl;
			}
			break;
		}

		case 2: {
			cout << "Enter registration of the car that you'd like to erase: ";
			char registr[20];
			cin >> registr;
			garage.erase(registr);
			break;
		}

		case 3: {
			cout << garage;
			break;
		}

		}

	} while (choice != 4);


	return 0;



}


