﻿#include "str.h"
#include <iostream>
#include <string.h>
#define NDEBUG
#include <cassert>
using namespace std;

//Constructor
MyString::MyString()
{
	this->text = nullptr;
	sz = 0;

}
//Copy Constructor
MyString::MyString(const MyString& old) {
	sz = strlen(old.text);
	this->text = new char[sz + 1];
	for (size_t i = 0; i < sz; i++) {
		this->text[i] = old.text[i];
	}
	this->text[sz] = '\0';
}

//Constructor with const char* argument
MyString::MyString(const char* str)
{
	if (str == nullptr) {
		throw invalid_argument("Invalid argument");
	}
	sz = strlen(str);
	this->text = new char[sz + 1];
	for (size_t i = 0; i < sz; i++) {
		this->text[i] = str[i];
	}
	text[sz] = '\0';


}
//returns char at position [pos]
char&
MyString::at(unsigned pos)
{
	if (strlen(this->text) <= pos) {
		throw out_of_range("index out of range!");
	}

	return this->text[pos];
}

//returns char at position [pos] for constants
const char&
MyString::at(size_t pos) const
{
	if (strlen(this->text) <= pos) {
		throw out_of_range("index out of range!");
	}
	return this->text[pos];
}

//operator [] returns char at position [pos]
char&
MyString::operator[](const unsigned pos)
{
	assert(strlen(text) > pos);

	return this->text[pos];
}

//operator [] returns char at position [pos] for constants
const char&
MyString::operator[](size_t pos) const
{
	return this->text[pos];
}

// returns the first element from the text
char&
MyString::front()
{

	return this->text[0];
}

//returns the first element from the text for constants
const char&
MyString::front() const
{

	return this->text[0];
}

//returns the last element from the text 
char&
MyString::back()
{

	unsigned len = strlen(this->text);
	return this->text[len - 1];
}

//returns the last element from the text for constants
const char&
MyString::back() const
{

	unsigned len = strlen(this->text);
	return this->text[len - 1];
}

//checks if text is empty - return 1 if it is empty
bool
MyString::empty() const
{
	if (sz == 0) {
		return true;
	}
	return false;
}

//returns the length of the text
size_t
MyString::size() const
{
	return sz;
}

//clear the text
void
MyString::clear()
{

	for (size_t i = 0; i < sz; i++) {
		this->text[i] = '\0';
	}
	sz = 0;
}

//operator that changes the text by adding an element behind
MyString&
MyString::operator+=(char c)
{
	push_back(c);
	return *this;
}

//function that changes the text by adding an element behind
void
MyString::push_back(char c)
{

	char* duplicate = new char[sz + 2];
	for (size_t i = 0; i < sz; i++) {
		duplicate[i] = this->text[i];
	}
	duplicate[sz] = c;
	duplicate[sz + 1] = '\0';
	clear();
	this->text = duplicate;
	sz = strlen(duplicate);

}

//function that removes one element from the text
void
MyString::pop_back()
{
	assert(sz > 1);
	char* duplicate = new char[sz + 1];
	for (size_t i = 0; i < sz - 1; i++) {
		duplicate[i] = this->text[i];
	}
	duplicate[sz - 1] = '\0';
	clear();
	this->text = duplicate;
	sz = strlen(duplicate);
}

//operator that add a text to the current text by concatinating them
MyString& MyString::operator+=(const MyString& rhs)
{
	size_t size1 = size();
	size_t len = strlen(rhs.text);

	char* duplicate = new char[len + size1 + 1];
	for (size_t i = 0; i < size1; i++) {
		duplicate[i] = this->text[i];
	}
	unsigned a = 0;
	for (size_t i = size1; i < size1 + len; i++) {
		duplicate[i] = rhs.text[a];
		a++;
	}
	duplicate[len + size1] = '\0';

	clear();
	this->text = duplicate;
	sz += strlen(duplicate);

	return *this;
}

//returns new text that is created by adding a char to the string
MyString MyString::operator+(char c) const {
	MyString strng(*this);
	strng.push_back(c);
	return strng;
}

//returns a new text that is created by adding a new text to the string
MyString MyString::operator+(const MyString& rhs) const {
	MyString strng(*this);
	strng += rhs;
	return strng;
}

//returns a  string
const char* MyString::c_str() const {

	return this->text;
}

//operator that checks if two MyString are equal
bool MyString::operator==(const MyString& rhs) const { //

	if (strcmp(this->text, rhs.text) == 0) {
		return 1;
	}

	return 0;
}


bool MyString::operator<(const MyString& rhs)const {
	size_t len;
	if (this->sz > rhs.sz) {
		len = rhs.sz;
	}

	else if (this->sz < rhs.sz)
	{
		len = this->sz;
	}

	else if (this->sz == rhs.sz)
	{
		len = this->sz;
	}

	for (size_t i = 0; i < len; i++) {
		if (this->text[i] > rhs.text[i]) {
			return 0;
		}
		else if (this->text[i] < rhs.text[i]) {
			return 1;
		}
		else if (this->text[i] == rhs.text[i]) {
			continue;
		}
	}

	if (this->sz > rhs.sz) {
		return 1;
	}

	return 0;
}
//Destructor
MyString::~MyString()
{
	delete[] this->text;
}

