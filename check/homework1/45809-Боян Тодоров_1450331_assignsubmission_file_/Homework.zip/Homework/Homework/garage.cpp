#include"garage.h"
#include <stdexcept>
#include <string.h>
#include<cassert>
#include<iostream>

//Constructor with size_t argument
Garage::Garage(size_t size) {

	this->vehicles = new Vehicle * [size];

	for (size_t i = 0; i < size; i++) {
		vehicles[i] = nullptr;
	}

	this->capacity = size;
	this->cpct = size;
}

//Function that inserts a vehicle
void Garage::insert(Vehicle& v) {
	if (capacity < v.space()) {
		throw std::invalid_argument("Garage is full!");
	}

	for (size_t i = 0; i < amt_vehicles; i++) {
		if (strcmp(v.registration(), vehicles[i]->registration()) == 0) {
			throw std::invalid_argument("Car is already in garage");
		}
	}

	vehicles[amt_vehicles] = &v;
	amt_vehicles++;
	capacity = capacity - v.space();
}

//Function that erases a car by given registration
void Garage::erase(const char* registration) {

	for (size_t i = 0; i < amt_vehicles; i++) {

		if (strcmp(vehicles[i]->registration(), registration) == 0) {
			capacity += vehicles[i]->space();
			vehicles[i] = vehicles[amt_vehicles - 1];
			vehicles[amt_vehicles - 1] = nullptr;
			amt_vehicles--;
		}
	}
}

//Function that gives access to the element at position pos
const Vehicle& Garage::at(size_t pos) const {

	if (amt_vehicles <= pos) {

		throw std::out_of_range("index out of range!");
	}

	return *vehicles[pos];
}
//operator that gives access to the element at position pos
const Vehicle& Garage::operator[](size_t pos) const {
	assert(pos < amt_vehicles);
	return *vehicles[pos];
}
//checks if garage is empty
bool Garage::empty() const {

	if (amt_vehicles == 0) {

		return true;
	}
	return false;
}

//returns the amount of vehicles in the garage
size_t Garage::size() const {
	return amt_vehicles;
}

//function that erases all the cars from the garage
void Garage::clear() {

	while (amt_vehicles != 0) {

		erase(vehicles[amt_vehicles - 1]->registration());

	}
}

//function that finds the element with registration (*registration)
const Vehicle* Garage::find(const char* registration) const {
	for (size_t i = 0; i < amt_vehicles; i++) {
		if (strcmp(vehicles[i]->registration(), registration) == 0) {
			return vehicles[i];
		}
		return nullptr;

	}
}


//destructor
Garage::~Garage() {
	delete[]vehicles;
}




