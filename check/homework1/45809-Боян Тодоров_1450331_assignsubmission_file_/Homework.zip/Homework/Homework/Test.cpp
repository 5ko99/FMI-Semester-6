#define CATCH_CONFIG_MAIN
#include"Test2.hpp"
#include"garage.h"



TEST_CASE("c_str()_Should_ReturnChar*") {
	MyString txt("text");
	REQUIRE(strcmp(txt.c_str(), "text") == 0);
}



TEST_CASE("at_ReturnsChar_whenChosenIndex") {
	MyString abc("abc");
	REQUIRE(abc.at(1) == 'b');
}

TEST_CASE("at_ReturnCharForConst_whenChosenIndex") {
	const MyString  address("Borisova");
	REQUIRE(address.at(2) == 'r');
}

TEST_CASE("[]operator_ReturnChar_WhenChosenIndex") {
	MyString name("George");
	REQUIRE(name[3] == 'r');
}



TEST_CASE("[]operator_ReturnCharForConsts_WhenChosenIndex") {
	MyString name("Paul");
	REQUIRE(name[0] == 'P');
}


TEST_CASE("front_GetTheFirstChar_GivenString") {
	MyString school("vazov");
	REQUIRE(school.front() == 'v');

}


TEST_CASE("front_GetTheFirstChar_WhenStringConst")
{
	const MyString highschool("abv");
	REQUIRE(highschool.front() == 'a');
}


TEST_CASE("back_GiveLastElement_WhenStringIsValid") {
	MyString ab("1234");
	REQUIRE(ab.back() == '4');
}


TEST_CASE("back_GiveLastElement_WhenConst") {

	const MyString cd("5678");
	REQUIRE(cd.back() == '8');
}


TEST_CASE("empty_Returns0_IfNotEmpty") {
	MyString full("FullText");
	REQUIRE(full.empty() == 0);

	MyString txt("text");
	REQUIRE(txt.empty() == 0);
}


TEST_CASE("size_ReturnAmount_IfNotEmpty") {
	MyString strn("words");

	REQUIRE(strn.size() == 5);
}


TEST_CASE("clear_EmptiesString_WhenStringNotEmpty") {
	MyString something("something");
	something.clear();
	REQUIRE(something.empty() == 1);
}


TEST_CASE("push_back__AddsSymbolToString_WhenStringNotEmpty") {
	MyString text("quantity");
	text.push_back('s');
	REQUIRE(strcmp(text.c_str(), "quantitys") == 0);
	REQUIRE(text.size() == 9);
}


TEST_CASE("pop_back_RemovesOneSymbol_WhenStringNotEmpty") {
	MyString pop("string");
	pop.pop_back();
	REQUIRE(strcmp(pop.c_str(), "strin") == 0);
	REQUIRE(pop.size() == 5);
}

TEST_CASE("operator+=_ConcatinateStringWithChar_WhenStringNotEmpty") {
	MyString op("op");
	op += 'c';
	REQUIRE(strcmp(op.c_str(), "opc") == 0);
	REQUIRE(op.size() == 3);
}


TEST_CASE("operator+=_ConcatinateTwoStrings_WhenNotEmpty") {
	MyString first("abc");
	MyString second("def");
	first += second;
	REQUIRE(strcmp(first.c_str(), "abcdef") == 0);
	REQUIRE(first.size() == 6);
}

TEST_CASE("operator+=_ConcatinateTwoString_WhenNotEmpty") {
	MyString first("a");
	MyString second("def");
	first += second;
	REQUIRE(strcmp(first.c_str(), "adef") == 0);
	REQUIRE(first.size() == 4);
}

TEST_CASE("operator+=_ConcatinateTwoString_WhenNotEmpty2") {
	MyString first("abc");
	MyString second("d");
	first += second;
	REQUIRE(strcmp(first.c_str(), "abcd") == 0);
	REQUIRE(first.size() == 4);

}

TEST_CASE("operator+_ConcatinateStringWithChar_WhenStringNotEmpty") {

	MyString add("add");
	MyString c = add + 'c';
	REQUIRE(strcmp(c.c_str(), "addc") == 0);
	REQUIRE(c.size() == 4);
}


TEST_CASE("operator+_ConcatinateTwoString_WhenStringsNotEmpty") {
	MyString str1("Good");
	MyString str2("Evening");
	MyString result = str1 + str2;
	REQUIRE(strcmp(result.c_str(), "GoodEvening") == 0);
	REQUIRE(result.size() == 11);
}

TEST_CASE("operator==_ChecksIfStringAreEqual_WhenStringNotEmpty") {
	MyString field("abv");
	MyString second("abv");
	REQUIRE((field == second) == 1);
}


TEST_CASE("operator<_ShowsWhichStringBigger_whenFirstBigger") {
	MyString field("abv");
	MyString second("aab");
	REQUIRE((second < field) == 1);
}

TEST_CASE("operator<_ShowsWhichStringBigger_whenSecondBigger") {
	MyString field("boyan");
	MyString second("todorov");
	REQUIRE((field < second) == 1);
}

TEST_CASE("operator<_ShowsWhichStringBigger_whenbBigger") {
	MyString a("a");
	MyString b("b");
	REQUIRE((a < b) == 1);
}

TEST_CASE("operator<_ShowsWhichStringBigger_whenaBigger") {
	MyString a("ab");
	MyString b("aa");
	REQUIRE((b < a) == 1);
}


TEST_CASE("registration_ShowsRegistrationAsString_WhenCorrectlyInput") {
	Vehicle car1("1412", "opel", 1);
	REQUIRE(strcmp(car1.registration(), "1412") == 0);
	REQUIRE(strcmp(car1.registration(), "141") > 0);
	REQUIRE(strcmp(car1.registration(), "1413") < 0);
}


TEST_CASE("Description_ShowsDescriptionAsString_WhenCorrectInput") {
	Vehicle car1("1412", "opel", 1);
	REQUIRE(strcmp(car1.description(), "opel") == 0);
	REQUIRE(strcmp(car1.description(), "vauxhall") < 0);
}

TEST_CASE("space_returnSizeTheCarTakes_WhenPositiveInput") {
	Vehicle car1("1412", "opel", 1);
	REQUIRE(car1.space() == 1);
	REQUIRE(car1.space() != 0);
}


TEST_CASE("insert_ShouldAddCar_WhenCarNotInGarageAlready") {
	Garage parking(10);
	Vehicle car("1111", "toyota", 2);
	parking.insert(car);
	REQUIRE(parking.size() == 1);
	REQUIRE(parking.find("1111")->description() == car.description());
}

TEST_CASE("insert_AddMoreCars_NotInGarageAlready") {
	Garage parking(10);
	Vehicle car("1111", "toyota", 2);
	Vehicle motorcycle("8123", "honda", 1);
	Vehicle bus("1234", "mercedes", 4);
	parking.insert(car);
	parking.insert(motorcycle);
	parking.insert(bus);
	REQUIRE(parking.size() == 3);
}

TEST_CASE("insert_AddingCar_whenAlreadyInGarage") {
	Garage parking(10);
	Vehicle car("1111", "toyota", 2);
	parking.insert(car);
	CHECK_THROWS(parking.insert(car));
}

TEST_CASE("insert_AddingCar_WhenParkingIsFull") {
	Garage parking(10);
	Vehicle car("1111", "toyota", 1);
	Vehicle bus("1234", "mercedes", 9);
	Vehicle motorcycle("9123", "suzuki", 1);
	parking.insert(car);
	parking.insert(bus);
	CHECK_THROWS(parking.insert(motorcycle));

}

TEST_CASE("Erase_ShouldRemoveCar_whenCarInGarage") {
	Garage parking(10);
	Vehicle car("1111", "toyota", 2);
	Vehicle bus("8712", "mercedes", 4);
	parking.insert(bus);
	parking.insert(car);
	parking.erase(bus.registration());
	REQUIRE(parking.find(bus.registration()) == nullptr);

}

TEST_CASE("at_ShouldReturnCar_whenPlaceNotEmpty") {
	Garage parking(10);
	Vehicle car("1111", "toyota", 2);
	Vehicle bus("8712", "mercedes", 4);
	parking.insert(bus);
	parking.insert(car);
	REQUIRE(strcmp(parking.at(0).description(), bus.description()) == 0);
}

TEST_CASE("[]operator_ShouldReturnCar_whenPlaceNotEmpty") {
	Garage parking(10);
	Vehicle car("1111", "toyota", 2);
	Vehicle bus("8712", "mercedes", 4);
	parking.insert(bus);
	parking.insert(car);
	REQUIRE(strcmp(parking[1].description(), car.description()) == 0);
}


TEST_CASE("empty_ReturnTrue_IfEmpty") {
	Garage parking(10);
	Vehicle car("1111", "toyota", 2);
	Vehicle bus("8712", "mercedes", 4);
	REQUIRE(parking.empty() == 1);
}

TEST_CASE("empty_ReturnTrue_IfEmptyAfterErasing") {
	Garage parking(10);
	Vehicle car("1111", "toyota", 2);
	Vehicle bus("8712", "mercedes", 4);
	parking.insert(bus);
	parking.insert(car);
	parking.erase(bus.registration());
	parking.erase(car.registration());
	REQUIRE(parking.empty() == 1);
}

TEST_CASE("empty_ReturnFalse_IfNotFullyEmpty") {
	Garage parking(10);
	Vehicle car("1111", "toyota", 2);
	Vehicle bus("8712", "mercedes", 4);
	parking.insert(bus);
	parking.insert(car);
	parking.erase(bus.registration());
	REQUIRE(parking.empty() == 0);
}

TEST_CASE("empty_ReturnFalse_IfNotEmpty") {
	Garage parking(10);
	Vehicle car("1111", "toyota", 2);
	Vehicle bus("8712", "mercedes", 4);
	parking.insert(bus);
	parking.insert(car);
	REQUIRE(parking.empty() == 0);
}

TEST_CASE("size_ReturnAmountOfCarsInGarage_WhenInGarage") {
	Garage parking(10);
	Vehicle car("1111", "toyota", 2);
	Vehicle bus("8712", "mercedes", 4);
	parking.insert(bus);
	parking.insert(car);
	REQUIRE(parking.size() == 2);
}

TEST_CASE("size_ReturnAmountOfCarsLeft_WhenCarErased") {
	Garage parking(10);
	Vehicle car("1111", "toyota", 2);
	Vehicle bus("8712", "mercedes", 4);
	Vehicle motorcycle("1421", "Honda", 1);
	parking.insert(bus);
	parking.insert(car);
	parking.insert(motorcycle);
	parking.erase(car.registration());
	parking.erase(bus.registration());
	REQUIRE(parking.size() == 1);
}

TEST_CASE("size_Return0_IfNoCarsInserted") {
	Garage parking(10);
	Vehicle car("1111", "toyota", 2);
	Vehicle bus("8712", "mercedes", 4);
	Vehicle motorcycle("1421", "Honda", 1);
	REQUIRE(parking.size() == 0);
}

TEST_CASE("size_Return0_ifAllCarsErased") {
	Garage parking(10);
	Vehicle car("1111", "toyota", 2);
	Vehicle bus("8712", "mercedes", 4);
	Vehicle motorcycle("1421", "Honda", 1);
	parking.insert(bus);
	parking.insert(car);
	parking.insert(motorcycle);
	parking.erase(car.registration());
	parking.erase(bus.registration());
	parking.erase(motorcycle.registration());
	REQUIRE(parking.size() == 0);
}

TEST_CASE("clear_ErasesAllCars_ifGarageNotEmpty") {
	Garage parking(10);
	Vehicle car("1111", "toyota", 2);
	Vehicle bus("8712", "mercedes", 4);
	Vehicle motorcycle("1421", "Honda", 1);
	Vehicle truck("7879", "Ford", 3);
	parking.insert(bus);
	parking.insert(car);
	parking.insert(motorcycle);
	parking.insert(truck);
	parking.clear();
	REQUIRE(parking.size() == 0);
	REQUIRE(parking.empty() == 1);
}

TEST_CASE("find_FindAcar_ByGivenValidRegistration") {
	Garage parking(10);
	Vehicle car("1111", "toyota", 2);
	Vehicle bus("8712", "mercedes", 4);
	parking.insert(car);
	REQUIRE(strcmp(parking.find("1111")->description(), "toyota") == 0);
}











