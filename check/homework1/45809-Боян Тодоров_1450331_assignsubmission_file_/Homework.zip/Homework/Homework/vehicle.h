#pragma once
#include "str.h"
#include<iostream>
using namespace std;

class Vehicle {
private:
	MyString  license_plate;
	MyString info;
	size_t places_filled;


public:
	Vehicle(const char* registration, const char* description, size_t space);
	const char* registration() const;
	const char* description() const;
	size_t space() const;

	friend ostream& operator<<(ostream& out, Vehicle& v) {

		out << "Registration: " << v.license_plate.c_str() << endl << "  Description: " << v.info.c_str() << endl << " Places that it fills: " << v.places_filled << endl << endl;
		return out;
	}

};