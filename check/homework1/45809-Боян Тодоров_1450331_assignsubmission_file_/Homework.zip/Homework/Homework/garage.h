#pragma once
#include "vehicle.h"
#include<iostream>
using namespace std;
class Garage {
private:
	size_t capacity;
	Vehicle** vehicles;
	size_t amt_vehicles = 0;
	size_t cpct;
public:
	Garage(size_t size);//
	void insert(Vehicle& v);//
	void erase(const char* registration);//
	const Vehicle& at(size_t pos) const;//
	const Vehicle& operator[](size_t pos) const;//
	bool empty() const;//
	size_t size() const;//
	void clear();//
	const Vehicle* find(const char* registration) const;//

	friend ostream& operator<<(ostream& out, const Garage& g) {
		for (size_t i = 0; i < g.amt_vehicles; i++) {
			out << *(g.vehicles[i]);
		}
		return out;
	}

	~Garage();
};