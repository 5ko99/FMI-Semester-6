#include"./garage/garage.hpp"
#include "./vehicle_creator/vehicle_creator.hpp"

using std::cout;
using std::endl;
using std::cin;

/**
 * Function that creates vehicle based on the user input
 * @param creator
 */
void createVehicle(VehicleCreator& creator);

/**
 * Function that prints the message and then saves the user's input into the string
 * @param msg
 * @param string
 */
void getInputForVehicle(const char* msg, MyString& string);

/**
 * Function that gets the registration number of the vehicle from the user and then if it exists adds it to the Garage
 * @param g
 * @param creator
 */
void addVehicleToGarage(Garage& g, VehicleCreator& creator);

/**
 * Function that gets the registration number of the vehicle from the user and then if it exists removes it from the Garage
 * @param g
 */
void removeVehicleFromGarage(Garage& g);

int main(){

    MyString mainMenu(  "\n1.Create vehicle\n" 
                        "2.Show garage\n" 
                        "3.Show vehicles\n" 
                        "4.Add vehicle to garages\n" 
                        "5.Remove vehicle from garage\n"
                        "6.Delete garage\n" 
                        "7.Exit\n");
    VehicleCreator creator;
    int capacity;
    do{
        cout<<"Garage creation:\nEnter garage capacity: ";
        cin>>capacity;
    }while(capacity<=0);

    Garage* g = new Garage(capacity);
    
    char option;
    do{
        std::cout<<mainMenu<<"Enter option:";
        cin>>option;
        getchar();
        switch(option){
            case '1':createVehicle(creator); break;
            case '2':{
                if(!g){
                    cout<<"\nGarage deleted!"<<endl;
                }else{
                    cout<<(*g);
                }
                break;
            }
            case '3':cout<<creator;break;
            case '4':{
                if(!g) {
                    cout<<"\nGarage deleted!"<<endl;
                }else{ 
                    addVehicleToGarage(*g,creator);
                } 
                break;
            }
            case '5':{
                if(!g){
                    cout<<"\nGarage deleted!"<<endl;
                }else{
                    removeVehicleFromGarage(*g);
                }
                break;
            }
            case '6':{
                if(!g){
                    cout<<"\nGarage already deleted!"<<endl;
                }else{
                    delete g;
                    g = nullptr;
                }
                break;
            }
        }

    }while(option!='7');

    return 0;
}

void createVehicle(VehicleCreator& creator){
    MyString registration;
    getInputForVehicle("\nEnter vehicle's registration: ", registration);
    char c;

    MyString description;
    getInputForVehicle("Enter vehicle's description: ", description);
    
    int space;
    cout<<"Enter vehicle's space: ";
    cin>>space;

    try{
        creator.createVehicle(registration, description, space);
    }catch(std::exception& e){
        cout<<"\n"<<e.what()<<endl;
    }
}

void getInputForVehicle(const char* msg, MyString& string){
    char c;
    cout<<msg;
    while(true){
        c=getchar();
        if(c=='\n'){break;}
        string+=c;
    };
}

void addVehicleToGarage(Garage& g, VehicleCreator& creator){
    if(creator.getNumberOfVehicles()==0){
        cout<<"\nThere are no vehicles created! Please first create one!"<<endl;
    }else{
        MyString registration;
        getInputForVehicle("\nEnter vehicle's registration: ",registration);
        Vehicle*v = creator.getVehicleByRegistration(registration);
        while(v==nullptr){
            registration.clear();
            getInputForVehicle("Invalid vehicle registration! Please try again: ", registration);
            v= creator.getVehicleByRegistration(registration);
        }

        try{
            g.insert(*v);
        }catch(std::exception& e){
            cout <<"\n"<< e.what() << endl;
        }
    }
}

void removeVehicleFromGarage(Garage& g){
    MyString registration;
    getInputForVehicle("\nEnter vehicle's registration: ", registration);

    try{
        g.erase(registration.c_str());
    }catch(std::exception& e) {
        cout<<"\n"<<e.what()<<endl;
    }
}