#define CATCH_CONFIG_MAIN
#include"../catch2.hpp"
#include"Vehicle.hpp"

TEST_CASE("Constructor"){
    SECTION("Nullptr for registration number"){
        
        try{
            Vehicle v(nullptr, "test",10);
        }catch(std::exception& e){
            REQUIRE(strcmp(e.what(), "Argument should not be nullptr!")==0);
        }       
    }
    
    SECTION("Nullptr for description"){
         try{
            Vehicle v1("test", nullptr, 5);
        }catch(std::exception& e){
            REQUIRE(strcmp(e.what(), "Argument should not be nullptr!")==0);
        }
    }

    SECTION("Nullptr for registration number and description"){
        try{
            Vehicle v2(nullptr, nullptr, 5);
        }catch(std::exception& e){
            REQUIRE(strcmp(e.what(), "Argument should not be nullptr!")==0);
        }
    }

    SECTION("Invalid space - 0"){
        try{
            Vehicle v("regNum", "descr", 0);
        }catch(std::exception& e){
            REQUIRE(strcmp(e.what(), "Vehicle space cannot be 0")==0);
        }
    }

    SECTION("Normal creation"){
        //Arrange
        Vehicle v("regNum", "descr", 2);

        //Assert
        REQUIRE(v.space()==2);
        REQUIRE(strcmp(v.registration(), "regNum")==0);
        REQUIRE(strcmp(v.description(), "descr")==0);

    }
}