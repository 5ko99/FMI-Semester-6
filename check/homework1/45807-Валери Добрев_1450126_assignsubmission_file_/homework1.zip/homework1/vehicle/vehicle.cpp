#include"vehicle.hpp"


Vehicle::Vehicle(MyString registrationNumber, MyString description, size_t space): vehicleRegistrationNumber(registrationNumber), vehicleDescription(description), vehicleSpace(space){
    if(space==0){
        throw std::invalid_argument("Vehicle space cannot be 0");
    }
}

const char* Vehicle::registration() const{ return vehicleRegistrationNumber.c_str(); }

const char* Vehicle::description() const{return vehicleDescription.c_str(); }

size_t Vehicle::space() const{ return vehicleSpace; }

std::ostream& operator<<(std::ostream& os, const Vehicle& vehicle){
    os<<"\n///////////////////////////////////////////////////\n"
      <<"Vehicle's registertration: "<< vehicle.registration()<<"\n"
      <<"Vehicle's description: "<< vehicle.description()<<"\n"
      <<"Vehicle's space: "<< vehicle.space()<<"\n"
      << "///////////////////////////////////////////////////";
    return os; 
}