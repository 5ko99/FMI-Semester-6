#pragma once
#include"../myString/myString.hpp"


class Vehicle{
    MyString vehicleRegistrationNumber;
    MyString vehicleDescription;
    size_t vehicleSpace;

public:
    /**
     * Constructor for creating a Vehicle
     * @param registrationNumber
     * @param description
     * @param space that the Vehicle takes
     */
    Vehicle(MyString registrationNumber, MyString description, size_t space);

    /**
     * Getters for the class' fields
     */
    const char* registration() const;

    const char* description() const;

    size_t space() const;
};

/**
 * Funtion for putting Vehicle's information in output stream
 */
std::ostream& operator<<(std::ostream& os, const Vehicle& vehicle);