#define CATCH_CONFIG_MAIN
#include "../catch2.hpp"
#include "myString.hpp"

TEST_CASE("Constructors"){

    SECTION("Default constructor"){
        //Arrange
        MyString str;

        //Assert
        REQUIRE(str.c_str()[0] == '\0');
        REQUIRE(str.size() == 0);
    }

    SECTION("Constructor with char* as parameter"){
        //Arrange
        MyString str("test_string");

        //Assert
        REQUIRE(strcmp(str.c_str(), "test_string") == 0);
        REQUIRE(str.size()==11);
    }
    SECTION("With null parameter"){
       
        try{
            MyString str(nullptr);
        }catch(std::exception& e){
            REQUIRE(strcmp(e.what(),"Argument should not be nullptr!")==0);
        }
    }

    SECTION("Copy constructor"){
        //Arrange
        MyString str("test_string");
        MyString copy(str);

        //Assert
        REQUIRE(strcmp(copy.c_str(), "test_string")==0);
        REQUIRE(copy.size() == 11);
    }
}

TEST_CASE("Copy assignment operator", "[operator=]"){
    
    SECTION("Self copy"){
        //Arrange
        MyString str("test_string");

        //Act
        str = str;

        //Assert
        REQUIRE(strcmp(str.c_str(), "test_string") == 0);
        REQUIRE(str.size() == 11);
    }

    SECTION("Copy of other string"){
        //Arrange
        MyString str("test_string");
        MyString copy;

        //Act
        copy = str;

        //Assert
        REQUIRE(strcmp(copy.c_str(), "test_string") == 0);
        REQUIRE(copy.size() == 11);
    }
}

TEST_CASE("Access to member at given position", "[at]"){
    
    SECTION("Out of range position"){
        //Arrange
        MyString str("test_string");

        //Assert
        REQUIRE_THROWS(str.at(12));
    }

    SECTION("In range position"){
        //Arrange
        MyString str("test_string");

        //Assert
        REQUIRE(str.at(1)=='e');
    }
    SECTION("Could change the value"){
        //Arrange
        MyString str("test_string");

        //Act
        str.at(4)=' ';

        //Assert
        REQUIRE(strcmp(str.c_str(), "test string") == 0);
    }
}

TEST_CASE("Array subscript operator", "[operator[]]"){
        SECTION("Changing the element"){
            //Arrange
            MyString str("test_string");

            //Act
            str[1]='E';

            //Assert
            REQUIRE(str.c_str()[1] =='E');
        }
        SECTION("Constant reference to the letter"){
             //Arrange
            MyString str("test_string");

            //Act
            const char c = str[1];

            //Assert
            REQUIRE(c=='e');
        }
        
}

TEST_CASE("Retrieving the first letter of the string", "[front]"){
        SECTION("Changing the front letter"){
            //Arrange
            MyString str("test_string");

            //Act
            str.front()='T';

            //Assert
            REQUIRE(str.c_str()[0] =='T');
        }
        SECTION("Constant reference to the front letter"){
            //Arrange
            MyString str("test_string");

            //Act
            const char c = str.front();

            //Assert
            REQUIRE(c =='t');
        }   
}

TEST_CASE("Retrieving the last letter of the string", "[back]"){
        SECTION("Changing the last letter"){
            //Arrange
            MyString str("test_string");

            //Act
            str.back()='G';

            //Assert
            REQUIRE(str.c_str()[10] =='G');
        }
        SECTION("Constant reference to the last letter"){
            //Arrange
            MyString str("test_string");

            //Act
            const char c = str.back();

            //Assert
            REQUIRE(c =='g');
        }   
}

TEST_CASE("Check if the string is empty", "[empty]"){
    SECTION("Emptry string"){
        //Arrange
        MyString str;

        //Assert
        REQUIRE(str.empty());
    }
    SECTION("Not empty string"){
        //Arrange
        MyString str("test_string");

        //Assert
        REQUIRE_FALSE(str.empty());
    }
}

TEST_CASE("Size of the string"){
    //Arrange
    MyString str("test_string");

    //Act
    size_t size = str.size();

    //Assert
    REQUIRE(size == strlen("test_string"));
}

TEST_CASE("Clear string", "[clear]"){
    //Arrange
    MyString str("test_string");

    //Act
    str.clear();

    //Assert
    REQUIRE(str.c_str()[0]==0);
    REQUIRE(str.size()==0);
}

TEST_CASE("Push character in the end", "[push_back]"){

    //Arrange
    MyString str("test_string");

    //Act
    str.push_back('c');

    //Assert
    REQUIRE(strcmp(str.c_str(), "test_stringc") == 0);
    
}

TEST_CASE("Removing the last character", "[pop_back]"){
     //Arrange
    MyString str("test_string");

    //Act
    str.pop_back();

    //Assert
    REQUIRE(strcmp(str.c_str(), "test_strin") == 0);
}

TEST_CASE("Adding character in the end", "[operator+=]"){
    //Arrange
    MyString str("test_string");

    //Act
    str+='c';

    //Assert
    REQUIRE(strcmp(str.c_str(), "test_stringc") == 0);

}

TEST_CASE("Concatenating 2 strings", "[operator+=]"){ 
    //Arrange
    MyString str1("test_");
    MyString str2("string");

    //Act
    str1+=str2;

    //Assert
    REQUIRE(strcmp(str1.c_str(), "test_string")== 0);

}

TEST_CASE("New string, result of concatenation of string and character", "[operator+]"){
    //Arrange
    MyString str("test_string");

    //Act
    MyString res = str+'s';

    //Assert
    REQUIRE(strcmp(res.c_str(), "test_strings") == 0);
    REQUIRE(res.size()==12);
}

TEST_CASE("New string, result of concatenation of two strings", "[operator+]"){
    //Arrange
    MyString str1("test_");
    MyString str2("string");

    //Act
    MyString res = str1+str2;

    //Assert
    REQUIRE(strcmp(res.c_str(), "test_string") == 0);
    REQUIRE(res.size()==11);
}

TEST_CASE("If 2 strings are equal", "[operator==]"){
    //Arrange
    MyString str1("test");
    MyString str2("test");
    MyString str3("string");

    //Assert
    REQUIRE(str1==str2);
    REQUIRE_FALSE(str1==str3);
}

TEST_CASE("Alphabetically smaller"){
    //Arrange
    MyString str1("string");
    MyString str2("test");
    MyString str3("apple");

    //Assert
    REQUIRE(str1 < str2);
    REQUIRE_FALSE(str1<str3);
}










