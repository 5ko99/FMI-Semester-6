#pragma once
#include<iostream>
#include<cstring>
#include<stdexcept>
#include<cassert>

class MyString{
    char* data;
    std::size_t length;
public:

    /** 
     * Default constructor  
     */
    MyString();

    /** 
     * Constructor with given data
     * @param data of the new string
     */
    MyString(const char* data);

    /** 
     * Copy constructor 
     * @param string of which copy will be made
     */
    MyString(const MyString& string);

    /** 
     * Predefined operator for assigning
     * @param string which value to be assigned
     */
    MyString& operator=(const MyString& string);

    /** 
     * Destructor which deletes the data that the object allocated
     */
    ~MyString();

    /** 
     * Method that gives acces to the charecter at the given postion 
     * @param pos
     * @throws std::out_of_range if the position is invalid
     */
    char& at(std::size_t pos);

    const char& at(std::size_t pos) const;

    /**
     * Overrided operator for giving access to the character at the given postion
     * @param pos
     */
    char& operator[](std::size_t pos);

    const char& operator[](std::size_t pos)const;

    /**
     * Method that gives access to the first character in the string
     */
    char& front();

    const char& front() const;

    /**
     * Method that gives access to the last character in the string
     */
    char& back();

    const char& back() const;

    /**
     * Method that checks if the string is empty
     * @return true if is empty, false otherwise
     */
    bool empty() const;

    /** 
     * Method for retrieving the length of the string
     * @return length of the string
     */
    std::size_t size() const;

    /**
     * Method that removes all characters from the string
     */
    void clear();

    /**
     * Method that pushes character in the end of the string
     * @param c
     */
    void push_back(char c);

    /**
     * Method that removes the last character from the string
     */
    void pop_back();

    /**
     * Operator that concatenates the string with the character
     * @param c
     */
    MyString& operator+=(char c);

    /**
     * Operator that concatenates the string with another
     * @param rhs
     */
    MyString& operator+=(MyString& rhs);

    /**
     * Operator that creates new string - concatenated this string with the character 
     * @param c
     */
    MyString operator+(char c) const;

     /**
     * Operator that creates new string - concatenated this string with another string 
     * @param rhs
     */
    MyString operator+(const MyString& rhs) const;

    /**
     * Method for retrieving pointer to null-terminated char array
     * @return char* 
     */
    const char* c_str() const;

    /**
     * Operator that checks if two strings are equal
     * @param rhs
     */
    bool operator==(const MyString& rhs)const;

    /**
     * Operator that compares two strings lexicographically
     * @param rhs
     */
    bool operator<(const MyString &rhs) const;

};

/**
 * Operator that puts the string's data into output stream
 * @param os
 * @param string
 * @return reference to the output stream with the string's data in it
 */
std::ostream& operator<<(std::ostream& os, const MyString string);