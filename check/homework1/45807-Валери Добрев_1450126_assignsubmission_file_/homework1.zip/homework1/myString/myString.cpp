#include "myString.hpp"

MyString::MyString() : length(0) {
    this->data = new char[1];
    this->data[0] = '\0';
    this->length = 0;
}

MyString::MyString(const char* data){
    if(!data){
        throw std::invalid_argument("Argument should not be nullptr!");
    }
    this->length = strlen(data);
    this->data = new char[this->length+1];
    strcpy(this->data, data);
}

MyString::MyString(const MyString& string): length(string.length) {    
    this->data = new char[this->length+1];
   strcpy(this->data, string.data);
}

MyString::~MyString(){
    if(this->data){
        delete[] this->data;
    }
    this->data=nullptr;
}

MyString& MyString::operator=(const MyString& string){
    if(this==&string) return *this;
    this->length = string.length;

    if(this->data){
        delete [] this->data;
    }
    this->data = new char[this->length+1];
    strcpy(this->data, string.data);

    return *this;

}


char& MyString::at(std::size_t pos){
    if(pos>=this->length){
        throw std::out_of_range("Index out of range");
    }
    return this->data[pos];
}


const char& MyString::at(std::size_t pos) const{ 
    if(pos>=this->length){
        throw std::out_of_range("Index out of range");
    }
    return this->data[pos];
}


char& MyString::operator[](std::size_t pos){
    return this->data[pos];
}

const char& MyString::operator[](std::size_t pos) const{ return this->data[pos];}

char& MyString::front(){
    return this->data[0];
}

const char& MyString::front()const{ return this->data[0]; }

char& MyString::back(){
    return this->data[this->length-1];
};

const char& MyString::back() const{ return this->data[this->length-1];}

bool MyString::empty() const{ return this->length==0; }

size_t MyString::size() const{ return this->length; }

void MyString::clear(){
    size_t size= length;
    for(size_t i=0; i<size; i++){
        pop_back();
    }
}

void MyString::push_back(char c){
    char* new_data = new char[this->length+2];
    if(!new_data || !this->data){
        if(new_data){
            delete [] new_data;
        }
        throw std::bad_alloc();
    }

    strcpy(new_data,this->data);
    new_data[this->length] = c;
    new_data[this->length+1]='\0';

    delete [] this->data;
    this->data = new_data;
    this->length++;

}

void MyString::pop_back(){
    this->length--;
    this->data[this->length] = '\0';
}

MyString& MyString::operator+=(char c){
    this->push_back(c);
    return *this;
}

MyString& MyString::operator+=(MyString& rhs){
    char* new_data = new char[this->length + rhs.length +1];
    if(!this->data || !rhs.data || !new_data){
        if(new_data){
            delete [] new_data;
        }
        throw std::bad_alloc();
    }
    strcpy(new_data,this->data);
    strcat(new_data, rhs.data);

    this->length+=rhs.length;
    delete [] this->data;
    this->data = new_data;

    return *this;
}

MyString MyString::operator+(char c) const{
    char* new_data = new char[this->length + 2];

    strcpy(new_data,this->data);
    new_data[this->length]=c;
    new_data[this->length+1] = '\0';

    MyString new_string(new_data);
    delete [] new_data;

    return new_string;
}

MyString MyString::operator+(const MyString& rhs) const{ 
    char* new_data = new char[this->length + rhs.length +1];

    strcpy(new_data,this->data);
    strcat(new_data, rhs.data);

    MyString new_string(new_data);
    delete [] new_data;

    return new_string;
}

const char* MyString::c_str() const{ return this->data;}

bool MyString::operator==(const MyString& rhs)const{ 
    return strcmp(this->data,rhs.data)==0;
}

bool MyString::operator<(const MyString &rhs) const{ 
    if(strcmp(this->data, rhs.data)<0){return true;}
    return false;
}

std::ostream& operator<<(std::ostream& os, const MyString string){
    
    os<<string.c_str();
    return os;
}


