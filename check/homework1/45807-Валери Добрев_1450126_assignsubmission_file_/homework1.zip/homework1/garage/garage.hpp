#pragma once
#include "../vehicle/vehicle.hpp"


class Garage{
    size_t capacity;
    size_t numberOfVehicles;
    Vehicle** vehicles;

    /**
     * Method that returns a pointer to the Vehicle with the given reistration
     * @param registration
     * @return nullptr if Vehicle not found, pointer to the Vehicle otherwise
     */    
    Vehicle* getVehicleByRegistration(const char* registration) const;

    /**
     * Method that swaps two Vechicles
     * @param v1 first Vehicle
     * @param v2 second Vehicle
     */
    void swapVehicles(Vehicle* v1, Vehicle* v2);

public:

    /**
     * Constructor that creates Garage with given capacity
     * @param capacity
     */
    Garage(size_t capacity);

    /**
     * Copy constructor
     * @param other garage
     */
    Garage(Garage& other);

    /**
     * Destructor
     */
    ~Garage();

    /**
     * Copy assignment operator
     * @param other garage
     */
    Garage& operator=(Garage& other);
   
    /**
     * Method that inserts Vehicle in the Garage
     * @param v Vehicle to be inserted
     * @throws std::invalid_argument if not enough space or Vehicle with the same registration exists
     */
    void insert(Vehicle& v);

    /**
     * Method that removes Vehicle from the Garage by registration
     * @param registration of the Vehicle 
     * @throws std::invalid_argument if nullptr registration or Vehicle not found
     */
    void erase(const char* registration);

    /**
     * Method that retrievs the Vehicle at given position in the Garage
     * @param position 
     * @throws std::invalid_argument if position is bigger than the number of cars in the Garage
     */
    const Vehicle& at(size_t pos) const;

    /**
     * Operator for retrieving the Vehicle at given position in the Garage
     * @param position 
     */
    const Vehicle& operator[](size_t pos)const;

    /**
     * Method that checks if the Garage is empty
     * @return true if is empty, false otherwise
     */
    bool empty() const;

    /**
     * Method for retrieving the number of Vehicles in the Garage
     */
    size_t size() const;

    /**
     * Method that removes all Vehicles from the Garage and set the number of Vehicles to 0
     */
    void clear();

    /**
     * Method for retrieving constant pointer to Vehicle with the given registration
     * @return pointer to the Vehicle if exists, nullptr otherwise
     */
    const Vehicle* find(const char* registration) const;

};

/**
 * Funtion for putting Garage's information in output stream
 */
std::ostream& operator<<(std::ostream& os, const Garage& garage);