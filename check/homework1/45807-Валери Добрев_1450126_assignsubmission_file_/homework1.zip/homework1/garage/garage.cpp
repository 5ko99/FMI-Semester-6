#include "garage.hpp"

Garage::Garage(size_t capacity): capacity(capacity), numberOfVehicles(0) {
    if(capacity == 0){
        throw std::invalid_argument("The garage could not be with 0 capacity");
    }
    vehicles = new Vehicle*[capacity];     
}

Garage::Garage(Garage& other) : Garage(other.capacity){
    for(size_t i = 0; i < other.numberOfVehicles; i++){
        this->vehicles[i] = other.vehicles[i];
    }
    this->numberOfVehicles = other.numberOfVehicles;
}


Garage::~Garage(){
    delete [] vehicles;
}

Garage& Garage::operator=(Garage& other){
    delete [] this->vehicles;

    this->capacity = other.capacity;
    this->numberOfVehicles = other.numberOfVehicles;
    this->vehicles = new Vehicle*[numberOfVehicles];

    for(size_t i=0; i<numberOfVehicles; i++){
        vehicles[i] = other.vehicles[i];
    }
    return *this;
}

void Garage::insert(Vehicle& v){
    if(v.space() > capacity){
        throw std::invalid_argument("Vehicle is too big for the garage");
    }
    if(getVehicleByRegistration(v.registration())){
        throw std::invalid_argument("Vehicle already exists!");
        
    }
    vehicles[numberOfVehicles] = &v;
    numberOfVehicles++;
    capacity-=v.space();
}

void Garage::erase(const char* registration){
    if(!registration){
        throw std::invalid_argument("Invalid registration!");
    }

    Vehicle* v = getVehicleByRegistration(registration);
    if(!v){
        throw std::invalid_argument("Vehicle not found!");
    }

    swapVehicles(v, vehicles[numberOfVehicles-1]);

    capacity+=vehicles[numberOfVehicles-1]->space();
    vehicles[numberOfVehicles-1] = nullptr;
    numberOfVehicles-=1;
}

Vehicle* Garage::getVehicleByRegistration(const char* registration) const{ 
    for(size_t i=0; i<numberOfVehicles; i++){
        if(strcmp(vehicles[i]->registration(),registration) == 0){
            return vehicles[i];
        }
    }
    return nullptr;
}

void Garage::swapVehicles(Vehicle* v1, Vehicle* v2){
    Vehicle* temp = v1; 
    v1=v2; 
    v2=v1;
}

const Vehicle& Garage::at(size_t pos) const{ 
    if(pos>=numberOfVehicles){
        throw std::out_of_range("Index out of range!");
    }
    return *vehicles[pos];
}

const Vehicle& Garage::operator[](size_t pos)const{ 
    return *vehicles[pos];
}

bool Garage::empty() const{ return numberOfVehicles==0; }

void Garage::clear(){
    for(size_t i=0; i<numberOfVehicles; i++){
        capacity+=vehicles[i]->space();
        vehicles[i]=nullptr;
    }
    numberOfVehicles = 0;
}

const Vehicle* Garage::find(const char* registration) const{
    return getVehicleByRegistration(registration);
}

size_t Garage::size() const{ return numberOfVehicles; }

std::ostream& operator<<(std::ostream& os, const Garage& garage){
    if(garage.size()==0){
        os<<"\nThe garage is empty.\n";
    }else{
        os<<"\n Number of cars in the garage: "<<garage.size();
        for(size_t i=0; i<garage.size(); i++){
            os<<garage[i]<<'\n';
        }
    }
    return os;
}