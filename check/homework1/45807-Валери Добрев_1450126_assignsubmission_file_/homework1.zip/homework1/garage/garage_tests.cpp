#define CATCH_CONFIG_MAIN
#include"../catch2.hpp"
#include "garage.hpp"

TEST_CASE("Constructor with given capacity"){

    SECTION("Invalid capacity"){
        try{
            Garage g(0);
        }catch(std::exception& e){
            REQUIRE(strcmp(e.what(), "The garage could not be with 0 capacity") == 0);
        }
    }
    SECTION("Valid garage"){
        //Arrange
        Garage g(5);

        //Assert
        REQUIRE(g.size() == 0);
    }

}

TEST_CASE("Copy constructor"){
    //Arrange
    Garage g(3);
    Vehicle v("regNum", "descr",2);
    g.insert(v);

    //Act
    Garage g2(g);

    //Assert
    REQUIRE(g2.size() == 1);
    REQUIRE(strcmp(g2.at(0).registration(), "regNum")==0);
    REQUIRE(strcmp(g2.at(0).description(), "descr")==0);
    REQUIRE(g2.at(0).space()==2);
}

TEST_CASE("Copy assignment operator"){
    //Arrange
    Garage g(3);
    Garage g2(2);
    Vehicle v("regNum", "descr",1);
    g.insert(v);

    //Act
    g2 = g;

    //Assert
    REQUIRE(g2.size() == 1);
    REQUIRE(strcmp(g2.at(0).registration(), "regNum")==0);
    REQUIRE(strcmp(g2.at(0).description(), "descr")==0);
    REQUIRE(g2.at(0).space()==1);
   
}

TEST_CASE("Insert Vehicle into the garage", "[insert]"){
    SECTION("Not enough space in the garage"){
        //Arrange
        Garage g(1);
        Vehicle v("regNum", "descr",2);

        //Assert
        REQUIRE_THROWS(g.insert(v));
        REQUIRE(g.size() == 0);
    }
    SECTION("Vehicle already exists"){
        //Arrange
        Garage g(5);
        Vehicle v("regNum", "descr",2);

        //Act
        g.insert(v);

        //Assert
        REQUIRE_THROWS(g.insert(v));
        REQUIRE(g.size() == 1);
    }
    SECTION("Valid Vehicle"){
        //Arrange
        Garage g(5);
        Vehicle v("regNum", "descr",2);

        //Act
        g.insert(v);

        //Assert
        REQUIRE(g.size() == 1);
    }
}

TEST_CASE("Removing Vehicle from the garage by registration number", "[erase]"){
    SECTION("Invalid registration number"){
        //Arrange
        Garage g(5);

        //Assert
        REQUIRE_THROWS(g.erase(nullptr));
    }
    SECTION("Non existing Vehicle registration number"){
        //Arrange
        Garage g(5);        
        Vehicle v("regNum", "descr", 2);

        g.insert(v);

        //Assert
        REQUIRE_THROWS(g.erase("reg"));
    }
    SECTION("Existing Vehicle"){
        //Arrange
        Garage g(5);
        Vehicle v("regNum", "descr",2);

        g.insert(v);

        //Act
        g.erase("regNum");

        //Assert
        REQUIRE(g.size()==0);
    }
}

TEST_CASE("Accessing Vehicle at given postition", "at"){
    SECTION("Invalid index"){
        //Arrange
        Garage g(5);
        Vehicle v("regNum", "descr",2);
        g.insert(v);

        //Assert
        REQUIRE_THROWS(g.at(2));
    }
    SECTION("Valid index"){
        //Arrange
        Garage g(5);
        Vehicle v("regNum", "descr",2);
        g.insert(v);

        //Act
        Vehicle res = g.at(0);

        //Assert
        REQUIRE(strcmp(res.registration(), "regNum")==0);
        REQUIRE(strcmp(res.description(), "descr")==0);
        REQUIRE(res.space()==2);
    }
}

TEST_CASE("Removing all vechicles from the garage", "[clear]"){
    //Arrange
    Garage g(5);
    Vehicle v("regNum", "descr",2);
    g.insert(v);

    //Act
    g.clear();

    //Assert
    REQUIRE(g.size()== 0);
    REQUIRE(&g[0] == nullptr);
}

TEST_CASE("Retrieving Vehicle by registration", "[find]"){
    SECTION("Non existing"){
        //Arrange
        Garage g(5);

        //Act
        const Vehicle* v = g.find("test");
        
        //Assert
        REQUIRE(v==nullptr);
    }
    SECTION("Existing Vehicle"){
        //Arrange
        Garage g(5);
        Vehicle v("regNum", "descr",2);
        g.insert(v);

        //Act
        const Vehicle* pv = g.find("regNum");

        //Assert
        REQUIRE(strcmp(pv->registration(), "regNum")==0);
        REQUIRE(strcmp(pv->description(), "descr")==0);
        REQUIRE(pv->space()==2);
    }
}