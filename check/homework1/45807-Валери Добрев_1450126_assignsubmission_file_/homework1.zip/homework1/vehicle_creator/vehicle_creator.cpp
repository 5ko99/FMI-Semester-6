#include "vehicle_creator.hpp"

VehicleCreator::VehicleCreator(size_t capacity): capacity(capacity), numberOfVehicles(0), vehicles(new Vehicle*[capacity]){
}

VehicleCreator::~VehicleCreator(){
    for(size_t i = 0; i < numberOfVehicles; i++){
        delete vehicles[i];
    }
    delete [] vehicles;
}

Vehicle* VehicleCreator::createVehicle(MyString registration, MyString description, size_t space){
    if(getVehicleByRegistration(registration)){
        throw std::invalid_argument("Vehicle with this registration already exists");
    }
    if(numberOfVehicles == capacity){

        this->resize();
    }
    this->vehicles[numberOfVehicles] = new Vehicle(registration, description, space);
    numberOfVehicles++;
    return this->vehicles[numberOfVehicles-1];
}

void VehicleCreator::resize(){
    Vehicle** new_vehicles = new Vehicle*[capacity*2];
    for(size_t i=0; i<numberOfVehicles; i++){
        new_vehicles[i] = vehicles[i];
    }
    this->capacity *=2;
    delete [] vehicles;
    vehicles = new_vehicles;
}

size_t VehicleCreator::getNumberOfVehicles() const{ return this->numberOfVehicles; }

const Vehicle* VehicleCreator::at(size_t pos)const{
    if(numberOfVehicles <= pos ){
        throw std::invalid_argument("Invalid postion");
    }
    return this->vehicles[pos];
}

Vehicle* VehicleCreator::getVehicleByRegistration(const MyString registration)const{ 
    for(size_t i = 0; i < numberOfVehicles;i++){
        if(strcmp(vehicles[i]->registration(), registration.c_str())==0) {
            return this->vehicles[i];
        }
    }
    return nullptr;
}


std::ostream& operator<<(std::ostream& os, const VehicleCreator& creator){
    if(creator.getNumberOfVehicles()==0){
        os<<"\nNo vehicles created!\n";
    }
    else{
        for(size_t i=0; i<creator.getNumberOfVehicles(); i++){
            os<<(*creator.at(i))<<'\n';
        }
    }
    return os;
}

