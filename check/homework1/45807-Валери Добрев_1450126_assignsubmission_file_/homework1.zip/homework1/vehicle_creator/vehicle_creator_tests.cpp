#define CATCH_CONFIG_MAIN
#include"../catch2.hpp"
#include "vehicle_creator.hpp"


TEST_CASE("Creating new vehicle"){
    SECTION("With invalid name"){
        //Arrange
        VehicleCreator creator;
        
        //Assert
        REQUIRE_THROWS(creator.createVehicle(nullptr, "desk", 1));
        REQUIRE(creator.getNumberOfVehicles()==0);
    }
    SECTION("With invalid description"){
        //Arrange
        VehicleCreator creator;
        
        //Assert
        REQUIRE_THROWS(creator.createVehicle("regNum",nullptr, 1));
        REQUIRE(creator.getNumberOfVehicles()==0);
    }
    SECTION("With invalid space"){
        //Arrange
        VehicleCreator creator;
        
        //Assert
        REQUIRE_THROWS(creator.createVehicle("regnum", "desc", 0));
        REQUIRE(creator.getNumberOfVehicles()==0);
    }
    SECTION("Vehicle already exists"){
        //Arrange
        VehicleCreator creator;
        creator.createVehicle("regNum", "desc", 1);

        //Assert
        REQUIRE_THROWS(creator.createVehicle("regNum","desc1",3));
    }
    SECTION("Regular creation"){
        //Arrange
        VehicleCreator creator;
        
        //Act
        Vehicle* vehicle = creator.createVehicle("regnum", "desc", 2);

        //Assert
        REQUIRE(creator.getNumberOfVehicles()==1);
        REQUIRE(creator.at(0) == vehicle);
    }
    SECTION("Resizing array of vehicles"){
        //Arrange
        VehicleCreator creator(1);
        
        //Act
        Vehicle* vehicle = creator.createVehicle("regnum", "desc", 2);
        Vehicle* vehicle2 = creator.createVehicle("regnum2", "desc2",3);

        //Assert
        REQUIRE(creator.getNumberOfVehicles()==2);
        REQUIRE(creator.at(0) == vehicle);
        REQUIRE(creator.at(1) == vehicle2);
    }

}
TEST_CASE("Vehicle at given postion", "[at]"){
    SECTION("Invalid postion"){
        //Arrange
        VehicleCreator creator;
        creator.createVehicle("regnum", "desc",10);


        //Assert
        REQUIRE_THROWS(creator.at(1));
    }
    SECTION("Valid postion"){
        //Arrange
        VehicleCreator creator;
        Vehicle* v = creator.createVehicle("regnum", "desc",10);

        //Act
        const Vehicle* v1 = creator.at(0);

        //Assert
        REQUIRE(v == v1);
        REQUIRE(strcmp(v1->registration(), v1->registration())==0);
        REQUIRE(strcmp(v1->description(), v1->description())==0);
        REQUIRE(v->space() == v1->space());
    }
}

TEST_CASE("Get vehicle by registration", "[getVehicleByRegistration]"){
    SECTION("Non existing vehicle"){
        //Arrange
        VehicleCreator creator;

        //Act
        Vehicle* v= creator.getVehicleByRegistration("registration");

        //Assert
        REQUIRE(v==nullptr);
    }

    SECTION("Existring vehicle"){
        //Arrange
        VehicleCreator creator;
        Vehicle* v = creator.createVehicle("registration", "desc", 2);

        //Act
        Vehicle* v1= creator.getVehicleByRegistration("registration");

        //Assert
        REQUIRE(v==v1);
    }
}