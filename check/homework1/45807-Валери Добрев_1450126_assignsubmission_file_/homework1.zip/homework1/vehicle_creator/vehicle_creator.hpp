#include "../vehicle/vehicle.hpp"

class VehicleCreator{
    Vehicle** vehicles;
    size_t capacity;
    size_t numberOfVehicles;

    void resize();
public:
    /** 
     * Constructor
     * @param capacity
     */
    VehicleCreator(size_t capacity = 5);

    /** 
     * Destructor
     */
    ~VehicleCreator();

    /** 
     * Method that creates new Vehicle and adds it to the array of vehicles, if not enough space will call resize()
     * @param registration
     * @param description
     * @param space
     * @throws std::invalid argument if vehicle with this registration already exists
     */ 
    Vehicle* createVehicle(MyString registration, MyString description, size_t space);

    size_t getNumberOfVehicles() const;

    /** 
     * Method that returns pointer to the Vehicle at the given posiotion
     * @param pos
     */
    const Vehicle* at(size_t pos)const;

    /** 
     * Method that returns pointer to the Vehicle by given registration number
     * @param registration
     * @return pointer to the Vehicle if found, nullptr otherwise
     */
    Vehicle* getVehicleByRegistration(const MyString registration)const;
};

/**
 * Funtion for putting the list of arrays in output stream
 */
std::ostream& operator<<(std::ostream& os, const VehicleCreator& creator);