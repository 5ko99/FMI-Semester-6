#include "Garage.h"
#include <cstring>
#include <algorithm>
#include <stdlib.h>

#define DESC_LEN 100
#define REG_LEN 20

using std::cout;
using std::cin;
using std::endl;

Vehicle* createVehicle()
{
    char reg[REG_LEN], desc[DESC_LEN];
    size_t space;

    cout << "registration: ";
    cin.getline(reg, REG_LEN);

    // if(strlen(reg) + 1 >= REG_LEN)
    // {
    //     cin.clear();
    //     cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    // }

    cout << "description: ";
    cin.getline(desc, DESC_LEN);

//    if(strlen(desc) + 1 >= 20)
//     {
//         cin.clear();
//         cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
//     }

    cout << "space: ";
    cin >> space;

    return new Vehicle(reg, desc, space);
}

void resizeVehiclesArray(Vehicle** vehicles, size_t* capacity)
{
    Vehicle** newVehicles = new Vehicle*[*capacity * 2];
    std::copy(vehicles, vehicles + *capacity, newVehicles);

    delete [] vehicles;
    vehicles = newVehicles;
    *capacity*=2;
}

int main()
{
    char input[DESC_LEN];

    size_t initialCapacity = 10;
    size_t capacity;
    size_t size = 0;

    Vehicle** vehicles = new Vehicle*[initialCapacity];

    cout << "Enter max parking lots: ";
    cin >> capacity;

    Garage garage(capacity);

    do{
        cout << "Enter command (type info to view all commands):" << endl;
        cout << ">>> ";

        cin.getline(input, DESC_LEN);

        // if(strlen(input) + 1 >= 100)
        // {
        //     cin.clear();
        //     cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        // }

        if(strcmp(input, "info") == 0)
        {
            cout << "\t/view garage/" << endl;
            cout << "\t/view vehicles/" << endl;
            cout << "\t/create vehicle/" << endl;
            cout << "\t/delete vehicle/" << endl;
            cout << "\t/add vehicle to garage/" << endl;
            cout << "\t/remove vehicle from garage/" << endl;
            cout << "\t/clear garage/" << endl;
        }
        if(strcmp("view garage", input) == 0)
        {
            if(garage.size() == 0)
            {
                cout << "\tgarage is empty" << endl;
            }
            else
            {
                for (size_t i = 0; i < garage.size(); i++)
                {
                    cout << '\t' << garage[i].registration() << "; " << garage[i].description() << "; " << garage[i].space() << endl;
                }
            }
        }
        if(strcmp("view vehicles", input) == 0)
        {
            if(size == 0)
            {
                cout << "\tno vehicles" << endl;
            }
            else
            {
                for (size_t i = 0; i < size; i++)
                {
                    cout << '\t' << vehicles[i]->registration() << "; " << vehicles[i]->description() << "; " << vehicles[i]->space() << endl;
                }
            }
        }
        if(strcmp("create vehicle", input) == 0)
        {
            if(size == initialCapacity)
            {
                resizeVehiclesArray(vehicles, &initialCapacity);
            }
            Vehicle* newVehicle = createVehicle();
            if(newVehicle)
            {
                vehicles[size++] = newVehicle;
                cout << "\t" << newVehicle->registration() << " created" << endl;
            }

        }
        if(strcmp("delete vehicle", input) == 0)
        {
            cout << "Enter vehicle registration: ";

            char r[REG_LEN];
            cin.getline(r, REG_LEN);

            for (size_t i = 0; i < size; i++)
            {
                if(strcmp(vehicles[i]->registration(), r) == 0)
                {
                    delete vehicles[i];
                    for (size_t j = i; j < size; j++)
                    {
                        vehicles[j] = vehicles[j+1];
                    }
                    vehicles[size-1] = nullptr;
                    size--;
                    cout << "\t" << r << " destroyed" << endl;
                    break;
                }
            }
        }
        if(strcmp("add vehicle to garage", input) == 0)
        {
            cout << "Enter vehicle registration: ";

            char r[REG_LEN];
            cin.getline(r, REG_LEN);

            for (size_t i = 0; i < size; i++)
            {
                if(strcmp(vehicles[i]->registration(), r) == 0)
                {
                    garage.insert(*(vehicles[i]));
                    break;
                }
            }

            if(garage.find(r))
            {
                cout << "\t" << r << " added to garage" << endl;
            }
        }
        if(strcmp("remove vehicle from garage", input) == 0)
        {
            cout << "Enter vehicle registration: ";

            char r[REG_LEN];
            cin.getline(r, REG_LEN);
            garage.erase(r);

            if(!garage.find(r))
            {
                cout << "\t" << r << " removed from garage" << endl;
            }
        }
        if(strcmp("clear garage", input) == 0)
        {
            garage.clear();
            if(garage.empty())
            {
                cout << "\tgarage is cleared" << endl;
            }
        }

    }while(strcmp(input, "exit") != 0);

    delete [] vehicles;

    return 0;
}