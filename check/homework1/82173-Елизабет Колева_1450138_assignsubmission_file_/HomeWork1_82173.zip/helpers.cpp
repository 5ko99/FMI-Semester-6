#include "helpers.hpp"

#include <new>

//#include <iostream> // ?????????
 //std::size_t

//#include "MyString.hpp"

// std::size_t strlen(const char* string) {
//     std::size_t len = 0;
//     while(*string++) {
//         ++len;
//     }
//     return len;
// }

// std::size_t strlen(const char& string) {
//     std::size_t len = 0;
//     std::size_t pos = 0;
//     while(string[pos] != '\0') {
//         ++pos;
//         ++len;
//     }
//     return len;
// }

std::size_t strlen(const char* string) {
    std::size_t len = 0;
    while(*string++) {
        ++len;
    }
    return len;
}


void stringCopy(const char* source, char* destination) {
    std::size_t pos = 0;

    while(source[pos]) {
        destination[pos] = source[pos];
        ++pos;
    }
    destination[pos] = 0;
}

void resize(char* string, std::size_t strLength) {
    char* tmp = new char[strLength];
    stringCopy(string, tmp);
    
    deleteDynArr(string, strLength);
    stringCopy(tmp, string);

}

void deleteDynArr(char *string, std::size_t strLength) {
    delete[] string;
    string = nullptr;

    strLength = 0;
}

bool areTheSame(const char* checkThis, size_t strLengthWhat, const char* compareWithThis, size_t strLenCompared) {
    if(strLengthWhat != strLenCompared) {
        return 0;
    }
    for(size_t i = 0; i < strLengthWhat; ++i) {
        if(checkThis[i] != compareWithThis[i]) {
            return 0;
        }
    }
    return 1;
}