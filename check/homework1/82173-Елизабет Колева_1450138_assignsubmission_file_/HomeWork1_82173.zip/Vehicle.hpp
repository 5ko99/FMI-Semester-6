#ifndef VEHICLE_H
#define VEHICLE_H
#include "MyString.hpp"

class Vehicle {

private:
    MyString regNumb;
    MyString descriptionOfCar;
    std::size_t numberOfParkingSpace;

    //deletes dyn allocated memory and equals to 0
    void clear();

public:
    //constructor for copying one veh obj into our
    Vehicle(const Vehicle& otherVehicle);

    Vehicle(const char* registration, const char* description, std::size_t space);

    //rule of 3 destruct
    ~Vehicle();

    //rule of 3/ big four / operator =
    //Vehicle& operator=(Vehicle& other);

    //Връща регистрационния номер като C-style символен низ
    const char* registration() const; //-- Връща регистрационния номер като C-style символен низ.
    
    //Връща описанието на превозното средство като C-style символен низ
    const char* description() const; 
    
    //Връща мястото, което заема превозното средство при паркиране
    std::size_t space() const;

    bool operator==(const Vehicle& otherVehicle) const;

    // help function for printing
    void printingCarInfo() const;


};

#endif