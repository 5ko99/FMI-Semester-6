#ifndef HELPERS_H
#define HELPERS_H

#ifndef CSTDDEF
#define CSTDDEF

#include <cstddef> //std::size_t
#endif

std::size_t strlen(const char* string);

void stringCopy(const char* source, char* destination);

void resize(char* string, std::size_t strLength);

void deleteDynArr(char *string, std::size_t strLength);

bool areTheSame(const char* checkThis, size_t strLengthWhat, const char* compareWithThis, size_t strLenCompared);


#endif