#include "MyString.hpp"

bool MyString::isItAllocated(char*& strArr, size_t strArrLen) {
    try {
        strArr = new char[strArrLen];
    }
    catch (std::bad_alloc& bad) {
        std::cout << bad.what();
        return 0;
    }
    return 1;
}

void MyString::deleteArr() {
    delete[] string;
    strLength = 0;
}

MyString::MyString() 
    : string(nullptr), strLength(0)
{
}

MyString::MyString(const MyString& other) {
    stringCopy(other.string, string);
    isItAllocated(string, strlen(string));
}

MyString::MyString(const char* str) {
    strLength = strlen(str) + 1;
    if(isItAllocated(string, strLength)) {
        stringCopy(str, string);
    }

    strLength = 0;
    string = nullptr;
    throw -1; 
    //std::bad_alloc("Couldn't allocate memory! :/");
    //string = new char[strLength];

}

MyString& MyString::operator=(const MyString& other) {
    if (this != &other && other.strLength > strLength) {
        char* newStr = nullptr;
        if(isItAllocated(newStr, other.strLength)) {
            delete[] string;
            string = newStr;
            strLength = other.strLength;
            stringCopy(newStr, string);
            return *this;
        }
        throw -1;
    }
    else {
        stringCopy(other.string, string);
        strLength = other.strLength;
    }
    return *this;
}


MyString::~MyString() {
    if(string != nullptr) {
        deleteDynArr(string, strLength);
    }
    strLength = 0;
}


std::size_t MyString::size() const {
    return strLength;
}

char& MyString::at(std::size_t pos) {
    if(pos < 0 || pos > size()) {
        throw std::out_of_range("Position out of range!");
    }

    return string[pos];
}

const char& MyString::at(std::size_t pos) const {
    if(pos < 0 || pos > size()) {
        throw std::out_of_range("Position out of range!");
    }

    return string[pos];
}

char& MyString::front() {
    assert(strLength > 0);
    return string[0];
}

const char& MyString::front() const {
    assert(strLength > 0);
    return string[0];
}

char& MyString::back() {
    return string[strLength-1];
}

const char& MyString::back() const {
    return string[strLength-1];
}

bool MyString::empty() const {
    return strLength == 0;
}

//std::size_t size() const { } // up

void MyString::clear() {
    string[0] = '\0';
    strLength = 0;
}

void MyString::push_back(char c) {
    std::size_t tmpLength = strLength + 1;
    char* tmp = nullptr;

    if(isItAllocated(tmp, tmpLength)) {
        throw -1;
    }

    stringCopy(string, tmp);
    deleteDynArr(string, strLength);

    tmp[tmpLength-1] = c;
    stringCopy(tmp, string);
    strLength = tmpLength;
    //string = tmp;
    // delete[] tmp;
    //deleteDynArr(string, strLength);
}

void MyString::pop_back() {
    assert(strLength > 0);
    string[strLength-1] = '\0';
    strLength--;
}

char& MyString::operator[](std::size_t pos) {
    assert(pos < strLength);
    return string[pos];
}

const char& MyString::operator[](std::size_t pos) const {
    assert(pos < strLength);
    return string[pos];
}

MyString& MyString::operator+=(char c) {
    push_back(c);
    return *this;
}

MyString& MyString::operator+=(const MyString& rhs) {
    
    std::size_t rhsLen = strlen(rhs.string) + 1;
    std::size_t newLength = strLength + rhsLen;

    char* newString = nullptr;
    if(!isItAllocated(newString, newLength)) {
        return *this;
    }

    stringCopy(string, newString);
    deleteDynArr(string, strLength);
    string = newString;
    std::size_t pos = 0;

    for(std::size_t i = strLength; i<newLength; ++i) {
        newString[i] = rhs.string[pos];
        ++pos;
    }
    strLength = newLength;
    deleteDynArr(newString, newLength);

    return *this;

}

MyString MyString::operator+(char c) const {
    MyString newString(*this);
    newString.push_back(c);
    return newString;
}

MyString MyString::operator+(const MyString& rhs) const {
    MyString newString(*this);
    newString += rhs;
    return newString;
}

const char* MyString::c_str() const {
    // char* pointNullArray = new char[strLength];
    // stringCopy(string, pointNullArray);
    // return pointNullArray;

    return string;
}

bool MyString::operator==(const MyString &rhs) const {
    if(strLength != rhs.strLength) {
        return false;
    }

    for(std::size_t i = 0; i < strLength; ++i) {
        if(string[i] != rhs.string[i]) {
            return false;
        }
    }

    return true;
}

bool MyString::operator<(const MyString &rhs) const {
    //if(string == ) prazen string mojem li da imame? Chudenka 100
    
    std::size_t pos = 0;
    while(pos < strLength && pos < rhs.strLength) {
        if(string[pos] != rhs.string[pos]) {
            return string[pos] < rhs.string[pos];
        }
        ++pos;
    }
    //empty cus empty string is lexi smaller than the other
    // !(rhs.empty()) cus if the second one's empty, the first isn't lexi smaller
    return empty() || !(rhs.empty());
}

std::ostream& operator<<(std::ostream& out, const MyString& rhs) {
    out << rhs.string;
    return out;
}
