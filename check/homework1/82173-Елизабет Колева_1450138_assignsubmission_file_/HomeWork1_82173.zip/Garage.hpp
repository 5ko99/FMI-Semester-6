#ifndef GARAGE_H
#define GARAGE_H

#include "VehicleStorage.hpp"

#include "Vehicle.hpp"


class Garage {

private:
    std::size_t capacity;

    std::size_t numberOfParkedCars;

    std::size_t occupied;

    //VehicleStorage** vehiclesInformation;

    Vehicle** vehiclesInformation;

    // making sure it's properly allocated the dyn array
    bool isMemoryAllocated(Vehicle**& userGarage, size_t userCapacity) const;

    // the place in the arr of the car, if it exists already
    std::size_t findMatch(const char* registration) const;

public:
    Garage();

    Garage(std::size_t size);

    Garage& operator=(const Garage& other);

    //rule of 3
    ~Garage();

    // rule of 3 + copy?

    void insert(Vehicle& v);
    
    //
    void erase(const char* registration);

    const Vehicle& at(std::size_t pos) const ;

    const Vehicle& operator[](std::size_t pos) const; 

    bool empty() const; 

    std::size_t size() const;

    void clear();

    const Vehicle* find(const char* registration) const;

};


#endif