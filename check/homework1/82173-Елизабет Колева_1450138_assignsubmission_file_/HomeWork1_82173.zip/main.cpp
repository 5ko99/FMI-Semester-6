#include<ios> //used to get stream size
#include<limits> //used to get numeric limits

#include "Garage.hpp"

using std::cin;
using std::cout;
using std::endl;

const unsigned int NUMBER_OF_CHOICES = 4;

void printMenu();
short getChoice();
void fixInput();
size_t getCapacity();
void printCurrentInfo(size_t capacity, size_t available, const Garage& userGarage);
void addNewVehicle(Garage userGarage, size_t capacity, size_t& notAvailable, size_t& carsInGarage, VehicleStorage& userStorage);
void removeVehicle(size_t& numberOfCars, size_t& notAvailable, Garage& userGarage);
void printGaragesContents(const Garage& userGarage);


int main() {
    size_t capacity = 0;
    unsigned choice;

    cout << "Let's make you a garage!" << endl;
    
    capacity = getCapacity();

    VehicleStorage userStorage(capacity);

    Garage userGarage(capacity);

    cout << "A garage with capacity of " << capacity << " was created." << endl; 

    size_t notAvailable = 0;
    size_t numberOfCars = 0;

    while(getChoice()) {

        printCurrentInfo(capacity, notAvailable, numberOfCars);

        choice = getChoice();

        switch (choice) 
        {
        case 1:
            addNewVehicle(userGarage, capacity, notAvailable, numberOfCars, userStorage);
            break;
        case 2:
            removeVehicle(numberOfCars, notAvailable, userGarage);
            break;
        case 3:
            printGaragesContents(userGarage);
            break;
        case 0:
            break;
        }
    }

    return 0;
}


void printMenu() {
    cout << "**********MENU**********" <<endl;
    cout << endl;
    cout << "1. Add a new vehicle to the garage. " << endl;
    cout << "2. Remove a vehicle from the garage." << endl;
    cout << "3. Print the contents of the garage." << endl;
    cout << "0. Exit." << endl;
    cout << "************************" <<endl;
}

short getChoice() {

    short choice;

    printMenu();
    do {
        cout << endl;
		cout << "Enter you choice: ";
        cin >> choice;

        if(!cin) {
            cout << "Your choice should be between 0 and 4!" << endl;
            fixInput();
            choice = -1;
        }
        else if (choice < 0 || choice > NUMBER_OF_CHOICES) {
			cout << "Please , choose a number between 0 and 4!" << endl;
        }

    } while (choice < 0 || choice > NUMBER_OF_CHOICES);

    return choice;
}

void fixInput() {
    cin.clear();
    cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
}

size_t getCapacity() {
    size_t capacity;

    do {
        cout << endl;
		cout << "You have to enter the desired capacity: ";
        cin >> capacity;

        if(!cin) {
            cout << "Your capacity should be a number bigger than 0!" << endl;
            fixInput();
            capacity = 0;
        }
        else if (capacity <= 0) {
			cout << "Please , choose a number bigger than 0!" << endl;
        }

    } while (capacity <= 0);

    return capacity;
}

void printCurrentInfo(size_t capacity, size_t available, const Garage& userGarage) {
    cout << "The current state of your garage - " << available << " used out of " << capacity << endl;
    cout << "You have " << userGarage.size() << " cars in the garage." << endl;
}

void addNewVehicle(Garage userGarage, size_t capacity, size_t& notAvailable, size_t& carsInGarage, VehicleStorage& userStorage) {
    if(notAvailable >= capacity) {
        cout << "You cannot add more cars into the garage! No more space available! :( " << endl;
        return;
    }

    char* tmp = new char[256];

    cout << "Enter the registration number: " << endl;
    cin.getline(tmp, 25);
    char* regNumbr = new char[strlen(tmp)+1];
    stringCopy(tmp, regNumbr);

    cout << "Enter the model/description of the car: " << endl;
    cin.getline(tmp, 256);
    char* description = new char[strlen(tmp)+1];
    stringCopy(tmp, description);

    size_t parkingSpace = 0;
    cout << "Enter the parking space needed to park the car: " << endl;
    parkingSpace = getCapacity();

    if(parkingSpace <= (capacity - notAvailable)) {
        Vehicle* tmpVehicle = userStorage.allocate(regNumbr, description, parkingSpace);
        cout << "Parking the car..." << endl;
        userGarage.insert(*tmpVehicle);

        notAvailable += userGarage[carsInGarage].space();
        ++carsInGarage;

        delete[] tmp;
        delete[] regNumbr;
        delete[] description;
    }
    else {
        cout << "Not enough space available!" << endl;
        return;
    }
}

void removeVehicle(size_t& numberOfCars, size_t& notAvailable, Garage& userGarage) {
    if(!userGarage.size()) {
        cout << "No vehicles parked, nothing can be removed!" << endl;
        return;
    }
    else {
        cout << "Choose from vehicle(s) with reg number(s): " << endl;
        for(size_t i = 0; i < userGarage.size(); ++i) {
            cout << (i+1) << ". ";
            userGarage[i].registration();
            cout << endl;
        }
        cout << "Now choose which one to remove (input reg number): " << endl;
        char* tmp = new char[256];
        cin.getline(tmp, 25);
        char* regNumbr = new char[strlen(tmp)+1];
        stringCopy(tmp, regNumbr);

        const Vehicle* tmpVehicle = userGarage.find(regNumbr);
        --numberOfCars;
        notAvailable -= tmpVehicle->space();
        userGarage.erase(regNumbr);
        
        delete[] tmp;
        delete[] regNumbr;
    }
}

void printGaragesContents(const Garage& userGarage) {
    if(!userGarage.size()) {
        cout << "No vehicles parked! No information available!" << endl;
        return;
    }
    cout << "-------------------------------" << endl;
    for(size_t i = 0; i < userGarage.size(); ++i) {
        cout << "Vehicle No" << i+1 << endl;
        userGarage[i].printingCarInfo();
        cout << "-------------------------------" << endl;
    }
}