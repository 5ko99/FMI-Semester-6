#include "VehicleStorage.hpp"

bool VehicleStorage::isMemoryAllocated(size_t capacity) {
    try {
        vehiclesStored = new Vehicle*[capacity];
    }
    catch (std::exception& e) {
        return false;
    }
    return true;
}


VehicleStorage::VehicleStorage() {
    vehiclesCount = 0;
    usedCapacity = 0;
    capacity = 1;

    if(isMemoryAllocated(capacity)) {
        for (size_t i = 0; i < capacity; ++i) {
            vehiclesStored[i] = nullptr;
        }
    }

}

VehicleStorage::VehicleStorage(size_t capacity) {
    if(this-> capacity != capacity) {
        this->capacity = capacity;
        if(isMemoryAllocated(capacity)) {

            for(size_t i = 0; i < capacity; ++i) {
                vehiclesStored[i] = nullptr;
            }
        }
        else {
            std::cout << "Couldn't allocate memory!" << std::endl;
        }
    }
}


VehicleStorage::~VehicleStorage() {
    for(size_t i = 0; i < vehiclesCount; ++i) {
        delete vehiclesStored[i];
    }
    delete[] vehiclesStored;
}

Vehicle* VehicleStorage::allocate(const char* registration, const char* description, std::size_t space) {
    if (usedCapacity >= capacity) {
        std::cout << "You cannot add more cars! No space available! :(" << std::endl;
        //return;
    }
    else {
        try { 
            vehiclesStored[vehiclesCount] = new Vehicle(registration, description, space);
            ++vehiclesCount;
        }
        catch (std::bad_alloc& bad)
        {
            std::cout<<bad.what() << std::endl;
            std::cout << "Couldn't allocate memory!" << std::endl;
        }
        
        return vehiclesStored[vehiclesCount-1];
    }
    return nullptr;
}