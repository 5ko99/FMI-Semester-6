#ifndef VEHICLE_STORAGE_H
#define VEHICLE_STORAGE_H

#include "Vehicle.hpp"

class VehicleStorage {
    // Тук трябва да има подходящи членове, които позволяват да пазите
    // всички създадени Vehicle обекти.
    size_t vehiclesCount;
    size_t usedCapacity;
    size_t capacity;

    Vehicle** vehiclesStored;

    bool isMemoryAllocated(size_t capacity);

public:
    // Създава празен алокатор
    VehicleStorage();

    VehicleStorage(size_t capacity);

    //void vehicleStoredSize(size_t capacity);
    
    // Унищожава алокатора и освобождава заделените от него обекти
    ~VehicleStorage(); 
    

    // Vehicle Обект, като го съхранява и връща указател към него.
    Vehicle* allocate(const char* registration, const char* description, std::size_t space);
};


#endif