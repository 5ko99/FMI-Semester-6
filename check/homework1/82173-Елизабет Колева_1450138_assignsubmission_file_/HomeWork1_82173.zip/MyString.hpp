#ifndef MYSTRING_H
#define MYSTRING_H



// #ifndef CSTDDEF
// #define CSTDDEF

//#include <cstddef> //std::size_t
//#include <ostream>
// #endif //std::size_t

#include <iostream>
#include <stdexcept>
//#include <exception>
#include <cassert>

#include "helpers.hpp"



class MyString {

private:
    char* string;
    std::size_t strLength;

    // 
    bool isItAllocated(char*& strArr, size_t strArrLen);

    // Deletes dynamically alloc array
    void deleteArr();

    
    //char* pointNullArray; //const char* MyString::c_str() const so I can take care of it

public:
    
    // Default constructor
    MyString();

    // rule of 3 cpy construct
    MyString(const MyString& other);

    // създава нов обект и копира в него съдържанието на str.
    MyString(const char* str);

    // rule of 3 operator =
    MyString& operator=(const MyString& other);

    // rule of 3 destruct
    ~MyString(); // ye

    //MyString& operator=(MyString&& other);

    //достъп до елемента намиращ се на позиция pos 
    //Ако такъв няма, да се хвърля изключение std::out_of_range.
    char& at(std::size_t pos); //std::out_of_range

    //като горната ф-я, но за константи
    const char& at(std::size_t pos) const;

    // достъп до елемента намиращ се на позиция pos
    //Функцията да не прави проверка за коректност дали pos е валидна позиция. (В debug режим assert-вайте дали pos е валидна позиция).
    char& operator[](std::size_t pos);

    //като горната ф-я, но за константи
    const char& operator[](std::size_t pos) const;

    //достъп до първия символ в низа
//Да НЕ СЕ прави проверка за коректност дали такъв символ има. (В debug режим assert-вайте че низът не е празен)
    char& front();

    //като горната ф-я, но за константи
    const char& front() const;

//достъп до последния символ в низа
    char& back();
//Да не се прави проверка за коректност дали такъв символ има. (В debug режим assert-вайте че низът не е празен).

    //като горната ф-я, но за константи
    const char& back() const;

//empty - toest string = "" ili delete[] string; ??? 
    //Проверява дали низът е празен
    bool empty() const;

    //дължина на низа
    std::size_t size() const;

    //изчиства съдържанието на низа
    void clear();
    // поправи го ве 

//strong exception guarantee
//https://www.tutorialspoint.com/cplusplus/cpp_exceptions_handling.htm

    //добавя символа c в края на низа
    void push_back(char c);

    //премахва последния символ от низа
    void pop_back();
//Да не се прави проверка за коректност дали такъв символ има. (В debug режим assert-вайте че низът не е празен).

    //добавя символа c в края на низа
    MyString& operator+=(char c);
    //Операцията да дава strong exception guarantee. Връща *this
// kwo???

    //онкатенира съдържанието на str към текущия низ
    MyString& operator+=(const MyString& rhs); //*this
//перацията да дава strong exception guarantee. Връща *this.

    //Връща нов символен низ, който се получава от текущия, конкатениран със символа c
    MyString operator+(char c) const;

    //Връща нов символен низ, който се получава от текущия, конкатениран с низа rhs
    MyString operator+(const MyString& rhs) const;

    //връща указател към null-terminated масив от тип char, който има съдържание идентично с това на низа
    const char* c_str() const;

    //Проверява дали два символни низа са еднакви
    bool operator==(const MyString &rhs) const;

    //Проверява дали текущият низ предхожда лексикографски rhs
    bool operator<(const MyString &rhs) const;

    // << out operator for easier cout
    friend std::ostream& operator<<(std::ostream& out, const MyString& rhs);
};

#endif