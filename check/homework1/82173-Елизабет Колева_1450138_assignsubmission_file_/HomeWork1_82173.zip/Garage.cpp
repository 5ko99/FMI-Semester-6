#include "Garage.hpp"

bool Garage::isMemoryAllocated(Vehicle**& userGarage, size_t userCapacity) const {
    try {
        userGarage = new Vehicle*[userCapacity];
    }
    catch (std::exception& e) {
        return false;
    }
    return true;
}

Garage::Garage() 
    :capacity(0), numberOfParkedCars(0), occupied(0), vehiclesInformation(nullptr)
{    
}

Garage::Garage(std::size_t size) { 
    capacity = size;
    numberOfParkedCars = 0;
    vehiclesInformation = nullptr;

    if(isMemoryAllocated(vehiclesInformation, capacity)) {
        for(size_t i = 0; i < capacity; i++) {
            vehiclesInformation[i] = nullptr;
        }
    }
    else {
        capacity = 0;
        numberOfParkedCars = 0;
        occupied = 0;
        vehiclesInformation = nullptr;
        throw -1;
    }
}
    
Garage::~Garage() { 
    delete[] vehiclesInformation;
    capacity = 0;
    numberOfParkedCars = 0;
    occupied = 0;
}

void Garage::insert(Vehicle& v) { 
    if (capacity < v.space() || ((capacity - occupied) < v.space())) {
        std::cout << "Not enough space to park it into the garage! :(" << std::endl;
        return;
    }

    if (findMatch(v.registration())>=0) {
        std::cout << "This vehicle is already in the garage!" << std::endl
                  << "You cannota park it again!" << std::endl;
        return;
    }

    if (numberOfParkedCars == capacity) { //if we dont have any free spots (pointers) in the garage
        std::cout << "Not enough space for cars to park it into the garage! :(" << std::endl;
        return;
    }
    
    vehiclesInformation[numberOfParkedCars] = &v;
    ++numberOfParkedCars;
    occupied += v.space();
    std::cout << "The new vehicle is successfully parked in the garage!" << std::endl;

}

void Garage::erase(const char* registration) { 
    // for(size_t c = 0; c < numberOfParkedCars; c++) {
    //     areTheSame(vehiclesInformation[c].registration(),registration, )
    // }
    size_t pos = findMatch(registration);
    if(pos >= 0) {
        std::cout << "Vehicle found parked in the garage!" << std::endl;
        vehiclesInformation[pos] = vehiclesInformation[numberOfParkedCars--];
        occupied -= (*vehiclesInformation[pos]).space();
        //assigning the last one to the newly freed position
        --numberOfParkedCars;
        vehiclesInformation[numberOfParkedCars--] = nullptr;

        std:: cout << "Vehicle with registration number: " << registration << " left the garage!" << std::endl;
    }
    else {
        std::cout << "No vehicle with reg number: " << registration << " was parked in the garage!" << std::endl;
        return;
    }
}


const Vehicle& Garage::at(std::size_t pos) const  { 
    if (pos >= numberOfParkedCars) {
        throw std::out_of_range("No cars parked at this spot! Out of range!");
    }
    return *vehiclesInformation[pos];
}

bool Garage::empty() const { 
    return occupied == 0;
} 

std::size_t Garage::size() const { 
    return numberOfParkedCars;
}

std::size_t Garage::findMatch(const char* registration) const{
    size_t pos = 0;
    bool theyMatched = 0;

    size_t registrationLength = strlen(registration);

    while(!theyMatched && pos < numberOfParkedCars) {
        //found = (*vehiclesInformation[pos]).registration();
        if(areTheSame(((*vehiclesInformation[pos]).registration()), numberOfParkedCars, registration, registrationLength)) {
            return pos;
        }
    }
    return -1;
}

void Garage::clear() { 
    for(size_t i = 0; i< numberOfParkedCars; ++i) {
        if(vehiclesInformation[i]) {
            vehiclesInformation[i] = nullptr;
        }
    }

    occupied = 0;
    numberOfParkedCars = 0;
}

const Vehicle* Garage::find(const char* registration) const{
    size_t i = 0; //iterator
    bool theyMatched = 0;
    const char* found;
    size_t registrationLength = strlen(registration);


    while(!theyMatched && i < numberOfParkedCars) {
        found = (*vehiclesInformation[i]).registration();
        
        if(areTheSame(found, numberOfParkedCars, registration, registrationLength)) {
            delete[] found;
            return vehiclesInformation[i];
        }

        ++i;
    }

    return nullptr;
}

Garage& Garage::operator=(const Garage& other) {
    if (this == &other) {
        return *this;
    }
    
    if (isMemoryAllocated(vehiclesInformation, other.capacity)) {
        capacity = other.capacity;
        numberOfParkedCars = other.numberOfParkedCars;
        occupied = other.occupied;
        for (size_t i = 0; i < numberOfParkedCars; ++i) {
            vehiclesInformation[i] = other.vehiclesInformation[i];
            // memory address from the new garage
        }

        return *this;
    }
    else {
        capacity = 0;
        numberOfParkedCars = 0;
        occupied = 0;
        vehiclesInformation = nullptr;
        throw -1;
    }

}

const Vehicle& Garage::operator[](std::size_t pos) const { 
    assert(pos >= 0 && pos < numberOfParkedCars);
    return *vehiclesInformation[pos];
} 
