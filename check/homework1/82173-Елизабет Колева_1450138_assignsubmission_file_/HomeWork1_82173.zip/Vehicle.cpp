#include "Vehicle.hpp"
#include "helpers.hpp"

void Vehicle::clear() {
    regNumb.clear();
    descriptionOfCar.clear();
    numberOfParkingSpace = 0;
}

Vehicle::Vehicle(const Vehicle& otherVehicle)
    : regNumb(nullptr), descriptionOfCar(nullptr), numberOfParkingSpace(0)
{
    regNumb = otherVehicle.regNumb;
    descriptionOfCar = otherVehicle.descriptionOfCar;
    numberOfParkingSpace = otherVehicle.numberOfParkingSpace;
}


Vehicle::Vehicle(const char* registration, const char* description, std::size_t space) 
    : regNumb(registration), descriptionOfCar(description), numberOfParkingSpace(space)
{
    if(space == 0) {
        //what if space is 0?
        throw std::invalid_argument("The space cannot equal 0!");
        space = 1; //solution maybe
    }
}

Vehicle::~Vehicle() {
    clear();
}

// Vehicle& Vehicle::operator=(Vehicle& other) {
//     if(this != &other) {
//         clear();
//         stringCopy(other.registration(), );

//     }
// }

// Vehicle& Vehicle::operator=(Vehicle& other) {
//     if (this != &other) {
//         clear();
//         stringCopy(other.regNumb, regNumb);
//         strLength = other.strLength;
//     }

//     return *this;
// }

const char* Vehicle::registration() const {
    return regNumb.c_str();
}

const char* Vehicle::description() const {
    return descriptionOfCar.c_str();
}

std::size_t Vehicle::space() const {
    return numberOfParkingSpace;
}

bool Vehicle::operator==(const Vehicle& otherVehicle) const {
    return regNumb == otherVehicle.regNumb;
}

void Vehicle::printingCarInfo() const {
    std::cout << "Registration number: " << regNumb << std::endl
              << "Description/Model: " << descriptionOfCar << std::endl
              << "Parking space needed: " << numberOfParkingSpace << std::endl;
}