#include "Garage.hpp"

using std::size_t;
using std::cout;
using std::endl;

Garage::~Garage(){
    delete[] _vehiArr;
}

Garage::Garage(std::size_t size){
    _numOfCars = 0;
    _sizeTaken = 0;
    _capacity = size;
    _vehiArr = new Vehicle *[_capacity];
}


void Garage::insert(Vehicle& v){
    if(v.space() + _sizeTaken > _capacity)
        throw std::invalid_argument("Not enough space for this vehicle");
    
    bool vExists = false;
    for(size_t i=0; i<_numOfCars; i++){
        if(!strcmp(_vehiArr[i]->registration(), v.registration())){
            vExists = true;
        }
    }
    if(vExists)
        throw std::invalid_argument("Vehicle already in garage");
    
    _vehiArr[_numOfCars++] = &v;
    _sizeTaken += v.space();
}

void Garage::erase(const char* registration){
    int index = -1;
    for(int i=0; i<_numOfCars;i++){
        if(!strcmp(_vehiArr[i]->registration(), registration)){
            index = i;
        }
    }
    if(index != -1){
        if(index != _numOfCars-1)_vehiArr[index] = _vehiArr[_numOfCars-1];
        _numOfCars--;
    }
}


const Vehicle& Garage::at(std::size_t pos) const{
    if(pos>=_numOfCars) throw std::out_of_range("vehicle at index does not exist");
    return *_vehiArr[pos];
}
const Vehicle& Garage::operator[](std::size_t pos) const{
    assert(pos<=_numOfCars);
    return *_vehiArr[pos];
}


const Vehicle* Garage::find(const char* registration) const{
    int index = -1;
    for(int i=0; i<_numOfCars;i++){
        if(!strcmp(_vehiArr[i]->registration(), registration)){
            index = i;
        }
    }
    if(index == -1){
        return nullptr;
    } else {
        return _vehiArr[index];
    }
}


bool Garage::empty() const{
    return _numOfCars==0;
}
std::size_t Garage::size() const{
    return _numOfCars;
}
void Garage::clear(){
    for(int i=0;i<_numOfCars;i++) _vehiArr[i] = nullptr;
    _numOfCars = 0;
}
