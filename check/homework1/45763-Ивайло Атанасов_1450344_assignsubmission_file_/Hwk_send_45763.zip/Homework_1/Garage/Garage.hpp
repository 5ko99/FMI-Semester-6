#ifndef Garage_hpp
#define Garage_hpp

#include "../Vehicle/Vehicle.hpp"

class Garage{
private:
    std::size_t _capacity;
    std::size_t _sizeTaken;
    std::size_t _numOfCars;
    Vehicle** _vehiArr = nullptr;
    
    void copy(const Garage& other);
public:
    Garage() = delete;
    ~Garage();
    Garage(std::size_t size);
    
    void insert(Vehicle& v);
    void erase(const char* registration);
    
    const Vehicle& at(std::size_t pos) const;
    const Vehicle& operator[](std::size_t pos) const;
    const Vehicle* find(const char* registration) const;
    
    bool empty() const;
    std::size_t size() const;
    void clear();
    
};

#endif
