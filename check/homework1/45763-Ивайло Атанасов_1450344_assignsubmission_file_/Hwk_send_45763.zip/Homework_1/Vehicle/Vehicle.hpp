#ifndef Vehicle_hpp
#define Vehicle_hpp

#include "../MyString/MyString.hpp"

class Vehicle {
private:
    MyString _registration;
    MyString _description;
    std::size_t _space;
public:
    Vehicle() = delete;
    Vehicle(const char* registration, const char* description, std::size_t space);
    const char* registration() const;
    const char* description() const;
    std::size_t space() const;
};

#endif
