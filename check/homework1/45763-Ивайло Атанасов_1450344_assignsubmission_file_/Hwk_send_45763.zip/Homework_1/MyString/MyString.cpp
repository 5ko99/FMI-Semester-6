#include "MyString.hpp"

// constructors
MyString::MyString(){
    reAllocateMem();
}

MyString::~MyString(){
    delete[] _str;
}

MyString::MyString(std::size_t len){
    _length = len;
    reAllocateMem();
}

MyString::MyString(MyString& other){
    copy(other);
}

MyString::MyString(const char* str){
    _length = measureC_str_Lenght(str);
    reAllocateMem();
    for(int i=0;i<_length;i++){
        this->_str[i] = str[i];
    }
}

void MyString::copy(const MyString& other){
    _length = other.size();
    reAllocateMem();
    for(int i=0;i<_length;i++){
        this->_str[i] = other[i];
    }
}

MyString& MyString::operator=(const MyString& other){
    if (this != &other){
        copy(other);
    }
    return *this;
}


// at/[]
char& MyString::at(std::size_t pos){
    if(pos<0 || pos>_length) {
        throw std::out_of_range("invalid_index");
    }
    return _str[pos];
}

const char& MyString::at(std::size_t pos) const{
    if(pos<0 || pos>_length) {
        throw std::out_of_range("invalid_index");
    }
    return _str[pos];
}

char& MyString::operator[](std::size_t pos){
    assert(pos<=_length);
    return _str[pos];
}

const char& MyString::operator[](std::size_t pos) const{
    assert(pos<=_length);
    return _str[pos];
}


// front and back bumper
char& MyString::front(){
    return _str[0];
}

const char& MyString::front() const{
    return _str[0];
}

char& MyString::back(){
    return _str[_length-1];
}

const char& MyString::back() const{
    return _str[_length-1];
}


// misc functions
bool MyString::empty() const{
    return _length==0;
}
std::size_t MyString::size() const{
    return _length;
}
void MyString::clear(){
    _length = 0;
    reAllocateMem();
}


// push&pop
void MyString::push_back(char c){
    char* buffer = new char[_length+2];
    for(int i=0;i<_length;i++)
        buffer[i] = _str[i];
    buffer[_length] = c;
    buffer[_length+1] = '\0';
    
    delete[] _str;
    _str = buffer;
    _length++;
}

void MyString::pop_back(){
    assert(_length>0);
    char* buffer = new char[_length];
    for(int i=0;i<_length-1;i++)
        buffer[i] = _str[i];
    buffer[_length-1] = '\0';
    
    delete[] _str;
    _str = buffer;
    _length--;
}


// concatenations
MyString& MyString::operator+=(char c){
    push_back(c);
    return *this;
}

MyString& MyString::operator+=(const MyString& rhs){
    std::size_t newLen = _length + rhs._length;
    char* buffer = new char[newLen+1];
    
    for(std::size_t i=0; i<_length; i++){
        buffer[i] = _str[i];
    }
    std::size_t ind = 0;
    for(std::size_t i=_length; i<newLen; i++){
        buffer[i] = rhs[ind];
        ind++;
    }
    buffer[newLen] = '\0';
    
    delete[] _str;
    _str = buffer;
    _length = newLen;
    return *this;
}

MyString MyString::operator+(char c) const{
    MyString newStr(_length);
    for(int i=0;i<_length;i++){
        newStr[i] = _str[i];
    }
    newStr[_length] ='\0';
    
    return newStr += c;
}

MyString MyString::operator+(const MyString& rhs) const{
    MyString newStr(_length);
    for(int i=0;i<_length;i++){
        newStr[i] = _str[i];
    }
    newStr[_length] = '\0';
    
    return newStr += rhs;
}


// c_str
const char* MyString::c_str() const{
    return _str;
}


// comparisons
bool MyString::operator==(const MyString &rhs) const{
    if(_length != rhs._length) return false;
    for(int i=0;i<_length;i++)
        if(_str[i] != rhs[i]) return false;
    return true;
}
bool MyString::operator==(const char* &rhs) const{
    int cLen = measureC_str_Lenght(rhs);
    if(_length != cLen) return false;
    for(int i=0; i<_length; i++)
        if(_str[i] != rhs[i]) return false;
    return true;
}
bool MyString::operator<(const MyString &rhs) const{
    int index = 0;
    while(index<_length && index<rhs._length){
        if(_str[index]==rhs[index])index++;
        else return _str[index]<rhs[index];
    }
    return false;
}


// helper functions ------
int MyString::measureC_str_Lenght(const char *str) const{
    int i=0, counter = 0;
    while(str[i]!='\0'){
        ++i;
        ++counter;
    }
    return counter;
}


void MyString::reAllocateMem(){
    delete[] _str;
    _str = new char[_length+1];
    _str[_length] = '\0';
}

void MyString::print(){
    for(int i=0;i<_length;i++)
        std::cout<<_str[i];
}
