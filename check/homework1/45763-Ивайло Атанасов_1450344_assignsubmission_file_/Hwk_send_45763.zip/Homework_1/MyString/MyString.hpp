#ifndef MyString_hpp
#define MyString_hpp

#include <iostream>
#include <cstring>
#include <assert.h>

class MyString{
public:
private:
    char* _str = nullptr;
    std::size_t _length = 0;
    
    void reAllocateMem();
    int measureC_str_Lenght(const char* str) const;
public:
    void print();
    
    MyString();                                 // default constructor
    MyString(size_t len);
    MyString(MyString& other);                  // copy constructor         |
    void copy(const MyString& other);           // copy function            |
    ~MyString();                                // destructor               | rule of three
    MyString& operator=(const MyString& other); // =                        |
    MyString(const char* str);                  // char array constructor
    
    // at & []
    char& at(std::size_t pos);
    const char& at(std::size_t pos) const;
    char& operator[](std::size_t pos);
    const char& operator[](std::size_t pos) const;
    
    // front/back
    char& front();
    const char& front() const;
    char& back();
    const char& back() const;
    
    // misc functions
    bool empty() const;
    std::size_t size() const;
    void clear();
    
    // push & pop
    void push_back(char c);
    void pop_back();
    
    // concatenation +
    MyString& operator+=(char c);
    MyString& operator+=(const MyString& rhs);
    MyString operator+(char c) const;
    MyString operator+(const MyString& rhs) const;
    
    // c_str
    const char* c_str() const;
    
    // comparisons
    bool operator==(const MyString &rhs) const;
    bool operator==(const char* &rhs) const;
    bool operator<(const MyString &rhs) const;
};

#endif
