
// Име: Ивайло Недялков Атанасов
// ФН: 45763
// Специалност: информатика
// Курс: 1
// Административна група: 2
// Кой компилатор използвате: LLVM
//

#include <iostream>
#include "VehicleGarageManager/VehicleGarageManager.hpp"

int main() {
    VehicleGarageManager VGM(6);
    
    Vehicle v1 = VGM.createNewVehicle("2200", "golfo bace", 1);
    VGM.addVehicleToGarage(v1);
    
    Vehicle v2 = VGM.createNewVehicle("1234", "samo napred zad nas e bylgariq", 1);
    Vehicle v3 = VGM.createNewVehicle("asd", "qwe", 3);
    VGM.addVehicleToGarage(v2);
    VGM.addVehicleToGarage(v3);
    
    VGM.printGarage();
    std::cout<<"--------"<<std::endl;
    VGM.destroyVehicle("asd");
    VGM.printGarage();
    
    VGM.cleanAll();
    return 0;
}
