#include "VehicleGarageManager.hpp"


VehicleGarageManager::VehicleGarageManager(std::size_t size){
    garage = new Garage(size);
    _vehiArr = nullptr;
    vehiclesCount = 0;
}

VehicleGarageManager::~VehicleGarageManager(){
    for(int i=0; i<vehiclesCount; i++){
        delete _vehiArr[i];
    }
    delete[] _vehiArr;
    delete garage;
    vehiclesCount = 0;
}


Vehicle& VehicleGarageManager::createNewVehicle(const char *reg, const char *desc, std::size_t space){
    Vehicle** buffer = new Vehicle*[vehiclesCount + 1];
    for(int i=0;i<vehiclesCount;i++){
        buffer[i] = _vehiArr[i];
    }
    Vehicle* newV = new Vehicle(reg, desc, space);
    buffer[vehiclesCount] = newV;
    
    delete[] _vehiArr;
    _vehiArr = buffer;
    vehiclesCount++;
    return *newV;
}

void VehicleGarageManager::addVehicleToGarage(Vehicle& v){
    garage->insert(v);
}

Vehicle* VehicleGarageManager::getVehicle(const char* reg) const{
    int index = -1;
    for(int i=0; i<vehiclesCount; i++){
        if(!strcmp(_vehiArr[i]->registration(), reg))index = i;
    }
    if(index != -1){
        return _vehiArr[index];
    } else return nullptr;
}



void VehicleGarageManager::removeVehicleFromGarage(Vehicle& v){
    garage->erase(v.registration());
}

void VehicleGarageManager::removeVehicleFromGarage(const char* reg){
    garage->erase(reg);
}



void VehicleGarageManager::destroyVehicle(const char* reg){
    Vehicle* vToDel = getVehicle(reg);
    if(vToDel == nullptr) return;
    garage->erase(reg);
    std::size_t index = getIndexOf(*vToDel);
    delete vToDel;
    if(index != vehiclesCount-1) _vehiArr[index] = _vehiArr[vehiclesCount-1];
    vehiclesCount--;
}


std::size_t VehicleGarageManager::getIndexOf(Vehicle& v){
    std::size_t index = -1;
    for(int i=0; i<vehiclesCount; i++){
        if(!strcmp(_vehiArr[i]->registration(), v.registration())) index = i;;
    }
    if(index != -1) return index;
    else throw std::invalid_argument("vehicle was not found");
}

void VehicleGarageManager::cleanAll(){
    for(int i=0; i<vehiclesCount; i++){
        delete _vehiArr[i];
    }
    delete[] _vehiArr;
    vehiclesCount = 0;
    _vehiArr = new Vehicle*[vehiclesCount];
}
void VehicleGarageManager::cleanGarage(){
    garage->clear();
}


const void VehicleGarageManager::printAll() const{
    for(int i=0; i<vehiclesCount; i++){
        std::cout<<"["<<_vehiArr[i]->registration()<<", "<<_vehiArr[i]->description()<<", "<<_vehiArr[i]->space()<<"]"<<std::endl;
    }
}

const void VehicleGarageManager::printGarage() const{
    for(int i=0; i<garage->size(); i++){
        std::cout<<"["<<garage->at(i).registration()<<", "<<garage->at(i).description()<<", "<<garage->at(i).space()<<"]"<<std::endl;
    }
}

std::size_t VehicleGarageManager::allVehiclesCount(){
    return vehiclesCount;
}
std::size_t VehicleGarageManager::vehiclesInGarageCount(){
    return garage->size();
}
