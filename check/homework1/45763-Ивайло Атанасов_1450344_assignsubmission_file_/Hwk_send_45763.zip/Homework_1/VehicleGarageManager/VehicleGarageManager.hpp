#ifndef VehicleGarageManager_hpp
#define VehicleGarageManager_hpp

#include <iostream>
#include "../Garage/Garage.hpp"

class VehicleGarageManager {
private:
    Garage* garage;
    Vehicle** _vehiArr;
    int vehiclesCount;
    
    std::size_t getIndexOf(Vehicle& v);
public:
    VehicleGarageManager() = delete;
    ~VehicleGarageManager();
    VehicleGarageManager(std::size_t size);
    
    Vehicle& createNewVehicle(const char* reg, const char* desc, std::size_t space);
    void addVehicleToGarage(Vehicle& v);
    void removeVehicleFromGarage(Vehicle& v);
    void removeVehicleFromGarage(const char* reg);
    Vehicle* getVehicle(const char* reg) const;
    
    void destroyVehicle(const char* reg);
    
    void cleanAll();
    void cleanGarage();
    
    const void printAll() const;
    const void printGarage() const;
    
    std::size_t allVehiclesCount();
    std::size_t vehiclesInGarageCount();
    
};

#endif
