#include <iostream>
#include <cstring>
#include "catch2.hpp"

#include "../Homework_1/Garage/Garage.hpp"


TEST_CASE("Testing Garage"){
    SECTION("insert scenario 1"){
        Garage gar(2);
        Vehicle v1("4321", "asddesc", 1);
        gar.insert(v1);
        bool passed = false;
        try{
            gar.insert(v1);
        } catch (const std::invalid_argument &e){
            passed = true;
        }
        REQUIRE(passed == true);
    }
    SECTION("insert scenario 2"){
        Garage gar(3);
        Vehicle v1("4321", "asddesc", 1);
        Vehicle v2("5678", "descriptione", 2);
        gar.insert(v1);
        bool passed = true;
        try{
            gar.insert(v2);
        } catch (const std::invalid_argument &e){
            passed = false;
        }
        REQUIRE(passed == true);
    }
    SECTION("insert scenario 3"){
        Garage gar(3);
        Vehicle v1("4321", "asddesc", 2);
        Vehicle v2("5678", "descriptione", 2);
        gar.insert(v1);
        bool passed = false;
        try{
            gar.insert(v2);
        } catch (const std::invalid_argument &e){
            passed = true;
        }
        REQUIRE(passed == true);
    }
    SECTION("at()"){
        Garage gar(10);
        Vehicle v1("4321", "asddesc", 2);
        Vehicle v2("5678", "ez", 2);
        Vehicle v3("9999", "gg", 2);
        gar.insert(v1);
        gar.insert(v2);
        gar.insert(v3);
        
        REQUIRE(!strcmp(gar.at(0).registration(), "4321"));
        REQUIRE(!strcmp(gar.at(0).description(), "asddesc"));
        
        REQUIRE(!strcmp(gar.at(1).registration(), "5678"));
        REQUIRE(!strcmp(gar.at(1).description(), "ez"));
        
        REQUIRE(!strcmp(gar.at(2).registration(), "9999"));
        REQUIRE(!strcmp(gar.at(2).description(), "gg"));
        
        bool passed = false;
        try{
            std::size_t temp = gar.at(3).space();
        } catch (std::out_of_range) {
            passed = true;
        }
        REQUIRE(passed == true);
    }
    
    SECTION("[][][][]"){
        Garage gar(10);
        Vehicle v1("4321", "asddesc", 2);
        Vehicle v2("5678", "ez", 2);
        Vehicle v3("9999", "gg", 2);
        gar.insert(v1);
        gar.insert(v2);
        gar.insert(v3);
        
        REQUIRE(!strcmp(gar[0].registration(), "4321"));
        REQUIRE(!strcmp(gar[0].description(), "asddesc"));
        
        REQUIRE(!strcmp(gar[1].registration(), "5678"));
        REQUIRE(!strcmp(gar[1].description(), "ez"));
        
        REQUIRE(!strcmp(gar[2].registration(), "9999"));
        REQUIRE(!strcmp(gar[2].description(), "gg"));
    }
    SECTION("erease()/size()/clear()/empty()"){
        Garage gar(10);
        Vehicle v1("4321", "asddesc", 2);
        Vehicle v2("5678", "ez", 2);
        Vehicle v3("9999", "gg", 2);
        Vehicle v4("2200", "synimyni", 2);
        Vehicle v5("5555", "petpetpetpet", 2);
        gar.insert(v1);
        gar.insert(v2);
        gar.insert(v3);
        
        REQUIRE(gar.size() == 3);
        gar.erase("5678");
        REQUIRE(gar.size() == 2);
        
        gar.insert(v4);
        REQUIRE(gar.size() == 3);
        
        gar.erase("2200");
        REQUIRE(gar.size() == 2);
        
        gar.clear();
        REQUIRE(gar.size() == 0);
        REQUIRE(gar.empty()==true);
        
        gar.insert(v5);
        REQUIRE(gar.size() == 1);
    }
    
    SECTION("find"){
        Garage gar(20);
        Vehicle v1("4321", "asddesc", 2);
        Vehicle v2("5678", "ez", 2);
        Vehicle v3("9999", "gg", 2);
        Vehicle v4("2200", "synimyni", 2);
        Vehicle v5("5555", "petpetpetpet", 2);
        gar.insert(v1);
        gar.insert(v2);
        gar.insert(v3);
        gar.insert(v4);
        gar.insert(v5);
        
        const Vehicle* found1 = gar.find("5678");
        REQUIRE(!strcmp(found1->registration(), "5678"));
        
        const Vehicle* found2 = gar.find("5555");
        REQUIRE(!strcmp(found2->registration(), "5555"));
        
        const Vehicle* found3 = gar.find("8888");
        REQUIRE(found3 == nullptr);
    }
    
    
}
