#include <iostream>
#include <cstring>
#include "catch2.hpp"

#include "../Homework_1/MyString/MyString.hpp"


TEST_CASE("Testing MyString"){
    SECTION("testing rule of 3"){
        MyString mstr;
        REQUIRE(mstr.size() == 0);
        MyString mstr2(mstr);
        REQUIRE(mstr.size() == mstr2.size());
        MyString mstr3("asd");
        REQUIRE(mstr3.size() == 3);
        
        MyString mstr4 = mstr3;
        REQUIRE(mstr4 == mstr3);
    }
    SECTION("at() functions"){
        MyString mstr("0123456");
        REQUIRE(mstr.at(0) == '0');
        REQUIRE(mstr.at(3) == '3');
        REQUIRE(mstr.at(6) == '6');
        
        bool excCaught = false;
        try{
            mstr.at(-15) = 'A';
        }catch(std::out_of_range){
            excCaught = true;
        }
        REQUIRE(excCaught);
        
        excCaught = false;
        try{
            mstr.at(100) = 'A';
        }catch(std::out_of_range){
            excCaught = true;
        }
        REQUIRE(excCaught);
        
        const char ch = mstr.at(3);
        REQUIRE(ch == '3');
        
        mstr.at(3) = 'M';
        REQUIRE(mstr.at(3) == 'M');
    }
        

    SECTION("[] functions"){
        MyString mstr("0123456");
        REQUIRE(mstr[0] == '0');
        REQUIRE(mstr[3] == '3');
        REQUIRE(mstr[6] == '6');
        
        const char ch = mstr[3];
        REQUIRE(ch == '3');
        
        mstr[2] = 'N';
        REQUIRE(mstr[2] == 'N');
    }
    
    SECTION("front/back"){
        MyString mstr("0123456");
        
        REQUIRE(mstr.front() == '0');
        const char ch1 = mstr.front();
        REQUIRE(ch1 =='0');
        mstr.front() = 'M';
        
        REQUIRE(mstr.back() == '6');
        const char ch2 = mstr.back();
        REQUIRE(ch2 =='6');
    }
        

    SECTION("misc"){
        MyString mstrEmpty;
        REQUIRE(mstrEmpty.empty());
        MyString mstrEmpty2("");
        REQUIRE(mstrEmpty2.empty());
        
        mstrEmpty.clear();
        mstrEmpty2.clear();
        REQUIRE(mstrEmpty.size()==0);
        REQUIRE(mstrEmpty2.size()==0);
        
        MyString mstr("0123");
        REQUIRE(mstr.size() == 4);
        mstr.clear();
        REQUIRE(mstr.size() == 0);
    }
    
    SECTION("push & pop"){
        MyString mstr("Hello world");
        std::size_t oldlen = mstr.size();
        mstr.push_back('Z');
        REQUIRE(mstr.size() == oldlen+1);
        REQUIRE(mstr.back() == 'Z');
        REQUIRE(mstr == "Hello worldZ");
        
        MyString mstr2("012345");
        oldlen = mstr2.size();
        mstr2.pop_back();
        REQUIRE(mstr2.size() == oldlen-1);
        REQUIRE(mstr2.back() == '4');
        REQUIRE(mstr2 == "01234");
    }
    
        
    SECTION("concatenations +=char / +=MyString"){
        MyString mstr1("Hello world");
        mstr1 += 'V';
        REQUIRE(mstr1 == "Hello worldV");
        
        MyString mstr2("Test");
        mstr1 += mstr2;
        REQUIRE(mstr1 == "Hello worldVTest");
    }
        
    
    SECTION("concatenations +char / +MyString"){
        MyString mstr1("Hello world");
        MyString mstr2;
        mstr2 = mstr1 + 'K';
        REQUIRE(mstr2 == "Hello worldK");
        
        MyString mstr3("Mest");
        MyString mstr4;
        mstr4 = mstr2 + mstr3;
        REQUIRE(mstr4 == "Hello worldKMest");
    }
    
    SECTION("c_str"){
        MyString mstr("Greetings planet");
        std::size_t len = strlen(mstr.c_str());
        REQUIRE(len == mstr.size());
        REQUIRE(mstr.c_str()[len] == '\0');
    }
    
        
    SECTION("comparisons"){
        // myString == MyString
        MyString mstr1("01234");
        MyString mstr2("56789");
        REQUIRE(mstr1 == mstr1);
        REQUIRE(!(mstr1 == mstr2));
        mstr1 = mstr2;
        REQUIRE(mstr1 == mstr2);
        
        // myString == c_string
        MyString mstr3("01234");
        REQUIRE(mstr3 == "01234");
        REQUIRE(!(mstr3 == "qwe"));
        
        // myString < myString
        MyString mstr4("abc");
        MyString mstr5("cdefg");
        MyString mstr6("xyz");
        bool b1 = mstr4<mstr5;
        REQUIRE(b1);
        bool b2 = !(mstr5<mstr4);
        REQUIRE(b2);
        bool b3 = mstr5<mstr6;
        REQUIRE(b3);
    }
}
