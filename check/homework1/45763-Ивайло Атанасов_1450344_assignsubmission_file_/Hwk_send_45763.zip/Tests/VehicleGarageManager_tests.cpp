#include <iostream>
#include <cstring>
#include "catch2.hpp"

#include "../Homework_1/VehicleGarageManager/VehicleGarageManager.hpp"

TEST_CASE("Testing VehicleGarageManager"){
    SECTION("initialising / adding vehicles"){
        VehicleGarageManager VGM(6);
        REQUIRE(VGM.allVehiclesCount() == 0);
        Vehicle v1 = VGM.createNewVehicle("1234", "desc1", 1);
        Vehicle v2 = VGM.createNewVehicle("2222", "desc2", 1);
        REQUIRE(VGM.allVehiclesCount() == 2);
        Vehicle v3 = VGM.createNewVehicle("3333", "desc3", 1);
        Vehicle v4 = VGM.createNewVehicle("4444", "desc4", 1);
        REQUIRE(VGM.allVehiclesCount() == 4);
        
        REQUIRE(VGM.vehiclesInGarageCount() == 0);
        VGM.addVehicleToGarage(v1);
        VGM.addVehicleToGarage(v2);
        REQUIRE(VGM.vehiclesInGarageCount() == 2);
        VGM.addVehicleToGarage(v3);
        VGM.addVehicleToGarage(v4);
        REQUIRE(VGM.vehiclesInGarageCount() == 4);
        
        Vehicle v8 = VGM.createNewVehicle("0673", "syvetska podvodnica", 80);
        bool didThrow = false;
        try{
            VGM.addVehicleToGarage(v8);
        }catch (const std::exception &e){
            didThrow = true;
        }
        REQUIRE(didThrow);
    }
    
    SECTION("removing vehicles"){
        VehicleGarageManager VGM(6);
        REQUIRE(VGM.allVehiclesCount() == 0);
        Vehicle v1 = VGM.createNewVehicle("1234", "desc1", 1);
        Vehicle v2 = VGM.createNewVehicle("2222", "desc2", 1);
        Vehicle v3 = VGM.createNewVehicle("3333", "desc3", 1);
        Vehicle v4 = VGM.createNewVehicle("4444", "desc4", 1);
        REQUIRE(VGM.allVehiclesCount() == 4);
        REQUIRE(VGM.vehiclesInGarageCount() == 0);
        
        VGM.removeVehicleFromGarage(v1);
        REQUIRE(VGM.vehiclesInGarageCount() == 0);
        
        VGM.addVehicleToGarage(v1);
        VGM.addVehicleToGarage(v3);
        VGM.addVehicleToGarage(v2);
        
        
        REQUIRE(VGM.vehiclesInGarageCount() == 3);
        REQUIRE(VGM.allVehiclesCount() == 4);
        VGM.removeVehicleFromGarage(v3);
        REQUIRE(VGM.vehiclesInGarageCount() == 2);
        REQUIRE(VGM.allVehiclesCount() == 4);
        
        VGM.removeVehicleFromGarage(v3);
        REQUIRE(VGM.vehiclesInGarageCount() == 2);
        REQUIRE(VGM.allVehiclesCount() == 4);
    }
    
    SECTION("destroying vehicles"){
        VehicleGarageManager VGM(6);
        REQUIRE(VGM.allVehiclesCount() == 0);
        Vehicle v1 = VGM.createNewVehicle("1234", "desc1", 1);
        Vehicle v2 = VGM.createNewVehicle("2222", "desc2", 1);
        Vehicle v3 = VGM.createNewVehicle("3333", "desc3", 1);
        Vehicle v4 = VGM.createNewVehicle("4444", "desc4", 1);
        REQUIRE(VGM.allVehiclesCount() == 4);
        REQUIRE(VGM.vehiclesInGarageCount() == 0);
        
        VGM.destroyVehicle("1234");
        REQUIRE(VGM.vehiclesInGarageCount() == 0);
        
        VGM.addVehicleToGarage(v1);
        VGM.addVehicleToGarage(v3);
        VGM.addVehicleToGarage(v2);
        
        
        REQUIRE(VGM.vehiclesInGarageCount() == 3);
        REQUIRE(VGM.allVehiclesCount() == 3);
        VGM.destroyVehicle("3333");
        REQUIRE(VGM.vehiclesInGarageCount() == 2);
        REQUIRE(VGM.allVehiclesCount() == 2);
        
        VGM.destroyVehicle("3333");
        REQUIRE(VGM.vehiclesInGarageCount() == 2);
        REQUIRE(VGM.allVehiclesCount() == 2);
    }
    
    SECTION("testing getVehicle / cleanGarage"){
        VehicleGarageManager VGM(6);
        REQUIRE(VGM.allVehiclesCount() == 0);
        Vehicle v1 = VGM.createNewVehicle("1234", "desc1", 1);
        Vehicle v2 = VGM.createNewVehicle("2222", "desc2", 1);
        Vehicle v3 = VGM.createNewVehicle("3333", "desc3", 1);
        Vehicle v4 = VGM.createNewVehicle("4444", "desc4", 1);
        
        Vehicle* v5 = VGM.getVehicle("3333");
        REQUIRE(!strcmp(v5->description(), "desc3"));
        
        VGM.cleanGarage();
        REQUIRE(VGM.allVehiclesCount()==4);
        REQUIRE(VGM.vehiclesInGarageCount()==0);
    }
    SECTION("testing getVehicle / cleanGarage"){
        VehicleGarageManager VGM(6);
        REQUIRE(VGM.allVehiclesCount() == 0);
        Vehicle v1 = VGM.createNewVehicle("1234", "desc1", 1);
        Vehicle v2 = VGM.createNewVehicle("2222", "desc2", 1);
        Vehicle v3 = VGM.createNewVehicle("3333", "desc3", 1);
        Vehicle v4 = VGM.createNewVehicle("4444", "desc4", 1);
        
        VGM.cleanAll();
        REQUIRE(VGM.allVehiclesCount()==0);
        REQUIRE(VGM.vehiclesInGarageCount()==0);
    }
}
