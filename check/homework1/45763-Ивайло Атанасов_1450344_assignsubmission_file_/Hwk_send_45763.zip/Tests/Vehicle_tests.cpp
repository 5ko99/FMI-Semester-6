#include <iostream>
#include <cstring>
#include "catch2.hpp"

#include "../Homework_1/Vehicle/Vehicle.hpp"


TEST_CASE("Testing Vehicle"){
    MyString vLicense("1234");
    MyString vDesc("Descriptiounero mero");
    Vehicle vehc(vLicense.c_str(), vDesc.c_str(), 4);
    
    REQUIRE(!strcmp(vehc.registration(), vLicense.c_str()));
    REQUIRE(!strcmp(vehc.description(), vDesc.c_str()));
    REQUIRE(vehc.space() == 4);
}
