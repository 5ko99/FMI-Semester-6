#include <iostream>
#include "Headers/MyString.h"
#include "Headers/Vehicle.h"
#include "Headers/Garage.h"
#include "Headers/MyContainer.h"
/*ПОЯСНЕНИЯ
 *
 * Както виждате имаме 4 команди: exit - излиза от програмата
 * createG - създава гараж
 * addCToGarage - добавя кола в гаража
 * print - принтира гаража
 *
 * Тук имах лека дилема. Гаражът, както е опоменато е предвиден да бъде САМО един.
 * Не съм създал ограничение за това, защото ми се видя ненужно, но ако това е трябвало се извинявам.
 * Един вариант това да се предотврати е да сложим ID статичен за класa Garage или и да проверяваме
 * дали то вече е 1 (например)
 *
 * Преди да започне програмата създавам "имитации" на гаража и контейнера.
 * Когато започне програмта вече създаденият гараж се приравнява с новия такъв, за да може капацитета да се
 * запази, такъв какъвто потребителят иска. (ето затова ми трявба оператор = в класа Garage)
 *
 *
 * За контейнера може да се направи същото, но за симулацията предполагам 1000 е достатъчно.
 * Забележете, че при изтриване на кола в гаража тя остава в контейнера, и ще се изтрие,
 * чак когато се изтрие контейнерът.
 *
 * Приятно проверяване. Ако има проблеми оставам на разположение:
 *
 * jany.drenchev@gmail.com
 * +359 885 629 802
 * FB: Яни Дренчев
 * GIT: https://github.com/YaniDrenchev
 *
 * */
int main() {
    const size_t MAX_SIZE = 1000;
    std::cout << "Welcome to Yani Drenchev's homework. FN: 45518 Informatics :)" << '\n';
    std::cout << "Here is a list of our commands: {exit, createG, addCToGarage, print}" << '\n';
    MyString command = "";
    MyContainer container{MAX_SIZE};
    Garage garage1{MAX_SIZE};
    while (true) {
        std::cin >> command;
        if (command == "exit") {
            break;
        }
        if (command == "createG") {
            std::cout << "Enter capacity >= 1" << '\n';
            int capacity;
            std::cin >> capacity;
            while (capacity <= 0) {
                std::cout << "Please enter VALID capacity" << '\n';
                std::cin >> capacity;
            }
            Garage garage2{static_cast<size_t>(capacity)};
            garage1 = garage2;
            std::cout << "Garage with capacity: " << capacity << " was created" << "\n";
        }
        if (command == "addCToGarage") {
            int space = 0;
            MyString regNumber = "";
            MyString desc = "";
            std::cout << "Please enter car registration number" << '\n';
            std::cin >> regNumber;
            std::cout << "Please enter car description" << '\n';
            std::cin >> desc;
            std::cout << "Please enter valid space >= 1 :)" << '\n';
            std::cin >> space;
            while (space <= 0) {
                std::cout << "Please enter valid space > 1 :)" << '\n';
                std::cin >> space;
            }
            Vehicle *car = container.allocate(regNumber.c_str(), desc.c_str(), space);
            try {
                garage1.insert(*car);
                std::cout << "Vehicle with registration: " << regNumber << " was added to garage" << "\n";
            }catch (std::out_of_range &err){
                std::cout << err.what() << '\n';
            }
        }

        if (command == "print") {
            if (garage1.empty()) {
                std::cout << "Garage is empty nothing to print" << "\n";
            } else {
                std::cout << "Printing cars" << "\n";
                for (int i = 0; i < garage1.size(); ++i) {
                    try {
                        std::cout << garage1.at(i).registration() << "\n";
                    } catch (...) {
                        continue;
                    }
                }
            }

        }
    }
}