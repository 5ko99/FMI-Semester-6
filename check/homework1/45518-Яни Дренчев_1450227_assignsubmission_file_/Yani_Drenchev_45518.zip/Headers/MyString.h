//
// Created by Yani Drenchev on 2021-04-11.
//
#include <iostream>

#ifndef HOMEWORK1_MYSTRING_H
#define HOMEWORK1_MYSTRING_H
/*ПОЯСНЕНИЯ
 * Имплементация наподобяваща std::string. Масивът от чарове е nullterminate, затова във фунцкцията c_str връщам
 * пойнтър към масива, който е член данна на този клас.
 * Интерфейсът съм го запазил да бъде, както е описано в задачата. destroy и copy са за мое улеснение и за пестене
 * на код.
 * ВАЖНО! Предефинирането на операторите << >>, може да хвърли инзключение, но съм го направил само, за да ползвам
 * MyString за четене от конзолата. Има друга реализация на << и >>, която е по-подходяща, но не мисля, че това е
 * част от домашното. Всяка една функция е тествана в tests_MyString.cpp в директорията Tests.
*/
class MyString {
private:
    char *string;
    std::size_t size_of_string;

    void destroy();
    void copy(const MyString &myString);
public:

    MyString();

    MyString(const char *str);

    ~MyString();

    MyString &operator=(const MyString &mystr);

    MyString(const MyString &mystr);

    char &at(std::size_t pos);

    const char &at(std::size_t pos) const;

    char &operator[](std::size_t pos);

    const char &operator[](std::size_t pos) const;

    char &front();

    const char &front() const;

    char &back();

    const char &back() const;

    bool empty() const;

    std::size_t size() const;

    void clear();

    void push_back(char c);

    void pop_back();

    MyString &operator+=(char c);

    MyString &operator+=(const MyString &rhs);

    MyString operator+(char c);

    MyString operator+(const MyString &rhs);

    const char *c_str() const;

    bool operator==(const MyString &rhs) const;

    bool operator<(const MyString &rhs) const;

    char *getString() const;

    friend std::istream &operator >> (std::istream &input, MyString &text){
        input >> text.string;
        return input;
    }

    friend std::ostream &operator << (std::ostream &output,const MyString &text){
        output << text.string;
        return  output;
    }


};

#endif //HOMEWORK1_MYSTRING_H
