//
// Created by Yani Drenchev on 2021-04-11.
//
#include "MyString.h"

#ifndef HOMEWORK1_VEHICLE_H
#define HOMEWORK1_VEHICLE_H
/*ПОЯСНЕНИЯ
 * Vehicle има няколко много прости функции, които служат за "гетъри". Rule of 3 не се налага, тъй като
 * не се работи с динамична памет. Полетата registrationNumbers, descriptions имат свои деструктори, което ни
 * спестява имплементацията експлицитно на rule of 3. Реализизациите, макар и кратки са отделени в .cpp файла
*/
class Vehicle {
private:

    MyString registrationNumbers;
    MyString descriptions;
    std::size_t spaces;

public:

    Vehicle(const char *registration, const char *description, std::size_t space);

    const char *registration() const;

    const char *description() const;

    std::size_t space() const;
};


#endif //HOMEWORK1_VEHICLE_H
