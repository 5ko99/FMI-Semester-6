//
// Created by Yani Drenchev on 14.04.21.
//

#ifndef HOMEWORK1_MYCONTAINER_H
#define HOMEWORK1_MYCONTAINER_H

#include "Vehicle.h"
/* Този клас пази всички създадени обекти от тип Vehicle. Запазва ги в него и връща пойнтър към тях.
 *
 * Когато обект от тип Garage се изтрие, обектите продължават да съществуват в този контейнер, докато той не се изтрие.
 * Този контейнер "наподобява" std::vector. Може да се направя и темплейт, за да работи с всякакъв тип данни.
 *
 * За мен този обект трябва да има само деструктор, а не експлицитна имплементация на rule of 3. Той ще бъде
 * създаден само веднъж в хода на програмата и ще бъде само изтрит.
 *
 * Коректността на функциите можете да видите в tests
 *
 * */


class MyContainer {
private:
    Vehicle **data;
    std::size_t  size = 0;

public:
    MyContainer(std::size_t size);
    ~MyContainer();
    Vehicle *allocate(const char *registration, const char *description, std::size_t space);
};

#endif //HOMEWORK1_MYCONTAINER_H
