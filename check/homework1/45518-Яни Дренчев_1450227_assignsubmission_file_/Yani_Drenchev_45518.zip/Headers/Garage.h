//
// Created by Yani Drenchev on 2021-04-11.
//
#include "iostream"
#include "Vehicle.h"
#ifndef HOMEWORK1_GARAGE_H
#define HOMEWORK1_GARAGE_H
/*ПОЯСНЕНИЯ:
 * Полето capacity пази първоначалното зададено capacity при създаване на гаража.
 * Полето allocated_capacity пази до момента заетото място в гаража, за да не стане, така че в даден момент
 * да се увеличи първоначалният капацитет
 *
 * numberOfVehicle - пази бройката на колите
 *
 * **cars e интересната част от този клас. Тя пази указател към масив от пойнтъри. Тези пойнтъри се подават
 * от класа MyContainer при създаване на обект от тип Vehicle. Това помага при изтриване на паметта от този клас да не
 * се унищожат обектите от тип Vehicle. Тези пойнтъри може и да се изтрият, но те все още ще съществуват отделно
 * от този клас в класа MyContainer.
 *
 * Това, което не ни трябва, но го има е оператора =. В нашата задача не се споменава за повече от 1 гараж.
 * На мен ми се наложи да го презапиша, защото в main функцията използвам този оператор (ще видите по-натам)
 *
 * Не съм използвал вашите препоръки за "местене" на последния елемент на празната позиция при триене.
 * При мен всички пийнтъри се инициализират, катo nullpntr. Това ми помага линейно да тъся свободно място в масива
 * и при първото такова, да добавям новата кола там.
 *
 * Наистина в началото инциализирам масива с ПОВЕЧЕ от колкото най-вероятно ще ни трябват, но това е най-лошия случай,
 * в който всяка кола заема ТОЧНО 1 място. Бих казах, че е пренебрежимо малка разликата, но ако има по-добър начин
 * за имплементация, ще се радвам да ми дадете обратна връзка.
 *
 * Реализациите са отделени в .cpp файл.
 *
 * */
class Garage {
private:
    std::size_t capacity;
    std::size_t allocated_capacity = 0;
    std::size_t numberOfVehicle = 0;
    Vehicle **cars;

    void destroy();

public:

    Garage(std::size_t size);

    ~Garage();

    Garage& operator=(const Garage&oth);

    void insert(Vehicle &v);

    void erase(const char *registration);

    const Vehicle &at(size_t pos) const;

    const Vehicle &operator[](size_t pos) const;

    bool empty() const;

    std::size_t size() const;

    void clear();

    const Vehicle *find(const char *registration) const;

};

#endif //HOMEWORK1_GARAGE_H
