//
// Created by Yani Drenchev on 14.04.21.
//

#include "../Sources/Garage.cpp"
#include "single_include/catch2/catch.hpp"

TEST_CASE("Garage constructor test", "[constructor]") {
    Garage a = {2};
    REQUIRE(a.size() == 0);
}

TEST_CASE("Garage empty test", "[empty]") {
    Garage a = {2};
    Garage b = {0};
    REQUIRE(b.empty());
    REQUIRE(a.empty());
}


TEST_CASE("Garage find and insert test", "[find]") {
    Garage a = {2};
    Vehicle b{"test", "test2", 1};
    a.insert(b);
    REQUIRE(a.find("test"));
}

TEST_CASE("Garage erase test", "[erase]") {
    Garage a = {2};
    Vehicle b{"test", "test2", 1};
    a.insert(b);
    a.erase("test");
    REQUIRE(a.find("test") == nullptr);
}

TEST_CASE("Garage at test", "[at]") {
    Garage a = {2};
    Vehicle b{"test", "test2", 1};
    a.insert(b);
    REQUIRE(strcmp(a.at(0).registration(), "test") == 0);
}

TEST_CASE("Garage [] test", "[operator []]") {
    Garage a = {2};
    Vehicle b{"test", "test2", 1};
    a.insert(b);
    REQUIRE(strcmp(a[0].registration(), "test") == 0);
}
TEST_CASE("Garage clear test", "[operator []]") {
    Garage a = {2};
    Vehicle b{"test", "test2", 1};
    a.clear();
    REQUIRE(a.size() == 0);
    REQUIRE(a.empty());
}

