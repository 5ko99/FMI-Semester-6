//
// Created by Yani Drenchev on 2021-04-12.
//
#include "../Sources/MyString.cpp"

#define CATCH_CONFIG_MAIN

#include "single_include/catch2/catch.hpp"


TEST_CASE("MyString Operator == test", "[operator=]") {
    MyString a = "test";
    MyString b = "test";
    REQUIRE(a == b);
}

TEST_CASE("MyString Operator += char test", "[operator=]") {
    MyString a = "test";
    MyString b = "testc";
    a+='c';
    REQUIRE(a == b);
}

TEST_CASE("MyString Operator += MyString test", "[operator=]") {
    MyString a = "test";
    MyString b = "bb";
    MyString c = "testbb";
    a+=b;
    REQUIRE(c == a);
}

TEST_CASE("MyString Operator = test", "[operator=]") {
    MyString a = "test25";
    MyString b = "test";
    a=b;
    REQUIRE(a == b);
}

TEST_CASE("MyString Operator + for char test", "[operator+]") {
    MyString a = "test2";
    MyString b = "test";
    b =  b + "2";
    REQUIRE(a == b);
}

TEST_CASE("MyString Operator == invalid test", "[operator=]") {
    MyString a = "test1";
    MyString b = "test";
    bool require = a == b;
    REQUIRE(!require);
}

TEST_CASE("MyString Operator < test", "[operator<]") {
    MyString a = "bb";
    MyString b = "aa";
    REQUIRE(b < a);
}

TEST_CASE("MyString Operator [] test", "[operator at ]") {
    MyString a = "bb";
    MyString b = "222b";
    REQUIRE(a[0] == 'b');
    REQUIRE(b[0] == '2');
    REQUIRE(a[0] != '2');
}

TEST_CASE("MyString at test", "[at]") {
    MyString a = "test";
    REQUIRE(a.at(0) == 't');
    REQUIRE(a.at(1) == 'e');
    REQUIRE(a.at(2) == 's');
}


TEST_CASE("MyString front test", "[front]") {
    MyString a = "test";
    MyString b = "rest";
    REQUIRE(a.front() == 't');
    REQUIRE(b.front() != 't');
}


TEST_CASE("MyString back test", "[back]") {
    MyString a = "test";
    MyString b = "tess";
    REQUIRE(a.back() == 't');
    REQUIRE(b.back() != 't');
}


TEST_CASE("MyString empty test", "[empty]") {
    MyString a = "";
    MyString b = "s";
    REQUIRE(a.empty());
    REQUIRE(!b.empty());
}


TEST_CASE("MyString clear test", "[size]") {
    MyString a = "";
    MyString b = "a";
    a.clear();
    b.clear();
    REQUIRE(a.empty());
    REQUIRE(b.empty());
}

TEST_CASE("MyString push_back test", "[push_back]") {
    MyString a = "";
    a.push_back('a');
    REQUIRE(a[0] == 'a');
    a.push_back('b');
    REQUIRE(a[1] == 'b');
}

TEST_CASE("MyString pop_back test", "[pop_back]") {
    MyString a = "a";
    a.pop_back();
    REQUIRE(a.empty());
}
