//
// Created by Yani Drenchev on 2021-04-14.
//
#include "../Sources/MyContainer.cpp"
#include "../Headers/Vehicle.h"
#include "single_include/catch2/catch.hpp"

TEST_CASE("MyContainer allocate test", "[constructor]") {
    MyContainer a = {2};
    Vehicle *b = a.allocate("test", "test", 3);
    REQUIRE(b);
}
