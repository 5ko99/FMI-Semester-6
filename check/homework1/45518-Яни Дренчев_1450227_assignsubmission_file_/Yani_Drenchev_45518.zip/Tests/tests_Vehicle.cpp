//
// Created by Yani Drenchev on 2021-04-14.
//
#include "../Sources/Vehicle.cpp"

#include "single_include/catch2/catch.hpp"

TEST_CASE("Vehicle constructor test", "[constructor]") {
    Vehicle a = {"test", "test2", 3};
    REQUIRE(strcmp( a.registration(), "test") == 0);
    REQUIRE(strcmp( a.description(), "test2") == 0);
    REQUIRE(a.space() == 3);
}