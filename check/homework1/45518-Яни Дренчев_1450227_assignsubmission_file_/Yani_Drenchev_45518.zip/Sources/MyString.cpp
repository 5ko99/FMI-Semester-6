//
// Created by Yani Drenchev on 2021-04-11.
//
//#define NDEBUG

#include "../Headers/MyString.h"
#include <cstring>
#include <iostream>
#include <stdexcept>
#include <cassert>

MyString::MyString() {
    string = nullptr;
    size_of_string = 0;
}

MyString::MyString(const char *str) {
    size_of_string = strlen(str);
    string = new char[size_of_string];
    std::strcpy(string, str);
}

MyString::~MyString() {
    destroy();
}

MyString &MyString::operator=(const MyString &mystr) {
    if (this == &mystr) {
        return *this;
    }

    copy(mystr);
    return *this;
}

MyString::MyString(const MyString &mystr) {
    copy(mystr);
}

void MyString::copy(const MyString &myString) {
    size_of_string = myString.size();
    delete[] string;
    string = new char[size_of_string];
    std::strcpy(string, myString.getString());
}

void MyString::destroy() {
    delete[] string;
}

char &MyString::at(std::size_t pos) {
    if (pos >= size_of_string) {
        throw std::out_of_range("Incorrect position");
    }
    return string[pos];
}

const char &MyString::at(std::size_t pos) const {
    if (pos >= size_of_string) {
        throw std::out_of_range("Incorrect position");
    }
    return string[pos];
}

char &MyString::operator[](std::size_t pos) {
    assert(size_of_string != 0);
    return string[pos];
}

const char &MyString::operator[](std::size_t pos) const {
    assert(size_of_string != 0);
    return string[pos];
}

char &MyString::front() {
    assert(size_of_string != 0);
    return string[0];
}

const char &MyString::front() const {
    assert(size_of_string != 0);
    return string[0];
}

char &MyString::back() {
    assert(size_of_string != 0);
    return at(size_of_string - 1);
}

const char &MyString::back() const {
    assert(size_of_string != 0);
    return at(size_of_string - 1);
}

bool MyString::empty() const {
    return size_of_string == 0;
}

std::size_t MyString::size() const {
    return size_of_string;
}

void MyString::clear() {
    *this = "";
}

void MyString::push_back(char c) {

    char *newString = nullptr;
    try {
        newString = new char[size_of_string + 1];
    } catch (std::bad_alloc &err) {
        return;
    }
    for (size_t i = 0; i < size_of_string; ++i) {
        newString[i] = string[i];
    }

    newString[size_of_string] = c;
    delete[] string;
    string = newString;
    size_of_string += 1;

}

void MyString::pop_back() {
    assert(size_of_string != 0);
    size_of_string -= 1;
}

MyString &MyString::operator+=(char c) {
    try {
        push_back(c);
    } catch (std::bad_alloc &err) {
        return *this;
    }

    return *this;
}

MyString &MyString::operator+=(const MyString &rhs) {
    for (std::size_t i = 0; i < rhs.size_of_string; ++i) {
        try {
            push_back(rhs[i]);
        } catch (std::bad_alloc &err) {
            return *this;
        }
    }
    return *this;
}

MyString MyString::operator+(char c) {

    MyString newString{string};
    try {
        newString.push_back(c);
    } catch (std::bad_alloc &err) {
        return newString;
    }

    return newString;
}

MyString MyString::operator+(const MyString &rhs) {
    MyString newString{string};
    for (int i = 0; i < rhs.size_of_string; ++i) {
        try {
            newString.push_back(rhs[i]);
        } catch (std::bad_alloc &err) {
            return newString;
        }
    }
    return newString;
}

const char *MyString::c_str() const {
    return string;
}

bool MyString::operator==(const MyString &rhs) const {
    return std::strcmp(string, rhs.string) == 0;
}

bool MyString::operator<(const MyString &rhs) const {
    return std::strcmp(string, rhs.string) < 0;
}

char *MyString::getString() const {
    return string;
}


