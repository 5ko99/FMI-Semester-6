//
// Created by Yani Drenchev on 14.04.21.
//

#include "../Headers/MyContainer.h"

Vehicle *MyContainer::allocate(const char *registration, const char *description, std::size_t space) {
    auto *x = new Vehicle(registration, description, space);
    data[size] = x;
    ++size;
    return x;
}

MyContainer::MyContainer(std::size_t size) {
    data = new Vehicle * [size];
}

MyContainer::~MyContainer() {
    for(std::size_t i = 0; i < size; ++i)
        delete data[i];
    delete [] data;
}
