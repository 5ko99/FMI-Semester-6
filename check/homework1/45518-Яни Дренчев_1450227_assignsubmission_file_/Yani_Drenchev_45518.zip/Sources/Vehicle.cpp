//
// Created by Yani Drenchev on 2021-04-11.
//

#include "../Headers/Vehicle.h"

Vehicle::Vehicle(const char *registration, const char *description, std::size_t space) {
    registrationNumbers = registration;
    descriptions = description;
    spaces = space;
}

const char *Vehicle::registration() const {
    return registrationNumbers.c_str();
}

const char *Vehicle::description() const {
    return descriptions.c_str();
}

std::size_t Vehicle::space() const {
    return spaces;
}

