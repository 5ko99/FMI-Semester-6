//
// Created by Yani Drenchev on 2021-04-11.
//

#include "../Headers/Garage.h"

Garage::Garage(std::size_t size) {
    capacity = size;
    cars = new Vehicle *[size];
    clear();
}

Garage::~Garage() {
    destroy();
}

void Garage::destroy() {
    delete [] cars;
}

void Garage::insert(Vehicle &v) {
    if (allocated_capacity + v.space() > capacity) {
        throw std::out_of_range("No more space");
    }
    if (find(v.registration())) {
        throw std::out_of_range("Duplicated space");
    }

    for (int i = 0; i < capacity; ++i) {
        if (cars[i] == nullptr) {
            allocated_capacity += v.space();
            numberOfVehicle++;
            cars[i] = & v;
            return;
        }
    }

    // should never come here
    std::cout << "Internal error";
}

void Garage::erase(const char *registration) {
    for (int i = 0; i < capacity; ++i) {
        if (cars[i] != nullptr){
            if (strcmp(cars[i]->registration(), registration) == 0) {
                allocated_capacity -= cars[i]->space();
                numberOfVehicle--;
                cars[i] = nullptr;
            }
        }
    }
}

const Vehicle &Garage::at(const size_t pos) const {
    if (pos >= capacity) {
        throw std::out_of_range("Out of range");
    }
    if (cars[pos] == nullptr) {
        throw std::out_of_range("Parking Space is empty");
    }
    return *cars[pos];
}

const Vehicle &Garage::operator[](const size_t pos) const {
    assert(!empty());
    return *cars[pos];
}

bool Garage::empty() const {
    return ! size();
}

std::size_t Garage::size() const {
    return numberOfVehicle;
}

void Garage::clear() {
    allocated_capacity = 0;
    numberOfVehicle = 0;
    for (int i = 0; i < capacity; ++i)
        cars[i] = nullptr;
}

const Vehicle *Garage::find(const char *registration) const {
    for (int i = 0; i < capacity; ++i) {
        if (cars[i] != nullptr){
            if (strcmp(cars[i]->registration(),registration) == 0)
                return cars[i];
        }
    }
    return nullptr;
}

Garage &Garage::operator=(const Garage &oth) {
    if (this == &oth){
        return *this;
    }
    destroy();
    capacity = oth.capacity;
    numberOfVehicle = oth.numberOfVehicle;
    allocated_capacity = oth.allocated_capacity;
    cars = new Vehicle *[capacity];
    for (int i = 0; i < capacity; ++i) {
        cars[i] = oth.cars[i];
    }
    return *this;
}



