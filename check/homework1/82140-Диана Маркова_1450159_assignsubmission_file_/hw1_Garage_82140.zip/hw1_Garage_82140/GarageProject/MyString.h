#ifndef MYSTRING_H
#define MYSTRING_H
#include <cstddef>
#include <iostream>

const std::size_t memAdd=15;
const char delim='\n';

class MyString
{
private:
    std::size_t Size;
    std::size_t capacity;
    char* myStr;
public:
    MyString();
    MyString(const char* str);
    ///Rule of three
    MyString(const MyString& other);
    MyString& operator=(const MyString& other);
    ~MyString();
    ///
    char& at(std::size_t pos);
    const char& at(std::size_t pos) const;
    char& operator[](std::size_t pos);
    const char& operator[](std::size_t pos) const;
    char& front();
    const char& front() const;
    char& back();
    const char& back() const;
    bool empty() const;
    std::size_t size() const;
    std::size_t getCap() const;
    void clear();
    void push_back(char c);
    void pop_back();
    MyString& operator+=(char c);
    MyString& operator+=(const MyString& rhs);
    MyString operator+(char c) const;
    //MyString operator+(const char* rhs) const;///added and implemented unintentionally
    MyString operator+(const MyString &rhs) const;
    const char* c_str() const;
    bool operator==(const MyString &rhs) const;
    bool operator!=(const MyString& rhs) const;
    bool operator<(const MyString &rhs) const;
    bool operator>(const MyString& rhs) const;
    bool operator<=(const MyString& rhs) const;
    bool operator>=(const MyString& rhs) const;
    void print() const;
    void input();
    friend std::istream& operator>>(std::istream& is, MyString& ms);
};

std::ostream& operator<<(std::ostream& os, const MyString& ms);

#endif
