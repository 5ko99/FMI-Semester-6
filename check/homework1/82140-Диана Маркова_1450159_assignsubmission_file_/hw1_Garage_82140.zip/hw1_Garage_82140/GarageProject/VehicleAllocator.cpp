#define _CRT_SECURE_NO_WARNINGS
#include "Vehicle.h"
#include "MyString.h"
#include "Garage.h"
#include "VehicleAllocator.h"

VehicleAllocator::VehicleAllocator(): vehicles(new Vehicle*[addCells]), cap(addCells), numberOfVehicles(0)
{}

VehicleAllocator::~VehicleAllocator()
{
    for(std::size_t i=0; i<numberOfVehicles; ++i)
    {
        delete vehicles[i];
    }
    delete[] vehicles;
}

void VehicleAllocator::expand(std::size_t newCap)
{
    Vehicle** temp=new Vehicle*[newCap];
    for(std::size_t i=0; i<numberOfVehicles; ++i) temp[i]=vehicles[i];
    delete[] vehicles;
    vehicles=temp;
    cap=newCap;
}

Vehicle* VehicleAllocator::allocate(const char* registration, const char* description, std::size_t space)
{
    Vehicle* v=new Vehicle(registration, description, space);
    if(numberOfVehicles+1<=cap) vehicles[numberOfVehicles++]=v;
    else
    {
        expand(numberOfVehicles+1+addCells);
        vehicles[numberOfVehicles++]=v;
    }
    return v;
}

std::size_t VehicleAllocator::getCap()const
{
    return cap;
}
std::size_t VehicleAllocator::getNumberOfVehicles() const
{
    return numberOfVehicles;
}
Vehicle** VehicleAllocator::getVehiclesArr() const
{
    return vehicles;
}


