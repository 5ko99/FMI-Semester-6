#ifndef GARAGE_H
#define GARAGE_H
#include "Vehicle.h"
#include "MyString.h"
#include <iostream>
#include <cstddef>

const std::size_t addMem=10;
///There are two "printing" ways, which are disparate.
///One only prints out details about the Garage and one simply prints out the information about each vehicle in it
class Garage
{
    Vehicle** vehicles;
    std::size_t capacity;
    std::size_t occupied;///number of occupied spaces(or parking lots)
    std::size_t currentSize;///size of the dynamic array
    std::size_t numberOfVehicles;///number of vehicles in the array
public:
    Garage(std::size_t size);
    ///Rule of three
    Garage(const Garage& other);
    ~Garage();
    Garage& operator=(const Garage& other);
    ///
    void insert(Vehicle& v);
    void erase(const char* registrtion);
    const Vehicle& at(std::size_t pos) const;
    const Vehicle& operator[](std::size_t pos) const;
    bool empty() const;
    std::size_t size() const;
    void clear();
    const Vehicle* find(const char* registration) const;
//std::size_t getOccupied() const;
//std::size_t getCurrentSize() const;
//std::size_t getCapacity() const;
    void printVehicles() const;
private:
    void expand(std::size_t newArraySize);

    friend std::ostream& operator<<(std::ostream& os, const Garage& g);
};




#endif
