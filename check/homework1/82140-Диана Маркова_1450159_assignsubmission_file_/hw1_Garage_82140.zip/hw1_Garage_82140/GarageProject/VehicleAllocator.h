#ifndef VEHICLEALLOCATOR_H
#define VEHICLEALLOCATOR_H
#include "Vehicle.h"
#include "MyString.h"
#include "Garage.h"
const std::size_t addCells=15;

///Does not follow Rule of three because it is not meant to be copied
///or used as an initializing object;
///Its sole purpose is to store some vehicles in the required way
class VehicleAllocator {
    Vehicle** vehicles;
    std::size_t cap;
    std::size_t numberOfVehicles;
public:
    VehicleAllocator();
    ~VehicleAllocator();
    Vehicle* allocate(const char* registration, const char* description, std::size_t space);
    std::size_t getCap()const;
    std::size_t getNumberOfVehicles() const;
    Vehicle** getVehiclesArr() const;
private:
    void expand(std::size_t newCap);
};

#endif
