#define _CRT_SECURE_NO_WARNINGS
///#define NDEBUG
#include "MyString.h"
#include <cstring>
#include <stdexcept>
#include <cassert>
#include <iostream>

///All functions(hopefully) provide strong exception guarantee
MyString::MyString(): MyString("")
{}

MyString::MyString(const char* str)
    :Size(std::strlen(str)), capacity(Size+1+memAdd), myStr(new char[capacity])
{
    std::strcpy(myStr, str);///strcpy does add '\0'
}

MyString::MyString(const MyString& other)
    :Size(other.Size), capacity(other.Size+1+memAdd), myStr(new char[capacity])
{
    std::strcpy(myStr, other.myStr);
}

MyString& MyString::operator=(const MyString& other)
{
    if(this!=&other)
    {
        std::size_t newCap=other.Size+1+memAdd;
        char* tempStr=new char[newCap];
        delete[] myStr;
        myStr=tempStr;
        std::strcpy(myStr, other.myStr);
        Size=other.Size;
        capacity=newCap;
    }
    return *this;
}

char& MyString::at(std::size_t pos)
{
    if(pos>=Size) throw std::out_of_range("Invalid position");
    return myStr[pos];
}

const char& MyString::at(std::size_t pos) const
{
    if(pos>=Size) throw std::out_of_range("Invalid position");
    return myStr[pos];
}

char& MyString::operator[](std::size_t pos)
{
    assert("Bad position!" && pos<Size);
    return myStr[pos];
}

const char& MyString::operator[](std::size_t pos) const
{
    assert("Bad position!" && pos<Size);
    return myStr[pos];
}

char& MyString::front()
{
    assert("Empty string" && !empty());
    return myStr[0];
}

const char& MyString::front() const
{
    assert("Empty string" && !empty());
    return myStr[0];
}

char& MyString::back()
{
    assert("Empty string" && !empty());
    return myStr[Size-1];
}

const char& MyString::back() const
{
    assert("Empty string" && !empty());
    return myStr[Size-1];
}

std::size_t MyString::size() const
{
    return Size;
}

std::size_t MyString::getCap() const
{
    return capacity;
}

///It does provide strong exception guarantee
void MyString::clear()
{
    //Might have just null-terminated the 0th symbol
    //Decided this would be more "secure", just in case
    if(empty()) return;
    for(std::size_t i=0; i<Size; ++i) myStr[i]='\0';
    Size=0;
}
///It does provide strong exception guarantee
void MyString::push_back(char c)
{
    if(Size+1+1<=capacity)
    {
        myStr[Size++]=c;
        myStr[Size]='\0';
        if(c=='\0') Size--;///if someone decides to push_back '\0'
    }
    else
    {
        std::size_t newCap=Size+2+memAdd;
        char* temp=new char[newCap];
        std::strcpy(temp, myStr);
        temp[Size++]=c;
        temp[Size]='\0';
        delete[] myStr;
        myStr=temp;
        capacity=newCap;
        if(c=='\0') Size--;
    }
}

void MyString::pop_back()
{
    assert("Empty string" && !empty());
    myStr[Size-1]='\0';
    Size--;
}

MyString::~MyString()
{
    delete[] myStr;
}

bool MyString::empty() const
{
    return Size==0;
}
///It does provide strong exception guarantee, because push back does so.
MyString& MyString::operator+=(char c)
{
    push_back(c);
    return *this;
}

MyString& MyString::operator+=(const MyString& rhs)
{
    if(Size+rhs.Size+1<=capacity)
    {
        std::strcat(myStr, rhs.myStr);
        Size+=rhs.Size;
    }
    else
    {
        std::size_t newCap=Size+rhs.Size+1+memAdd;
        char* temp=new char[newCap];
        std::strcpy(temp, myStr);
        std::strcat(temp, rhs.myStr);
        delete[] myStr;
        myStr=temp;
        capacity=newCap;
        Size+=rhs.Size;
    }
    return *this;
}

MyString MyString::operator+(char c) const
{
    MyString temp(*this);
    //In case of an exception being thrown, no fields would be affected
    temp+=c;
    //We reach this point only when temp has already been constructed
    //If this operation were to fail, invariants would again be kept intact.
    return temp;
}

MyString MyString::operator+(const MyString& rhs) const
{
    MyString temp(*this);
    temp+=rhs;
    return temp;
}

const char* MyString::c_str() const
{
    return myStr;
}

bool MyString::operator==(const MyString& rhs) const
{
    return std::strcmp(myStr, rhs.myStr)==0;
}

bool MyString::operator!=(const MyString& rhs) const
{
    return !(*this==rhs);
}

bool MyString::operator<(const MyString& rhs) const
{
    return std::strcmp(myStr, rhs.myStr)<0;
}

bool MyString::operator>(const MyString& rhs) const
{
    return rhs<*this;
}

bool MyString::operator>=(const MyString& rhs) const
{
    return !(rhs>*this);
}

bool MyString::operator<=(const MyString& rhs) const
{
    return !(rhs<*this);
}

void MyString::print() const
{
    std::cout<<c_str()<<std::endl;
    std::cout<<"capacity: "<<capacity<<std::endl;
    std::cout<<"size: "<<Size<<std::endl;
}

///Makes use of the getters
std::ostream& operator<<(std::ostream& os, const MyString& ms)
{
    os<<ms.c_str();
    return os;
}

///These input functions do provide strong exception guarantee
void MyString::input()
{
    MyString temp;
    char reader;
    do
    {
        std::cin.get(reader);
        if(reader!=delim)
        temp+=reader;
    }
    while(reader!=delim);
    *this=temp;
}

std::istream& operator>>(std::istream& is, MyString& ms)
{
    MyString temp;
    char reader;
    do
    {
        std::cin.get(reader);
        if(reader!=delim)
        temp+=reader;
    }
    while(reader!=delim);
    ms=temp;
    return is;
}
