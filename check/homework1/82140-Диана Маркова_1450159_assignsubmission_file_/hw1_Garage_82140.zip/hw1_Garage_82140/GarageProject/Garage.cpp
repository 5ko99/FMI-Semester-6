#define _CRT_SECURE_NO_WARNINGS
///#define NDEBUG
#include "Garage.h"
#include "Vehicle.h"
#include "MyString.h"
#include <iostream>
#include <cstddef>
#include <cassert>
#include <cstring>

Garage::Garage(std::size_t size):
    vehicles(new Vehicle*[addMem]), capacity(size),
    occupied(0), currentSize(addMem), numberOfVehicles(0)
{}

Garage::Garage(const Garage& other):
    vehicles(new Vehicle*[other.numberOfVehicles+addMem]),
    capacity(other.capacity), occupied(other.occupied),
    currentSize(other.numberOfVehicles+addMem), numberOfVehicles(other.numberOfVehicles)
{
    for(std::size_t i=0; i<numberOfVehicles; ++i) vehicles[i]=other.vehicles[i];
}

Garage& Garage::operator=(const Garage& other)
{
    if(this!=&other)
    {
        Vehicle** temp=new Vehicle* [other.numberOfVehicles+addMem];
        for(std::size_t i=0; i<other.numberOfVehicles; ++i) temp[i]=other.vehicles[i];
        delete[] vehicles;
        ///The array pointer never points to nothing.
        ///Memory is always allocated initially
        vehicles=temp;
        capacity=other.capacity;
        occupied=other.occupied;
        currentSize=other.numberOfVehicles+addMem;
        numberOfVehicles=other.numberOfVehicles;
    }
    return *this;
}

std::size_t Garage::size() const
{
    return numberOfVehicles;
}

const Vehicle* Garage::find(const char* registration) const
{
    for(std::size_t i=0; i<numberOfVehicles; ++i)
        if(std::strcmp(vehicles[i]->registration(), registration)==0) return vehicles[i];
    return nullptr;
}

bool Garage::empty() const
{
    return !numberOfVehicles;
}

void Garage::insert(Vehicle& v)
{
    if(find(v.registration())) throw std::invalid_argument("A vehicle with an identical registration is currently in the garage!");
    if(occupied+v.space()>capacity) throw std::overflow_error("Not enough free lots for the vehicle");
    if(currentSize>=1+numberOfVehicles)
    {
        vehicles[numberOfVehicles++]=&v;
        occupied+=v.space();
    }
    else
    {
        expand(1+numberOfVehicles);
        ///If it fails, it will throw bad_alloc. The invariants will be kept intact in that case
        vehicles[numberOfVehicles++]=&v;
        occupied+=v.space();
    }
}
///Note that expand does add an additional chunk of memory
void Garage::expand(std::size_t newArraySize)
{
    Vehicle** temp=new Vehicle*[newArraySize+addMem];
    for(std::size_t i=0; i<numberOfVehicles; ++i)
        temp[i]=vehicles[i];
    delete[] vehicles;
    vehicles=temp;
    currentSize=newArraySize+addMem;
}

void Garage::erase(const char* registration)
{
    if(empty()) return;
    const Vehicle* carToBeRemoved=find(registration);
    if(!carToBeRemoved) return;
    std::size_t pos;
    for(pos=0; pos<numberOfVehicles; ++pos)
        if(std::strcmp((vehicles[pos])->registration(), registration)==0) break;
    vehicles[pos]=vehicles[numberOfVehicles-1];
    occupied-=(*carToBeRemoved).space();
    numberOfVehicles--;
}

const Vehicle& Garage::at(std::size_t pos) const
{
    if(pos>=numberOfVehicles) throw std::out_of_range("No access outside of the array!");
    return *(vehicles[pos]);
}

const Vehicle& Garage::operator[](std::size_t pos) const
{
    assert(("No access outside of the array!"&&pos<numberOfVehicles));
    return *(vehicles[pos]);
}

void Garage::clear()
{
    if(empty()) return;
    occupied=0;
    numberOfVehicles=0;
}

Garage::~Garage()
{
    delete[] vehicles;
}

std::ostream& operator<<(std::ostream& os, const Garage& g)
{
    os<<"capacity: "<<g.capacity<<'\n'
        <<"occupied lots: "<<g.occupied<<'\n'
            <<"number of vehicles in the garage: "<<g.numberOfVehicles<<'\n';
                //<<"amount of memory allocated: "<<g.currentSize<<'\n';
    return os;
}
/*
std::size_t Garage::getOccupied() const
{
    return occupied;
}

std::size_t Garage::getCurrentSize() const
{
    return currentSize;
}
std::size_t Garage::getCapacity() const
{
    return capacity;
}
*/
void Garage::printVehicles() const
{
    for(std::size_t i=0; i<numberOfVehicles; ++i)
    {
        std::cout<<(*vehicles[i])<<std::endl;///Makes use of operator<< for Vehicle
    }
    std::cout<<"----------------------------------"<<std::endl;
}
