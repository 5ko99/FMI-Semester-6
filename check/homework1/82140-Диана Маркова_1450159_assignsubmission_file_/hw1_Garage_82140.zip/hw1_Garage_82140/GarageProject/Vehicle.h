#ifndef VEHICLE_H
#define VEHICLE_H
#include "MyString.h"
#include <iostream>
#include <cstddef>
#include <stdexcept>

class Vehicle
{
    MyString Registration;
    MyString Description;
    std::size_t Space;
public:
    Vehicle(const char* registration, const char* description, std::size_t space);
    const char* registration() const;
    const char* description() const;
    std::size_t space() const;
};
std::ostream& operator<<(std::ostream& os, const Vehicle& v);

#endif
