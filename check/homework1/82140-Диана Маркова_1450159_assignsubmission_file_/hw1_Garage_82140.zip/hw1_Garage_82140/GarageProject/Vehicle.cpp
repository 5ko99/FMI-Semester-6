#define _CRT_SECURE_NO_WARNINGS
#include "MyString.h"
#include "Vehicle.h"
#include <iostream>
#include <cstddef>

///No need to implement operator=, copy constructor or destructor.
///MyString deals with itself.
Vehicle::Vehicle(const char* registration, const char* description, std::size_t space):
    Registration(registration), Description(description), Space(space)
{}
const char* Vehicle::registration() const
{
    return Registration.c_str();
}
const char* Vehicle::description() const
{
    return Description.c_str();
}
std::size_t Vehicle::space() const
{
    return Space;
}

std::ostream& operator<<(std::ostream& os, const Vehicle& v)
{
    os<<"registration: "<<v.registration()
    <<'\n'<<"description: "<<v.description()
    <<'\n'<<"space: "<<v.space();
    return os;
}
