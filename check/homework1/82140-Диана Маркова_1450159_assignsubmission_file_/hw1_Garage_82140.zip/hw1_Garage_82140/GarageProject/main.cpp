#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstddef>
#include "Garage.h"
#include "Vehicle.h"
#include "MyString.h"
#include "VehicleAllocator.h"
#include <limits>


const char greeter[]="Hello! ";
const char optionsStatement[]="Options: \n1. Add a Vehicle\n2. Remove a Vehicle\n3. Print out vehicles\n4. Exit\n";
const char OptionStatement[]="Type in a valid option value:\n";
const char CapacityStatement[]="Type in a valid garage capacity value:\n";
const char optionAnnouncer[]="----------------------------------\nYou've entered option ";
const char errorMessage[]="Sorry, an unknown error occurred!(most likely a memory one)\n";
const char emptystr[]="";
const char failedOpr[]="Operation is unsuccessful! ";

enum options
{
    UNKNOWN=0,
    ADD,
    REMOVE,
    PRINT,
    EXIT,
    COUNTER
};

bool isOptionValid(std::size_t opt)
{
    return (opt!=UNKNOWN&&opt<COUNTER);
}

bool alwaysTrue(size_t n)
{
    return true;
}

std::size_t inputASize_t(const char* PromptMessage=emptystr, bool condition(std::size_t)=alwaysTrue)
{
    while(true)
    {
        std::size_t num;
        std::cout<<PromptMessage;
        if(!(std::cin>>num))
        {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            continue;
        }
        if(condition(num)) return num;
    }
}

int main()
{
    try
    {
        std::size_t capacity;
        std::size_t option;
        std::cout<<greeter;
        capacity=inputASize_t(CapacityStatement);
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        MyString buff;
        MyString buff1;
        VehicleAllocator allocator1;
        Garage userGarage(capacity);
    do
    {
        std::cout<<optionsStatement;
        option=inputASize_t(OptionStatement, isOptionValid);
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        if(option==EXIT)
        {
            break;
        }
        switch(option)
    {
        case ADD:
            {
                std::cout<<optionAnnouncer<<ADD<<std::endl;
                std::cout<<"Registration: ";
                try {std::cin>>buff;}
                catch(...) {throw;}//Unnecessary, left for clarity
                std::cout<<"Description: ";
                try {std::cin>>buff1;}
                catch(...) {throw;}//Unnecessary, left for clarity
                std::size_t space;
                space=inputASize_t("Space: ");
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                try {userGarage.insert(*allocator1.allocate(buff.c_str(), buff1.c_str(), space));}
                catch(std::invalid_argument& e)
                {
                    std::cout<<failedOpr<<e.what()<<std::endl;
                }
                catch(std::overflow_error& e)
                {
                    std::cout<<failedOpr<<e.what()<<std::endl;
                }
                catch(...){throw;}//Unnecessary, left for clarity
            }
            break;
        case REMOVE:
            {
                std::cout<<optionAnnouncer<<REMOVE<<std::endl;
                std::cout<<"Type in the registration of the vehicle to be removed: ";
                try{buff.input();} catch(...) {throw;}//Unnecessary, left for clarity
//std::cout<<buff;
                userGarage.erase(buff.c_str());
//std::cout<<" has been removed"<<std::endl;
            }

            break;
        case PRINT:
            std::cout<<optionAnnouncer<<PRINT<<std::endl;
            std::cout<<userGarage<<std::endl;
            userGarage.printVehicles();
            break;
    }
    }
     while(true);
    }
    catch(...)
    {
        std::cout<<errorMessage<<std::endl;
        return 1;
    }
    return 0;
}
