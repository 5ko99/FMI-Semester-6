#ifndef MYSTRINGTESTS_H
#define MYSTRINGTESTS_H
#include "catch2.hpp"
#include "../GarageProject/MyString.h"
#include <cstring>
#include <stdexcept>
#include <iostream>

TEST_CASE("Normal constructors set values correctly and memory is not shared with parameters", "[MyString]")
{
    SECTION("Values are set correctly when zero-sized cstring is passed")
    {
        MyString ms1("");
        MyString ms3;
        REQUIRE(ms1.getCap()==memAdd+1);///Note that memAdd is defined in class header
        REQUIRE(ms1.size()==0);
        REQUIRE(std::strcmp("", ms1.c_str())==0);
        REQUIRE(ms3.getCap()==memAdd+1);
        REQUIRE(ms3.size()==0);
        REQUIRE(std::strcmp("", ms3.c_str())==0);
    }
    SECTION("Values are set correctly when non-zero sized cstring is passed")
    {
        MyString ms2("something");
        REQUIRE(ms2.getCap()==memAdd+1+9);
        REQUIRE(ms2.size()==9);
        REQUIRE(std::strcmp("something", ms2.c_str())==0);
        MyString ms3("supercalifragilisticexpialidocioussupercalifragilisticexpialidocioussupercalifragilisticexpialidocious");
        REQUIRE(ms3.getCap()==memAdd+1+102);
        REQUIRE(ms3.size()==102);
        REQUIRE(std::strcmp("supercalifragilisticexpialidocioussupercalifragilisticexpialidocioussupercalifragilisticexpialidocious", ms3.c_str())==0);

    }
    SECTION("Constructed strings do not share memory with initializing parameter")
    {
        const char str1[100]="string1";
        const char str2[100]="string2";
        char str[100]="";
        std::strcpy(str, str1);
        MyString test(str1);
        std::strcpy(str, str2);
        REQUIRE(std::strcmp(test.c_str(), str1)==0);
    }
}

TEST_CASE("Copy constructor sets values correctly and no copies share memory", "[MyString]")
{
    MyString ms1;
    MyString ms2("something");
    SECTION("Copy constructor sets values correctly")
    {
        MyString ms5(ms1);
        REQUIRE(ms5.getCap()==memAdd+1);
        REQUIRE(ms5.size()==0);
        REQUIRE(std::strcmp("", ms5.c_str())==0);
        MyString ms6(ms2);
        REQUIRE(ms6.getCap()==memAdd+1+9);
        REQUIRE(ms6.size()==9);
        REQUIRE(std::strcmp("something", ms6.c_str())==0);
    }
    SECTION("No memory is shared between copies")
    {
        const char str1[100]="string1";
        char str[100]="";
        std::strcpy(str, str1);
        const MyString* ms1=new MyString(str);
        const MyString ms2=*ms1;
        REQUIRE(std::strcmp(ms1->c_str(), ms2.c_str())==0);
        REQUIRE(ms1->c_str()!=ms2.c_str());
        delete ms1;
    }
}

TEST_CASE("Copy assignment is done correctly", "[MyString]")
{
    SECTION("Values are set correctly")
    {
        MyString ms1;
        MyString ms2("something");
        MyString ms7=ms1;
        MyString ms8=ms2;
        REQUIRE(ms7.getCap()==memAdd+1);
        REQUIRE(ms7.size()==0);
        REQUIRE(std::strcmp("", ms7.c_str())==0);
        REQUIRE(ms8.getCap()==memAdd+1+9);
        REQUIRE(ms8.size()==9);
        REQUIRE(std::strcmp("something", ms8.c_str())==0);
    }
    SECTION("No memory is shared between copies after assignment")
    {
        const char str1[100]="string1";
        const char str2[100]="string2";
        char str[100]="";
        std::strcpy(str, str1);
        const MyString* ms1=new MyString(str);
        MyString ms2(str2);
        ms2=*ms1;
        REQUIRE(std::strcmp(ms1->c_str(), ms2.c_str())==0);
        REQUIRE(ms1->c_str()!=ms2.c_str());
        delete ms1;
    }
}

TEST_CASE("Testing at", "[MyString]")
{
    SECTION("Testing const version")
    {
        const MyString ms1;
        const MyString ms2("myText");
        REQUIRE_THROWS(ms1.at(0));
        REQUIRE_THROWS(ms2.at(6));
        REQUIRE(ms2.at(0)=='m');
        REQUIRE(ms2.at(2)=='T');
        REQUIRE(ms2.at(5)=='t');
    }
    SECTION("Testing non-const version")
    {
        MyString ms1;
        MyString ms2("myText");
        REQUIRE_THROWS(ms1.at(0));
        REQUIRE_THROWS(ms2.at(6));
        REQUIRE(ms2.at(0)=='m');
        REQUIRE(ms2.at(2)=='T');
        REQUIRE(ms2.at(5)=='t');
    }
}
///c_str has already been tested in the above test_cases

TEST_CASE("Testing operator[]", "[MyString]")
{
    SECTION("Testing const version")
    {
        const MyString ms1;
        const MyString ms2("myText");
        REQUIRE_NOTHROW(ms2[0]=='m');
        REQUIRE_NOTHROW(ms2[2]=='T');
        REQUIRE_NOTHROW(ms2[5]=='t');
    }
    SECTION("Testing non-const version")
    {
        MyString ms1;
        MyString ms2("myText");
        REQUIRE_NOTHROW(ms2[0]=='m');
        REQUIRE_NOTHROW(ms2[2]=='T');
        REQUIRE_NOTHROW(ms2[5]=='t');
      }
}

TEST_CASE("Testing front", "[MyString]")
{
    SECTION("Testing const version")
    {
        const MyString ms1;
        const MyString ms2("myText");
        REQUIRE(ms2.front()=='m');
        ///ms1.front(); -- to assert assertions
    }

    SECTION("Testing non-const version")
    {
        MyString ms1;
        MyString ms2("myText");
        REQUIRE(ms2.front()=='m');
       /// ms1.front(); -- to assert assertions
    }
}

TEST_CASE("Testing back", "[MyString]")
{
    SECTION("Testing const version")
    {
        const MyString ms1;
        const MyString ms2("myText");
        REQUIRE(ms2.back()=='t');
        //ms1.back();
    }

    SECTION("Testing non-const version")
    {
        MyString ms1;
        MyString ms2("myText");
        REQUIRE(ms2.back()=='t');
        //ms1.back();
    }
}

TEST_CASE("Testing size method", "[MyString]")
{
    MyString ms1;
    MyString ms2("myText");
    REQUIRE(ms1.size()==0);
    REQUIRE(ms2.size()==6);
}

TEST_CASE("Testing empty method", "[MyString]")
{
    MyString ms1;
    MyString ms2("myText");
    REQUIRE(ms1.empty());
    REQUIRE(!ms2.empty());
}

TEST_CASE("Testing clear method", "[MyString]")
{
    MyString ms1;
    MyString ms2("myText");
    ms1.clear();
    REQUIRE(ms1.size()==0);
    REQUIRE(std::strcmp(ms1.c_str(), "")==0);
    ms2.clear();
    REQUIRE(ms2.size()==0);
    REQUIRE(std::strcmp(ms2.c_str(), "")==0);
}

TEST_CASE("Testing push_back method", "[MyString]")
{
    MyString ms1;
    MyString ms2("myText");
    MyString ms3;
    MyString ms4(ms2);
    ms1.push_back('c');
    REQUIRE((std::strcmp(ms1.c_str(), "c")==0&&ms1.size()==1));
    ms2.push_back('c');
    REQUIRE((std::strcmp(ms2.c_str(), "myTextc")==0&&ms2.size()==7));
    ms3.push_back('\0');
//std::cout<<ms3.size()<<std::endl;
//std::cout<<ms3.c_str()<<std::endl;
    REQUIRE((std::strcmp(ms3.c_str(), "")==0&&ms3.size()==0));
    ms4.push_back('\0');
    REQUIRE((std::strcmp(ms4.c_str(), "myText")==0&&ms4.size()==6));
}

TEST_CASE("Testing pop_back method", "[MyString]")
{
    MyString m1;
    MyString m2("myText");
    ///m1.pop_back(); -- to assert assertions
    m2.pop_back();
    REQUIRE((std::strcmp(m2.c_str(), "myTex")==0&&m2.size()==5));
}

TEST_CASE("Testing operator+=", "[MyString]")
{
    SECTION("For chars in rhs")
    {
        MyString ms1;
        MyString ms2("myText");
        ms1+='c';
        ms2+='c';
        REQUIRE((std::strcmp(ms1.c_str(), "c")==0&&ms1.size()==1));
        REQUIRE((std::strcmp(ms2.c_str(), "myTextc")==0&&ms2.size()==7));
    }
    SECTION("For MyString objects in rhs")
    {
        MyString ms1;
        MyString ms2("myText");
        MyString ms3("extension");
        MyString ms4("supercalifragilisticexpialidocioussupercalifragilisticexpialidocioussupercalifragilisticexpialidocious");
        ///3*34=102
        ms2+=ms3;
        REQUIRE((std::strcmp(ms2.c_str(), "myTextextension")==0&&ms2.size()==15));
        ms1+=ms4;
        REQUIRE((std::strcmp(ms1.c_str(), "supercalifragilisticexpialidocioussupercalifragilisticexpialidocioussupercalifragilisticexpialidocious")==0&&ms1.size()==102));
        REQUIRE(ms1.getCap()==ms4.size()+memAdd+1);
        ms2=ms2;
        REQUIRE((std::strcmp(ms2.c_str(), "myTextextension")==0&&ms2.size()==15));
        MyString ms5("Textextensionstr");//16 size
        MyString edgecap("my");//cap is 15+2+1=18
        edgecap+=ms5;
        REQUIRE((std::strcmp(edgecap.c_str(), "myTextextensionstr")==0&&edgecap.size()==18));
        REQUIRE(edgecap.getCap()==2+ms5.size()+memAdd+1);
    }
}

TEST_CASE("Testing operator+", "[MyString]")///Based on the previous one, we don't need to check all cases
{
    SECTION("For chars in rhs")
    {
        MyString ms2("myText");
        MyString temp=ms2+'c';
        REQUIRE((std::strcmp(temp.c_str(), "myTextc")==0&&temp.size()==7));
    }
/*
    SECTION("For const char* in rhs")
    {
        MyString ms("myText");
        MyString temp=ms+"someOtherText";
        REQUIRE((std::strcmp(temp.c_str(), "myTextsomeOtherText")==0&&temp.size()==19));
    }
*/
//std::cout<<temp1<<std::endl;
    SECTION("For MyString objects in rhs")
    {
        MyString ms3("someText");
        MyString ms4("someOtherText");
        MyString temp1=ms3+ms4;
        REQUIRE((std::strcmp(temp1.c_str(), "someTextsomeOtherText")==0&&temp1.size()==21));
    }
}

TEST_CASE("Testing comparison operators", "[MyString]")
{
    MyString ms0;
    MyString ms;
    MyString ms1("supercalifragilisticexpialidocious");
    MyString ms2("abc");
    MyString ms3("supercalifragilisticexpialidocious");
    REQUIRE((ms1>ms2&&ms1>ms&&ms<ms2));
    REQUIRE((ms1==ms3&&ms1!=ms2));
    REQUIRE((ms1>=ms2&&ms1<=ms3&&ms0<=ms&&ms0>=ms));
}

TEST_CASE("Why")
{
    MyString a("00st description");
    MyString b;
    for(std::size_t i=0; i<a.size(); ++i) b+=a[i];
    //std::cout<<b.c_str()<<"/"<<a.c_str();
    REQUIRE(std::strcmp(a.c_str(),b.c_str())==0);

}

#endif
