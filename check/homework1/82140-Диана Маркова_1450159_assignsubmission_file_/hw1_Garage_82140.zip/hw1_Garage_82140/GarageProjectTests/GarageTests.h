#ifndef GARAGETESTS_H
#define GARAGETESTS_H

#include "catch2.hpp"
#include "../GarageProject/Vehicle.h"
#include "../GarageProject/MyString.h"
#include "../GarageProject/Garage.h"
#include "../GarageProject/VehicleAllocator.h"
#include <stdexcept>
#include <iostream>


TEST_CASE("Constructor works properly", "[Garage]")
{
    SECTION("Testing normal constructor")
     {
        Garage g(5);
        REQUIRE(g.size()==0);
     }
        //REQUIRE((g.getCapacity()==5&&g.getOccupied()==0&&g.size()==0&&g.getCurrentSize()==addMem));
}

///Find and insert are tested simultaneously

TEST_CASE("Testing insert", "[Garage]")
{
    Garage g1(0);
//std::cout<<g1.size()<<std::endl;
    //In this test, addMem has been previously set to 10
    Vehicle v1("someReg1", "someDescrpt1", 5);
    Vehicle v2("someReg2", "someDescrpt2", 5);
    Vehicle v3("someReg3", "someDescrpt3", 5);
    Vehicle v4("someReg4", "someDescrpt4", 5);
    Vehicle v5("someReg5", "someDescrpt5", 5);
    Vehicle v6("someReg6", "someDescrpt6", 5);
    Vehicle v7("someReg6", "someDescrpt6", 5);
    Vehicle v8("someReg8", "someDescrpt8", 5);
    Vehicle v9("someReg9", "someDescrpt9", 5);
    Vehicle v10("someReg10", "someDescrpt10", 5);
    Vehicle v11("someReg11", "someDescrpt11", 5);
    Vehicle v12("someReg12", "someDescrpt12", 5);
    SECTION("Testing case where capacity is too small")
    {
        REQUIRE_THROWS_AS(g1.insert(v1), std::overflow_error);
    }
    SECTION("Testing case where a vehicle with the same registration is already in the garage(array)")
    {
        Garage g2(35);
        g2.insert(v1);
        g2.insert(v2);
        g2.insert(v3);
        g2.insert(v4);
        g2.insert(v5);
        g2.insert(v6);
//g2.insert(v7);
//std::cout<<v6.registration()<<std::endl;
//std::cout<<v7.registration()<<std::endl;
//std::cout<<g2<<std::endl;
       REQUIRE_THROWS_AS(g2.insert(v7), std::invalid_argument);
    }

    SECTION("Testing case where no problems should occur")
    ///except for potential bad_alloc error, but it is negligible
    {
        Garage g3(35);
        REQUIRE_NOTHROW(g3.insert(v1));
        REQUIRE_NOTHROW(g3.insert(v2));
        REQUIRE_NOTHROW(g3.insert(v3));
        REQUIRE_NOTHROW(g3.insert(v4));
        REQUIRE_NOTHROW(g3.insert(v5));
        REQUIRE_NOTHROW(g3.insert(v6));
        REQUIRE_NOTHROW(g3.insert(v8));
    }
    ///Mind that addMem here is 10
    SECTION("Testing case where expansion is meant to happen")
    {
        Garage g4(55);
        g4.insert(v1);
        g4.insert(v2);
        g4.insert(v3);
        g4.insert(v4);
        g4.insert(v5);
        g4.insert(v6);
        g4.insert(v8);
        g4.insert(v9);
        g4.insert(v10);
        g4.insert(v11);
//        std::size_t preExpansion=g4.getCurrentSize();
//std::cout<<g4<<std::endl;
        g4.insert(v12);
//std::cout<<g4<<std::endl;
        REQUIRE(g4.size()==11);

        SECTION("Testing out edge capacity case")
    {
        Garage g1(5);
        Vehicle v1("someReg1", "someDescrpt1", 5);
        REQUIRE_NOTHROW(g1.insert(v1));

    }
        //REQUIRE((g4.getCapacity()==55&&g4.getOccupied()==55&&g4.size()==11&&g4.getCurrentSize()==addMem+1+preExpansion));
//g4.printVehicles();
//std::cout<<g1<<std::endl;
//g1.printVehicles();
    }
    /*
    SECTION("Testing case where bad_alloc should be thrown")
    {
        Garage g1(2'147'483);
        Vehicle v1("smth", "smth", 2'147'483);
        REQUIRE_THROWS_AS(g1.insert(v1), std::bad_alloc);
    }
    ///?disfunctional
    */
}

TEST_CASE("Access to vehicles works properly", "[Garage]")
{
    Vehicle v1("someReg1", "someDescrpt1", 5);
    Vehicle v2("someReg2", "someDescrpt2", 5);
    Vehicle v3("someReg3", "someDescrpt3", 5);
    Vehicle v4("someReg4", "someDescrpt4", 5);
    Vehicle v5("someReg5", "someDescrpt5", 5);
    Vehicle v6("someReg6", "someDescrpt6", 5);
    Vehicle v8("someReg8", "someDescrpt8", 5);
    Vehicle v9("someReg9", "someDescrpt9", 5);
    Vehicle v10("someReg10", "someDescrpt10", 5);
    Vehicle v11("someReg11", "someDescrpt11", 5);
    Vehicle v12("someReg12", "someDescrpt12", 5);

    SECTION("Operator []")
    {
        Garage g4(55);
        g4.insert(v1);
        g4.insert(v2);
        g4.insert(v3);
        g4.insert(v4);
        g4.insert(v5);
        REQUIRE(g4.at(0)==v1);
        REQUIRE(g4.at(1)==v2);
        REQUIRE(g4.at(2)==v3);
        REQUIRE(g4.at(3)==v4);
        REQUIRE(g4.at(4)==v5);
        REQUIRE_THROWS(g4.at(5));
        Garage g5(0);
        REQUIRE_THROWS(g5.at(0));
    }
}

TEST_CASE("Copy constructor works properly", "[Garage]")
{
    Garage g4(55);
    Vehicle v1("someReg1", "someDescrpt1", 5);
    Vehicle v2("someReg2", "someDescrpt2", 5);
    Vehicle v3("someReg3", "someDescrpt3", 5);
    Vehicle v4("someReg4", "someDescrpt4", 5);
    Vehicle v5("someReg5", "someDescrpt5", 5);
    Vehicle v6("someReg6", "someDescrpt6", 5);
    Vehicle v7("someReg6", "someDescrpt6", 5);
    Vehicle v8("someReg8", "someDescrpt8", 5);
    Vehicle v9("someReg9", "someDescrpt9", 5);
    Vehicle v10("someReg10", "someDescrpt10", 5);
    Vehicle v11("someReg11", "someDescrpt11", 5);
    Vehicle v12("someReg12", "someDescrpt12", 5);
    g4.insert(v1);
    g4.insert(v2);
    g4.insert(v3);
    g4.insert(v4);
    g4.insert(v5);
    g4.insert(v6);
    g4.insert(v8);
    g4.insert(v9);
    g4.insert(v10);
    g4.insert(v11);
    g4.insert(v12);
//std::cout<<g4<<std::endl;
    Garage g1(g4);
//std::cout<<g1<<std::endl;
    REQUIRE(g1.size()==11);
    for(std::size_t i=0; i<g1.size(); ++i)
    {
        REQUIRE(g1.at(i)==g4.at(i));
    }
    //REQUIRE((g1.getCapacity()==55&&g1.getOccupied()==55&&g1.size()==11&&g1.getCurrentSize()==addMem+g4.size()));
}

TEST_CASE("Operator= works properly", "[Garage]")
{
    Garage g1(15);
    Vehicle v1("someReg1", "someDescrpt1", 5);
    Vehicle v2("someReg2", "someDescrpt2", 5);
    Vehicle v3("someReg3", "someDescrpt3", 5);
    g1.insert(v1);
    g1.insert(v2);
    g1.insert(v3);
    Garage g2(35);
    Vehicle v4("someReg4", "someDescrpt4", 5);
    Vehicle v5("someReg5", "someDescrpt5", 5);
    Vehicle v6("someReg6", "someDescrpt6", 5);
    Vehicle v8("someReg8", "someDescrpt8", 5);
    Vehicle v9("someReg9", "someDescrpt9", 5);
    Vehicle v10("someReg10", "someDescrpt10", 5);
    Vehicle v11("someReg11", "someDescrpt11", 5);
    g2.insert(v4);
    g2.insert(v5);
    g2.insert(v6);
    g2.insert(v8);
    g2.insert(v9);
    g2.insert(v10);
    g2.insert(v11);
    g1=g2;
    REQUIRE(g1.size()==g2.size());
    for(std::size_t i=0; i<g1.size(); ++i) REQUIRE(g1.at(i)==g2.at(i));
    //REQUIRE((g1.getCapacity()==g2.getCapacity()&&g1.getOccupied()==g2.getOccupied()&&g1.size()==g2.size()&&g1.getCurrentSize()==addMem+g2.size()));
    g1=g1;
    REQUIRE(g1.size()==g2.size());
    //REQUIRE((g1.getCapacity()==g2.getCapacity()&&g1.getOccupied()==g2.getOccupied()&&g1.size()==g2.size()&&g1.getCurrentSize()==addMem+g2.size()));
}

TEST_CASE("Clear works properly", "[Garage]")
{
    Garage g4(55);
    Garage g3(0);
    Vehicle v1("someReg1", "someDescrpt1", 5);
    Vehicle v2("someReg2", "someDescrpt2", 5);
    Vehicle v3("someReg3", "someDescrpt3", 5);
    Vehicle v4("someReg4", "someDescrpt4", 5);
    Vehicle v5("someReg5", "someDescrpt5", 5);
    Vehicle v6("someReg6", "someDescrpt6", 5);
    Vehicle v7("someReg6", "someDescrpt6", 5);
    Vehicle v8("someReg8", "someDescrpt8", 5);
    Vehicle v9("someReg9", "someDescrpt9", 5);
    Vehicle v10("someReg10", "someDescrpt10", 5);
    Vehicle v11("someReg11", "someDescrpt11", 5);
    Vehicle v12("someReg12", "someDescrpt12", 5);
    Vehicle v13("someReg13", "someDescrpt13", 5);
    g4.insert(v1);
    g4.insert(v2);
    g4.insert(v3);
    g4.insert(v4);
    g4.insert(v5);
    g4.insert(v6);
    g4.insert(v8);
    g4.insert(v9);
    g4.insert(v10);
    g4.insert(v11);
    g4.insert(v12);
    REQUIRE_NOTHROW(g4.clear());
    REQUIRE(g4.size()==0);
    REQUIRE_NOTHROW(g3.clear());
    REQUIRE(g3.size()==0);
}

TEST_CASE("Erase works properly", "[Garage]")
{
    Garage g4(55);
    Garage g5(55);
    Vehicle v1("someReg1", "someDescrpt1", 5);
    Vehicle v2("someReg2", "someDescrpt2", 5);
    Vehicle v3("someReg3", "someDescrpt3", 5);
    Vehicle v4("someReg4", "someDescrpt4", 5);
    Vehicle v5("someReg5", "someDescrpt5", 5);
    Vehicle v6("someReg6", "someDescrpt6", 5);
    Vehicle v7("someReg6", "someDescrpt6", 5);
    Vehicle v8("someReg8", "someDescrpt8", 5);
    Vehicle v9("someReg9", "someDescrpt9", 5);
    Vehicle v10("someReg10", "someDescrpt10", 5);
    Vehicle v11("someReg11", "someDescrpt11", 5);
    Vehicle v12("someReg12", "someDescrpt12", 5);
    Vehicle v13("someReg13", "someDescrpt13", 5);
    g4.insert(v1);
    g4.insert(v2);
    g4.insert(v3);
    g4.insert(v4);
    g4.insert(v5);
    g4.insert(v6);
    g4.insert(v8);
    g4.insert(v9);
    g4.insert(v10);
    g4.insert(v11);
    g4.insert(v12);

    g5.insert(v12);
    g5.insert(v2);
    g5.insert(v3);
    g5.insert(v4);
    g5.insert(v5);
    g5.insert(v6);
    g5.insert(v8);
    g5.insert(v9);
    g5.insert(v10);
    g5.insert(v11);
   // std::size_t preErasure=g4.getCurrentSize();
    REQUIRE_NOTHROW(g4.erase(v13.registration()));
    REQUIRE(g4.size()==11);
    //REQUIRE((g4.getCapacity()==55&&g4.getOccupied()==55&&g4.size()==11&&g4.getCurrentSize()==preErasure));
    REQUIRE_NOTHROW(g4.erase(v1.registration()));
    REQUIRE(g4.size()==g5.size());
    for(std::size_t i=0; i<g4.size(); ++i) REQUIRE(g4.at(i)==g5.at(i));
    //REQUIRE((g4.getCapacity()==55&&g4.getOccupied()==55-v1.space()&&g4.size()==10&&g4.getCurrentSize()==preErasure));
}

std::size_t testSpace(std::size_t i){return 5*i+107;}

Vehicle generateVehicle(std::size_t i, bool unique=true)
{
    MyString reg("Test registration");
    MyString des("Test description");
    if(unique) des[0]=reg[0]='0'+i/10;
    des[1]=reg[1]='0'+i%10;///just so descriptions are different too
    const std::size_t space=testSpace(i);
    //std::cout<<reg.c_str()<<'\n'<<des.c_str()<<std::endl;
    return Vehicle(reg.c_str(), des.c_str(), space);
}

TEST_CASE("Garage can store 100 different vehicles", "[Garage]")
{
    VehicleAllocator va;
    Garage garage(1000000);
    //REQUIRE(garage.getOccupied()==0);
    std::size_t checkTotalOccupied=0;
    for(std::size_t i=0; i<100; ++i)
    {
        Vehicle v=generateVehicle(i, true);
        //std::cout<<v<<std::endl;
        //std::cout<<*(garage.find(v.registration()));
        garage.insert(*va.allocate(v.registration(), v.description(), v.space()));
        checkTotalOccupied+=testSpace(i);
        //REQUIRE (garage.getOccupied()==checkTotalOccupied);
    }
}

TEST_CASE("Garage doesn't allow storing of duplicates", "[Garage]")
{
    VehicleAllocator va;
    Garage garage(1000000);
    //REQUIRE(garage.getOccupied()==0);
    std::size_t checkTotalOccupied=0;
    for(std::size_t i=0; i<100; ++i)
    {
        Vehicle v=generateVehicle(i, false);
        //std::cout<<v<<std::endl;
        //std::cout<<*(garage.find(v.registration()));
        try{garage.insert(*va.allocate(v.registration(), v.description(), v.space()));}
        catch(std::invalid_argument)
        {}
        if(i<10) checkTotalOccupied+=testSpace(i);
        //REQUIRE (garage.getOccupied()==checkTotalOccupied);
    }

}


#endif // GARAGETESTS_H
