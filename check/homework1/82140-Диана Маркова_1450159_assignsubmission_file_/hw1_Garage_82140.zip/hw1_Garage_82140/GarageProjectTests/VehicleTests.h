#ifndef VEHICLETESTS_H
#define VEHICLETESTS_H

#include "catch2.hpp"
#include "../GarageProject/MyString.h"
#include "../GarageProject/Vehicle.h"
#include <cstddef>
#include <cstring>

bool operator==(const Vehicle& v1, const Vehicle& other)
{
    return(std::strcmp(v1.registration(), other.registration())==0
           &&std::strcmp(v1.description(), other.description())==0
           &&v1.space()==other.space());
}

bool operator!=(const Vehicle& v1, const Vehicle& other)
{
    return !(v1==other);
}

///The test tests all methods
TEST_CASE("Testing vehicle", "[Vehicle]")
{
    SECTION("Constructor initializes  members correctly")
    {
        Vehicle v("aVehicle", "Some type of a vehicle", 10);
        REQUIRE((std::strcmp(v.registration(), "aVehicle")==0
                 &&std::strcmp(v.description(), "Some type of a vehicle")==0&&v.space()==10));
        //Sharing when construction happens is avoided, because MyString follows Big 4
        char reg1[100]="someReg";
        char des1[100]="someDes";
        std::size_t sz1=10;
        char reg2[100]="someReg2";
        char des2[100]="someDes2";
        std::size_t sz2=11;

        char reg[100]="";
        char des[100]="";
        std::size_t sz=sz1;

        std::strcpy(reg, reg1);
        std::strcpy(des, des1);

        Vehicle v1(reg, des, sz);

        std::strcpy(reg, reg2);
        std::strcpy(des, des2);
        sz=sz2;
        REQUIRE(std::strcmp(v1.registration(), reg1)==0);
        REQUIRE(std::strcmp(v1.description(), des1)==0);
        REQUIRE(v1.space()==sz1);
    }

    SECTION("Copying is correctly done and no members are shared")
    {
        char reg[100]="someReg";
        char des[100]="someDes";
        std::size_t sz=10;
        const Vehicle* v1=new Vehicle(reg, des, sz);
        const Vehicle v2=*v1;
        REQUIRE(*v1==v2);
        REQUIRE(v1->registration()!=v2.registration());
        REQUIRE(v1->description()!=v2.description());
        delete v1;
    }

    SECTION("Assignment is done correctly and no memory is shared")
    {
        char reg1[100]="someReg";
        char des1[100]="someDes";
        std::size_t sz1=10;
        char reg2[100]="someReg2";
        char des2[100]="someDes2";
        std::size_t sz2=11;

        char reg[100]="";
        char des[100]="";
        std::size_t sz=sz1;

        std::strcpy(reg, reg1);
        std::strcpy(des, des1);

        const Vehicle* v1=new Vehicle (reg, des, sz);
        Vehicle v2(reg2, des2, sz2);
        v2=*v1;
        REQUIRE(v2==*v1);
        REQUIRE(v1->registration()!=v2.registration());
        REQUIRE(v1->description()!=v2.description());
        delete v1;
    }

}



#endif
