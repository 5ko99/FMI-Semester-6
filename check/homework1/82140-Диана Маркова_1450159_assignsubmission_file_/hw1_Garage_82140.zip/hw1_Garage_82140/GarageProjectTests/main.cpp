#define CATCH_CONFIG_MAIN
#include "MyStringTests.h"
#include "VehicleTests.h"//Order matters here
#include "GarageTests.h"
#include "VehicleAllocatorTests.h"
