#ifndef VEHICLEALLOCATORTESTS_H
#define VEHICLEALLOCATORTESTS_H
#include "../GarageProject/Vehicle.h"
#include "../GarageProject/VehicleAllocator.h"
#include <cstring>
#include <cstddef>

TEST_CASE("Testing basic insert method and creation", "[VehicleAllocator]")
{
    VehicleAllocator va1;
    va1.allocate("someReg", "someDescrpt", 5);
    REQUIRE(std::strcmp((va1.getVehiclesArr()[0])->registration(), "someReg")==0);
    REQUIRE(std::strcmp((va1.getVehiclesArr()[0])->description(), "someDescrpt")==0);
    REQUIRE((va1.getVehiclesArr()[0])->space()== 5);
}

TEST_CASE("Insertion and creation works properly")
{
    VehicleAllocator va1;
    Vehicle exmp("someReg", "someDescrpt", 5);
    for(std::size_t i=0; i<10000; ++i)
    {
        va1.allocate("someReg", "someDescrpt", 5);
    }
    for(std::size_t i=0; i<10000; ++i)
    {
        REQUIRE(*va1.getVehiclesArr()[i]==exmp);
    }
}

#endif
