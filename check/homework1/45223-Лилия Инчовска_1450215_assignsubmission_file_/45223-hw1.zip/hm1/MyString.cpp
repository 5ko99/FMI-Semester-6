#include "MyString.h"
#include <cstring>
#include <cassert>

MyString::MyString() {
    str = new char[1];
    str[0] = '\0';
    strSize = used = 0;
}

MyString::MyString(const char* str) {
    strSize = strlen(str) + 1;
    this->str = new char[strSize];
    used = strSize - 1;
    strcpy(this->str, str);
}

MyString::MyString(const MyString& str1) {
    strSize = str1.strSize;
    used = str1.used;
    str = new char[strSize];
    strncpy(str, str1.str, strSize);
}

MyString::~MyString() {delete str;}

char& MyString::at(std::size_t pos) {
    assert(pos > 0);
    assert(pos <= used);
    try {
        if(pos < used && pos >= 0) {
                return str[pos];
        }
        else {
            throw std::out_of_range("Out of Range");
        }

    } catch(const std::out_of_range& e) {
        std::cerr << "Error: "
                  <<  e.what() << '\n';
    }
}

const char& MyString::at(std::size_t pos) const {
    assert(pos > 0);
    assert(pos <= used);
    try {
        if(pos < used && pos >= 0) {
                return str[pos];
        }
        else {
            throw std::out_of_range("Out of Range");
        }

    } catch(const std::out_of_range& e) {
        std::cerr << "Error: "
                  <<  e.what() << '\n';
    }
}

char& MyString::operator[](std::size_t pos) {
    assert(pos <= used);
    assert(pos >= 0);
    assert(pos < strSize);
    try {
        return str[pos];
    } catch(const std::out_of_range& e) {
        std::cerr << "Error: "
                  <<  e.what()
                  << '\n';
    }
}

const char& MyString::operator[](std::size_t pos) const {
    assert(pos <= used);
    assert(pos >= 0);
    assert(pos < strSize);
    try {
        return str[pos];
    } catch(const std::out_of_range& e) {
        std::cerr << "Error: "
                  <<  e.what()
                  << '\n';
    }
}

char& MyString::front() {
    assert(str != nullptr);
    return str[0];
}

const char& MyString::front() const {
    assert(str != nullptr);
    return str[0];
}

char& MyString::back() {
    assert(str != nullptr);
    return str[used - 1];
}

const char& MyString::back() const {
    assert(str != nullptr);
    return str[used - 1];
}

bool MyString::empty() const {
    return used == 0;
}

std::size_t MyString::size() const {
    return used;
}

void MyString::clear() {
    if(str != nullptr)
            str[0] = '\0';
    used = 0;
}

void MyString::increaseSize(std::size_t newSize) {
    assert(str != nullptr);
    assert(strSize < newSize);
    try {
        char* biggerStr = new char[newSize];
        strncpy(biggerStr, str, strSize);
        delete[] str;
        str = biggerStr;
        strSize = newSize;
    } catch(const std::bad_alloc& e) {
        std::cerr << "Error: "
                  <<  e.what()
                  << '\n';
    }
}

void MyString::push_back(char c) {
    assert(str != nullptr);
    if(strSize == 0)
        increaseSize(2);
    else if(strSize - used > 0) increaseSize(2*strSize + used);

    str[used] = c;
    used++;
}

void MyString::pop_back() {
    assert(str != nullptr);
    str[used-1] = '\0';
    used--;
}

char* MyString::getString() const {
    return str;
}

MyString& MyString::operator+=(char c) {
    push_back(c);

    return *this;
}

MyString& MyString::operator+=(const MyString& rhs) {
    if(this->strSize - this->used <= rhs.used) increaseSize(this->used + rhs.used + 1);
    strncpy(this->str + this->used, rhs.str, rhs.used);
    this->used += rhs.used;

    return *this;
}

MyString MyString::operator+(char c) const {
    try {
        std::size_t newSize;
        if(strSize - used > 1)
            newSize = strSize;
        else newSize = 2 * strSize;

        char* cpyStr = new char[newSize];
        strncpy(cpyStr, str, strSize);
        cpyStr[used] = c;
        cpyStr[used + 1] = '\0';
        MyString result(cpyStr);

        return result;
    } catch(const std::bad_alloc& e) {
        std::cerr << "Error: "
                  <<  e.what()
                  << '\n';
    }
}

MyString MyString::operator+(const MyString& rhs) const {
    try {
        std::size_t newSize;
        if(strSize - used > rhs.used)
            newSize = strSize;
        else newSize = strSize + rhs.used;

        char* cpyStr = new char[newSize];
        strncpy(cpyStr, str, strSize);
        strncpy(cpyStr + used, rhs.str, rhs.used);
        MyString result(cpyStr);

        return result;
    } catch(const std::bad_alloc& e) {
        std::cerr << "Error: "
                  <<  e.what()
                  << '\n';
    }
}

const char* MyString::c_str() const {
    std::size_t length = this->used + 1;
    char* str1 = new char[length];
    for (std::size_t i = 0; i < length; ++i)
            str1[i] = this->str[i];

    str1[length] = '\0';

    return str1;
}

bool MyString::operator==(const MyString &rhs) const {
    if(this->used != rhs.used)
        return false;

    for(size_t i = 0; i < this->used; ++i) {
        if(this->str[i] != rhs.str[i])
            return false;
    }

    return true;
}

bool MyString::operator<(const MyString &rhs) const {
    if(*this == rhs)
        return false;
    for(size_t i = 0; i < this->used && i < rhs.used; ++i) {
        if(this->str[i] > rhs.str[i])
            return false;
        }

    return true;
}
