#include <iostream>
#include <cstring>
#include "MyString.h"
#include "Vehicle.h"
#include "Garage.h"

int main() {
    Garage g(7);
    Vehicle v1("QVE123", "car", 1);
    Vehicle v2("TRLO32", "bus", 3);
    Vehicle v3("FRPL43", "bus", 3);
    g.insert(v1);
    g.insert(v2);
    g.insert(v3);

    std::cout << "All vehicles in the garage: " << std::endl;
    for (std::size_t i = 0; i < g.size(); ++i) {
        std::cout << g[i].registration() << " " << g[i].description() << " " << g[i].space() << std::endl;
    }
    std::cout << "Size: " << g.size() << std::endl;

    g.erase("TRLO32");
    for (std::size_t i = 0; i < g.size(); ++i) {
        std::cout << g[i].registration() << " " << g[i].description() << " " << g[i].space() << std::endl;
    }
    std::cout << "Size: " << g.size() << std::endl;

    Vehicle v4("RIP000", "big bus", 4);
    g.insert(v4);

//    std::size_t capacity = 1;
//    std::cout << "Enter the garage's capacity" << std::endl;
//    do {
//        std::cout << "Please, choose a value between 1 and 65534: ";
//        std::cin >> capacity;
//    } while(capacity <= 0 || capacity >= 65535);
//
//    Garage garage(capacity);
//
//    char action;
//    std::cout << "Actions: " << std::endl;
//    std::cout << "\t1 - adding a vehicle in the garage\n"
//              << "\t2 - removing a vehicle from the garage\n"
//              << "\t3 - displaying information about all vehicles in the garage\n"
//              << "\t4 - exiting the program\n";
//
//    do {
//        std::cout << "Please, select an action: ";
//        std::cin >> action;
//
//        switch(action) {
//            case '1':{
//
//                break;
//            }
//            case '2': {
//
//                break;
//            }
//            case '3': {
//
//                break;
//            }
//        }
//    } while(action != '4');

    return 0;
}
