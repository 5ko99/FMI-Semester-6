#pragma once

#include <iostream>
#include "Vehicle.h"

class Garage {
    private:
        Vehicle* vehicles;
        std::size_t cnt_vehicles;
        std::size_t used;
        std::size_t capacity;

        //void free();
        void copy(const Garage&);
        //void resize(std::size_t size);
        std::size_t findIndex(const char* registration) const;

        public:
        Garage(std::size_t size);

        // copy constructor
        Garage(const Garage&);

        // destructor - NOT WORKING
        //~Garage();

        //copy assignment operator
        Garage& operator=(const Garage&);

        void insert(Vehicle& v);

        bool empty() const;

        std::size_t size() const;

        void clear();

        const Vehicle& at(std::size_t pos) const;

        const Vehicle& operator[](std::size_t pos) const;

        const Vehicle* find(const char* registration) const;

        void erase(const char* registration);
};
