#pragma once

#include <iostream>
#include "MyString.h"
#include <string.h>

class Vehicle {
  private:
      MyString serialNnumber;
      MyString information;
      std::size_t parkingSlotSpace;

  public:
      Vehicle(const char* registration = "", const char* description = "", std::size_t space = 0);

      const char* registration() const;

      const char* description() const;

      std::size_t space() const;
};
