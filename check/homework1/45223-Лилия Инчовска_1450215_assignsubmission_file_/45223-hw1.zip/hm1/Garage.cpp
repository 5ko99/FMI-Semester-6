#include <iostream>
#include <cassert>

#include "Garage.h"
#include "Vehicle.h"

Garage::Garage(std::size_t size): cnt_vehicles(0) , capacity(size), used(0) {
    vehicles = new Vehicle[capacity];
}

//Garage::~Garage() {delete[] vehicles;}

void Garage::copy(const Garage& rhs) {
	if(rhs.capacity == 0) return;

	vehicles = new Vehicle[rhs.capacity];
	for(std::size_t i = 0; i < rhs.cnt_vehicles; ++i) 	{
		vehicles[i] = rhs.vehicles[i];
	}
	cnt_vehicles = rhs.cnt_vehicles;
	capacity = rhs.capacity;
	used = rhs.used;
}

Garage::Garage(const Garage& rhs): vehicles(nullptr), cnt_vehicles(0) , capacity(0), used(0) {
    copy(rhs);
}

//copy assignment operator
Garage& Garage::operator=(const Garage& rhs) {
    if(this != & rhs) {
		delete[] vehicles;
		copy(rhs);
	}
	return *this;
}

//void Garage::resize(std::size_t new_capacity) {
//	assert(cnt_vehicles < new_capacity);
//	Vehicle* buffer = new Vehicle[new_capacity];
//	for(std::size_t i = 0; i < cnt_vehicles; ++i) {
//		buffer[i] = vehicles[i];
//	}
//	delete[] vehicles;
//	vehicles = buffer;
//	capacity = new_capacity;
//}

void Garage::insert(Vehicle& v) {
    try {
        if(v.space() > capacity - used)
            throw std::length_error("No available space");
        if(findIndex(v.registration()) != -1)
            throw std::invalid_argument("A vehicle with this serial number is already in the garage!");
        else {
            used += v.space();
            vehicles[cnt_vehicles++] = v;
        }
    } catch(const std::length_error& e) {
        std::cerr << "Error: "
                  <<  e.what() << '\n';
    } catch(const std::invalid_argument& e) {
        std::cerr << "Error: "
                  <<  e.what() << '\n';
    }
}

std::size_t Garage::size() const {
    return this->cnt_vehicles;
}

bool Garage::empty() const {
    return cnt_vehicles ? false : true;
}

void Garage::clear() {
    delete[] vehicles;
    vehicles = new Vehicle[capacity];
    cnt_vehicles = used = 0;
}

const Vehicle& Garage::at(std::size_t pos) const {
    assert(pos >= 0);
    assert(pos <= capacity);
    try {
        if(pos < used && pos >= 0) {
                return this->vehicles[pos];
        }
        else {
            throw std::out_of_range("Out of Range");
        }

    } catch(const std::out_of_range& e) {
        std::cerr << "Error: "
                  <<  e.what() << '\n';
    }
}

const Vehicle& Garage::operator[](std::size_t pos) const {
    assert(pos <= used);
    assert(pos >= 0);
    assert(pos < capacity);
    try {
        return this->vehicles[pos];
    } catch(const std::out_of_range& e) {
        std::cerr << "Error: "
                  <<  e.what()
                  << '\n';
    }
}

std::size_t Garage::findIndex(const char* registration) const {
    for (std::size_t i = 0; i < cnt_vehicles; ++i) {
        if (strlen(vehicles[i].registration()) == strlen(registration)) {
            for (std::size_t j = 0; j < strlen(registration); ++j) {
                if (vehicles[i].registration()[j] != registration[j]) {
                    break;
                } else if (j == strlen(registration) - 1) {
                    return i;
                }
            }
        }
    }
    return -1;
}

const Vehicle* Garage::find(const char* registration) const {
    std::size_t index = findIndex(registration);
    std::cout << index;
    if (index == -1)
        return nullptr;

    const Vehicle v(vehicles[index].registration(), vehicles[index].description(), vehicles[index].space());
    std::cout << v.description();
    return &v;
}

void Garage::erase(const char* registration) {
    assert(cnt_vehicles != 0);

    std::size_t index = findIndex(registration);
    if(index == -1)
        return;

    used -= vehicles[index].space();
	vehicles[index] = vehicles[cnt_vehicles - 1];
	cnt_vehicles--;
}
