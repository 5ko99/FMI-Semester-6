#include "MyString.h"
#include "Vehicle.h"
#include <cstring>

Vehicle::Vehicle(const char* registration, const char* description, std::size_t space): serialNnumber(registration), information(description), parkingSlotSpace(space) { }

const char* Vehicle::registration() const {
    return serialNnumber.getString();
}

const char* Vehicle::description() const {
    return information.getString();
}

std::size_t Vehicle::space() const {
    return parkingSlotSpace;
}
