#pragma once

#include <iostream>

class MyString {
    private:
        char* str;
        std::size_t strSize;
        std::size_t used;

        void increaseSize(std::size_t newSize);


    public:
        MyString();

        MyString(const MyString&);

        MyString(const char* str);

        ~MyString();

        char& at(std::size_t pos);

        const char& at(std::size_t pos) const;

        char& operator[](std::size_t pos);

        const char& operator[](std::size_t pos) const;

        char& front();

        const char& front() const;

        char& back();

        const char& back() const;

        bool empty() const;

        std::size_t size() const;

        void clear();

        void push_back(char c);

        void pop_back();

        char* getString() const;

        MyString& operator+=(char c);

        MyString& operator+=(const MyString& rhs);

        MyString operator+(char c) const;

        MyString operator+(const MyString& rhs) const;

        const char* c_str() const;

        bool operator==(const MyString &rhs) const;

        bool operator<(const MyString &rhs) const;
};


