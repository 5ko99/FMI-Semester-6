#include "MyString.h"
#include <exception>
#include <string.h>
size_t size_of(const char* str)
{
    if(str == nullptr) return 0;
    char i=str[0];
    int counter=0;
    while (i!='\0')
    {
        counter++;
        i=str[counter];
    }
    return counter;
}
void swap(MyString& first,MyString& second)
{
    using std::swap;

    swap(first.size,second.size);
    swap(first.str,second.str);
    //std::cout<<first.str;
}

char* MyString::give_str() const {return this->str;}

MyString::MyString()
{
    this->str=nullptr;
    this->size=0;
}
MyString::MyString(const MyString& other)
{
    this->str=new char[other.size+1];
    this->size=other.size;
    strcpy(this->str,other.str);
}

MyString::~MyString()
{
    delete [] str;
}
MyString& MyString::operator=(const MyString& other){
    MyString temp(other);
    swap(*this,temp);

    return *this;
}
MyString& MyString::operator=(const char* other){
    delete [] str;
    this->str=new char[size_of(other)+1];
    this->size=size_of(other);
    strcpy(this->str,other);

    return *this;
}
MyString::MyString(const char* other)
{
    this->str=new char[size_of(other)+1];
    this->size=size_of(other);
    strcpy(this->str,other);
}
char& MyString::at(std::size_t pos)
{
    if (pos >= size_of(this->str)) throw std::out_of_range("No element");
    else return this->str[pos];
}
const char& MyString::at(std::size_t pos) const
{
    if (pos >= size_of(this->str)) throw std::out_of_range("No element");
    return this->str[pos];
}
char& MyString::operator[](const size_t pos) {return this->str[pos];}

const char& MyString::operator[](std::size_t pos) const {return this->str[pos];}

char& MyString::front(){return this->str[0];}

const char& MyString::front() const{return this->str[0];}

char& MyString::back() {return this->str[size-1];}

const char& MyString::back() const {return this->str[size-1];}



size_t MyString::size_() const {return this->size;}

void MyString::clear(){
    delete[] str;
    this->str = nullptr;
    this->size= 0;
}

void MyString::push_back(char c)
{
    char* temp=new char[strlen(this->str)+1];
    strcpy(temp,this->str);
    delete [] str;
    this->size=size+1;
    this->str=new char[this->size+1];
    for(int i=0;i<strlen(temp);i++)this->str[i]=temp[i];
    this->str[this->size-1]=c;
    this->str[this->size]='\0';

    delete [] temp;

}
void MyString::pop_back()
{
    char *temp=new char[size_of(str)+1];
    strcpy(temp,this->str);
    delete [] str;
    this->size=size-1;
    this->str=new char[this->size+1];
    for(int i=0;i<strlen(temp)-1;i++)this->str[i]=temp[i];
    this->str[size]='\0';

    delete [] temp;


}
void MyString::print() const
{
    for (int i=0;i<this->size;i++)
    {
        std::cout<<this->str[i];
    }
    std::cout<<std::endl;
}
MyString& MyString:: operator+=(char c){
    this->push_back(c);
    return *this;
}
MyString& MyString::operator+=(const MyString& rhs){

    char*temp=new char[this->size+1];
    char*temp2=new char[rhs.size+1];

    strcpy(temp,this->str);
    strcpy(temp2,rhs.str);

    delete [] this->str;
    size_t length=this->size;
    this->size=rhs.size+size;
    this->str=new char[this->size+1];

    for(int i=0;i<length;i++){
        this->str[i]=temp[i];
        if(i==length-1) {
            for (int j = 0; j < rhs.size; j++) {
                i++;
                this->str[i] = temp2[j];
            }
        }
    }

    this->str[size]='\0';

    delete [] temp;
    delete [] temp2;

    return *this;
}
MyString MyString::operator+(char c) const
{
    MyString new_str;
    new_str=this->str;
    new_str+=c;

    return new_str;
}
MyString MyString::operator+(const MyString &rhs) const
{
    MyString new_str;
    new_str=this->str;
    new_str+=rhs;

    return new_str;
}
const char* MyString::c_str() const{
    char* new_str=new char[this->size+1];
    strcpy(new_str,this->str);

    return new_str;
}
bool MyString::operator==(const MyString &rhs) const
{
    int counter=0;
    for(int i=0;i<this->size;i++)
    {
        if(str[i]==rhs.str[i])counter++;
    }
    if(counter==this->size && rhs.size==this->size)return 1;
    else return 0;
}
bool MyString::operator<(const MyString &rhs) const
{
    return size_of(this->str)<size_of(rhs.str);
}
bool MyString::operator==(const char* rhs) const
{
    int counter=0;
    for(int i=0;i<this->size;i++)
    {
        if(str[i]==rhs[i])counter++;
    }
    if(counter==this->size && size_of(rhs)==this->size)return 1;
    else return 0;
}
bool MyString::empty() {
    if (str==nullptr || strcmp(str,"")) return true;
    else return false;
}