#ifndef DOMASHNAOOP2021_VEHICLE_H
#define DOMASHNAOOP2021_VEHICLE_H
#include "MyString.h"

class Vehicle {
private:
    MyString registration;
    MyString description;
    std::size_t space;
public:
//    Vehicle();
    Vehicle(const char* registration, const char* description, std::size_t space);
    const MyString& get_registration() const;
    const MyString& get_description() const;
    std::size_t get_space() const;
};


#endif //DOMASHNAOOP2021_VEHICLE_H
