//#include <iostream>
#include "MyString.h"
#include "Vehicle.h"
#include "Garage.h"

Vehicle pejo("SA 1234","pejo",2);
Vehicle ferari("A 2222","ferari",3);
Vehicle shkodich("A 9224","shkodich",2);
Vehicle opel("A 1111","opel",1);

void insert(Garage& gr,Vehicle& v)
{
    gr.insert(v);
}
void remove(Garage& gr,Vehicle& v){
    gr.erase(v.get_registration().give_str());
}
void print_cars(Garage& gr)
{
    gr.print();
}
void list_cars()
{
    std::cout<<"1. Peugeot: "<<"registration-["<<pejo.get_registration().give_str()<<"] description-["<<pejo.get_description().give_str()<<"] space-["<<pejo.get_space()<<"]"<<std::endl;
    std::cout<<"2. Ferrari: "<<"registration-["<<ferari.get_registration().give_str()<<"] description-["<<ferari.get_description().give_str()<<"] space-["<<ferari.get_space()<<"]"<<std::endl;
    std::cout<<"3. Skoda: "<<"registration-["<<shkodich.get_registration().give_str()<<"] description-["<<shkodich.get_description().give_str()<<"] space-["<<shkodich.get_space()<<"]"<<std::endl;
    std::cout<<"4. Opel: "<<"registration-["<<opel.get_registration().give_str()<<"] description-["<<opel.get_description().give_str()<<"] space-["<<opel.get_space()<<"]"<<std::endl;
    std::cout<<"5. Exit\n";
}
void options_1(){
    std::cout<<"1. Create garage"<<std::endl;
    std::cout<<"2. Exit"<<std::endl;
}
void options_2()
{
    std::cout<<"1. Insert car"<<std::endl;
    std::cout<<"2. Remove car"<<std::endl;
    std::cout<<"3. Show cars"<<std::endl;
    std::cout<<"4. Exit"<<std::endl;
}
void options_3()
{
    int option=0;
    size_t size;
    std::cout<<"Enter the size for your garage: ";std::cin>>size;
    Garage gr(size);
    while (option!=4)
    {
        options_2();
        std::cin>>option;
        if(option==1)//insert car
        {
            int car_option=0;
            list_cars();
            while (car_option<1 || car_option>4) {
                std::cin>>car_option;
                if (car_option == 1) {
                    try {
                        insert(gr, pejo);
                    }
                    catch (std::out_of_range&) {
                        std::cout<<"Car with same registration is in the garage or there is no space for the selected car\n";
                        car_option=0;
                    }
                    if(car_option==1)break;
                }
                if (car_option == 2) {
                    try {
                        insert(gr, ferari);
                    }
                    catch (std::out_of_range&) {
                        std::cout<<"Car with same registration is in the garage or there is no space for the selected car\n";
                        car_option=0;
                    }
                    if(car_option==2)break;
                }
                if (car_option == 3) {
                    try {
                        insert(gr, shkodich);
                    }
                    catch (std::out_of_range&) {
                        std::cout<<"Car with same registration is in the garage or there is no space for the selected car\n";
                        car_option=0;
                    }
                    if(car_option==3)break;
                }
                if (car_option == 4) {
                    try {
                        insert(gr, opel);
                    }
                    catch (std::out_of_range&) {
                        std::cout<<"Car with same registration is in the garage or there is no space for the selected car\n";
                        car_option=0;
                    }
                    if(car_option==4)break;
                }
                if(car_option==5)break;
                if(car_option<1 || car_option>4)std::cout<<"Enter number between 1 and 4 or pres 5 for exit\n";
            }
        }else if(option==2)//remove car
        {
            char reg[20];
            std::cout<<"Enter registration of the vehicle you want to remove\n";
            std::cin.ignore();
            std::cin.getline(reg,19);
            gr.erase(reg);
        }
        else if (option==3)//print
        {
            gr.print();
        }
        else if(option==4)
        {
            break;
        }
    }
}
void menu(){
    int number=0;
    std::cout<<"=================MY GARAGE=================\n";
    while (number != 2)
    {
        options_1();
        std::cin>>number;
        if (number==1)
        {
           options_3();
        }
        else if(number==2)break;
    }

}
int main() {
menu();
}
