#ifndef DOMASHNAOOP2021_GARAGE_H
#define DOMASHNAOOP2021_GARAGE_H
#include "Vehicle.h"

class Garage {
private:
    size_t size;//broi mesta v garaja
    Vehicle **vehicles;
    size_t vehicles_count;//broi prevozni sredstva v garaja
public:
    Garage(size_t size);
    Garage(const Garage& other);
    Garage& operator=(const Garage& other);
    ~Garage();
    int empty_spaces();
    bool unique_registration(Vehicle& v);
    void insert(Vehicle& v);
    void erase(const char* registration);
    const Vehicle& at(std::size_t pos) const;
    const Vehicle& operator[](std::size_t pos) const;
    bool empty() const;
    void clear();
    size_t size_() const;
    const Vehicle* find(const char* registration) const;
    void print();
    friend void swap(Garage& first,Garage& second);
};

#endif //DOMASHNAOOP2021_GARAGE_H
