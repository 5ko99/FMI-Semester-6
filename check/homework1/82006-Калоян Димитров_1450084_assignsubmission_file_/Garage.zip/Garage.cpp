#include "Garage.h"
#include "MyString.h"
void swap(Garage& first,Garage& second)
{
    using std::swap;

    swap(first.size,second.size);
    swap(first.vehicles,second.vehicles);
    swap(first.vehicles_count,second.vehicles_count);

}
bool compare(const char* first,const char* second)
{
    int counter=0;
    for(int i=0;i<strlen(first);i++)
    {
        if(first[i]==second[i])counter++;
    }
    if(counter==strlen(first) && strlen(first)==strlen(second)) return true;
    else return false;
}
Garage::Garage(size_t size)
{
    this->size=size;
    this->vehicles= nullptr;
    this->vehicles_count=0;
}
Garage::Garage(const Garage &other)
{
    this->size=other.size;
    this->vehicles= new Vehicle*[other.vehicles_count];
    this->vehicles_count=other.vehicles_count;

    for (int i=0;i<other.vehicles_count;i++)this->vehicles[i]=new Vehicle(other.vehicles[i]->get_registration().give_str(),other.vehicles[i]->get_description().give_str(),other.vehicles[i]->get_space());
}
Garage& Garage::operator=(const Garage &other) {
    Garage temp(other);
    swap(*this,temp);

    return *this;
}
Garage::~Garage()
{
    this->size=0;
    for(int i=0;i<vehicles_count;i++)delete vehicles[i];
    delete [] vehicles;
    this->vehicles_count=0;
}
int Garage::empty_spaces()
{
    int sum=0;
    for(int i=0;i<this->vehicles_count;i++)
    {
        if(vehicles[i]!= nullptr)
            sum+=this->vehicles[i]->get_space();
    }
    if(sum==this->size)return 0;
    else         return size-sum;
}
bool Garage::unique_registration(Vehicle &v)
{
    for(int i=0;i<vehicles_count;i++)
    {
        if (vehicles[i]->get_registration()==v.get_registration())return 0;
    }
    return 1;
}

void Garage::insert(Vehicle &v)
{
    int empty_spaces=this->empty_spaces();
    int current_v=v.get_space();
    if(empty_spaces<current_v || !unique_registration(v))
    {
        throw std::out_of_range("Garage is full");
    }
    else if (vehicles_count==0)
    {
        this->vehicles=new Vehicle *[vehicles_count+1];
        this->vehicles_count=vehicles_count+1;
        this->vehicles[vehicles_count-1]=new Vehicle(v);
    }
    else{
        Vehicle** temp=new Vehicle*[vehicles_count];
        for (int i=0;i<vehicles_count;i++)temp[i]=this->vehicles[i];
        delete [] vehicles;

        this->vehicles=new Vehicle*[vehicles_count+1];
        for (int i=0;i<vehicles_count;i++)this->vehicles[i]=temp[i];
        this->vehicles_count=vehicles_count+1;

        this->vehicles[vehicles_count-1]=new Vehicle(v);

        delete [] temp;
    }
}
void Garage::print(){
    std::cout<<"------------------------------------------------------\n";
    for(int i=0;i<vehicles_count;i++)
    {
        std::cout<<"registration-["<<vehicles[i]->get_registration().give_str()<<"] description-["<<vehicles[i]->get_description().give_str()<<"] size-["<<vehicles[i]->get_space()<<"]"<<std::endl;
    }
    std::cout<<"------------------------------------------------------\n";
}
void Garage::erase(const char *registration)
{
    for(int i=0;i<vehicles_count;i++)
    {
        if (compare(vehicles[i]->get_registration().give_str(),registration))
        {
            delete vehicles[i];
            for(int j=i;j<vehicles_count-1;j++)
            {
                vehicles[i]=vehicles[j+1];
            }
            vehicles_count--;
        }
    }
}

const Vehicle &Garage::at(std::size_t pos) const {
    if (pos<0 || pos-1>vehicles_count-1)throw std::out_of_range("Out of range");

    return *vehicles[pos-1];
}

const Vehicle &Garage::operator[](std::size_t pos) const {
    return *vehicles[pos];
}
bool Garage::empty() const
{
    if(vehicles_count==0)return true;
    else                 return false;
}
void Garage::clear(){
    for(int i=0;i<vehicles_count;i++)delete vehicles[i];
    delete [] vehicles;
    this->vehicles= nullptr;
    this->vehicles_count=0;
}
size_t Garage::size_() const
{
    return vehicles_count;
}

const Vehicle *Garage::find(const char *registration) const {
    for(int i=0;i<vehicles_count;i++)
    {
        if (compare(vehicles[i]->get_registration().give_str(),registration)) {
            return vehicles[i];
        }
    }
    return nullptr;
}
