#include "Vehicle.h"
Vehicle::Vehicle(const char* registration, const char* description, std::size_t space)
:registration(registration),description(description),space(space){}

const MyString& Vehicle::get_registration() const {return this->registration;}
const MyString& Vehicle::get_description() const  {return this->description;}
size_t Vehicle::get_space() const {return this->space;}

