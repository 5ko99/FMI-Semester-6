#ifndef DOMASHNAOOP2021_MYSTRING_H
#define DOMASHNAOOP2021_MYSTRING_H
#include <iostream>

class MyString {
private:
    char *str;
    size_t size;
public:
    MyString();
    MyString(const MyString& other);
    MyString(const char* str);
    ~MyString();
    MyString& operator=(const MyString& str);
    MyString& operator=(const char* str);
    char& operator[](const size_t pos);
    char& at(std::size_t pos);
    const char& at(std::size_t pos) const;
    const char& operator[](std::size_t pos) const;
    char& front ();
    const char& front() const;
    char& back();
    const char& back() const;
    bool empty();
    std::size_t size_() const;
    void clear();
    void push_back(char c);
    void pop_back();
    char* give_str() const;
    void print() const;
    MyString& operator+=(char c);
    MyString& operator+=(const MyString& rhs);
    MyString operator+(char c) const;
    MyString operator+(const MyString& rhs) const;
    const char* c_str() const;
    bool operator==(const MyString &rhs) const;
    bool operator==(const char* rhs) const;
    bool operator<(const MyString &rhs) const;

    friend void swap(MyString& first,MyString& second);
};
void swap(MyString& first,MyString& second);

#endif //DOMASHNAOOP2021_MYSTRING_H
