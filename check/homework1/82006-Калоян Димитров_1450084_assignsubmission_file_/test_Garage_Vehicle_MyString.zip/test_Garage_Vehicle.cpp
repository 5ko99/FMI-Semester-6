#include <iostream>
#include "../domashnaOOP2021/MyString.h"
#include "../domashnaOOP2021/Vehicle.h"
#include "../domashnaOOP2021/Garage.h"


bool testError = false;
using TestFunction= void(*)();

bool runTest(TestFunction func,const char* name)
{
    testError= true;
    std::cout<<"Running test: "<<name<<"...";
    func();
    std::cout<<(testError ? "Success!\n" : "Failed!\n");

    return testError;
}


#define TEST_CASE(name)                 \
void name();                            \
bool test_##name=runTest(name, #name);  \
void name()

#define CHECK(condition) testError = (condition)

Vehicle pejo("SA 1234","pejo",2);
Vehicle ferari("A 2222","ferari",3);
Vehicle shkodich("A 9224","shkodich",2);
Vehicle opel("A 1111","opel",1);

TEST_CASE(copy_constructor_Garage)
{
    Garage gr(5);
    gr.insert(pejo);
    gr.insert(ferari);
    Garage mr(gr); //ferari is on second position in the garage -> mr[1]=ferari
    CHECK(mr[1].get_registration()==ferari.get_registration());
}
TEST_CASE(insert)
{
    Garage gr(5);
    gr.insert(pejo);
    CHECK(gr[0].get_registration()==pejo.get_registration());
}
TEST_CASE(erase)
{
    Garage gr(5);
    gr.insert(pejo);
    gr.insert(ferari);//A 2222
    gr.erase("A 2222");
    CHECK(gr.find("A 2222")== nullptr);
}
TEST_CASE(at_pos)
{
    Garage gr(5);
    gr.insert(pejo);
    gr.insert(ferari);//A 2222
    CHECK(gr.at(2).get_registration()==ferari.get_registration());
}
TEST_CASE(brackets_operator)
{
    Garage gr(5);
    gr.insert(pejo);
    gr.insert(ferari);//A 2222
    CHECK(gr[1].get_registration()==ferari.get_registration());
}
TEST_CASE(empty)
{
    Garage gr(5);
    CHECK(gr.empty());
}
TEST_CASE(clear)
{
    Garage gr(5);
    gr.insert(pejo);
    gr.insert(ferari);//A 2222
    gr.clear();
    CHECK(gr.empty());
}
TEST_CASE(size)
{
    Garage gr(5);
    gr.insert(pejo);
    gr.insert(ferari);//A 2222
    CHECK(gr.size_()==2);
}
TEST_CASE(find)
{
    Garage gr(5);
    gr.insert(pejo);
    gr.insert(ferari);//A 2222
    CHECK(gr.find("A 2222")->get_registration()==ferari.get_registration());
}


int main() {

    return 0;
}
