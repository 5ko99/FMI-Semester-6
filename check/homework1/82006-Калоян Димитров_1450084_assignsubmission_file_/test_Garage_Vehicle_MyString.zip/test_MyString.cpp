#include <iostream>
#include "../domashnaOOP2021/MyString.h"
bool testError = false;
using TestFunction= void(*)();

bool runTest(TestFunction func,const char* name)
{
    testError= true;
    std::cout<<"Running test: "<<name<<"...";
    func();
    std::cout<<(testError ? "Success!\n" : "Failed!\n");

    return testError;
}


#define TEST_CASE(name)                 \
void name();                            \
bool test_##name=runTest(name, #name);  \
void name()

#define CHECK(condition) testError = (condition)

TEST_CASE(assigment_operator_MyString)
{
    MyString first("first");
    MyString second("second");
    first=second;
    CHECK(first=="second");
}
TEST_CASE(assigment_operator_string)
{
    MyString first("first");
    first="second";
    CHECK(first=="second");
}
TEST_CASE(brackets_for_position)
{
    MyString first("first");
    CHECK(first[2]=='r');
}
TEST_CASE(method_at)
{
    MyString first("first");
    CHECK(first.at(2)=='r');
}
TEST_CASE(first_char)
{
    MyString first("first");
    CHECK(first.front()=='f');
}
TEST_CASE(last_char)
{
    MyString first("first");
    CHECK(first.back()=='t');
}
TEST_CASE(empty)
{
    MyString first;//first==nullptr
    CHECK(first.empty());
}
TEST_CASE(size)
{
    MyString first("first");
    CHECK(first.size_()==5);
}
TEST_CASE(clear)
{
    MyString first("first");
    first.clear();
    CHECK(first==nullptr);
}
TEST_CASE(push_back)
{
    MyString first("first");
    first.push_back('F');
    CHECK(first.back()=='F');
}
TEST_CASE(pop_back)
{
    MyString first("first");
    first.pop_back();
    CHECK(first=="firs");
}
TEST_CASE(concatenate_char)
{
    MyString first("first");
    first+='F';
    CHECK(first.back()=='F');
}
TEST_CASE(concatenate_MyString)
{
    MyString first("first");
    MyString second("second");
    first+=second;
    CHECK(first=="firstsecond");
}
TEST_CASE(plus_operator_char)
{
    MyString first("first");
    CHECK(first+'F'=="firstF");
}
TEST_CASE(plus_operator_MyString)
{
    MyString first("first");
    MyString second("second");
    CHECK(first+second=="firstsecond");
}
TEST_CASE(c_str)
{
    MyString first("first");
    CHECK(first.c_str()[first.size_()]=='\0');
}
TEST_CASE(logical_equal_operator_MyString)
{
    MyString first("first");
    MyString second("second");
    CHECK(!(first==second));
}
TEST_CASE(logical_equal_operator_string)
{
    MyString first("first");
    const char* second={"sec"};
    CHECK(!(first==second));
}
TEST_CASE(logical_operator_greater)
{
    MyString first("first");
    MyString second("secondd");
    CHECK(first<second);
}


int main() {

    return 0;
}
