#pragma once
#include "Vehicle.h"
class Garage
{
public:
	Garage(std::size_t sz);//++
	~Garage() { delete[] inGarage; };//++
	void insert(Vehicle& v);//++
	void erase(const char* reg);
	const Vehicle& at(std::size_t pos) const;//++
	const Vehicle& operator[](std::size_t pos) const;//++
	bool empty() const;//++
	std::size_t size() const { return carsIn; };//+?
	void clear();//++
	const Vehicle* find(const char* reg) const;//++
	void printGarage();
	
private:
	size_t sizeG;
	std::size_t free_space;
	std::size_t carsIn;
	Vehicle** inGarage;
};