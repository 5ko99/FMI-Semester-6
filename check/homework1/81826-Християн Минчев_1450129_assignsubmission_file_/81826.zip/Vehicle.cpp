#include "Vehicle.h"
Vehicle::Vehicle(const char* r, const char* d, std::size_t s)
{
	Registration = r;
	Description = d;
	Space = s;
}
