#pragma once
#include "MyString.h"

MyString::MyString() {
	str = new char[1];
	str[0] = '\0';
	len = 0;
}
MyString::~MyString()
{
	delete[] this->str;
}
MyString::MyString(const char* input) 
{
	len = strlen(input);
	this->str = new char[len + 1];
	strcpy_s(this->str,len+1, input);
}
MyString::MyString(const MyString& from)
{
	len = from.size();
	this->str = new char[len + 1];
	strcpy_s(this->str,len+1, from.str);
};

MyString& MyString::operator=(const MyString& from)
{
	this->len = (from.len)+1;
	delete[] str;
	str = new char[len];
	for (size_t i = 0; i <= len; i++)
		str[i] = from.str[i];

	return *this;
}
char& MyString::at(std::size_t pos) {
	if (pos < 0 || pos > len)
		throw std::out_of_range("There is no such position.");
	return str[pos];
}
const char& MyString::at(std::size_t pos) const {
	if (pos < 0 || pos > len)
		throw std::out_of_range("There is no such position.");
	return str[pos];
}
char& MyString::operator[](std::size_t pos)
{
	assert(pos >= 0 && pos <= len);
	return str[pos];
}
const char& MyString::operator[](std::size_t pos) const
{
	assert(pos >= 0 && pos <= len);
	return str[pos];
}
char& MyString::front()
{
	assert(len > 0);
	return str[0];
}
const char& MyString::front() const
{
	assert(len > 0);
	return *(str + 1);
}
char& MyString::back()
{
	assert(len > 0);
	return str[len - 1];
}
const char& MyString::back() const
{
	assert(len > 0);
	return str[len - 1];
}
bool MyString::empty() const
{
	if (len != 0)
		return false;
	return true;
}
std::size_t MyString::size() const
{
	return len;
}
void MyString::clear()
{
	for (int i = 0; i < len; i++)
	{
		str[i] = '\0';
	}
}
void MyString::push_back(char c)
{
	try {
		if ((c < 'a') || (c > '~'))
			throw std::invalid_argument("invalid c");
		len++;
		char* temp = new char[len + 1];
		for (int i = 0; i < len - 1; i++)
			temp[i] = str[i];
		temp[len - 1] = c;
		temp[len] = '\0';
		delete[] str;
		str = new char[strlen(temp)];
		for (int j = 0; j < len; j++)
			str[j] = temp[j];
		delete[] temp;
	}
	catch (const std::exception & e)
	{
		std::cout << e.what() << std::endl;
	}
}

void MyString::pop_back()
{
	assert(len > 0);
	len--;
	char* temp = new char[len + 1];
	for (int i = 0; i < len; i++) {
		temp[i] = str[i];
	}
	temp[len] = '\0';
	delete[] str;
	str = new char[len + 1];
	for (int i = 0; i < len; i++) {
		str[i] = temp[i];
	}
	str[len] = '\0';
	delete[] temp;
}
MyString& MyString::operator+=(const MyString& rhs)
{
	/*int j = len;
	len += rhs.len;
	for (int i = 0; i < rhs.len; i++, j++)
		str[j] = rhs.str[i];
	str[len] = '\0';
	return *this;*/

	size_t new_len = this->len + rhs.len + 2;
	char* temp = new char[new_len];
	size_t br = 0;
	for (size_t i = 0; i < this->len; i++) {
		temp[br] = str[i];
		br++;
	}
	for (size_t j = 0; j < rhs.len; j++) {
		temp[br] = rhs[j];
		br++;
	}
	temp[br] = '\0';
	br++;
	this->len = new_len - 1;
	delete[] str;
	str = new char[len + 1];
	for (size_t j = 0; j <= len; j++)
		str[j] = temp[j];
	delete[] temp;
	return *this;
}
bool MyString::operator==(const MyString& rhs) const
{
	return !strcmp(this->c_str(), rhs.c_str());
}
std::ostream& operator <<(std::ostream& os, const MyString& obj)
{
	os << obj.c_str();
	return os;
};
