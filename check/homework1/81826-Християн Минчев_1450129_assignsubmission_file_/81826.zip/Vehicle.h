#pragma once
#include "Mystring.h"

class Vehicle 
{
public:
	Vehicle(const char* r, const char* d, std::size_t s);
	const char* registration() const { return (Registration.c_str()); };
	const char* description() const { return (Description.c_str()); };
	std::size_t space() const { return Space; };

private:
	MyString Registration;
	MyString Description;
	std::size_t Space;
};