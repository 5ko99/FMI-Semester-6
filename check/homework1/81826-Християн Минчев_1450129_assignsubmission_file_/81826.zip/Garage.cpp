#include "Garage.h"
bool Garage::empty()const
{
	if (carsIn == 0) return 1;
	else return 0;
}
const Vehicle& Garage::at(std::size_t pos) const {
	if (pos <= 0 || pos > carsIn)
		throw std::out_of_range("There is no such position.");
	return *inGarage[pos];
}
const Vehicle& Garage::operator[](std::size_t pos) const
{
	assert(pos >= 0 && pos < carsIn);
	return *inGarage[pos];
}
void Garage::clear() 
{
	carsIn = 0;
	free_space = this->sizeG;
	for (std::size_t i = 0; i < carsIn; i++)
	{
		delete inGarage[i];
	}
};
Garage::Garage(std::size_t sz)
{
	this->sizeG = sz;
	free_space = sz;
	carsIn = 0;
	inGarage = new Vehicle * [sz];
};
void Garage::insert(Vehicle& v)
{
	if ( v.space()<=free_space)
	{
		for (int i = 0; i < carsIn; i++)
			if (inGarage[i]->registration() == v.registration())
				throw std::exception("There is already vehicle with this registration!");
		inGarage[carsIn] = &v;
		carsIn++;
		free_space -= v.space();
	}
	else
		throw std::out_of_range("There is no enough space");
};
void Garage::erase(const char* reg)
{

}
const Vehicle* Garage::find(const char* reg) const
{
	for (int i = 0; i < carsIn; i++)
		if (inGarage[i]->registration() == reg) return inGarage[i];
	return nullptr;
}
void Garage::printGarage()
{
	std::cout << "Garage:" << "\n\n";
	for (int i = 0; i <carsIn; i++)
	{
		std::cout << "Registration of vehicle" << i << ": "<<inGarage[i]->registration()<<"\n";
		std::cout << "Description of vehicle" << i << ": " << inGarage[i]->description() << "\n";
		std::cout << "Space of vehicle" << i << ": " << inGarage[i]->space() << "\n";
		std::cout << "\n";
	}
}
