//
// Created by pgpetrov on 8.04.21 г..
//

#ifndef UNIGARAGE__GARAGE_H_
#define UNIGARAGE__GARAGE_H_

#include <cstddef>
#include "Vehicle.h"

class Garage {
 public:
  explicit Garage(std::size_t size);
  Garage(const Garage &other);
  Garage(Garage &&other) noexcept;
  ~Garage();
  Garage &operator=(const Garage &rhs);
  Garage &operator=(Garage &&rhs) noexcept;
  void insert(Vehicle& v);
  void erase(const char* registration);
  const Vehicle& at(std::size_t pos) const;
  const Vehicle& operator[](std::size_t pos) const;
  bool empty() const;
  std::size_t size() const;
  void clear();
  const Vehicle* find(const char* registration) const;

 private:
  void reserve(std::size_t newCapacity);

  Vehicle **vehicles;
  std::size_t vehiclesAllocated;
  std::size_t vehiclesCount;
  std::size_t maxSpace;
  std::size_t currSpace;
};

#endif //UNIGARAGE__GARAGE_H_
