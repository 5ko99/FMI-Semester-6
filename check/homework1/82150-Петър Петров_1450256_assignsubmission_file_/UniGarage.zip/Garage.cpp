//
// Created by pgpetrov on 8.04.21 г..
//

#include <cstring>
#include <algorithm>
#include <stdexcept>
#include <utility>
#include "Garage.h"

Garage::Garage(std::size_t size)
    : maxSpace(size), currSpace(size), vehicles(new Vehicle *[1]), vehiclesCount(0), vehiclesAllocated(1) {}

Garage::Garage(const Garage &other)
    : vehicles(new Vehicle *[other.vehiclesAllocated]),
      vehiclesAllocated(other.vehiclesAllocated),
      vehiclesCount(other.vehiclesCount),
      maxSpace(other.maxSpace),
      currSpace(other.currSpace) {
  for (std::size_t i = 0; i < vehiclesCount; ++i) {
    vehicles[i] = other.vehicles[i];
  }
}

Garage::Garage(Garage &&other) noexcept
    : vehicles(other.vehicles),
      vehiclesAllocated(other.vehiclesAllocated),
      vehiclesCount(other.vehiclesCount),
      maxSpace(other.maxSpace),
      currSpace(other.currSpace) {
  other.vehicles = nullptr;
  other.vehiclesCount = other.vehiclesAllocated = 0;
}

Garage::~Garage() {
  delete[] vehicles;
  vehicles = nullptr;
  vehiclesAllocated = vehiclesCount = 0;
  maxSpace = currSpace = 0;
}

Garage &Garage::operator=(const Garage &rhs) {
  if (this == &rhs)
    return *this;
  auto newArr = new Vehicle *[rhs.vehiclesCount];
  delete[] vehicles;
  vehicles = newArr;
  vehiclesAllocated = rhs.vehiclesCount;
  vehiclesCount = rhs.vehiclesCount;
  for (std::size_t i = 0; i < vehiclesCount; ++i) {
    vehicles[i] = rhs.vehicles[i];
  }
  maxSpace = rhs.maxSpace;
  currSpace = rhs.currSpace;
  return *this;
}

Garage &Garage::operator=(Garage &&rhs) noexcept {
  vehicles = rhs.vehicles;
  vehiclesAllocated = rhs.vehiclesAllocated;
  vehiclesCount = rhs.vehiclesCount;
  maxSpace = rhs.maxSpace;
  currSpace = rhs.currSpace;
  rhs.vehicles = nullptr;
  rhs.vehiclesCount = rhs.vehiclesAllocated = 0;
  return *this;
}

const Vehicle *Garage::find(const char *registration) const {
  for (std::size_t i = 0; i < vehiclesCount; ++i)
    if (strcmp(vehicles[i]->registration(), registration) == 0) {
      return vehicles[i];
    }
  return nullptr;
}

void Garage::insert(Vehicle &v) {
  if (currSpace < v.space())
    throw std::logic_error("No space available for vehicle to park, aborting!");
  if (find(v.registration()))
    throw std::logic_error("Already a vehicle with duplicate registration, aborting!");
  if (vehiclesCount == vehiclesAllocated) {
    reserve(vehiclesAllocated * 2);
  }
  vehicles[vehiclesCount++] = &v;
  currSpace -= v.space();
}

void Garage::erase(const char *registration) {
  for (std::size_t i = 0; i < vehiclesCount; ++i)
    if (strcmp(vehicles[i]->registration(), registration) == 0) {
      currSpace += vehicles[i]->space();
      --vehiclesCount;
      std::swap(vehicles[i], vehicles[vehiclesCount]);
      return;
    }
}

const Vehicle &Garage::at(std::size_t pos) const {
  if (pos < 0 || pos >= vehiclesCount)
    throw std::out_of_range("Invalid position specified for a vehicle!");
  return *vehicles[pos];
}

const Vehicle &Garage::operator[](std::size_t pos) const {
  return *vehicles[pos];
}

bool Garage::empty() const {
  return vehiclesCount == 0;
}

std::size_t Garage::size() const {
  return vehiclesCount;
}

void Garage::clear() {
  vehiclesCount = 0;
  currSpace = maxSpace;
}

void Garage::reserve(std::size_t newCapacity) {
  if (newCapacity <= vehiclesAllocated)
    return;
  auto newArr = new Vehicle *[newCapacity];
  for (std::size_t i = 0; i < vehiclesCount; ++i) {
    newArr[i] = vehicles[i];
  }
  delete[] vehicles;
  vehicles = newArr;
  vehiclesAllocated = newCapacity;
}
