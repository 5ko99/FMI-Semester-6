//
// Created by pgpetrov on 8.04.21 г..
//

#ifndef UNIGARAGE__VEHICLE_H_
#define UNIGARAGE__VEHICLE_H_

#include <cstddef>
#include "MyString.h"

class Vehicle {
 public:
  Vehicle(const char* registration, const char* description, std::size_t space);
  const char* registration() const;
  const char* description() const;
  std::size_t space() const;
 private:
  MyString _registration;
  MyString _description;
  std::size_t _space;
};

#endif //UNIGARAGE__VEHICLE_H_
