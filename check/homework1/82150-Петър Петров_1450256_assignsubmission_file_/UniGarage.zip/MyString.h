//
// Created by pgpetrov on 7.04.21 г..
//

#ifndef UNIGARAGE__MYSTRING_H_
#define UNIGARAGE__MYSTRING_H_

#include <cstddef>

class MyString {
 public:
  MyString();
  MyString(const char* str);
  MyString(const MyString& other);
  MyString(MyString&& other) noexcept;
  ~MyString();
  MyString& operator=(const MyString& other);
  MyString& operator=(MyString&& other);
  explicit operator bool() const; // checks whether object is in a valid state(if it is not destroyed)
  char& at(std::size_t pos); // throws std::out_of_range
  const char& at(std::size_t pos) const;
  char& operator[](std::size_t pos); // in debug mode assert legal pos
  const char& operator[](std::size_t pos) const;
  char& front(); // in debug mode assert non-emptiness
  const char& front() const;
  char& back();
  const char& back() const;
  bool empty() const;
  std::size_t size() const;
  void clear();
  void reserve(std::size_t newCapacity);
  void push_back(char c);
  void pop_back();
  MyString& operator+=(char c);
  MyString& operator+=(const MyString& rhs);
  MyString operator+(char c) const;
  MyString operator+(const MyString& rhs) const;
  const char* c_str() const;
  bool operator==(const MyString& rhs) const;
  bool operator<(const MyString& rhs) const;

 private:
  char* data = nullptr;
  std::size_t allocated = 0;
  std::size_t used = 0;

  void checkBounds(std::size_t pos) const;
};

#endif //UNIGARAGE__MYSTRING_H_
