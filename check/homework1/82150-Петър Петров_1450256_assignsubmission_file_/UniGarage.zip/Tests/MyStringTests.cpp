//
// Created by pgpetrov on 7.04.21 г..
//

#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include "../MyString.h"

TEST_CASE("MyString: size, comparison, clear") {
  MyString my_string("alabala");
  const MyString &string = my_string; // using const reference to make sure methods are const
  REQUIRE((string.size() == 7));
  REQUIRE((!my_string.empty()));
  REQUIRE(string == "alabala");
  REQUIRE(string < "alacala");
  REQUIRE(MyString("ababala") < string);
  my_string.clear();
  REQUIRE(string.size() == 0);
  REQUIRE_THROWS_AS(string.at(-1), std::out_of_range);
  REQUIRE_THROWS_AS(string.at(0), std::out_of_range);
  REQUIRE_THROWS_AS(string.at(1), std::out_of_range);
  REQUIRE(string.empty());
}

TEST_CASE("MyString: indexing, assignment") {
  MyString s("");
  const MyString &s1 = "shlubadub";
  REQUIRE((bool(s) && bool(s1)));
  REQUIRE(((s = s1) == s1));
  REQUIRE(s1.back() == 'b');
  REQUIRE(s1.front() == 's');
  REQUIRE(s[2] == 'l');
  const char c = 'c';
  s[1] = c;
  REQUIRE(s[1] == 'c');
  for (std::size_t i = 0; i < s.size(); ++i) {
    REQUIRE((&s[i]) == (&s.at(i)));
  }
  REQUIRE_THROWS_AS(s.at(-1), std::out_of_range);
  REQUIRE_THROWS_AS(s.at(s.size()), std::out_of_range);
  REQUIRE_THROWS_AS(s.at(s.size() + 1), std::out_of_range);
  REQUIRE(s.c_str() != s1.c_str());
  REQUIRE(s.size() == s1.size());
}

TEST_CASE("MyString: push_back, pop_back, operators +=, +") {
  MyString s = "sdlkfjsfd";
  std::size_t prevSize = s.size();
  s.push_back('z');
  REQUIRE(s.back() == 'z');
  REQUIRE(s.size() == prevSize + 1);
  s.pop_back();
  REQUIRE(s.size() == prevSize);
  s += 'z';
  REQUIRE(s.back() == 'z');
  REQUIRE(s.size() == prevSize + 1);
  prevSize = s.size();
  s += s;
  REQUIRE(s.size() == prevSize*2);
  for (std::size_t i = 0; i < prevSize; ++i) {
    REQUIRE(s[i] == s[prevSize+i]);
  }
  prevSize = s.size();
  const MyString &other = s;
  s = s+other;
  s = other+s;
  s += other;
  REQUIRE(s.size() == prevSize*8);
  for (std::size_t i = 0; i < prevSize; ++i) {
    REQUIRE(s[i] == s[prevSize+i]);
    //REQUIRE(s[i] == s[prevSize*2 + i]);
  }
}

TEST_CASE("MyString: copy and move semantics") {
  MyString s1("abracadabra");
  MyString s2(s1);
  MyString s3 = s2;

  REQUIRE((bool(s1) && bool(s2) && bool(s3)));

  SECTION("copy") {
    REQUIRE((s1 == s2 && s2 == s3 && s1 == s3));
    REQUIRE((s1.c_str() != s2.c_str() && s2.c_str() != s3.c_str()));
    REQUIRE((s1.size() == s2.size() && s2.size() == s3.size()));
  }

  SECTION("move") {
    s3 += "sdlkfsdf";
    s2 = std::move(s3);
    REQUIRE(s2[2] == 'r');
    REQUIRE_FALSE(s2 == s1);
    REQUIRE(s2.size() > s1.size());
    REQUIRE(!bool(s3));
  }
}