//
// Created by pgpetrov on 9.04.21 г..
//

#include "catch.hpp"
#include "../Vehicle.h"

TEST_CASE("Vehicle: correct creation, immutability") {
  const Vehicle polo("XX1234YY", "fastest car i've ever seen", 1);
  REQUIRE(strcmp(polo.registration(), "XX1234YY") == 0);
  REQUIRE(strcmp(polo.description(), "fastest car i've ever seen") == 0);
  REQUIRE(polo.space() == 1);
}