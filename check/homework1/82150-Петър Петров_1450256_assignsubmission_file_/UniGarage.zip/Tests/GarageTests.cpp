//
// Created by pgpetrov on 9.04.21 г..
//

#include "catch.hpp"
#include "../Garage.h"

TEST_CASE("Garage: creation") {
  const Garage g(3);
  REQUIRE(g.size() == 0);
  REQUIRE(g.empty());
  REQUIRE(g.find("XX1234YY") == nullptr);
  REQUIRE_THROWS_AS(g.at(0), std::out_of_range);
  REQUIRE_THROWS_AS(g.at(-1), std::out_of_range);
  REQUIRE_THROWS_AS(g.at(1), std::out_of_range);
  REQUIRE("");
}

TEST_CASE("Garage actions") {
  SECTION("Zero capacity garage") {
    Garage g(0);
    Vehicle tmp = Vehicle("XX1234XX", "bla", 1);
    REQUIRE_THROWS_AS(g.insert(tmp), std::logic_error);
    REQUIRE(g.empty());
    g.erase("XX1234XX"); // see if no problems occur
    g.erase("YX1234XX");
  }

  SECTION("Non-zero capacity garage") {
    Garage g1(3);
    Vehicle meVehicle0 = Vehicle("XX1234XX", "bla", 1);
    g1.insert(meVehicle0);

    SECTION("Trying to insert without sufficient space") {
      REQUIRE(g1.size() == 1);
      Vehicle tmp = Vehicle("x", "bla", 3);
      REQUIRE_THROWS_AS(g1.insert(tmp), std::logic_error);
      REQUIRE(g1.size() == 1);
      REQUIRE(!g1.empty());
    }

    Vehicle meVehicle = Vehicle("YY1234YY", "blabla", 2);

    SECTION("Correct insertion and some indexing") {
      REQUIRE(&g1[0] == &meVehicle0);
      REQUIRE_THROWS_AS(g1.at(2), std::out_of_range);
      REQUIRE_NOTHROW(g1.insert(meVehicle));
      REQUIRE(g1.find(meVehicle.registration()) == &meVehicle);
      REQUIRE(g1.find(meVehicle0.registration()) == &meVehicle0);
    }

    SECTION("Correct erase and some indexing") {
      REQUIRE_NOTHROW(g1.insert(meVehicle));
      g1.erase(meVehicle.registration());
      REQUIRE(g1.size() == 1);
      REQUIRE(g1.find(meVehicle.registration()) == nullptr);
      REQUIRE(g1.find(meVehicle0.registration()) == &meVehicle0);
      REQUIRE(&g1[0] == &meVehicle0);
      REQUIRE_THROWS_AS(g1.at(1), std::out_of_range);
      REQUIRE_THROWS_AS(g1.insert(meVehicle0), std::logic_error);
    }

    SECTION("Correct indexing and clear") {
      Vehicle tmp[] = {
          {"aasdasd", "asdasd", 2},
          {"xxxxxxx", "other", 1},
          {"yyyyyyy", "yet another", 7},
          {"", "yet another vehicle but this one with a rather large description", 2},
          {"zzzzzzzzzzzzzzzzzzz", "bruh", 4},
          {"a", "", 0},
      };
      Garage g(16);
      for (Vehicle& v : tmp) {
        REQUIRE_NOTHROW(g.insert(v));
      }
      for (std::size_t i = 0; i < g.size(); ++i) {
        REQUIRE_NOTHROW(g.at(i));
        REQUIRE(&g.at(i) == &g[i]);
      }

      SECTION("clear") {
        g.clear();
        REQUIRE(g.empty());
        Vehicle truck("AS2943XA", "for heavy loads", 16);
        REQUIRE_NOTHROW(g.insert(truck));
        REQUIRE_THROWS_AS(g.insert(tmp[0]), std::logic_error);
      }
    }
  }
}

TEST_CASE("Garage: Copy and move semantics") {
  Vehicle tmp1 = Vehicle("aasdasd", "asdasd", 2);
  Vehicle tmp2 = Vehicle("xxxxxxx", "other", 1);
  Vehicle tmp3 = Vehicle("yyyyyyy", "yet another", 2);
  Garage g1(6);

  SECTION("Copy") {
    Garage g2 = g1;
    REQUIRE(g2.empty());
    g1.insert(tmp1);
    REQUIRE(g2.empty()); // asserts that object is indeed correctly copied
    g2.insert(tmp1);
    g2.insert(tmp2);
    g2.insert(tmp3);

    Vehicle medium_vehicle("YY1248XX", "normal", 2);
    REQUIRE_THROWS_AS(g2.insert(medium_vehicle), std::logic_error);
    Vehicle small_vehicle("XX2344XX", "cheap af", 1);
    REQUIRE_NOTHROW(g2.insert(small_vehicle));

    Garage g3 = g2;
    REQUIRE(g3.size() == g2.size());
    for (std::size_t i = 0; i < g3.size(); ++i) {
      REQUIRE(&g3.at(i) == &g2.at(i));
    }

    g1 = g2;
    REQUIRE(g3.size() == g1.size());
    for (std::size_t i = 0; i < g3.size(); ++i) {
      REQUIRE(&g3.at(i) == &g1.at(i));
    }
  }

  SECTION("Move") {
    Garage g(5);
    g.insert(tmp1);
    g.insert(tmp2);

    Garage gm = std::move(g);

    REQUIRE(gm.size() == 2);
    REQUIRE(gm.find(tmp1.registration()) == &tmp1);
    REQUIRE(gm.find(tmp2.registration()) == &tmp2);

    REQUIRE_NOTHROW(gm.insert(tmp3));
    gm.erase(tmp3.registration());

    Vehicle big_vehicle("AA AAAA AA", "barovets", 3);
    REQUIRE_THROWS_AS(gm.insert(big_vehicle), std::logic_error); // not enough space

    Garage gt = gm;
    gt = std::move(gm);
    REQUIRE(gt.size() == 2);
    REQUIRE(gt.find(tmp1.registration()) == &tmp1);
    REQUIRE(gt.find(tmp2.registration()) == &tmp2);

    REQUIRE_NOTHROW(gt.insert(tmp3));

    REQUIRE_THROWS_AS(gt.insert(big_vehicle), std::logic_error); // not enough space
  }

}