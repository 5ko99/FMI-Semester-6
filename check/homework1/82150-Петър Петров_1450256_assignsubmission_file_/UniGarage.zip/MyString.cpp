//
// Created by pgpetrov on 7.04.21 г..
//

#include "MyString.h"
#include <cstring>
#include <stdexcept>
#include <cassert>

MyString::MyString() : data(new char[1]), used(1), allocated(1) {
  data[0] = '\0';
}

MyString::MyString(const char *str) {
  allocated = strlen(str) + 1;
  data = new char[allocated];
  used = allocated;
  strcpy(data, str);
}

MyString::MyString(const MyString &other)
    : data(new char[other.used]), allocated(other.used), used(other.used) {
  strcpy(data, other.data);
}

MyString::MyString(MyString &&other) noexcept: data(other.data), allocated(other.allocated), used(other.used) {
  other.data = nullptr;
  other.allocated = other.used = 0;
}

MyString::~MyString() {
  delete[] data;
  data = nullptr;
  used = allocated = 0;
}

MyString &MyString::operator=(const MyString &other) {
  if (this != &other) {
    char *newData = new char[other.used];
    strcpy(newData, other.data);
    delete[] data;
    data = newData;
    allocated = other.used;
    used = allocated;
  }
  return *this;
}

MyString &MyString::operator=(MyString &&other) {
  if (this != &other) {
    delete[] data;
    data = other.data;
    allocated = other.allocated;
    used = other.used;
    other.data = nullptr;
    other.used = other.allocated = 0;
  }
  return *this;
}

MyString::operator bool() const {
#ifdef DEBUG
  assert(allocated > 0 && used > 0 && used <= allocated);
#endif
  return data;
}

void MyString::checkBounds(std::size_t pos) const {
  if (pos < 0 || pos >= used-1)
    throw std::out_of_range("Index out of bounds!");
}

char &MyString::at(std::size_t pos) {
  checkBounds(pos);
  return data[pos];
}

const char &MyString::at(std::size_t pos) const {
  checkBounds(pos);
  return data[pos];
}

char &MyString::operator[](std::size_t pos) {
#ifdef DEBUG
  assert(pos < 0 || pos > used);
#endif
  return data[pos];
}

const char &MyString::operator[](std::size_t pos) const {
#ifdef DEBUG
  assert(pos < 0 || pos > used);
#endif
  return data[pos];
}

char &MyString::front() {
#ifdef DEBUG
  assert(!empty());
#endif
  return data[0];
}

const char &MyString::front() const {
#ifdef DEBUG
  assert(!empty());
#endif
  return data[0];
}

char &MyString::back() {
#ifdef DEBUG
  assert(!empty());
#endif
  return data[used - 2];
}

const char &MyString::back() const {
#ifdef DEBUG
  assert(!empty());
#endif
  return data[used - 2];
}

bool MyString::empty() const {
  return used == 1; // only for terminating null byte
}

std::size_t MyString::size() const {
  return used - 1;
}

void MyString::clear() {
  data[0] = '\0';
  used = 1;
}

void MyString::push_back(char c) {
  if (used == allocated) {
    reserve(allocated * 2);
  }
  data[used - 1] = c;
  used++;
  data[used - 1] = '\0';
}

void MyString::reserve(std::size_t newCapacity) {
  if (newCapacity <= allocated)
    return;
  char *newData = new char[newCapacity];
  strcpy(newData, data);
  delete[] data;
  data = newData;
  allocated = newCapacity;
}

void MyString::pop_back() {
#ifdef DEBUG
  assert(!empty());
#endif
  --used;
  data[used - 1] = '\0';
}

MyString &MyString::operator+=(char c) {
  push_back(c);
  return *this;
}

MyString &MyString::operator+=(const MyString &rhs) {
  if (this == &rhs) {
    MyString tmp(*this);
    tmp += rhs;
    return *this = std::move(tmp);
  } // ensures that we don't try strcat(x, x) as it's undefined behavior
  reserve(used + rhs.size()); // will be noop if above if-block executes
  strcat(data, rhs.data);
  used += rhs.size();
  return *this;
}

MyString MyString::operator+(char c) const {
  MyString ret(*this);
  ret.push_back(c);
  return ret;
}

MyString MyString::operator+(const MyString &rhs) const {
  MyString ret(*this);
  ret += rhs;
  return ret;
}

const char *MyString::c_str() const {
  return data;
}

bool MyString::operator==(const MyString &rhs) const {
  return strcmp(data, rhs.data) == 0;
}

bool MyString::operator<(const MyString &rhs) const {
  return strcmp(data, rhs.data) < 0;
}
