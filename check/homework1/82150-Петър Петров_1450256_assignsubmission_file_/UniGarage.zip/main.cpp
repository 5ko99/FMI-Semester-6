#include <iostream>
#include "Garage.h"

void insert(Garage& g);
void erase(Garage& g);
void print(Garage& g);
void cleanup();

const char* helpMsg = "i: insert; e: erase; p: print garage contents; h: help; q: quit; ";

int main() {
  std::cout << "Specify the capacity you want your garage to have:" << std::endl;
  std::size_t capacity;
  std::cin >> capacity;
  Garage myGarage(capacity);

  while (true) {
    std::cout << "Type in 1 character to execute a command. h: help and q: quit. :" << std::endl;
    char c;
    std::cin >> c;

    switch (c) {
      case 'i':
        insert(myGarage);
        break;
      case 'e':
        erase(myGarage);
        break;
      case 'p':
        print(myGarage);
        break;
      case 'q':
        cleanup();
        return 0;
      case 'h':
        std::cout << helpMsg << std::endl;
        break;
      default:
        std::cerr << "Invalid command specified!" << std::endl;
    }
  }
}

Vehicle* vehiclesRegistrar[10000]; // assuming user won't create too many new vehicles
std::size_t vehiclesCount = 0;

void cleanup() {
  for (std::size_t i = 0; i < vehiclesCount; ++i) {
    delete vehiclesRegistrar[i];
  }
}

void insert(Garage& g) {
  std::cout << "Specify registration plate for Vehicle:" << std::endl;
  char registration[50];
  std::cin >> registration;
  std::cout << "Specify a short description for Vehicle:" << std::endl;
  char description[300];
  std::cin.ignore();
  std::cin.getline(description, sizeof description);
  std::cout << "Specify amount of parking space that Vehicle takes up:" << std::endl;
  std::size_t parkSpace;
  std::cin >> parkSpace;

  vehiclesRegistrar[vehiclesCount++] = new Vehicle(registration, description, parkSpace);
  try {
    g.insert(*vehiclesRegistrar[vehiclesCount - 1]);
  } catch (std::logic_error& error) {
    std::cerr << error.what() << std::endl;
  }
}

void erase(Garage& g) {
  std::cout << "Specify registration plate for Vehicle that you want erased:" << std::endl;
  char registration[50];
  std::cin >> registration;

  if (g.find(registration)) {
    g.erase(registration);
    std::cout << "Vehicle with matching registration successfully erased." << std::endl;
  } else {
    std::cerr << "No Vehicle with mathcing registration!" << std::endl;
  }
}

void print(Garage& g) {
  std::cout << "Garage contents:" << std::endl;
  for (std::size_t i = 0; i < g.size(); ++i) {
    std::cout << g[i].registration() << " " << g[i].description() << " " << g[i].space() << std::endl;
  }
}