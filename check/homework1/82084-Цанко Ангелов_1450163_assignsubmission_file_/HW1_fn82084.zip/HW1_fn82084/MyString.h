#ifndef __MyString__HH
#define __MyString__HH

#include <iostream>

class MyString
{
private:
  int temp_size;
  int capacity;
  char *array;

  void copy(const MyString &);
  void delete_string();

public:
  MyString();
  MyString(const MyString &other);
  MyString &operator=(const MyString &other);
  ~MyString();
  MyString(const char *str);
  char &at(std::size_t pos);
  const char &at(std::size_t pos) const;
  char &operator[](std::size_t pos);
  const char &operator[](std::size_t pos) const;
  char &front();
  const char &front() const;
  char &back();
  const char &back() const;
  bool empty() const;
  std::size_t size() const;
  void clear();
  void push_back(char c);
  void pop_back();
  MyString &operator+=(char c);
  MyString &operator+=(const MyString &rhs);
  MyString operator+(char c) const;
  MyString operator+(const MyString &rhs) const;
  const char *c_str() const;
  bool operator==(const MyString &rhs) const;
  bool operator<(const MyString &rhs) const;

  friend std::ostream &operator<<(std::ostream &out, MyString &str);
  int getSize() const;
  int getCapacity() const;
  void setSize(int _temp_size);
  void setCapacity(int _capacity);
  void SetString(char *);
  char *getArray() const;
};

#endif
