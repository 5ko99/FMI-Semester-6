#ifndef __Garage__HH
#define __Garage__HH

#include<iostream>
#include<assert.h>
#include "Vehicle.h"

class Garage
{
    private:
    Vehicle** vehicles = nullptr;
    std::size_t capacity_vehicles;
    std::size_t size_vehicles;
    std::size_t count = 0;

    void copy(const Garage &other);
    void delete_garage();


    public:
    Garage();
    Garage(const Garage& other);
    Garage& operator=(const Garage& other); 
    ~Garage();
    Garage(std::size_t size);
    void insert(Vehicle& v); 
    void erase(const char* registration); 
    void clear(); 
    const Vehicle& at(size_t pos) const;
    const Vehicle* find(const char* registration) const;
    bool empty() const;
    std::size_t size() const;
    const Vehicle& operator[](size_t pos) const;

};

#endif