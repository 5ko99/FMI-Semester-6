#include <iostream>
#include "Vehicle.h"

Vehicle::Vehicle(const char *registration, const char *description, std::size_t space) 
{
    this->registration_number = new char[strlen(registration) + 1];
    strcpy(registration_number.getArray(), registration);
    this->details = new char[strlen(description) + 1];
    strcpy(details.getArray(), description);
    this->num_of_parks = space;
}

const char *Vehicle::registration() const
{
    return this->registration_number.c_str();
}

const char *Vehicle::description() const
{
    return this->registration_number.c_str();
}

std::size_t Vehicle::space() const
{
    return this->num_of_parks;
}

