#ifndef __Vehicle__HH
#define __Vehicle__HH

#include<iostream>
#include <cstring>
#include "MyString.h"

class Vehicle
{
    private:
    MyString registration_number;
    MyString details;
    std::size_t num_of_parks;

    public:
    Vehicle(const char* registration, const char* description, std::size_t space);
    const char* registration() const;
    const char* description() const;
    std::size_t space() const;

};

#endif