#include <iostream>
#include "MyString.h"
#include "Vehicle.h"
#include "Garage.h"

void print()
{
    std::cout << "Choose option:" << std::endl;
    std::cout << "1) Create a new garage" << std::endl;
    std::cout << "2) Add new vehicle " << std::endl;
    std::cout << "3) Erase vehicle " << std::endl;
    std::cout << "4) Print all vehicles " << std::endl;
    std::cout << "0) Exit" << std::endl;
}

int main()
{
    int number;
    Garage g;
    Vehicle v("", "", 0);

    do
    {
        print();
        std::cin >> number;

        if (number == 0)
        {
            std::cout << "Exit successfully";
            return 0;
        }

        if (number == 1)
        {
            std::cout << "Choose garage capacity:";
            int n;
            do
            {
                std::cin >> n;
                std::cin.ignore();
            } while (n < 0);

           Garage g(n);
        }

        if (number == 2)
        {
            std::cout << "Choose vehicle details:" << std::endl;
            char reg[100];
            char det[100];
            size_t vehicle_space;

            std::cout << "Write registration:" << std::endl;
            std::cin.getline(reg, 99);
            std::cin.ignore();
            std::cout << "Write description:" << std::endl;
            std::cin.getline(det, 99);
            std::cout << "Write vehicle space:" << std::endl;
            std::cin >> vehicle_space;
            Vehicle v(reg, det, vehicle_space);
            g.insert(v);
        }

        if (number == 3)
        {
            std::cout << "Vehicle erassed!";
            g.erase(v.registration());
        }

        if (number == 4)
        {
            for (int i = 0; i < g.size(); i++)
           {
               std::cout<<"Vehicle number:"<<i+1<<std::endl;
               std::cout<<g[i].registration()<<std::endl; 
               std::cout<<g[i].description()<<std::endl; 
               std::cout<<g[i].space()<<std::endl; 
           }
        }

    } while (number > 0 || number < 4);

    return 0;
}