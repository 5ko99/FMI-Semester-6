#include <iostream>
#include "Garage.h"

void Garage::copy(const Garage &other)
{
    capacity_vehicles = other.capacity_vehicles;
    size_vehicles = other.size_vehicles;
    count = other.count;
    vehicles = new (std::nothrow) Vehicle *[size_vehicles];
    for (int i = 0; i < capacity_vehicles; i++)
    {
        vehicles[i] = other.vehicles[i];
    }
}

void Garage::delete_garage()
{
    delete[] vehicles;
}

Garage::Garage()
{
    count = 0;
    size_vehicles = 0;
    capacity_vehicles = 1;
    vehicles = new Vehicle *[capacity_vehicles];
}

Garage::Garage(const Garage &other)
{
    copy(other);
}

Garage &Garage::operator=(const Garage &other)
{
    if (this != &other)
    {
        delete_garage();
        copy(other);
    }
    return *this;
}

Garage::~Garage()
{
    delete_garage();
}

Garage::Garage(std::size_t size)
{
    capacity_vehicles = size;
    size_vehicles = 0;
    delete[] vehicles;
    vehicles = new Vehicle *[capacity_vehicles];
    for (int i = 0; i < capacity_vehicles; ++i)
    {
        vehicles[i] = nullptr;
    }
}

void Garage::insert(Vehicle &v)
{
    if ((v.space() + size_vehicles) > capacity_vehicles)
    {
        std::cout << "Garage is full! Vehicle cannot be added." << std::endl;
        return;
    }

    for (int i = 0; i < count; ++i)
    {
        if (strcmp(vehicles[i]->registration(), v.registration()) == 0)
        {
            std::cout << "This vehicle exists!" << std::endl;
            return;
        }
    }
    vehicles[count++] = &v;
    size_vehicles += v.space();
    std::cout << "Vehicle added successfully!" << std::endl;
}
void Garage::erase(const char *registration)
{
    for (int i = 0; i < count; ++i)
    {
        if (strcmp(this->vehicles[i]->registration(), registration) == 0)
        {
            std::cout << "Car founded successfully!" << std::endl;
            this->count--;
            size_vehicles -= vehicles[i]->space();
            vehicles[i] = vehicles[count];
            vehicles[count] = nullptr;
        }
    }

    std::cout << "Car erased!" << std::endl;
}
void Garage::clear()
{
    for (int i = 0; i < capacity_vehicles; ++i)
    {
        vehicles[i] = nullptr;
    }
    count = 0;
    size_vehicles = 0;
}

const Vehicle &Garage::at(size_t pos) const
{
    if (pos >= count)
    {

        throw std::out_of_range("Not in range");
    }
    std::cout << "Correct!";
    return *vehicles[pos];
}

const Vehicle *Garage::find(const char *registration) const
{
    for (int i = 0; i < count; ++i)
    {
        if (strcmp(vehicles[i]->registration(), registration) == 0)
        {
            std::cout << "Vehicle founded successfully!" << std::endl;
            return vehicles[i];
        }
    }
    return nullptr;
}

bool Garage::empty() const
{
    return count == 0;
}

size_t Garage::size() const
{
    return count;
}

const Vehicle &Garage::operator[](size_t pos) const
{
#ifdef _DEBUG
    assert(pos < count);
#endif

    return *(vehicles[pos]);
}

