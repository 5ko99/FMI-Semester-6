#define CATCH_CONFIG_MAIN 
#include "catch2.hpp"
#include "MyString.h"
#include "Vehicle.h"
#include "Garage.h"

TEST_CASE("Space check")
{
    Vehicle v("registration", "detail", 1);
    CHECK(v.space() == 1);
}

TEST_CASE("Garage - constructor with parameters")
{
    Garage g(15);
    const size_t capacity = 15;
    CHECK(0 == g.size());
}

TEST_CASE("Garage - copy constructor")
{
    Garage g(20);
    Garage g2(g);
    const size_t capacity = 20;

    CHECK(g.size() == g2.size());
}

TEST_CASE("empty")
{
    Garage g(20);
    g.clear();

    CHECK(g.size() == 0);
}

TEST_CASE("MyString - constructor with parameters")
{
    MyString strin("proba");
    CHECK(strcmp(strin.c_str(), "proba") == 0);
}

TEST_CASE("front")
{
    MyString strin;
    strin.SetString("proba");
    CHECK(strin.front() == 'p');
}

TEST_CASE("at")
{
    MyString strin;
    strin.SetString("proba");
    CHECK(strin.at(0) == 'p');
}

TEST_CASE("operator[]")
{
    MyString strin;
    strin.SetString("proba");
    CHECK(strin[0] == 'p');
}

TEST_CASE("back")
{
    MyString strin;
    strin.SetString("proba");
    CHECK(strin.back() == 'a');
}

TEST_CASE("size")
{
    MyString strin("proba");
    CHECK(strin.size() == 5);
}

TEST_CASE("c_str")
{
    MyString strin;
    strin.SetString("proba");
    CHECK(strcmp(strin.c_str(), "proba") == 0);
}







