#include <iostream>
#include <cstring>
#include <assert.h>
#include <exception>
#include "MyString.h"

void MyString::copy(const MyString &other)
{
    capacity = other.capacity;
    temp_size = other.temp_size;
    array = new (std::nothrow) char[strlen(other.array) + 1];
    strcpy(array, other.array);
}

void MyString::delete_string()
{
    delete[] array;
}

MyString::MyString()
{
    temp_size = 0;
    capacity = 1;
    array = new char[capacity];
}

MyString::MyString(const MyString &other)
{
    copy(other);
}

MyString &MyString::operator=(const MyString &other)
{
    if (this != &other)
    {
        delete_string();
        copy(other);
    }
    return *this;
}

MyString::~MyString()
{
    delete_string();
}

void MyString::setSize(int _temp_size)
{
    temp_size = _temp_size;
}

void MyString::setCapacity(int _capacity)
{
    capacity = _capacity;
}

MyString::MyString(const char *str)
{
    temp_size = strlen(str);
    this->array = new char[temp_size + 1];
    strcpy(array, str);
}

char &MyString::at(std::size_t pos)
{
    if (pos > getSize())
    {
        throw std::out_of_range("Error");
    }

    return array[pos];
}

const char &MyString::at(std::size_t pos) const
{
    if (pos > getSize())
    {
        throw std::out_of_range("Error");
    }

    return array[pos];
}

char &MyString::operator[](std::size_t position)
{
#ifdef _DEBUG
    assert(position < temp_size);
#endif

    return array[position];
}

const char &MyString::operator[](std::size_t position) const
{
#ifdef _DEBUG
    assert(position < temp_size);
#endif

    return array[position];
}

char &MyString::front()
{
#ifdef _DEBUG
    assert(array != nullptr);
#endif

    return array[0];
}

const char &MyString::front() const
{
#ifdef _DEBUG
    assert(array != nullptr);
#endif

    return array[0];
}

char &MyString::back()
{
#ifdef _DEBUG
    assert(array != nullptr);
#endif

    return array[temp_size - 1];
}

const char &MyString::back() const
{
#ifdef _DEBUG
    assert(array != nullptr);
#endif

    return array[temp_size - 1];
}

std::size_t MyString::size() const
{
    return strlen(array);
}

int MyString::getSize() const
{
    return this->temp_size;
}

int MyString::getCapacity() const
{
    return this->capacity;
}

bool MyString::empty() const
{
    if (temp_size == 0)
    {
        return true;
    }
    return false;
}

char *MyString::getArray() const
{
    return this->array;
}

void MyString::clear()
{
    delete[] array;
    temp_size = 0;
    capacity = 0;
}

void MyString::push_back(char c)
{
    char *new_array = new char[capacity];
    strcpy(new_array, array);
    capacity = strlen(array) + 2;
    temp_size = strlen(array);
    delete[] array;
    array = new char[capacity];
    strcpy(array, new_array);
    array[temp_size] = c;
    temp_size++;
    array[temp_size] = '\0';
}

void MyString::pop_back()
{
    array[temp_size - 1] = '\0';
}

MyString &MyString::operator+=(char c)
{
    char *new_array = new char[capacity];
    strcpy(new_array, array);
    capacity = strlen(array) + 2;
    temp_size = strlen(array) + 1;
    delete[] array;
    array = new char[capacity];
    strcpy(array, new_array);
    array[temp_size] = c;
    temp_size++;
    array[temp_size] = '\0';
    delete[] new_array;
    return *this;
}

MyString &MyString::operator+=(const MyString &rhs)
{
    char *temp_array = new char[capacity];
    strcpy(temp_array, array);
    delete[] array;
    capacity = capacity + strlen(rhs.array) + 1;
    temp_size = temp_size + strlen(rhs.array);
    char *array = new char[capacity];
    strcpy(array, temp_array);

    for (int i = strlen(temp_array), j = 0; i < capacity, j <= rhs.temp_size; i++, j++)
    {
        array[i] = rhs.array[j];
    }
    array[temp_size] = '\0';
    delete[] temp_array;
    return *this;
}

MyString MyString::operator+(char c) const
{
    MyString res;
    res.capacity = capacity + 1;
    res.temp_size = temp_size + 1;
    strcpy(res.array, array);
    res.array[temp_size] = c;
    res.array[temp_size + 1] = '\0';

    return res;
}

MyString MyString::operator+(const MyString &rhs) const
{
    MyString res;
    res.capacity = capacity + strlen(rhs.array) + 1;
    res.temp_size = temp_size + strlen(rhs.array) + 1;
    strcpy(res.array, array);

    for (int i = strlen(array), j = 0; i < res.capacity, j <= rhs.temp_size; i++, j++)
    {
        res.array[i] = rhs.array[j];
    }
    res.array[res.temp_size] = '\0';

    return res;
}

const char *MyString::c_str() const
{
    char *new_array = new char[capacity];
    strcpy(new_array, array);
    new_array[temp_size] = '\0';
    return new_array;
}

bool MyString::operator==(const MyString &rhs) const
{
    return (strcmp(this->array, rhs.array) == 0);
}

bool MyString::operator<(const MyString &rhs) const
{
    return (strcmp(this->array, rhs.array) < 0);
}

void MyString::SetString(char *a)
{
    delete[] array;
    capacity = strlen(a) + 1;
    temp_size = strlen(a);
    array = new (std::nothrow) char[strlen(a) + 1];
    strcpy(array, a);
}

std::ostream &operator<<(std::ostream &out, MyString &str)
{
    out << str.getArray() << std::endl;

    return out;
}


