#define CATCH_CONFIG_MAIN
#include "Vehicle.hh"
#include "catch.hh"

#define CATCH_CONFIG_MAIN
#include "MyString.hh"
#include "catch.hh"

TEST_CASE("Vehicle functionality", "[Vehicle]") {

  Vehicle v("sa1994as", "Red Ferrari", 2);

  SECTION("registration() returns the correct string") {
    REQUIRE_FALSE(strcmp(v.registration(), "sa1994as"));
  }
  SECTION("occupiedSpace() returns the correct string") {
    REQUIRE(v.space() == 2);
  }
  SECTION("description() returns the correct string") {
    REQUIRE_FALSE(strcmp(v.description(), "Red Ferrari"));
  }
}