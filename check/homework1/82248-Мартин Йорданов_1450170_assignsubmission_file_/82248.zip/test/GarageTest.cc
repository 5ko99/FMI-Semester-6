#define CATCH_CONFIG_MAIN
#include "Garage.hh"
#include "catch.hh"

TEST_CASE("DynArray functionality", "[DynArray]") {

  Garage g(5);
  Vehicle v1("sa1994as", "Red Ferrari", 2);
  Vehicle v2("v2001tx", "Yellow Lamborgini", 3);

  REQUIRE(g.empty());
  REQUIRE_NOTHROW(g.insert(v1));
  REQUIRE_FALSE(g.empty());

  SECTION("Adding same vehicle twice") {
    REQUIRE(g.size() == 1);

    REQUIRE_THROWS(g.insert(v1));
    REQUIRE(g.size() == 1);
  }

  SECTION("Not enough space") {
    Vehicle v3("eh1234hm", "No desc", 5);
    REQUIRE_THROWS(g.insert(v3));

    REQUIRE(g.size() == 1);
  }

  SECTION("Clear garage") {
    g.clear();
    REQUIRE(g.empty());
  }

  SECTION("Erase vehicle if exists") {
    g.erase("sa1994as");
    REQUIRE(g.empty());
  }

  SECTION("Erase vehicle if it does not exist") {
    REQUIRE_NOTHROW(g.erase("t3333aa"));
    REQUIRE_FALSE(g.empty());
  }
  SECTION("Erase swaps last") {
    g.insert(v2);
    REQUIRE_NOTHROW(g.at(1));

    g.erase("sa1994as");

    REQUIRE(g.size() == 1);

    REQUIRE(&g.at(0) == &v2);
    REQUIRE_THROWS(g.at(1));
  }

  SECTION("Find vehicle") {
    REQUIRE(g.find("v2001tx") == nullptr);

    g.insert(v2);

    REQUIRE(g.find("v2001tx") == &v2);
  }
}