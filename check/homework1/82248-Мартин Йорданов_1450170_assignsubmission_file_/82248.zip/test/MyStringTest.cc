#define CATCH_CONFIG_MAIN
#include "MyString.hh"
#include "catch.hh"

TEST_CASE("MyString functionality", "[MyString]") {

  MyString s("Hello World");

  REQUIRE_FALSE(s.empty());

  SECTION("size gives correct answear") { REQUIRE(s.size() == 11); }
  SECTION("Test front() does not change size") {
    std::size_t size = s.size();
    char c = s.front();

    REQUIRE(c == 'H');
    REQUIRE(s.size() == size);
  }
  SECTION("Test back() does not change size") {
    std::size_t size = s.size();
    char c = s.back();

    REQUIRE(c == 'd');

    REQUIRE(s.size() == size);
  }
  SECTION("Test push_back() does not change size") {
    std::size_t size = s.size();
    s.push_back('!');

    REQUIRE(s.back() == '!');
    REQUIRE(s.size() == size + 1);
  }
  SECTION("Test pop_back() does not change size") {
    std::size_t size = s.size();
    s.pop_back();

    REQUIRE(s.size() == size - 1);
  }

  SECTION("at() needs to result in the same thing as operator[]") {
    REQUIRE(!s.empty());
    REQUIRE(s.at(1) == 'e');
    REQUIRE(s[1] == 'e');
  }

  SECTION("at() needs to throw for negative, operator[] does not") {
    REQUIRE_THROWS_AS(s.at(-1), std::out_of_range);
    REQUIRE_NOTHROW(s[-11]);
  }

  SECTION("at() needs to throw for big index, operator[] does not") {
    REQUIRE_THROWS_AS(s.at(100), std::out_of_range);
    REQUIRE_NOTHROW(s[111]);
  }

  SECTION("test clear()") {
    REQUIRE_FALSE(s.empty());
    s.clear();
    REQUIRE(s.empty());
  }

  SECTION("test operator==()") {
    auto s2 = MyString("Hello World");

    REQUIRE(s2 == s);
  }
  SECTION("test operator<()") {
    auto s2 = MyString("Hello World!");

    REQUIRE(s < s2);
    REQUIRE_FALSE(s == s2);
  }

  SECTION("test c_str()") {
    std::size_t size = s.size();
    auto str = s.c_str();

    REQUIRE(str[size] == '\0');
  }
}