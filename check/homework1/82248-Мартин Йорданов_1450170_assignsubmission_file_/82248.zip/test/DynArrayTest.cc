#define CATCH_CONFIG_MAIN
#include "DynArray.hh"
#include "catch.hh"

TEST_CASE("DynArray functionality", "[DynArray]") {

  DynArray<int> v(5);

  REQUIRE(v.empty());
  REQUIRE(v.capacity() >= 5);

  SECTION("resizing bigger changes size and capacity") {
    v.resize(10);

    REQUIRE(v.empty());
    REQUIRE(v.capacity() >= 10);
  }
  SECTION("resizing smaller breaks on assert") {
    v.push_back(7);
    REQUIRE_THROWS_AS(v.resize(0), std::invalid_argument);
  }
  SECTION("push_back element") {
    REQUIRE(v.empty());

    v.push_back(10);

    REQUIRE_FALSE(v.empty());
  }
  SECTION("pop_back element") {
    REQUIRE(v.empty());

    v.push_back(10);
    v.pop_back();

    REQUIRE(v.empty());
  }

  SECTION("at() needs to result in the same thing as operator[]") {
    REQUIRE(v.empty());

    v.push_back(10);
    v.push_back(20);
    v.push_back(30);

    REQUIRE(v.at(1) == 20);
    REQUIRE(v[1] == 20);
  }

  SECTION("at() needs to throw for negative, operator[] does not") {
    REQUIRE(v.empty());

    v.push_back(10);
    v.push_back(20);
    v.push_back(30);

    REQUIRE_THROWS_AS(v.at(-1), std::out_of_range);
    REQUIRE_NOTHROW(v[-11]);
  }

  SECTION("at() needs to throw for bigger than size, operator[] does not") {
    REQUIRE(v.empty());

    v.push_back(10);
    v.push_back(20);
    v.push_back(30);

    REQUIRE_THROWS_AS(v.at(7), std::out_of_range);
    REQUIRE_NOTHROW(v[9]);
  }
}