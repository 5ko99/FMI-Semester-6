#include "Vehicle.hh"

Vehicle::Vehicle(const char* registration, const char* description,
                 std::size_t space)
    : _registration(registration), _description(description),
      _occupiedParkingSpaces(space) {}

const char* Vehicle::registration() const { return _registration.c_str(); }
const char* Vehicle::description() const { return _description.c_str(); }
std::size_t Vehicle::space() const { return _occupiedParkingSpaces; }

std::ostream& operator<<(std::ostream& out, const Vehicle& v) {
  out << "{ registration: " << v.registration()
      << "\n\tdescription: " << v.description() << ",\n\tspace: " << v.space()
      << "}";

  return out;
}