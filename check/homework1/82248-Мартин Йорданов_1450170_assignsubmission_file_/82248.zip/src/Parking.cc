#include "Garage.hh"
#include "MyString.hh"
#include "Vehicle.hh"

void freeMem(Garage& g);
void printOptions();
void addVehicleToGarage(Garage& g);
void removeVehicleFromGarage(Garage& g);

int main(int argc, char const* argv[]) {
  Garage g;

  std::cout << "Enter capacity for Garage: ";
  std::cin >> g;
  char option;
  do {
    printOptions();
    std::cin >> option;
    switch (option) {
    case 'a':
      addVehicleToGarage(g);
      break;

    case 'd':
      removeVehicleFromGarage(g);
      break;

    case 'p':
      std::cout << g;
    }
  } while (option != 'q');

  freeMem(g);

  return 0;
}

void freeMem(Garage& g) {
  for (size_t i = 0; i < g.size(); ++i)
    delete &g.at(i);
}

void printOptions() {
  std::cout << "a -> Add vehicle\n"
            << "d -> Delete vehicle\n"
            << "p -> Print garage content\n"
            << "q -> Quit\n"
            << "Type cmd: ";
}

void addVehicleToGarage(Garage& g) {
  std::size_t space;

  std::cout << "Enter space occupied by vehicle: ";
  std::cin >> space;

  char desc[101], reg[21];
  std::cout << "Enter registration(max 20), then description(max 100): ";

  std::cin >> reg;
  std::cin.ignore(1);
  std::cin.getline(desc, 100);

  Vehicle* v = new Vehicle(reg, desc, space);
  try {
    g.insert(*v);
  } catch (const std::exception& e) {
    std::cerr << e.what() << '\n';
    delete v;
  }
}

void removeVehicleFromGarage(Garage& g) {
  std::cout << "Enter registration to be removed: ";

  char reg[21];
  std::cin >> reg;

  const Vehicle* v = g.find(reg);

  g.erase(reg);

  delete v;
}
