#include "MyString.hh"
#include "DynArray.hh"
#include <cassert>
#include <cstring>

MyString::MyString(const char* str) {
  std::size_t len = strlen(str);
  _data = DynArray<char>();

  for (size_t i = 0; i <= len; ++i)
    _data.push_back(str[i]);
}

char& MyString::at(size_t pos) { return _data.at(pos); }

const char& MyString::at(std::size_t pos) const { return _data.at(pos); }

char& MyString::operator[](std::size_t pos) {
  // assert(pos < size());
  return _data[pos];
}

const char& MyString::operator[](std::size_t pos) const {
  // assert(pos < size());
  return _data[pos];
}

char& MyString::front() {
  // assert(size());
  return _data[0];
}

const char& MyString::front() const {
  // assert(size());
  return _data[0];
}

char& MyString::back() {
  // assert(size());
  return _data[size() - 1];
}

const char& MyString::back() const {
  // assert(size());
  return _data[size() - 1];
}

std::size_t MyString::size() const { return _data.size() - 1; }

bool MyString::empty() const { return !size(); }

void MyString::clear() {
  _data.clear();
  _data.push_back('\0');
}

void MyString::push_back(char c) {
  _data.pop_back(); // Removes '\0'
  _data.push_back(c);
  _data.push_back('\0');
}
void MyString::pop_back() {
  _data.pop_back(); // Removes '\0'
  _data.pop_back(); // Removes meaningful char
  _data.push_back('\0');
}

MyString& MyString::operator+=(char c) {
  push_back(c);
  return *this;
}

MyString& MyString::operator+=(const MyString& rhs) {
  for (auto&& i : rhs._data) {
    push_back(i);
  }

  return *this;
}

MyString MyString::operator+(char c) const {
  MyString newString(*this);
  newString.push_back(c);
  return newString;
}

MyString MyString::operator+(const MyString& rhs) const {
  MyString newString(*this);

  for (auto&& i : rhs._data) {
    newString.push_back(i);
  }

  return newString;
}

const char* MyString::c_str() const { return _data.data(); }

bool MyString::operator==(const MyString& rhs) const {
  return strcmp(_data.data(), rhs._data.data()) == 0;
}

bool MyString::operator<(const MyString& rhs) const {
  return strcmp(_data.data(), rhs._data.data()) < 0;
}
