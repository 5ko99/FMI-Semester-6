#include "Garage.hh"
#include <Vehicle.hh>
#include <cstring>
#include <stdexcept>

Garage::Garage(std::size_t size) : _capacity(size) {}
Garage::Garage() {}

void Garage::insert(Vehicle& v) {
  if (_capacity < _occupiedSpace + v.space())
    throw std::length_error("Vehicle too big!");

  else if (find(v.registration()) != nullptr)
    throw std::logic_error("Vehicle already in garage!");

  _storage.push_back(&v);
  _occupiedSpace += v.space();
}

void Garage::erase(const char* registration) {
  const Vehicle* v = find(registration);

  if (v == nullptr)
    return;

  for (size_t i = 0; i < _storage.size(); i++) {
    if (!strcmp(registration, _storage[i]->registration())) {
      _occupiedSpace -= _storage[i]->space();
      _storage[i] = _storage.back();
      _storage.pop_back();
    }
  }
}

const Vehicle& Garage::at(std::size_t pos) const { return *_storage.at(pos); }

const Vehicle& Garage::operator[](std::size_t pos) const {
  return *_storage[pos];
}

bool Garage::empty() const { return _storage.empty(); }

std::size_t Garage::size() const { return _storage.size(); }

void Garage::clear() { _storage.clear(); }

const Vehicle* Garage::find(const char* registration) const {
  const Vehicle* v = nullptr;
  for (size_t i = 0; i < _storage.size(); i++) {
    if (!strcmp(registration, _storage[i]->registration()))
      v = _storage[i];
  }

  return v;
}

std::istream& operator>>(std::istream& in, Garage& g) {
  std::size_t cap;
  in >> cap;

  g = Garage(cap);
  return in;
}
std::ostream& operator<<(std::ostream& out, const Garage& g) {
  out << "{ capacity: " << g._capacity
      << ", spaceLeft: " << g._capacity - g._occupiedSpace << ",\n";

  for (size_t i = 0; i < g._storage.size(); i++) {
    out << i << ": " << g[i] << ",\n";
  }
  out << "}\n";

  return out;
}