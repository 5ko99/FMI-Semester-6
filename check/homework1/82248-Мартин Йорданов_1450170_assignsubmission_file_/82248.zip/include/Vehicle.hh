#ifndef VEHICLE_H
#define VEHICLE_H
#include "MyString.hh"
#include <iostream>

class Vehicle {
  MyString _registration, _description;
  std::size_t _occupiedParkingSpaces;

  friend std::ostream& operator<<(std::ostream& out, const Vehicle& v);
  //   Vehicle() = delete;
public:
  Vehicle(const char* registration, const char* description, std::size_t space);

  const char* registration() const;
  const char* description() const;
  std::size_t space() const;
};

#endif