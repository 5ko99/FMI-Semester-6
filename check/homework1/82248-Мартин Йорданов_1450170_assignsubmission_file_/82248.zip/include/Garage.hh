#ifndef GARAGE_H
#define GARAGE_H

#include "DynArray.hh"
#include "Vehicle.hh"
#include <cstring>

class Garage {
  std::size_t _capacity, _occupiedSpace = 0;
  DynArray<const Vehicle*> _storage;
  friend std::ostream& operator<<(std::ostream& out, const Garage& g);
  friend std::istream& operator>>(std::istream& in, Garage& g);

public:
  Garage();
  Garage(std::size_t size);
  void insert(Vehicle& v);
  void erase(const char* registration);
  const Vehicle& at(std::size_t pos) const;
  const Vehicle& operator[](std::size_t pos) const;
  bool empty() const;
  std::size_t size() const;
  void clear();
  const Vehicle* find(const char* registration) const;
};

#endif