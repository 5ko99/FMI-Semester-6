#ifndef MY_ScharRING_H
#define MY_ScharRING_H
#include "DynArray.hh"
#include <cstddef>

class MyString {
  DynArray<char> _data;

public:
  MyString(const char* str);
  char& at(std::size_t pos);
  const char& at(std::size_t pos) const;

  char& operator[](std::size_t pos);
  const char& operator[](std::size_t pos) const;

  char& front();
  const char& front() const;
  char& back();
  const char& back() const;

  std::size_t size() const;
  bool empty() const;
  void clear();

  void push_back(char c);
  void pop_back();

  MyString& operator+=(char c);
  MyString& operator+=(const MyString& rhs);

  MyString operator+(char c) const;
  MyString operator+(const MyString& rhs) const;

  const char* c_str() const;

  bool operator==(const MyString& rhs) const;
  bool operator<(const MyString& rhs) const;
};

#endif