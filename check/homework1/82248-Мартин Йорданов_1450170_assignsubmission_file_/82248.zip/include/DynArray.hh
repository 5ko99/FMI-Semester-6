#ifndef DYN_ARRAY_H
#define DYN_ARRAY_H

#include <cstddef>
#include <stdexcept>
template <class T> class DynArray {
  std::size_t _capacity = 0, _size = 0;

  T* _data = nullptr;

public:
  DynArray() {}
  ~DynArray() { delete[] _data; }
  DynArray(const DynArray<T>& other) {
    DynArray(other._capacity);

    for (size_t i = 0; i < other._size; ++i)
      push_back(other._data[i]);
    _size = other._size;
  }

  DynArray(std::size_t capacity) : _capacity(capacity) {
    _data = new T[_capacity];
  }

  DynArray<T>& operator=(const DynArray<T>& other) {
    if (this != &other) {
      clear();
      resize(other._capacity);

      for (size_t i = 0; i < other._size; ++i)
        push_back(other._data[i]);
    }
    return *this;
  }

  T& at(std::size_t pos) {
    return const_cast<T&>(const_cast<const DynArray*>(this)->at(pos));
  }
  const T& at(std::size_t pos) const {
    if (pos >= _size || pos < 0)
      throw std::out_of_range("array index");

    return _data[pos];
  }

  T& operator[](std::size_t pos) {
    return const_cast<T&>(const_cast<const DynArray*>(this)->operator[](pos));
  }
  const T& operator[](std::size_t pos) const { return _data[pos]; }

  T& front() { return _data[0]; }
  const T& front() const { return _data[0]; }

  T& back() { return _data[_size - 1]; }
  const T& back() const { return _data[_size - 1]; }

  std::size_t size() const { return _size; }
  std::size_t capacity() const { return _capacity; }

  bool empty() const { return !_size; }
  void clear() { _size = 0; }

  void push_back(T obj) {
    if (_size == _capacity)
      resize(_capacity * 2 + 1);

    _data[_size++] = obj;
  }
  void pop_back() { --_size; }

  const T* data() const noexcept { return _data; }
  T* data() noexcept { return _data; }

  void erase(std::size_t pos) {
    _data[pos] = _data[_size - 1];
    pop_back();
  }
  void resize(std::size_t n) {
    if (n < _size)
      throw std::invalid_argument("N needs to be bigger than size");
    T* newData = new T[n];

    for (size_t i = 0; i < _size; ++i)
      newData[i] = _data[i];

    delete[] _data;
    _data = newData;
    _capacity = n;
  }

  T* begin() { return _data; }
  const T* begin() const { return _data; }

  T* end() { return _data + _size + 1; }
  const T* end() const { return _data + _size + 1; }
};

#endif