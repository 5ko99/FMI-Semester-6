#ifndef VEHICLE_H_HEADER
#define VEHICLE_H_HEADER
#include "MyString.h"

class Vehicle
{
private:
	MyString regNumber;
	MyString descr;
	std::size_t takenSpace;

public:
	Vehicle(const char* registration, const char* description, std::size_t space);

	const char* registration() const;
	const char* description() const;
	std::size_t space() const;
};
#endif

