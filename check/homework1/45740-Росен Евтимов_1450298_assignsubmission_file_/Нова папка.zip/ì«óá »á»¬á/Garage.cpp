#include "Garage.h"

Garage::Garage(std::size_t size)
{
	this->maxCapacity = size;
	this->regNumbers = new MyString[maxCapacity];
	this->descriptions = new MyString[maxCapacity];
	this->spaceTaken = new std::size_t[maxCapacity];
	this->currentAvailableCapacity = maxCapacity;
	this->currentVehicleNumber = 0;
}

Garage::Garage(const Garage& newGarage)
{
	if (newGarage.regNumbers)
	{
		this->regNumbers = new MyString[newGarage.maxCapacity];
		this->descriptions = new MyString[newGarage.maxCapacity];
		this->spaceTaken = new std::size_t[newGarage.maxCapacity];
		this->currentVehicleNumber = newGarage.currentVehicleNumber;
		this->currentAvailableCapacity = newGarage.currentAvailableCapacity;
		for (int i = 0; i < currentVehicleNumber; i++)
		{
			this->regNumbers[i] = newGarage.regNumbers[i];
			this->descriptions[i] = newGarage.descriptions[i];
			this->spaceTaken[i] = newGarage.spaceTaken[i];
		}
		this->maxCapacity = newGarage.maxCapacity;
	}
	else
	{
		regNumbers = nullptr;
		descriptions = nullptr;
		spaceTaken = nullptr;
		maxCapacity = 0;
		currentVehicleNumber = 0;
		currentAvailableCapacity = 0;
	}
}

Garage& Garage::operator=(const Garage& other)
{
	if (this != &other)
	{
		delete[] this->regNumbers;
		this->regNumbers = nullptr;
		delete[] this->descriptions;
		this->descriptions = nullptr;
		delete[] this->spaceTaken;
		this->spaceTaken = nullptr;

		if (other.regNumbers)
		{
			this->regNumbers = new MyString[other.maxCapacity];
			this->descriptions = new MyString[other.maxCapacity];
			this->spaceTaken = new std::size_t[other.maxCapacity];
			this->currentVehicleNumber = other.currentVehicleNumber;
			this->currentAvailableCapacity = other.currentAvailableCapacity;
			for (int i = 0; i < currentVehicleNumber; i++)
			{
				this->regNumbers[i] = other.regNumbers[i];
				this->descriptions[i] = other.descriptions[i];
				this->spaceTaken[i] = other.spaceTaken[i];
			}
			this->maxCapacity = other.maxCapacity;
		}
		else
		{
			regNumbers = nullptr;
			descriptions = nullptr;
			spaceTaken = nullptr;
			maxCapacity = 0;
			currentVehicleNumber = 0;
			currentAvailableCapacity = 0;
		}
	}
	return *this;
}

Garage::~Garage()
{
	delete[] this->regNumbers;
	delete[] this->descriptions;
	delete[] this->spaceTaken;
}

void Garage::insert(Vehicle& v)
{
	if (currentAvailableCapacity < v.space())
	{
		throw "No space for current vehicle in the garage.";
	}
	
	for (int i = 0; i < this->currentVehicleNumber; i++)
	{
		if (MyString(v.registration()) == regNumbers[i])
		{
			throw "Current vehicle already exists in the garage.";
		}
	}

	this->regNumbers[currentVehicleNumber] = v.registration();
	this->descriptions[currentVehicleNumber] = v.description();
	this->spaceTaken[currentVehicleNumber] = v.space();
	this->currentVehicleNumber++;
	this->currentAvailableCapacity -= v.space();
}

void Garage::erase(const char* registration)
{
	
}

const Vehicle& Garage::at(std::size_t pos) const
{
	if (currentVehicleNumber < pos)
	{
		throw std::out_of_range("No vehicle on that position.");
	}
	else
	{
		Vehicle *v = new Vehicle(regNumbers[pos].c_str(), descriptions[pos].c_str(), spaceTaken[pos]);
		return *v;
	}
}

const Vehicle& Garage::operator[](std::size_t pos) const
{
	assert (currentVehicleNumber > pos);
	return at(pos);
}

bool Garage::empty() const
{
	if (currentVehicleNumber == 0)
	{
		return true;
	}

	return false;
}

std::size_t Garage::size() const
{
	return currentVehicleNumber;
}

void Garage::clear()
{
	delete[] this->regNumbers;
	delete[] this->descriptions;
	delete[] this->spaceTaken;
	this->regNumbers = nullptr;
	this->descriptions = nullptr;
	this->spaceTaken = nullptr;
	this->currentVehicleNumber = 0;
	this->currentAvailableCapacity = maxCapacity;
}

const Vehicle* Garage::find(const char* registration) const
{
	for (int i = 0; i < currentVehicleNumber; i++)
	{
		if (regNumbers[i].c_str() == registration)
		{
			return new Vehicle(regNumbers[i].c_str(), descriptions[i].c_str(), spaceTaken[i]);
		}
	}
}