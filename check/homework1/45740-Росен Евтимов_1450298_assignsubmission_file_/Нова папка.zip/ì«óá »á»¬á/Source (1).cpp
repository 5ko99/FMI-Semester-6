#include <iostream>
#include "MyString.h"
#include "Vehicle.h"

int main()
{

	MyString* m = new MyString("pls work");
	std::cout << m->c_str();
	std::cout << std::endl;

	const char a = m->at(2);

	std::cout << a;
	std::cout << std::endl;

	MyString newStr = "Magiqta na Ani";
	std::cout << newStr.c_str();
	std::cout << std::endl;

	MyString copyc(newStr);
	std::cout << copyc.c_str();
	std::cout << std::endl;

	copyc += "!";
	std::cout << copyc.c_str();
	std::cout << std::endl;

	copyc.pop_back();
	std::cout << copyc.c_str();
	std::cout << std::endl;

	std::cout << copyc.back();
	std::cout << std::endl;

	std::cout << copyc.front();
	std::cout << std::endl;

	return 0;
}