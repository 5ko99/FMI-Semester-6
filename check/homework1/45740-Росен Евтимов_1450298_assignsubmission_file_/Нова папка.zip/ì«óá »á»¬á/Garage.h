#ifndef GARAGE_H_HEADER
#define GARAGE_H_HEADER
#include "Vehicle.h"

class Garage
{
private:
	std::size_t maxCapacity;
	MyString* regNumbers;
	MyString* descriptions;
	std::size_t* spaceTaken;
	std::size_t currentVehicleNumber;
	std::size_t currentAvailableCapacity;

public:
	Garage(std::size_t size);
	Garage(const Garage& newGarage);
	Garage& operator=(const Garage& other);
	~Garage();

    void insert(Vehicle& v);
	void erase(const char* registration);
	const Vehicle& at(std::size_t pos) const;
	const Vehicle& operator[](std::size_t pos) const;
	bool empty() const;
	std::size_t size() const;
	void clear();
	const Vehicle* find(const char* registration) const;
};

#endif