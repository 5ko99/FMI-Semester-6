#include "Vehicle.h"


	Vehicle::Vehicle(const char* registration, const char* description, std::size_t space)
	{
		this->regNumber = registration;
		this->descr = description;
		this->takenSpace = space;
	}

	const char* Vehicle::registration() const
	{
		return this->regNumber.c_str();
	}

	const char* Vehicle::description()const
	{
		return this->descr.c_str();
	}

	std::size_t Vehicle::space() const
	{
		return this->takenSpace;
	}
