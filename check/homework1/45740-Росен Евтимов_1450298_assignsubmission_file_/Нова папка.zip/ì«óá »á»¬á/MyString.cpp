#include "MyString.h"


MyString::MyString()
{
    this->string = nullptr;
    this->length = 0;
}

MyString::MyString(const MyString& mystring)
{
    if (mystring.string)
    {
        this->string = new char[mystring.length + 1];
        strcpy_s(this->string, mystring.length + 1, mystring.string);
        length = mystring.length;
    }
    else
    {
        string = nullptr;
        length = 0;
    }
}

MyString::~MyString()
{
    if (string)
    {
        delete[] string;
    }
}

MyString& MyString::operator=(const MyString& other)
{
    if (this != &other)
    {
        delete[] string;
        string = nullptr;

        if (other.string)
        {
            this->string = new char[other.length + 1];
            strcpy_s(this->string, other.length + 1, other.string);
            length = other.length;
        }
    }

    return *this;

}

MyString::MyString(const char* str)
{
    if (str)
    {
        this->length = strlen(str);
        this->string = new char[length + 1];
        strcpy_s(this->string, length + 1, str);
    }
    else
    {
        this->string = nullptr;
        this->length = 0;
    }
}

char& MyString::at(std::size_t pos)
{
    if (length <= pos)
    {
        throw std::out_of_range("Index out of range");
    }
    return this->string[pos];
}

const char& MyString::at(std::size_t pos) const
{
    return this->at(pos);
}

char& MyString::operator[](std::size_t pos)
{
    assert(length > pos);
    return at(pos);
}

const char& MyString::operator[](std::size_t pos) const
{
    return this->operator[](pos);
}

char& MyString::front()
{
    assert(this->length > 0);
    return at(0);
}

const char& MyString::front() const
{
    return this->front();
}

char& MyString::back()
{
    assert(this->length > 0);
    return at(length - 1);
}

const char& MyString::back() const
{
    return this->back();
}

bool MyString::empty() const
{
    if (length == 0)
    {
        return true;
    }

    return false;
}

std::size_t MyString::size() const
{
    return length;
}

void MyString::clear()
{
    delete[] this->string;
    this->string = nullptr;
    length = 0;
}

void MyString::push_back(char c)
{
    char* buffer = new char[length + 1];
    if (buffer != nullptr)
    {
        if (this->string != nullptr)
        {
            strcpy_s(buffer, length, this->string);
        }
        buffer[length] = c;
        this->string = nullptr;
        this->string = new char[length + 1];
        strcpy_s(this->string, length + 1, buffer);
    }
}

void MyString::pop_back()
{
    assert(length > 0);
    char* buffer = new char[length];
    this->string[length - 1] = '\0';
    strcpy_s(buffer, length, this->string);
    this->string = nullptr;
    this->string = new char[length];
    strcpy_s(this->string, length, buffer);
    this->length = length - 1;
}

MyString& MyString::operator+=(char c)
{
    push_back(c);
    return *this;
}

MyString& MyString::operator+=(const MyString& rhs)
{
    if (this->string == nullptr)
    {
        *this = rhs;
        return *this;
    }
    char* buffer = new char[length + rhs.length + 1]; //mnogo grozno
    if (buffer != nullptr)
    {
        strcpy_s(buffer, length + 1, this->string);
        strcat_s(buffer, length + rhs.length + 1, rhs.string);
        MyString newString(buffer);
        delete[] buffer;
        *this = newString;
    }
    return *this;
}

MyString MyString::operator+(char c) const
{
    //MyString newString(this->string);
    MyString newString = this->string;
    newString += c;
    return newString;
}

MyString MyString::operator+(const MyString& rhs) const
{
    MyString newString = this->string;
    newString += rhs;
    return newString;
}

const char* MyString::c_str() const
{
    return this->string;
}

bool MyString::operator==(const MyString& rhs) const
{
    if (strcmp(this->string, rhs.string) == 0)
    {
        return true;
    }
    return false;
}

bool MyString::operator<(const MyString& rhs) const
{
    if (strcmp(this->string, rhs.string) < 0)
    {
        return true;
    }
    return false;
}