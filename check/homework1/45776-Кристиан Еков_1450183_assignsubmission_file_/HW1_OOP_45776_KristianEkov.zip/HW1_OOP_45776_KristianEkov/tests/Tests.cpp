// Tests.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <windows.h>
#include "../HW1_OOP_45776_KristianEkov/MyString.h"
#include <string>
using namespace std;

bool test_MySting_Default_Constructor_Initializes_Correct_With_EmptyString() {
	// Arrange & Act 
	MyString empty;

	// Assert
	bool result = (empty.c_str()[0] == '\0');

	return result;
}

// case: abc
bool test_MySting_Default_Constructor_Initializes_Correct_With_PassedString() {
	// Arrange & Act 
	MyString str("abc");
	// Assert
	bool result = (str.c_str()[0] == 'a') && (str.c_str()[1] == 'b') && (str.c_str()[2] == 'c') && (str.c_str()[3] == '\0');
	return result;
}

bool test_MyString_at_Should_Return_Correct_Element() {
	// Arrange & Act 
	MyString str("abc");
	// Assert
	bool result = str.at(1) == 'b';

	return result;
}

bool test_MyString_operator_square_brackets_Should_Return_Correct_Element() {
	// Arrange & Act 
	MyString str("abc");
	// Assert
	bool result = str[1] == 'b';

	return result;
}

bool test_MyString_front_Should_return_Correct_Element() {
	// Arrange & Act 
	MyString str("abc");
	// Assert
	bool result = str.front() == 'a';

	return result;
}

bool test_MyString_back_Should_return_Correct_Element() {
	// Arrange & Act 
	MyString str("abc");
	// Assert
	bool result = str.back() == 'c';

	return result;
}

bool test_MyString_empty_Should_return_false_when_sting_is_not_empty() {
	// Arrange & Act 
	MyString str("abc");
	// Assert
	bool result = !str.empty();

	return result;
}

bool test_MyString_size_Should_return_correct_size() {
	// Arrange & Act 
	MyString str("abc");
	// Assert
	bool result = str.size() == 3;

	return result;
}

bool test_MyString_clear_Should_make_string_empty() {
	// Arrange & Act 
	MyString str("abc");
	str.clear();
	// Assert
	bool result = str[0] == '\0';

	return result;
}

bool test_MyString_pop_back_Should_remove_last_element() {
	// Arrange & Act 
	MyString str("abc");
	str.pop_back();
	// Assert
	bool result = str[2] == '\0';

	return result;
}

bool result_test_MySting_Default_Constructor_Initializes_Correct_With_EmptyStrin = test_MySting_Default_Constructor_Initializes_Correct_With_EmptyString();
bool result_test_MySting_Default_Constructor_Initializes_Correct_With_PassedString = test_MySting_Default_Constructor_Initializes_Correct_With_PassedString();
bool result_test_MyString_at_Should_Return_Correct_Element = test_MyString_at_Should_Return_Correct_Element();
bool result_test_MyString_operator_square_brackets_Should_Return_Correct_Element = test_MyString_operator_square_brackets_Should_Return_Correct_Element();
bool result_test_MyString_front_Should_return_Correct_Element = test_MyString_front_Should_return_Correct_Element();
bool result_test_MyString_back_Should_return_Correct_Element = test_MyString_back_Should_return_Correct_Element();
bool result_test_MyString_empty_Should_return_false_when_sting_is_not_empty = test_MyString_empty_Should_return_false_when_sting_is_not_empty();
bool result_test_MyString_size_Should_return_correct_size = test_MyString_size_Should_return_correct_size();
bool result_test_MyString_clear_Should_make_string_empty = test_MyString_clear_Should_make_string_empty();
bool result_test_MyString_pop_back_Should_remove_last_element = test_MyString_pop_back_Should_remove_last_element();


void WriteSuccessMsg(const char* testName) {
	cout << testName << endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 2);
	cout << "Passed!" << endl << endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
}

void WriteFailMsg(const char* testName) {
	cout << testName << endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 4);
	cout << "Failed!" << endl << endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
}

int main()
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 62);
	cout << "MySting Tests" << endl;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);

	if (result_test_MySting_Default_Constructor_Initializes_Correct_With_EmptyStrin)
	{
		WriteSuccessMsg("test_MySting_Default_Constructor_Initializes_Correct_With_EmptyString");
	}
	else {
		WriteFailMsg("test_MySting_Default_Constructor_Initializes_Correct_With_EmptyString");
	}

	if (result_test_MySting_Default_Constructor_Initializes_Correct_With_PassedString)
	{
		WriteSuccessMsg("test_MySting_Default_Constructor_Initializes_Correct_With_PassedString");
	}
	else {
		WriteFailMsg("test_MySting_Default_Constructor_Initializes_Correct_With_PassedString");
	}

	if (result_test_MyString_at_Should_Return_Correct_Element)
	{
		WriteSuccessMsg("test_MySting_Default_Constructor_Initializes_Correct_With_PassedString");
	}
	else {
		WriteFailMsg("test_MySting_Default_Constructor_Initializes_Correct_With_PassedString");
	}

	if (result_test_MyString_operator_square_brackets_Should_Return_Correct_Element)
	{
		WriteSuccessMsg("test_MyString_operator_square_brackets_Should_Return_Correct_Element");
	}
	else {
		WriteFailMsg("test_MyString_operator_square_brackets_Should_Return_Correct_Element");
	}

	if (result_test_MyString_front_Should_return_Correct_Element)
	{
		WriteSuccessMsg("test_MyString_front_Should_return_Correct_Element");
	}
	else {
		WriteFailMsg("test_MyString_front_Should_return_Correct_Element");
	}

	if (result_test_MyString_back_Should_return_Correct_Element)
	{
		WriteSuccessMsg("test_MyString_back_Should_return_Correct_Element");
	}
	else {
		WriteFailMsg("test_MyString_back_Should_return_Correct_Element");
	}

	if (result_test_MyString_empty_Should_return_false_when_sting_is_not_empty)
	{
		WriteSuccessMsg("test_MyString_empty_Should_return_false_when_sting_is_not_empty");
	}
	else {
		WriteFailMsg("test_MyString_empty_Should_return_false_when_sting_is_not_empty");
	}

	if (result_test_MyString_size_Should_return_correct_size)
	{
		WriteSuccessMsg("test_MyString_size_Should_return_correct_size");
	}
	else {
		WriteFailMsg("test_MyString_size_Should_return_correct_size");
	}

	if (result_test_MyString_clear_Should_make_string_empty)
	{
		WriteSuccessMsg("test_MyString_clear_Should_make_string_empty");
	}
	else {
		WriteFailMsg("test_MyString_clear_Should_make_string_empty");
	}

	if (result_test_MyString_pop_back_Should_remove_last_element)
	{
		WriteSuccessMsg("test_MyString_pop_back_Should_remove_last_element");
	}
	else {
		WriteFailMsg("test_MyString_pop_back_Should_remove_last_element");
	}
}