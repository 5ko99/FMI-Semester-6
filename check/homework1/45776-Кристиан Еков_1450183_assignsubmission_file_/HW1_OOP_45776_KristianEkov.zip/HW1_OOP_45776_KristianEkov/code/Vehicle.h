#pragma once
#include "MyString.h"
class Vehicle
{
	MyString Description;
	MyString RegistrationNumber;
	std::size_t VehicleSize;
public:
	Vehicle(const char* registration, const char* description, std::size_t space);

	const char* registration() const;

	const char* description() const;

	std::size_t space() const;
};

