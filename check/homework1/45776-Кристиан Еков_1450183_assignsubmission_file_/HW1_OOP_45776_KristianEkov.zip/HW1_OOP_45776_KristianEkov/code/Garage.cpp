#include "Garage.h"

Garage::Garage(std::size_t size)
{
	Vehicles = new Vehicle * [size];
	Capacity = size;
	UsedSpaces = 0;
	NumberOfVehicles = 0;
}

void Garage::insert(Vehicle& v)
{
	if ((v.space() + UsedSpaces) > Capacity)
	{
		// cant enter
		return;
	}

	int index = -1;
	for (size_t i = 0; i < NumberOfVehicles; i++)
	{
		if (strcmp(v.registration() ,Vehicles[i]->registration()))
		{
			index = i;
			break;
		}
	}

	if (index > -1) {
		// cant enter
		return;
	}
	else {
		Vehicles[NumberOfVehicles] = &v;
		++NumberOfVehicles;
		UsedSpaces += v.space();
	}
}

void Garage::erase(const char* registration)
{
	MyString reg(registration);
	int index = -1;
	for (size_t i = 0; i < NumberOfVehicles; i++)
	{
		MyString curentReg(Vehicles[i]->registration());
		if (curentReg == reg)
		{
			index = i;
			break;
		}
	}
	if (index > -1) {
		Vehicles[index] = nullptr;
		Vehicles[index] = Vehicles[NumberOfVehicles - 1];
		Vehicles[NumberOfVehicles - 1] = nullptr;
		--NumberOfVehicles;
	}
}

const Vehicle& Garage::at(std::size_t pos) const
{
	return  *Vehicles[pos];
}

bool Garage::empty() const
{
	if (NumberOfVehicles == 0)
	{
		return true;
	}
	return false;
}

std::size_t Garage::size() const
{
	return NumberOfVehicles;
}

void Garage::clear()
{
	for (size_t i = 0; i < NumberOfVehicles; i++)
	{
		Vehicles[i] = nullptr;
	}
	NumberOfVehicles = 0;
	UsedSpaces = 0;
}

const Vehicle* Garage::find(const char* registration) const
{
	int index = -1;
	for (size_t i = 0; i < NumberOfVehicles; i++)
	{
		const char* reg = Vehicles[i]->registration();
		if (strcmp(registration,reg ))
		{
			index = i;
			break;
		}
	}
	if (index > -1) {
		return Vehicles[index];
	}
	return nullptr;
}
