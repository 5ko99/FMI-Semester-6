#include "Vehicle.h"

Vehicle::Vehicle(const char* registration, const char* description, std::size_t space)
{
	RegistrationNumber = registration;
	Description = MyString(description);
	VehicleSize = space;
}

const char* Vehicle::registration() const
{
	return RegistrationNumber.c_str();
}

const char* Vehicle::description() const
{
	return Description.c_str();
}

std::size_t Vehicle::space() const
{
	return VehicleSize;
}
