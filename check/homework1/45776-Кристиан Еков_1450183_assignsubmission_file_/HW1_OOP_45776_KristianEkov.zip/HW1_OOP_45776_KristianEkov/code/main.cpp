#include <iostream>
#include "Vehicle.h"
#include "Garage.h"
using namespace std;
void Run();

int main() {

	Run();
	return 0;
}

void DisplayMenu(bool createdG, int entered) {
	if (!createdG)
	{
		cout << "To Create Garage press 1" << endl;
	}
	if (createdG)
	{
		cout << "To Enter Vehicle into Garage press 2" << endl;
	}

	if (createdG && (entered > 0))
	{
		cout << "To remove all vehicles in garage press 3" << endl;
		cout << "To remove specific vehicle press 4" << endl;
	}

	cout << "To exit program press 5" << endl << endl;

}

void Run() {
	Garage g(0);
	char line[1024];
	int capacity = 0;
	int entered = 0;
	bool createdG = false;

	while (true)
	{
		DisplayMenu(createdG, entered);
		cin >> line;
		if (line[0] == '1')
		{
			cout << "Enter garage capacity: ";
			cin >> capacity;

			g = Garage(capacity);
			cout << "You now have a garage with " << capacity << " spaces" << endl << endl;
			createdG = true;
		}

		if (line[0] == '2')
		{
			cout << "Enter Vehicle data" << endl;

			cout << "Enter Vehicle registration" << endl;
			char* reg = new char[1]{ '\0' };
			cin >> reg;

			cout << "Enter Vehicle description" << endl;
			char* description = new char[1]{ '\0' };
			cin >> description;

			cout << "Enter Vehicle size" << endl;
			size_t size;
			cin >> size;
			cout << endl;
			Vehicle v(reg, description, size);

			const Vehicle* vFind = g.find(reg);
			if (vFind != nullptr)
			{
				cout << "Vehicle already in Garage!" << endl;
			}
			else {
				if ((entered + size) <= capacity)
				{
					g.insert(v);
					++entered;

					if (g.size() > 0)
					{
						cout << "Garage now has " << entered << " vehicles " << endl;
						for (size_t i = 0; i < entered; i++)
						{
							Vehicle vh = g.at(i);
							int spaceNumber = i + 1;
							cout << "at space " << spaceNumber << " " << vh.registration() << " " << vh.description() << " " << vh.space() << endl;
						}
						cout << endl;
					}
				}
				else {
					cout << "Not enough space for current vehicle" << endl;
					cout << "Only " << (capacity - entered) << " spaces left" << endl;
				}
			}
		}

		if (line[0] == '3') {
			g.clear();
			entered = 0;
			cout << "Garage now has " << entered << " vehicles " << endl;
		}

		if (line[0] == '4') {
			cout << "Enter Vehicle registration" << endl;
			char* reg = new char[1]{ '\0' };
			cin >> reg;
			g.erase(reg);
			--entered;
			cout << "Vehicle with registration " << reg << " left!" << endl;
			if (g.size() > 0)
			{
				cout << "Garage now has " << entered << " vehicles " << endl;
				for (size_t i = 0; i < entered; i++)
				{
					Vehicle vh = g.at(i);
					int spaceNumber = i + 1;
					cout << "at space " << spaceNumber << " " << vh.registration() << " " << vh.description() << " " << vh.space() << endl;
				}
				cout << endl;
			}
			else {
				cout << "Garage is now empty free spaces " << capacity << endl;
			}
		}

		if (line[0] == '5')
		{
			cout << "Parking Employee Apu says : Thank you come again!" << endl;
			return;
		}
	}
}