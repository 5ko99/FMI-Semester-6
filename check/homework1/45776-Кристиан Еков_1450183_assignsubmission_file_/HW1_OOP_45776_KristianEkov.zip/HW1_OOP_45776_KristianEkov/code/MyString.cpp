#include "MyString.h"
#include <iostream>

MyString::MyString()
{
	StringBody = new char[1];
	StringBody[0] = '\0';
	Length = 0;
}

MyString::MyString(const char* str)
{
	copyString(str);
}

MyString::~MyString()
{
	//delete[]StringBody;
}

char& MyString::at(std::size_t pos)
{
	if (pos >= Length)
	{
		std::out_of_range;
	}
	return StringBody[pos];
}

const char& MyString::at(std::size_t pos) const
{
	return StringBody[pos];;
}

char& MyString::operator[](std::size_t pos)
{
	return at(pos);
}

const char& MyString::operator[](std::size_t pos) const
{
	return at(pos);
}

char& MyString::front()
{
	return at(0);
}

const char& MyString::front() const
{
	return at(0);
}

char& MyString::back()
{
	return at(Length - 1);
}

const char& MyString::back() const
{
	return at(Length - 1);
}

bool MyString::empty() const
{
	if (Length == 0)
	{
		return true;
	}
	return false;
}

std::size_t MyString::size() const
{
	return Length;
}

void MyString::clear()
{
	delete[] StringBody;
	StringBody = new char[1]{ '\0' };
	Length = 0;
}

void MyString::pop_back()
{
	StringBody[Length - 1] = '\0';
	--Length;
}

MyString& MyString::operator+=(const MyString& rhs)
{
	int newLength = Length + rhs.size();
	char* concatenated = new char[newLength + 1];

	int writeindex = 0;

	for (size_t i = 0; i < Length; ++i)
	{
		concatenated[writeindex] = StringBody[i];
		++writeindex;
	}

	for (size_t i = 0; i < rhs.size(); ++i)
	{
		concatenated[writeindex] = rhs.StringBody[i];
		++writeindex;
	}

	concatenated[newLength] = '\0';

	delete[] StringBody;
	StringBody = concatenated;
	Length = newLength;

	return *this;
}

MyString& MyString::operator=(const MyString& rhs)
{
	if (this == &rhs)
		return *this;


	int newSize = rhs.size();
	char* buffer = new char[newSize + 1];
	for (size_t i = 0; i < newSize; i++)
	{
		buffer[i] = rhs.StringBody[i];
	}
	buffer[newSize] = '\0';
	delete[]StringBody;
	StringBody = buffer;
	Length = newSize;
	return *this;
}

const char* MyString::c_str() const
{
	return StringBody;
}

bool MyString::operator==(const MyString& rhs) const
{
	if (Length != rhs.Length)
	{
		return false;
	}


	if (!strcmp(this->StringBody, rhs.StringBody))
	{
		return false;
	}

	return true;
}

bool MyString::operator<(const MyString& rhs) const
{
	int i = 0;
	while (StringBody[i] && StringBody[i] == rhs.StringBody[i])
	{
		++i;
	}

	int res = StringBody[i] - rhs.StringBody[i];
	if (res < 0)
	{
		return true;
	}

	return false;
}

bool MyString::operator!=(const MyString& rhs) const
{
	if (Length != rhs.Length)
	{
		return true;
	}

	for (size_t i = 0; i < Length; ++i)
	{
		if (StringBody[i] != rhs.StringBody[i])
		{
			return true;
		}
	}

	return false;
}



void MyString::copyString(const char* str)
{
	size_t len = 0;
	while (true)
	{
		if (str[len] == '\0')
			break;
		++len;
	}

	char* buffer = new char[len + 1];
	for (size_t i = 0; i < len; ++i)
	{
		buffer[i] = str[i];
	}
	buffer[len] = '\0';

	delete[]StringBody;
	StringBody = buffer;
	Length = len;
}
