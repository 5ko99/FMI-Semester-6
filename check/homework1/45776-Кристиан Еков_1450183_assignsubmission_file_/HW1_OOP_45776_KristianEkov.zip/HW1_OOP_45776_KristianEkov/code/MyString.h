﻿#pragma once
#include <cstddef>
#include  <stdexcept>

class MyString
{
public:
	MyString();

	MyString(const char* str);

	~MyString();

	// returs sting element at given position
	char& at(std::size_t pos);

	// returs sting element at given position
	const char& at(std::size_t pos) const;

	char& operator[](std::size_t pos);

	const char& operator[](std::size_t pos) const;

	// returns first element of string
	char& front();

	// returns first element of string
	const char& front() const;

	// returns last element of string
	char& back();

	// returns last element of string
	const char& back() const;

	// checks if string is empty
	bool empty() const;

	// returns sting size
	std::size_t size() const;

	// deletes string content
	void clear();

	// removes string last element
	void pop_back();

	// retuns string as cstring style
	const char* c_str() const;

	MyString& operator+=(const MyString& rhs);

	MyString& operator=(const MyString& rhs);

	bool operator==(const MyString& rhs) const;

	bool operator<(const MyString& rhs) const;

	bool operator!=(const MyString& rhs) const;

private:
	char* StringBody = nullptr;

	int Length = 0;

	void copyString(const char* str);
};

