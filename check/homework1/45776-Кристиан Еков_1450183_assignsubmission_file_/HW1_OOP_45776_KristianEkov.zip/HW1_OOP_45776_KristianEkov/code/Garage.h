#pragma once
#include "Vehicle.h"
class Garage
{
	size_t Capacity;
	size_t UsedSpaces;
	Vehicle** Vehicles = nullptr;
	size_t NumberOfVehicles;
public:
	Garage(std::size_t size);

	void insert(Vehicle& v);

	void erase(const char* registration);

	// returns vehicle at given position
	const Vehicle& at(std::size_t pos) const;

	// checks if Garage is empty
	bool empty() const;

	// returns number of vehicles in Garage
	std::size_t size() const;

	// removes all vehicles from Garage
	void clear();

	// returns vehicle at given position, if there isnt one returns nullptr
	const Vehicle* find(const char* registration) const;
};

