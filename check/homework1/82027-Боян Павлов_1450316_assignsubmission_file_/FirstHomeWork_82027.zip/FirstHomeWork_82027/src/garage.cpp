#include <iostream>
#include "garage.h"
#include <cassert>
using std::cout;
using std::endl;
using std::nothrow;

//constructor and destructor
Garage::Garage(std::size_t size)
{
    assert(size > 0);
    capacity = size;
    //maxNumberOfCars = size;
    numberOfCars = 0;
    usedCapacity = 0;
    vehicles = allocateGarageSpace(capacity);
}

Garage::Garage(const Garage &obj)
{
    capacity = obj.capacity;
    usedCapacity = 0;
    numberOfCars = 0;
    vehicles = allocateGarageSpace(capacity);
}

Garage &Garage::operator=(const Garage &obj)
{
    capacity = obj.capacity;
    usedCapacity = 0;
    numberOfCars = 0;
    vehicles = allocateGarageSpace(capacity);
    return *this;
}

Garage::~Garage()
{
    delete[] vehicles;
}

//functions

Vehicle **allocateGarageSpace(unsigned capacity)
{
    try
    {
        Vehicle **vehicles = new Vehicle *[capacity];
        return vehicles;
    }
    catch (const std::bad_alloc &e)
    {
        cout << e.what() << endl;
        return nullptr;
    }
}

//function which adds a car in the garage
//if this car is already in there or if there is a car with the same RPlate throws exception
//function gives strong exception guarantee
void Garage::insert(Vehicle &v)
{
    bool flag = false;
    const char *temp = v.registration();
    const char *tmp2 = nullptr;
    for (int i = 0; i < this->numberOfCars; i++)
    {
        tmp2 = this->vehicles[i]->registration();
        if (strCmp(temp, tmp2) == 0)
        {
            flag = true;
        }
        delete[] tmp2;
        if (flag == true)
        {
            throw std::invalid_argument("This vehicle is already in the garage\n");
        }
    }
    delete[] temp;

    if (flag == true)
    {
        return;
    }

    unsigned objSpace = v.space();
    if (usedCapacity + objSpace > capacity)
    {
        throw std::out_of_range("Not enough space in the garage");
    }
    vehicles[numberOfCars] = &v;
    usedCapacity = usedCapacity + objSpace;
    //capacity = capacity - usedCapacity;
    numberOfCars++;
}

//function which removes car from the garage by RPlate
//function takes the last car of the arr and places it on the removed car
void Garage::erase(const char *registration)
{
    //Do not throw exception if no car is found
    //Find vehicle index by registration
    //move last car in the one that we clear and set the pointer of the last car in the array to nullptr
    const char *tmp2;
    for (int i = 0; i < numberOfCars; i++)
    {
        tmp2 = this->vehicles[i]->registration();
        if (strCmp(registration, tmp2) == 0)
        {
            capacity = capacity + vehicles[i]->space();
            usedCapacity = usedCapacity - vehicles[i]->space();
            vehicles[i] = vehicles[numberOfCars - 1];
            vehicles[numberOfCars - 1] = nullptr;
            cout << "Vehicle with registration:" << registration << " removed\n";
            numberOfCars--;

            break;
        }
    }
}

// function which gives access to a car on possition pos
//function throws exception if the possition is invalid
const Vehicle &Garage::at(std::size_t pos) const
{
    if ((pos - 1) < 0 || (pos - 1) >= numberOfCars)
    {
        throw std::invalid_argument("Invalid possition");
    }
    else
    {
        return *vehicles[pos - 1];
    }
}
//function which gives access to a car on possition pos
//function has no checks in it - it has assert
const Vehicle &Garage::operator[](std::size_t pos) const
{
    assert(pos <= numberOfCars);
    assert(pos > 0);

    return *vehicles[pos];
}
//function which checks if the garage is empty
bool Garage::empty() const
{
    for (int i = 0; i < numberOfCars; i++)
    {
        if (vehicles[i] != nullptr)
        {
            return false;
        }
    }
    return true;
}
//function which gives the exact number of the vehicles in the garage
std::size_t Garage::size() const
{
    return numberOfCars;
}
//function which clears the garage of cars, but the capacity remains unchanged.
void Garage::clear()
{
    for (int i = 0; i < numberOfCars; i++)
    {
        vehicles[i] = nullptr;
    }
    numberOfCars = 0;
    capacity = capacity + usedCapacity;
    usedCapacity = 0;
}
//function which returns a vehicle by it's Rplate
//if there is no such vehicle - returns nullptr
const Vehicle *Garage::find(const char *registration) const
{
    const char *temp = nullptr;
    for (int i = 0; i < numberOfCars; i++)
    {
        temp = vehicles[i]->registration();
        if (strCmp(temp, registration) == 0)
        {
            delete[] temp;
            return vehicles[i];
        }
        delete[] temp;
    }
    return nullptr;
}