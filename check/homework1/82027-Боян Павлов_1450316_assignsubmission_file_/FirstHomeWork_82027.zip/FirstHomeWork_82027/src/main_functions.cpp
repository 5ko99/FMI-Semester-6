#include <iostream>
#include "garage.h"
#include "menu_enum.h"
#include "main_functions.h"
using std::cin;
using std::cout;
using std::endl;
using std::nothrow;
const int MAX_STRING_LENGHT = 60;
const int T_MAX_STRING_LENGHT = 50;

void menu(Garage &myGarage)
{
    int choice;
    Vehicle *vehicle = nullptr;

    do
    {
        cout << "Please enter your choice: " << endl;
        cout << "Enter 1 for: add vehicle in garage: " << endl;
        cout << "Enter 2 for: remove vehicle from garage: " << endl;
        cout << "Enter 3 for: print all vehicles from garage: " << endl;
        cout << "Enter 4 for: exit menu: " << endl;
        cin >> choice;

        cin.ignore();
        cin.clear();

        switch (choice)
        {
        case add_vehicle_in_garage:
        {
            try
            {
                delete vehicle;
                // Vehicle *vehicle = createNewVehicle();
                vehicle = createNewVehicle();
                addVehicleInGarage(*vehicle, myGarage);
            }
            catch (const std::bad_alloc &e)
            {
                std::cout << e.what() << '\n';
            }
            break;
        }
        case remove_vehicle_from_garage:
            removeVehicleFromGarage(myGarage);
            break;
        case print_all_vehicles_from_garage:
            printAllVehiclesFromGarage(myGarage);
            break;
        case exit_menu:
            cout << "You are exitting the program, have a nice day\n";
            delete vehicle;
            break;
        default:
            cout << "You entered wrong command, try again" << endl;
            break;
        }

    } while (choice != exit_menu);
}

Vehicle *createNewVehicle()
{
    // Ensure you always get a vehicle, not nullptr
    char registration[MAX_STRING_LENGHT] = {};
    cout << "Enter registration \n";
    // cout.flush();
    cin.getline(registration, T_MAX_STRING_LENGHT);

    char description[MAX_STRING_LENGHT] = {};
    cout << "Enter describtion \n";
    // cout.flush();
    cin.getline(description, T_MAX_STRING_LENGHT);

    std::size_t space = 0;
    cout << "Enter vehicles's occuping space" << endl;
    cin >> space;

    Vehicle *vehicle = new Vehicle(registration, description, space);
    return vehicle;
}

bool checkInputStringLenght(char *string)
{
    int len = strLen(string);
    if (len > MAX_STRING_LENGHT)
    {
        return false;
    }
    return true;
}

void addVehicleInGarage(Vehicle &givenVehicle, Garage &myGarage)
{
    try
    {
        myGarage.insert(givenVehicle);
    }
    catch (const std::invalid_argument &e)
    {
        std::cout << e.what() << '\n';
    }
    catch (std::out_of_range &e)
    {
        std::cout << e.what() << '\n';
    }
}

void removeVehicleFromGarage(Garage &myGarage)
{
    char registrationP[T_MAX_STRING_LENGHT];
    cout << "Enter Register plate: ";
    cin >> registrationP;
    myGarage.erase(registrationP);
}

void printAllVehiclesFromGarage(Garage &myGarage)
{
    const char *temp = nullptr;
    const char *temp1 = nullptr;
    if (myGarage.size() == 0)
    {
        cout << "Garage is currently empty\n";
        return;
    }

    for (int i = 1; i <= myGarage.size(); i++)
    {
        temp = myGarage.at(i).description();
        temp1 = myGarage.at(i).registration();
        cout << "Vehicle: " << temp;
        cout << " with registration: " << temp1;
        cout << " currently occupying " << myGarage.at(i).space();
        cout << endl;
        delete[] temp;
        delete[] temp1;
    }
}
