#ifndef _GARAGE_
#define _GARAGE_
#include "vehicle.h"

/*! 
* \class Garage
* \brief the class has 4 properties - capacity, used capacity, number of cars in the garage, vehicles in the garage
*/
class Garage
{
private:
    std::size_t capacity;
    std::size_t usedCapacity;

    std::size_t numberOfCars;
    Vehicle **vehicles;

public:
    ///constructor and destructor
    Garage(std::size_t size);
    ///copy constructor
    ///when we copy a garage - we copy only it's size. There is no way one car to be in two separete,
    ///different garages.
    Garage(const Garage &);
    ~Garage();

    ///functions

    ///function which copies the garage space
    ///when we copy a garage - we copy only it's size. There is no way one car to be in two separete,
    ///different garages.
    Garage &operator=(const Garage &);
    ///function which adds a car in the garage
    ///if this car is already in there or if there is a car with the same RPlate throws exception
    ///function gives strong exception guarantee
    void insert(Vehicle &v);
    ///function which removes car from the garage by RPlate
    ///function takes the last car of the arr and places it on the removed car
    void erase(const char *registration);
    /// function which gives access to a car on possition pos
    ///function throws exception if the possition is invalid
    const Vehicle &at(std::size_t pos) const;
    /// function which gives access to a car on possition pos
    ///function has no checks in it - it has assert
    const Vehicle &operator[](std::size_t pos) const;
    ///function which checks if the garage is empty
    bool empty() const;
    ///function which gives the exact number of the vehicles in the garage
    std::size_t size() const;
    ///function which clears the garage of cars, but the capacity remains unchanged.
    void clear();
    ///function which returns a vehicle by it's Rplate
    ///if there is no such vehicle - returns nullptr
    const Vehicle *find(const char *registration) const;
};
Vehicle **allocateGarageSpace(unsigned capacity);
void position(Garage &);

#endif // _GARAGE_
