#ifndef _MENU_
#define _MENU_

/*! 
* \enum MyString
* \brief enum for different choises in menu
*/
enum menu
{
    /// first choise - add_vehicle_in_garage
    add_vehicle_in_garage = 1,
    /// second choise - remove_vehicle_from_garage
    remove_vehicle_from_garage,
    /// third choise - print_all_vehicles_from_garage
    print_all_vehicles_from_garage,
    /// last choise - exit the program
    exit_menu
};

#endif //_MENU_