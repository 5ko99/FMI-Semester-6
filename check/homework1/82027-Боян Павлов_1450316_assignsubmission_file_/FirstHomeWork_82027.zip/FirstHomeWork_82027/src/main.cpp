#include <iostream>
#include "main_functions.h"

using std::cin;
using std::cout;
using std::endl;
using std::nothrow;


int main()
{
    unsigned int size = 0;
    do
    {
        cout << "Please create your garage, by entering a valid size! Enter garage size: ";
        cin >> size;
    } while (!cin);

    cout << endl;
    Garage myGarage(size);
    menu(myGarage);
    return 0;
}
