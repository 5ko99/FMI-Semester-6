#pragma once
#include <iostream>

/*! 
*   \brief Class MyString.
*   \author B. Pavlov
*/
#ifndef _MYSTRING_
#define _MYSTRING_

/*! 
* \class MyString
* \brief the class has two properties. Properties for containing chars and size of the string
*/
class MyString
{
private:
    ///member variable of type char* s
    char *string;
    ///member variable of type int
    int strLenght;

public:
    /// rule of 3 = copy constructor, destructor, assignment operator
    /// rule of 5 = copy constructor, destructor, assignment operator, move operator, const move operator

    ///default constructor
    MyString();
    ///copy constructor
    MyString(const MyString &);
    ///function which create a deep copy of the first string assign it's value on the second string.
    MyString &operator=(const MyString &);
    ///destructor
    ~MyString();
    ///copy constructor, another variation
    MyString(const char *str);
    ///Move function
    void move(MyString &obj);
    ///create Const Move constructor
    ///function which allocates memory for member variable called string
    void allocateString(int);
    /// \brief getters
    ///function which gives you access to the element on position "pos"
    char &at(std::size_t pos);
    ///function which gives you access to the element on position "pos" for constants
    const char &at(std::size_t pos) const;
    ///function which gives you access to the first element of the string
    char &front();
    ///function which gives you access to the first element of the string for constants
    const char &front() const;
    ///function which gives you access to the last element of the string
    char &back();
    ///function which gives you access to the last element of the string (for constants)
    const char &back() const;
    ///function which checks if the array is empty
    bool empty() const;
    ///function which clears the containment of the string
    void clear();
    ///function which adds a character at the end of the string
    void push_back(char c);
    ///function which remove the last character of the string
    void pop_back();
    ///function which returns a pointer to null-terminated char arr which has the same containment as the given arr
    const char *c_str() const;
    /// \brief operator functions
    ///function which concatenates the character "c" with the string
    MyString &operator+=(char c);
    ///function which concatenates the character "c" with the string and returns a copy obj.
    MyString operator+(char c) const;
    ///function which concatenates the string "rhs" with the given string and returns *this, gives strong exeption guarantee
    MyString &operator+=(const MyString &rhs);
    ///function which concatenates the string "rhs" with the given string and returns a copy obj.
    MyString operator+(const MyString &rhs) const;
    ///function which gives you access to the element on position "pos"
    char &operator[](std::size_t pos);
    ///function which gives you access to the element on position "pos" for constants
    const char &operator[](std::size_t pos) const;
    ///function which checks if the two given arrays are identical
    bool operator==(const MyString &rhs) const;
    ///function which checks the first array contains the second.
    bool operator<(const MyString &rhs) const;
    /// \brief helpers
    ///function which copies the containtment of the source obj-string into the second obj-string
    void strCpyInto(MyString *destination) const;
    ///function which copies the containtment of the source string and place it into the second
    void strCpyFrom(const char *source);
    ///function which compares two obj-strings
    ///returns 0 when they have the same containment
    int strCmp(const MyString *second) const;
    ///function which compares the string of the obj-string with the given string
    ///returns 0 when they have the same containment
    int strCmp(const char *second) const;
    /// function which return the size of the string
    std::size_t size() const;
};
///other functions and helpers
std::size_t strLen(const char *string);
char *allocateString1(int);
void strcopy(char *destination, const char *source);
int strCmp(const char *first, const char *second);

#endif // _MYSTRING_