#ifndef _VEHICLE_
#define _VEHICLE_
#include "myString.h"

///\class Vehicle
///object created by this class MUST BE IMMUTABLE
class Vehicle
{
private:
    const MyString registerPlate;
    const MyString descriptionOfVehicle;
    const std::size_t occupiedParkingSpace;

public:
    ///costructor
    Vehicle(const char *registration, const char *description, std::size_t space);

    ///destructor
    ///there is no need of destructor because MyString calls his.
    /// ~Vehicle();

    ///function which returns the register plate as C-style char array
    const char *registration() const;
    ///function which returns the description plate as C-style char array
    const char *description() const;
    ///function which returns the units of the occupied parking space by the vehicle
    std::size_t space() const;
};

#endif //_VEHICLE_