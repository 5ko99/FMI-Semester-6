#include <iostream>
#include "myString.h"
#include <cassert>
// #include <cstring>
using std::cout;
using std::endl;
using std::nothrow;
// using std::strcpy;

MyString::MyString()
{
    string = nullptr;
    strLenght = 0;
}

MyString::~MyString()
{
    delete[] string;
    string = nullptr;
    strLenght = 0;
}

MyString::MyString(const MyString &obj)
{
    this->strLenght = obj.size();
    if (obj.string == nullptr)
    {
        this->string = nullptr;
    }
    else
    {
        this->allocateString(obj.strLenght);
        obj.strCpyInto(this);
    }
}

MyString &MyString::operator=(const MyString &obj)
{
    this->strLenght = obj.size();
    if (obj.string == nullptr)
    {
        this->string = nullptr;
    }
    else
    {
        this->allocateString(obj.strLenght);
        obj.strCpyInto(this);
    }
    return *this;
}

MyString::MyString(const char *str)
{
    int lenght = strLen(str);
    this->strLenght = lenght;

    if (lenght != 0)
    {
        this->allocateString(lenght);
        this->strCpyFrom(str);
    }
    else
    {
        this->string = nullptr;
    }
}

std::size_t MyString::size() const
{
    unsigned counter = 0;
    if (!string)
    {
        return 0;
    }
    while (string[counter] != '\0')
    {
        counter++;
    }
    return counter;
}

std::size_t strLen(const char *string)
{
    unsigned counter = 0;
    if (!string)
    {
        return 0;
    }
    while (string[counter] != '\0')
    {
        counter++;
    }
    return counter;
}

void MyString::strCpyInto(MyString *destination) const
{
    int lenghtDestination = destination->strLenght;
    int i = 0;
    while (i < lenghtDestination)
    {
        destination->string[i] = this->string[i];
        i++;
    }
    destination->string[i] = '\0';
}

void MyString::strCpyFrom(const char *source)
{
    int lenghtSource = strLen(source);
    int lenght = this->strLenght;

    if (lenghtSource <= lenght)
    {
        int i = 0;
        while (i < lenght)
        {
            this->string[i] = source[i];
            i++;
        }
        this->string[i] = '\0';
    }
}

int MyString::strCmp(const MyString *second) const
{
    char *text1 = this->string;
    char *text2 = second->string;
    int len1 = strLen(text1);
    int len2 = strLen(text2);

    if (len1 != len2)
    {
        return len1 - len2;
    }

    if (text1 == text2)
    {
        return 0;
    }

    if (text1 == nullptr && text2 == nullptr ||
        text1 == nullptr && text2 != nullptr && len2 == 0 ||
        text2 == nullptr && text1 != nullptr && len1 == 0)
    {
        return 0;
    }

    if (len1 == 0 && text1 == nullptr)
    {
        return *text2;
    }

    if (len2 == 0 && text2)
    {
        return *text1;
    }

    while (*text1 && *text1 == *text2)
    {
        text1++;
        text2++;
    }
    return *text1 - *text2;
}

int MyString::strCmp(const char *second) const
{
    char *text1 = this->string;
    const char *text2 = second;
    int len1 = strLen(text1);
    int len2 = strLen(text2);
    if (len1 != len2)
    {
        return len1 - len2;
    }
    if (text1 == text2)
    {
        return 0;
    }
    if (text1 == nullptr && text2 == nullptr ||
        text1 == nullptr && text2 != nullptr && len2 == 0 ||
        text2 == nullptr && text1 != nullptr && len1 == 0)
    {
        return 0;
    }

    if (len1 == 0 && text1 == nullptr)
    {
        return *text2;
    }

    if (len2 == 0 && text2)
    {
        return *text1;
    }

    while (*text1 && *text1 == *text2)
    {
        text1++;
        text2++;
    }
    return *text1 - *text2;
}

int strCmp(const char *first, const char *second)
{
    int len1 = strLen(first);
    int len2 = strLen(second);
    if (len1 != len2)
    {
        return len1 - len2;
    }
    if (first == second)
    {
        return 0;
    }
    if (first == nullptr && second == nullptr ||
        first == nullptr && second != nullptr && len2 == 0 ||
        second == nullptr && first != nullptr && len1 == 0)
    {
        return 0;
    }

    if (len1 == 0 && first == nullptr)
    {
        return *second;
    }

    if (len2 == 0 && second)
    {
        return *first;
    }

    while (*first && *first == *second)
    {
        first++;
        second++;
    }
    return *first - *second;
}

void MyString::allocateString(int size)
{
    try
    {
        if (size == 0)
        {
            this->string = nullptr;
        }
        else
        {
            char *newString = new char[size + 1]();
            // newString[size] = '\0';
            this->strLenght = size;
            this->string = newString;
        }
    }
    catch (const std::bad_alloc &e)
    {
        cout << "Memory Allocation"
             << " failed: "
             << e.what()
             << endl;
        this->string = nullptr;
        this->strLenght = 0;
    }
}

char *allocateString1(int size)
{
    try
    {
        if (size == 0)
        {
            return nullptr;
        }
        else
        {
            char *newString = new char[size + 1]();
            //newString[size] = '\0';
            return newString;
        }
    }
    catch (const std::bad_alloc &e)
    {
        cout << "Memory Allocation"
             << " failed: "
             << e.what()
             << endl;
        return nullptr;
    }
}

char &MyString::at(std::size_t pos)
{
    if (strLenght < pos || strLenght == 0)
    {
        throw std::out_of_range("out of range exeption");
    }
    return this->string[pos];

    // try
    // {
    //     if (strLenght < pos || strLenght == 0)
    //     {
    //         throw std::out_of_range("out of range exeption");
    //     }
    //     else
    //     {
    //         return this->string[pos];
    //     }
    // }
    // catch (const std::out_of_range &e)
    // {
    //     cout << "Out of range exeption:" << e.what();
    // }
    // //TODO
    // //You need to return a const lvalue
    // //return zero ?
    // return string[strLenght + 1];
}

const char &MyString::at(std::size_t pos) const
{
    if (strLenght < pos || strLenght == 0)
    {
        throw std::out_of_range("out of range exeption");
    }
    return this->string[pos];

    // try
    // {
    //     if (strLenght < pos)
    //     {
    //         throw std::out_of_range("out of range exeption");
    //     }
    //     else
    //     {
    //         return this->string[pos];
    //     }
    // }
    // catch (const std::out_of_range &e)
    // {
    //     cout << "Out of range exeption:" << e.what();
    // }
    // //TODO
    // //You need to return a const lvalue
    // //return zero ?
    // return string[strLenght + 1];
}

char &MyString::operator[](std::size_t pos)
{
    assert(pos > 0);
    assert(pos < strLenght);

    return string[pos];
    //assert to find out if pos is valid position
}

const char &MyString::operator[](std::size_t pos) const
{
    assert(pos > 0);
    assert(pos < strLenght);

    return string[pos];
    //assert to find out if pos is valid position
}

char &MyString::front()
{
    assert(this != nullptr);
    assert(strLenght != 0);

    return string[0];
    //assert to find out if pos is valid position
}

const char &MyString::front() const
{
    assert(this != nullptr);
    assert(strLenght != 0);

    return string[0];
    //assert to find out if pos is valid position
}

char &MyString::back()
{
    assert(this != nullptr);
    assert(strLenght != 0);

    return string[strLenght];
    //assert to find out if pos is valid position
}

const char &MyString::back() const
{
    assert(this != nullptr);
    assert(strLenght != 0);

    return string[strLenght];
    //assert to find out if pos is valid position
}

bool MyString::empty() const
{
    if (this->strLenght == 0)
    {
        return true;
    }
    return false;
}

void MyString::clear()
{
    if (string)
    {
        for (int i = 0; i < strLenght; i++)
        {
            string[i] = '\0';
        }
    }
}

void MyString::push_back(char c)
{
    //Optimise ?
    try
    {
        int len = strLenght;
        char *newString = allocateString1(len + 1);
        strcopy(newString, string);
        newString[len] = c;
        delete[] string;
        string = newString;
        strLenght++;
    }
    catch (const std::bad_alloc &e)
    {
        cout << "Memory Allocation"
             << " failed: "
             << e.what()
             << endl;
    }
    //give strong exeption guarantee.
}

void MyString::pop_back()
{
    //Optimise ?
    if (this->string == nullptr || this == nullptr)
    {
        return;
    }
    int len = strLenght;
    char *newString = allocateString1(len);
    strcopy(newString, string);
    newString[len - 1] = '\0';
    delete[] string;
    string = newString;
    strLenght--;
}

//function which returns a pointer to null-terminated char arr which has the same containment as the given arr
const char *MyString::c_str() const
{
    char *newAr = allocateString1(strLenght);
    strcopy(newAr, string);
    return newAr;
}

MyString &MyString::operator+=(const MyString &rhs)
{
    MyString concatenatedString;
    if (rhs.string == this->string && this->string == nullptr || rhs.string == nullptr)
    {
        return *this;
    }

    if (this->string == nullptr)
    {
        this->string = allocateString1(rhs.strLenght);
        this->strLenght = rhs.strLenght;
        strcopy(this->string, rhs.string);
        return *this;
    }

    concatenatedString.strLenght = this->strLenght + rhs.strLenght;
    concatenatedString.allocateString(concatenatedString.strLenght);
    for (int i = 0; i < this->strLenght; i++)
    {
        concatenatedString.string[i] = this->string[i];
    }
    for (size_t i = this->strLenght; i < concatenatedString.strLenght + 1; i++)
    {
        concatenatedString.string[i] = rhs.string[i - this->strLenght];
    }
    //concatenatedString.string[concatenatedString.strLenght + 1] = '\0';
    try
    {
        delete[] string;
        this->strLenght = concatenatedString.strLenght;
        string = allocateString1(strLenght);
        strcopy(this->string, concatenatedString.string);
    }
    catch (const std::bad_alloc &e)
    {
        cout << "Memory Allocation"
             << " failed: "
             << e.what()
             << endl;
        return *this;
    }

    return *this;
    //strong exception guarantee
}

MyString &MyString::operator+=(char c)
{
    try
    {
        int len = strLenght;
        char *newString = allocateString1(len + 1);
        strcopy(newString, string);
        newString[len] = c;
        delete[] string;
        string = newString;
        strLenght++;
        return *this;
    }
    catch (const std::bad_alloc &e)
    {
        cout << "Memory Allocation"
             << " failed: "
             << e.what()
             << endl;
        return *this;
    }
    //give strong exeption guarantee.
}

MyString MyString::operator+(char c) const
{
    MyString newString;
    int len = strLenght;
    newString.string = allocateString1(len + 1);
    strcopy(newString.string, string);
    newString.string[len] = c;
    newString.string[len + 1] = '\0';
    newString.strLenght = len + 1;
    return newString;
}

MyString MyString::operator+(const MyString &rhs) const
{
    MyString concatenatedString;
    if (rhs.string == this->string && this->string == nullptr)
    {
        return concatenatedString;
    }
    if (rhs.string == nullptr)
    {
        concatenatedString = *this;
        return concatenatedString;
    }
    if (this->string == nullptr)
    {
        concatenatedString = rhs;
        return concatenatedString;
    }

    concatenatedString.strLenght = this->strLenght + rhs.strLenght;
    concatenatedString.allocateString(concatenatedString.strLenght);
    for (int i = 0; i < this->strLenght; i++)
    {
        concatenatedString.string[i] = this->string[i];
    }
    for (size_t i = this->strLenght; i < concatenatedString.strLenght + 1; i++)
    {
        concatenatedString.string[i] = rhs.string[i - this->strLenght];
    }
    //concatenatedString.string[concatenatedString.strLenght + 1] = '\0';
    return concatenatedString;
}

bool MyString::operator==(const MyString &rhs) const
{
    int flag = this->strCmp(&rhs);
    if (flag == 0)
    {
        return true;
    }
    return false;
}

bool MyString::operator<(const MyString &rhs) const
{
    int i = strLenght;
    int flag = true;
    if (string == nullptr || rhs.string == nullptr)
    {
        return false;
    }

    for (int i = 0; i < strLenght; i++)
    {
        if (string[i] != rhs.string[i])
        {
            flag = false;
            break;
        }
    }
    return flag;
}

void strcopy(char *dest, const char *src)
{
    int pos = 0;
    if (dest == nullptr || src == nullptr)
    {
        return;
    }
    while (src[pos])
    {
        dest[pos] = src[pos];
        ++pos;
    }
    dest[pos] = '\0';
}

void MyString::move(MyString &obj)
{
    char *string_swap = nullptr;
    int strLenght_swap = 0;

    strLenght_swap = this->strLenght;
    string_swap = this->string;
    this->strLenght = obj.strLenght;
    this->string = obj.string;
    obj.string = string_swap;
    obj.strLenght = strLenght_swap;
}