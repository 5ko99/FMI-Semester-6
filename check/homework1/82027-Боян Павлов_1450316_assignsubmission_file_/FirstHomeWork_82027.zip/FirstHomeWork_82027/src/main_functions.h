#ifndef _M_FUNCTIONS
#define _M_FUNCTIONS
#include "garage.h"
#include "menu_enum.h"

/// function for the menu
void menu(Garage &myGarage);
/// function used in the menu to add vehicles
void addVehicleInGarage(Vehicle &givenVehicle, Garage &myGarage);
/// function used in the menu to remove vehicles
void removeVehicleFromGarage(Garage &myGarage);
/// function used to print all the vehicles in the garage
void printAllVehiclesFromGarage(Garage &myGarage);
/// creates new vehicle
Vehicle *createNewVehicle();
//function which checks the lenght of the input string
bool checkInputStringLenght(char *string);

#endif //_M_FUNCTIONS