// #include "..\catch.hpp"
// #include "myString.h"
// // #include "myString.cpp"
// #include "vehicle.h"
// // #include "vehicle.cpp"
// #include "garage.h"
// // #include "garage.cpp"

// //Unit tests for MyString

// TEST_CASE("string lenght", "[strLen]")
// {
//     SECTION("given nullptr")
//     {
//         const char *text = nullptr;
//         MyString text1(text);
//         REQUIRE(text1.size() == 0);
//     }
//     SECTION("normal text - one word")
//     {
//         const char *text = "Hello";
//         MyString text1(text);
//         REQUIRE(text1.size() == 5);
//     }
//     SECTION("sentence")
//     {
//         const char *text = "Hello you are my world!";
//         MyString text1(text);
//         REQUIRE(text1.size() == 23);
//     }
// }

// TEST_CASE("string comparison", "[strCmp]")
// {
//     SECTION("given nullptr, different")
//     {
//         const char *text11 = nullptr;
//         const char *text22 = "hi";
//         MyString text1(text11);
//         MyString text2(text22);
//         REQUIRE(text1.strCmp(&text2) != 0);
//     }
//     SECTION("given nullptr, same")
//     {
//         const char *text11 = nullptr;
//         const char *text22 = nullptr;
//         MyString text1(text11);
//         MyString text2(text22);
//         REQUIRE(text1.strCmp(&text2) == 0);
//     }
//     SECTION("different, no nullptr")
//     {
//         const char *text11 = "hello";
//         const char *text22 = "hi";
//         MyString text1(text11);
//         MyString text2(text22);
//         REQUIRE(text1.strCmp(&text2) != 0);
//     }

//     SECTION("same")
//     {
//         const char *text11 = "hi";
//         const char *text22 = "hi";
//         MyString text1(text11);
//         MyString text2(text22);
//         REQUIRE(text1.strCmp(&text2) == 0);
//     }
// }

// TEST_CASE("copy constructor with given obj-string", "[copyConstr-obj-string]")
// {
//     SECTION("nullptr copy")
//     {
//         const char *text11 = nullptr;
//         MyString text1(text11);
//         MyString text2(text1);
//         REQUIRE(text1.strCmp(&text2) == 0);
//     }
//     SECTION("normal string copy")
//     {
//         const char *text11 = "hi";
//         MyString text1(text11);
//         MyString text2(text1);
//         REQUIRE(text1.strCmp(&text2) == 0);
//     }
//     SECTION("comparisson with other value")
//     {
//         const char *text11 = "hi";
//         const char *text33 = "ho";
//         MyString text1(text11);
//         MyString text3(text33);
//         MyString text2(text3);
//         REQUIRE(text1.strCmp(&text2) != 0);
//     }
// }

// TEST_CASE("copy constructor with given string", "[copyConstr-string]")
// {
//     SECTION("nullptr copy")
//     {
//         const char *text11 = nullptr;
//         MyString text1(text11);
//         REQUIRE(text1.strCmp(text11) == 0);
//     }
//     SECTION("normal string copy")
//     {
//         const char *text11 = "hi";
//         MyString text1(text11);
//         REQUIRE(text1.strCmp(text11) == 0);
//     }
//     SECTION("comparisson with other value")
//     {
//         const char *text11 = "hi";
//         const char *text33 = "ho";
//         MyString text1(text11);
//         int tmp = text1.strCmp(text33);
//         REQUIRE(tmp != 0);
//     }
// }

// TEST_CASE("operator =", "operator=")
// {
//     SECTION("nullptr copy with operator=")
//     {
//         const char *text11 = nullptr;
//         MyString text1(text11);
//         MyString text2 = text1;
//         REQUIRE(text1.strCmp(&text2) == 0);
//     }
//     SECTION("normal string copy with operator=")
//     {
//         const char *text11 = "hi";
//         MyString text1(text11);
//         MyString text2 = text1;
//         REQUIRE(text1.strCmp(&text2) == 0);
//     }
//     SECTION("comparisson with different value value, operator=")
//     {
//         const char *text11 = "hi";
//         const char *text33 = "ho";
//         MyString text1(text11);
//         MyString text3(text33);
//         MyString text2 = text1;
//         int tmp = text1.strCmp(&text3);
//         REQUIRE(tmp != 0);
//     }
// }

// TEST_CASE("check empty", "[check empty]")
// {
//     SECTION("given nullptr")
//     {
//         const char *text11 = nullptr;
//         MyString text1(text11);
//         REQUIRE(text1.empty() == 1);
//     }
//     SECTION("normal string")
//     {
//         const char *text11 = "hi";
//         MyString text1(text11);
//         REQUIRE(text1.empty() == 0);
//     }
// }

// TEST_CASE("clear string", "[clear string]")
// {
//     SECTION("given nullptr")
//     {
//         const char *text11 = nullptr;
//         const char *text12 = nullptr;
//         MyString text1(text11);
//         text1.clear();
//         REQUIRE(text1.strCmp(text12) == 0);
//     }
//     SECTION("normal string clearing")
//     {
//         const char *text11 = "hi";
//         const char *emtpy = "";
//         MyString text1(text11);
//         text1.clear();
//         REQUIRE(text1.strCmp(emtpy) == 0);
//     }
// }

// TEST_CASE("operator ==", "[operator ==]")
// {
//     SECTION("given nullptr, different")
//     {
//         const char *text11 = nullptr;
//         const char *text22 = "hi";
//         MyString text1(text11);
//         MyString text2(text22);
//         REQUIRE((text1 == text2) == false);
//     }
//     SECTION("given nullptr, same")
//     {
//         const char *text11 = nullptr;
//         const char *text22 = nullptr;
//         MyString text1(text11);
//         MyString text2(text22);
//         REQUIRE((text1 == text2) == true);
//     }
//     SECTION("different, no nullptr")
//     {
//         const char *text11 = "hello";
//         const char *text22 = "hi";
//         MyString text1(text11);
//         MyString text2(text22);
//         REQUIRE((text1 == text2) == false);
//     }

//     SECTION("same")
//     {
//         const char *text11 = "hi";
//         const char *text22 = "hi";
//         MyString text1(text11);
//         MyString text2(text22);
//         REQUIRE((text1 == text2) == true);
//     }
// }

// TEST_CASE("operator <", "[operator <]")
// {
//     SECTION("given nullptr, different")
//     {
//         const char *text11 = nullptr;
//         const char *text22 = "hi";
//         MyString text1(text11);
//         MyString text2(text22);
//         REQUIRE((text1 < text2) == false);
//     }
//     SECTION("given nullptr, same")
//     {
//         const char *text11 = nullptr;
//         const char *text22 = nullptr;
//         MyString text1(text11);
//         MyString text2(text22);
//         REQUIRE((text1 < text2) == false);
//     }
//     SECTION("different, no nullptr")
//     {
//         const char *text22 = "hillo";
//         const char *text11 = "hi";
//         MyString text1(text11);
//         MyString text2(text22);
//         REQUIRE((text1 < text2) == true);
//     }

//     SECTION("same")
//     {
//         const char *text11 = "hi";
//         const char *text22 = "hi";
//         MyString text1(text11);
//         MyString text2(text22);
//         REQUIRE((text1 < text2) == true);
//     }
// }

// TEST_CASE("operator + obj, returns MyString obj", "[operator +obj, obj]")
// {
//     SECTION("given nullptr, different")
//     {
//         const char *text11 = nullptr;
//         const char *text22 = "hi";
//         MyString text1(text11);
//         MyString text2(text22);
//         MyString text3 = (text1 + text2);
//         REQUIRE(text3.strCmp(text22) == 0);
//     }

//     SECTION("given nullptr, same")
//     {
//         const char *text11 = nullptr;
//         const char *text22 = nullptr;
//         MyString text1(text11);
//         MyString text2(text22);
//         MyString text3 = (text1 + text2);
//         REQUIRE(text3.strCmp(text22) == 0);
//     }

//     SECTION("different, no nullptr")
//     {
//         const char *text22 = "hillo";
//         const char *text11 = "hi";
//         MyString text1(text11);
//         MyString text2(text22);
//         MyString text3 = (text2 + text1);
//         REQUIRE(text3.strCmp("hillohi") == 0);
//     }

//     SECTION("different nd, no nullptr")
//     {
//         const char *text22 = "hillo";
//         const char *text11 = "hi";
//         MyString text1(text11);
//         MyString text2(text22);
//         MyString text3 = (text1 + text2);
//         REQUIRE(text3.strCmp("hill_ohi") != 0);
//     }

//     SECTION("same")
//     {
//         const char *text11 = "hi";
//         const char *text22 = "hi";
//         MyString text1(text11);
//         MyString text2(text22);
//         MyString text3 = (text1 + text2);
//         REQUIRE(text3.strCmp("hihi") == 0);
//     }
// }

// TEST_CASE("operator + char, returns MyString obj", "[operator +c, obj]")
// {
//     SECTION("given nullptr, different")
//     {
//         const char *text11 = nullptr;
//         char letter = 'c';
//         MyString text1(text11);
//         MyString text3 = (text1 + letter);
//         REQUIRE(text3.strCmp("c") == 0);
//     }

//     SECTION("given nullptr and empty symbol, same")
//     {
//         const char *text11 = nullptr;
//         char letter = 0;
//         MyString text1(text11);
//         MyString text3 = (text1 + letter);
//         REQUIRE(text3.strCmp("") == 0);
//     }

//     SECTION("different, no nullptr")
//     {
//         const char *text22 = "hillo";
//         char letter = 'h';
//         MyString text2(text22);
//         MyString text3 = (text2 + letter);
//         REQUIRE(text3.strCmp("hilloh") == 0);
//     }

//     SECTION("different nd, no nullptr")
//     {
//         const char *text22 = "hillo";
//         const char *text11 = "hi";
//         MyString text1(text11);
//         MyString text2(text22);
//         MyString text3 = (text1 + text2);
//         REQUIRE(text3.strCmp("hill_ohi") != 0);
//     }

//     SECTION("same")
//     {
//         const char *text11 = "hi";
//         const char *text22 = "hi";
//         MyString text1(text11);
//         MyString text2(text22);
//         MyString text3 = (text1 + text2);
//         REQUIRE(text3.strCmp("hihi") == 0);
//     }
// }

// TEST_CASE("empty function", "[empty]")
// {
//     SECTION("given nullptr")
//     {
//         const char *text11 = nullptr;
//         MyString text1(text11);
//         REQUIRE(text1.empty() == true);
//     }

//     SECTION("input sentence")
//     {
//         const char *text11 = "love you";
//         MyString text1(text11);
//         REQUIRE(text1.empty() == false);
//     }

//     SECTION("word")
//     {
//         const char *text11 = "hate";
//         MyString text1(text11);
//         REQUIRE(text1.empty() == false);
//     }
// }

// TEST_CASE("clear function", "[clear]")
// {
//     SECTION("given nullptr")
//     {
//         const char *text11 = nullptr;
//         MyString text1(text11);
//         text1.clear();
//         REQUIRE(text1.strCmp("") == 0);
//     }

//     SECTION("input: sentence")
//     {
//         const char *text11 = "love you";
//         MyString text1(text11);
//         text1.clear();
//         REQUIRE(text1.strCmp("") == 0);
//     }

//     SECTION("input: word")
//     {
//         const char *text11 = "hate";
//         MyString text1(text11);
//         text1.clear();
//         REQUIRE(text1.strCmp("") == 0);
//     }
// }

// // // TEST_CASE("push_back", "[push]")
// // // {
// // //     SECTION("given nullptr, different")
// // //     {
// // //         const char *text11 = nullptr;
// // //         MyString text1(text11);
// // //
// // //         REQUIRE(text1.strCmp("") == 0);
// // //     }
// // //
// // //     SECTION("input: sentence")
// // //     {
// // //         const char *text11 = "love you";
// // //         MyString text1(text11);
// // //
// // //         REQUIRE(text1.strCmp("") == 0);
// // //     }
// // //
// // //     SECTION("input: word")
// // //     {
// // //         const char *text11 = "hate";
// // //         MyString text1(text11);
// // //
// // //         REQUIRE(text1.strCmp("") == 0);
// // //     }
// // // }

// TEST_CASE("pop_back", "[pop_back]")
// {
//     SECTION("given nullptr")
//     {
//         const char *text11 = nullptr;
//         MyString text1(text11);
//         text1.pop_back();
//         REQUIRE(text1.strCmp("") == 0);
//     }

//     SECTION("input: sentence")
//     {
//         const char *text11 = "love you";
//         MyString text1(text11);
//         text1.pop_back();
//         REQUIRE(text1.strCmp("love yo") == 0);
//     }

//     SECTION("input: word")
//     {
//         const char *text11 = "hate";
//         MyString text1(text11);
//         text1.pop_back();
//         REQUIRE(text1.strCmp("hat") == 0);
//     }
// }

// TEST_CASE("at, non-constant", "[at,non-const]")
// {
//     SECTION("given nullptr")
//     {
//         const char *text11 = nullptr;
//         MyString text1(text11);
//         try
//         {
//             char letter = text1.at(0);
//         }
//         catch (const std::out_of_range &e)
//         {
//             REQUIRE(strCmp(e.what(), "out of range exeption") == 0);
//         }
//     }
//     SECTION("first char")
//     {
//         const char *text11 = "love you";
//         MyString text1(text11);
//         char letter = text1.at(0);
//         REQUIRE(letter == 'l');
//     }

//     SECTION("incorect lenght - terminating null")
//     {
//         const char *text11 = "hate";
//         MyString text1(text11);
//         try
//         {
//             char letter = text1.at(4);
//         }
//         catch (const std::out_of_range &e)
//         {
//             REQUIRE(strCmp(e.what(), "out of range exeption") == 0);
//         }
//     }
//     SECTION("incorect lenght at the end")
//     {
//         const char *text11 = "hate";
//         MyString text1(text11);
//         try
//         {
//             char letter = text1.at(5);
//         }
//         catch (const std::out_of_range &e)
//         {
//             REQUIRE(strCmp(e.what(), "out of range exeption") == 0);
//         }
//     }

//     SECTION("incorect lenght negative number")
//     {
//         const char *text11 = "hate";
//         MyString text1(text11);
//         try
//         {
//             char letter = text1.at(-1);
//         }
//         catch (const std::out_of_range &e)
//         {
//             REQUIRE(strCmp(e.what(), "out of range exeption") == 0);
//         }
//     }
// }

// // TEST_CASE("assert test []", "[assert test]")
// // {
// //     const char *text11 = "hi";
// //     MyString text1(text11);
// //     char letter = text1[5];
// // }

// // TEST_CASE("assert test - back", "[assert test]")
// // {
// //     const char *text11 = "";
// //     MyString text1(text11);
// //     char letter = text1.back();
// // }

// TEST_CASE("operator += obj, returns MyString obj", "[operator +=obj, obj]")
// {
//     SECTION("given nullptr, different")
//     {
//         const char *text11 = nullptr;
//         const char *text22 = "hi";
//         MyString text1(text11);
//         MyString text2(text22);
//         text1 += text2;
//         REQUIRE(text1.strCmp(text22) == 0);
//     }

//     SECTION("given nullptr, same")
//     {
//         const char *text11 = nullptr;
//         const char *text22 = nullptr;
//         MyString text1(text11);
//         MyString text2(text22);
//         text1 += text2;
//         REQUIRE(text1.strCmp(text22) == 0);
//     }

//     SECTION("different, no nullptr")
//     {
//         const char *text22 = "hillo";
//         const char *text11 = "hi";
//         MyString text1(text11);
//         MyString text2(text22);
//         text2 += text1;
//         REQUIRE(text2.strCmp("hillohi") == 0);
//     }

//     SECTION("different nd, no nullptr")
//     {
//         const char *text22 = "hillo";
//         const char *text11 = "hi";
//         MyString text1(text11);
//         MyString text2(text22);
//         text1 += text2;
//         REQUIRE(text1.strCmp("hill_ohi") != 0);
//     }

//     SECTION("same")
//     {
//         const char *text11 = "hi";
//         const char *text22 = "hi";
//         MyString text1(text11);
//         MyString text2(text22);
//         text1 += text2;
//         REQUIRE(text1.strCmp("hihi") == 0);
//     }
// }

// // TEST_CASE("allocating memory", "[allocation]")
// // {
// //     char *text = allocateString1(100000000000);
// //     REQUIRE(text == nullptr);
// // }

// TEST_CASE("move assignment", "[move]")
// {
//     SECTION("valid argument")
//     {
//         int result1 = 0;
//         int result2 = 0;

//         const char *text1 = "hey!";
//         const char *text2 = "Halo!";
//         MyString str1(text1);
//         MyString str2(text2);
//         str1.move(str2);
//         result1 = str1.strCmp(text2);
//         result2 = str2.strCmp(text1);
//         bool flag = (result1 == result2);
//         REQUIRE(flag == 1);
//     }
// }

// //Unit tests for Garage

// TEST_CASE("insert vehicle")
// {
//     SECTION("valid argument")
//     {
//         Garage myGarage(5);
//         Vehicle DidosCar("CA0001CA", "BMW", 3);
//         Vehicle MariosCar("PB0001CA", "AUDI", 3);
//         Vehicle SashosCar("B0001CA", "VW", 2);
//         myGarage.insert(DidosCar);
//         //myGarage.insert(SashosCar);
//         REQUIRE_THROWS_AS(myGarage.insert(MariosCar), std::out_of_range);
//     }

//     SECTION("car which is already there")
//     {
//         Garage myGarage(5);
//         Vehicle DidosCar("CA0001CA", "BMW", 3);
//         Vehicle MariosCar("CA0001CO", "AUDI", 2);
//         myGarage.insert(DidosCar);
//         myGarage.insert(MariosCar);
//         const char *temp1 = (myGarage.at(2)).registration();
//         const char *temp2 = MariosCar.registration();
//         REQUIRE(strCmp(temp1, temp2) == 0);
//         delete[] temp1;
//         delete[] temp2;
//     }

//     SECTION("car which too big")
//     {
//         Garage myGarage(5);
//         Vehicle DidosCar("CA0001CA", "BMW", 6);
//         REQUIRE_THROWS_AS(myGarage.insert(DidosCar), std::out_of_range);
//     }
// }

// TEST_CASE("erase vehicle + isEmpty")
// {
//     SECTION("valid argument")
//     {
//         Garage myGarage(5);
//         Vehicle DidosCar("CA0001CA", "BMW", 3);
//         myGarage.insert(DidosCar);
//         myGarage.erase("CA0001CA");
//         REQUIRE(myGarage.empty() == true);
//     }

//     SECTION("invalid argument")
//     {
//         Garage myGarage(5);
//         Vehicle DidosCar("CA0001CA", "BMW", 3);
//         Vehicle MariosCar("CA0001CO", "AUDI", 2);
//         myGarage.insert(DidosCar);
//         myGarage.insert(MariosCar);
//         myGarage.erase("CA0001CO");
//         REQUIRE(myGarage.empty() == false);
//     }
// }

// TEST_CASE("number of cars")
// {
//     SECTION("two cars expected")
//     {
//         Garage myGarage(8);
//         Vehicle DidosCar("CA0001CA", "BMW", 3);
//         Vehicle MariosCar("PB0001CA", "AUDI", 3);
//         myGarage.insert(DidosCar);
//         myGarage.insert(MariosCar);
//         REQUIRE(myGarage.size() == 2);
//     }

//     SECTION("three cars expected")
//     {
//         Garage myGarage(8);
//         Vehicle DidosCar("CA0001CA", "BMW", 3);
//         Vehicle MariosCar("PB0001CA", "AUDI", 3);
//         Vehicle SashosCar("B0001CA", "VW", 2);
//         myGarage.insert(DidosCar);
//         myGarage.insert(MariosCar);
//         myGarage.insert(SashosCar);
//         REQUIRE(myGarage.size() == 3);
//     }
// }

// TEST_CASE("clear")
// {
//     SECTION("two cars expected")
//     {
//         Garage myGarage(8);
//         Vehicle DidosCar("CA0001CA", "BMW", 3);
//         Vehicle MariosCar("PB0001CA", "AUDI", 3);
//         myGarage.insert(DidosCar);
//         myGarage.insert(MariosCar);
//         myGarage.clear();
//         REQUIRE(myGarage.empty() == true);
//     }

//     SECTION("three cars expected")
//     {
//         Garage myGarage(8);
//         Vehicle DidosCar("CA0001CA", "BMW", 3);
//         Vehicle MariosCar("PB0001CA", "AUDI", 3);
//         Vehicle SashosCar("B0001CA", "VW", 2);
//         myGarage.insert(DidosCar);
//         myGarage.insert(MariosCar);
//         myGarage.insert(SashosCar);
//         myGarage.clear();
//         REQUIRE(myGarage.empty() == true);
//     }
// }

// TEST_CASE("operator= garage")
// {
//     SECTION("valid")
//     {
//         Garage myGarage(8);
//         Garage yourGarage = (myGarage);
//         bool flag = myGarage.size() == yourGarage.size();
//         bool flag1 = myGarage.empty() == yourGarage.empty();
//         REQUIRE((flag && flag1) == true);
//     }
// }