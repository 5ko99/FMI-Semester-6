#include <iostream>
#include "vehicle.h"
#include <cassert>
using std::cout;
using std::endl;
using std::nothrow;

Vehicle::Vehicle(const char *registration,
                 const char *description,
                 std::size_t space) : registerPlate(registration),
                                      descriptionOfVehicle(description),
                                      occupiedParkingSpace(space)
{
    //empty;
}

const char *Vehicle::registration() const
{
    // the user of this function must clean himself the allocated memory
    return registerPlate.c_str();
}


const char *Vehicle::description() const
{
    // the user of this function must clean himself the allocated memory
    return descriptionOfVehicle.c_str();
}

std::size_t Vehicle::space() const
{
    // the user of this function must clean himself the allocated memory
    return occupiedParkingSpace;
}