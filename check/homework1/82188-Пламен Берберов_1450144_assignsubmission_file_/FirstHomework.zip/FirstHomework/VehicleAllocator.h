#pragma once
#include "Vehicle.h"

class VehicleAllocator {
    Vehicle** vehicles;
    size_t size;
public:
    VehicleAllocator();

    ~VehicleAllocator();

    Vehicle* allocate(const char* registration, const char* description, size_t space);
};
