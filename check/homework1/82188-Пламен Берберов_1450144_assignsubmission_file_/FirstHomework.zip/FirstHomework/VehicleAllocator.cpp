#include "VehicleAllocator.h"


VehicleAllocator::VehicleAllocator()
{
	this->vehicles = nullptr;
	this->size = 0;
}

Vehicle* VehicleAllocator::allocate(const char* registration, const char* description, size_t space)
{
	Vehicle** tmp = new Vehicle*[this->size + 1];

	for (size_t k = 0; k < this->size; k++)
	{
		tmp[k] = this->vehicles[k];
	}

	tmp[this->size] = new Vehicle(registration, description, space);
	this->size++;
	this->vehicles = tmp;

	return this->vehicles[this->size - 1];
}

VehicleAllocator::~VehicleAllocator()
{
	for (size_t k = 0; k < this->size; k++)
	{
		delete this->vehicles[k];
	}

	delete[] vehicles;
	this->vehicles = nullptr;
	this->size = 0;
}