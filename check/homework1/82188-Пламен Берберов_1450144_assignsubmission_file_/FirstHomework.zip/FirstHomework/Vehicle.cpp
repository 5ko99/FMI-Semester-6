#include "Vehicle.h"

Vehicle::Vehicle(const char* registration, const char* description, size_t space)
{
	this->_registration = registration;
	this->_description = description;
	this->_space = space;
}

Vehicle& Vehicle::operator=(const Vehicle& v)
{
	if (&v == this) return *this;

	this->_registration = v.registration();
	this->_description = v.description();
	this->_space = v.space();

	return *this;
}

Vehicle::Vehicle(const Vehicle& v)
{
	this->_description = v.description();
	this->_registration = v.registration();
	this->_space = v.space();
}

Vehicle::~Vehicle()
{
	
}

const char* Vehicle::registration() const
{
	return this->_registration.c_str();
}

const char* Vehicle::description() const
{
	return this->_description.c_str();
}

size_t Vehicle::space() const
{
	return this->_space;
}

std::ostream& operator<<(std::ostream& out, const Vehicle& v)
{
	std::cout << "Registration: " << v.registration() << std::endl;
	std::cout << "Description: " << v.description() << std::endl;
	std::cout << "Space: " << v.space() << std::endl;

	return out;
}