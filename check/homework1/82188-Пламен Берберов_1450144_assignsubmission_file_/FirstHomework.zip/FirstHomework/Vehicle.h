#pragma once
#include "MyString.h"
#include <iostream>

class Vehicle
{
	MyString _registration;
	MyString _description;
	size_t _space;
public:
	Vehicle(const char* registration, const char* description, size_t space);
	Vehicle(const Vehicle& v);
	Vehicle& operator=(const Vehicle& v);
	~Vehicle();
	const char* registration() const;
	const char* description() const;
	size_t space() const;
	
	friend std::ostream& operator<< (std::ostream&, const Vehicle& v);
};

