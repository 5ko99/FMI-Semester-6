#include "Garage.h"
#include <stdexcept>

Garage::Garage(size_t size)
{
	this->capacity = size;
	this->numberOfVehicles = 0;
	this->vehicles = nullptr;
	this->occupied = 0;
}

Garage::~Garage()
{
	this->occupied = 0;
	this->capacity = 0;
	this->numberOfVehicles = 0;
	delete[] this->vehicles;
}

Garage::Garage(const Garage& other)
{
	this->numberOfVehicles = other.numberOfVehicles;
	this->capacity = other.capacity;
	this->vehicles = new Vehicle * [this->numberOfVehicles];
	this->occupied = other.occupied;
	for (size_t k = 0; k < this->numberOfVehicles; k++)
	{
		this->vehicles[k] = other.vehicles[k];
	}
}


Garage& Garage::operator=(const Garage & other)
{
	if (&other == this) return *this;

	this->numberOfVehicles = other.numberOfVehicles;
	this->capacity = other.capacity;
	this->occupied = other.occupied;
	this->vehicles = new Vehicle * [this->numberOfVehicles];
	for (size_t k = 0; k < this->numberOfVehicles; k++)
	{
		this->vehicles[k] = other.vehicles[k];
	}

	return *this;
}

void Garage::insert(Vehicle& v)
{
	if (this->occupied + v.space() > this->capacity)
	{
		throw std::exception("Capacity reached!");
	}
	if (this->find(v.registration()) != nullptr)
	{
		throw std::exception("Vehicle already in garage!");
	}
	try
	{
		Vehicle** tmp = new Vehicle* [this->numberOfVehicles + 1];
		this->numberOfVehicles++;
		for (size_t k = 0; k < this->numberOfVehicles - 1; k++)
		{
			tmp[k] = this->vehicles[k];
		}
		tmp[numberOfVehicles - 1] = &v;
		
		delete[] this->vehicles;
		this->occupied += v.space();
		this->vehicles = tmp;
	}
	catch (...)
	{
		numberOfVehicles--;
		throw std::exception("Vehicle could not be inserted into this garage!");
	}
}

void Garage::deleteAt(size_t pos)
{
	this->vehicles[pos] =  this->vehicles[this->numberOfVehicles - 1];
	this->vehicles[this->numberOfVehicles - 1] = nullptr;
	this->numberOfVehicles--;
}

void Garage::erase(const char* registration)
{
	for (size_t k = 0; k < this->numberOfVehicles; k++)
	{
		if (!strcmp(this->vehicles[k]->registration(), registration))
		{
			this->deleteAt(k);
		}
	}
}

const Vehicle& Garage::at(size_t pos) const
{
	if (pos < 0 || pos >= this->numberOfVehicles)
	{
		throw std::out_of_range("index out of range");
	}
	return *(this->vehicles[pos]);
}
const Vehicle& Garage::operator[](size_t pos) const
{
#ifdef DEBUG
	assert (pos < 0 || pos >= this->numberOfVehicles);
#endif // DEBUG

	return *(this->vehicles[pos]);
}

bool Garage::empty() const
{
	return this->numberOfVehicles == 0;
}

size_t Garage::size() const
{
	return this->numberOfVehicles;
}

void Garage::clear()
{
	delete[] this->vehicles;
}

const Vehicle* Garage::find(const char* registration) const
{
	for (size_t k = 0; k < this->numberOfVehicles; k++)
	{
		if (!strcmp(this->vehicles[k]->registration(), registration))
		{
			return &(this->operator[](k));
		}
	}

	return nullptr;
}