#include "MyString.h"

#include <cstring>
#include <cassert>
#include <exception>
#include <stdexcept>

MyString::MyString()
{
	this->data = new char[1];
	this->data[0] = '\0';
	this->length = 0;
	this->capacity = 0;
}

void MyString::resize(size_t newLength)
{
	if (newLength > this->capacity)
	{
		char* buffer = new char[newLength + 1];
		strcpy(buffer, this->data);
		delete[] this->data;

		this->data = buffer;
		this->length = newLength;
		this->capacity = newLength;
	}
	else
	{
		this->length = newLength;
	}
}

MyString::~MyString()
{
	delete[] this->data;
	this->data = nullptr;
	this->length = 0;
	this->capacity = 0;
}

MyString::MyString(const char* str)
{
	this->length = strlen(str);
	this->data = new char[this->length + 1];
	this->capacity = this->length;
	strcpy(this->data, str);
}

MyString::MyString(const MyString& other)
{
	this->length = other.length;
	this->data = new char[this->length + 1];
	this->capacity = this->length;
	strcpy(this->data, other.data);
}

MyString& MyString::operator=(const MyString& other)
{
	if (this == &other) return *this;

	this->resize(other.length);
	this->length = other.length;
	strcpy(this->data, other.data);

	return *this;
}

const char& MyString::at(size_t pos) const
{
	if (pos < 0 || pos >= this->length)
	{
		throw std::out_of_range("index out of range");
	}
	return this->data[pos];
}

char& MyString::at(size_t pos)
{
	if (pos < 0 || pos >= this->length)
	{
		throw std::out_of_range("index out of range");
	}
	return this->data[pos];
}

char& MyString::operator[](size_t pos)
{
#ifdef DEBUG
	assert (pos < 0 || pos >= this->length);
#endif // DEBUG

	return this->data[pos];
}

const char& MyString::operator[](size_t pos) const
{
#ifdef DEBUG
	assert(pos < 0 || pos >= this->length);
#endif // DEBUG

	return this->data[pos];
}

char& MyString::front()
{
#ifdef DEBUG
	assert(this->length > 0);
#endif // DEBUG

	return this->data[0];
}

const char& MyString::front() const
{
#ifdef DEBUG
	assert(this->length > 0);
#endif // DEBUG

	return this->data[0];
}

char& MyString::back()
{
#ifdef DEBUG
	assert(this->length > 0);
#endif // DEBUG

	return this->data[this->length - 1];
}

const char& MyString::back() const
{
#ifdef DEBUG
	assert(this->length > 0);
#endif // DEBUG

	return this->data[this->length - 1];
}

bool MyString::empty() const
{
	return this->length == 0;
}

size_t MyString::size() const
{
	return this->length;
}

void MyString::clear()
{
	this->length = 0;
	this->resize(0);
	strcpy(this->data, "");
}

void MyString::push_back(char c)
{
	this->resize(this->length + 1);
	strncat(this->data, &c, 1);
}

const char* MyString::c_str() const
{
	return this->data;
}

void MyString::pop_back()
{
#ifdef DEBUG
	assert(this->length > 0)
#endif // DEBUG

	this->data[length - 1] = '\0';
	this->resize(length - 1);
}

MyString& MyString::operator+=(char c)
{
	this->push_back(c);
	return *this;
}

MyString& MyString::operator+=(const MyString& rhs)
{
	this->resize(this->length + rhs.length);
	strcat(this->data, rhs.data);

	return *this;
}

MyString MyString::operator+(char c) const
{
	MyString tmp(*this);
	tmp += c;

	return tmp;
}

MyString MyString::operator+(const MyString& rhs) const
{
	MyString tmp(*this);
	tmp += rhs;

	return tmp;
}

bool MyString::operator==(const MyString& rhs) const
{
	if (&rhs == this)
	{
		return true;
	}
	if (!strcmp(this->data, rhs.data))
	{
		return true;
	}
	return false;
}

bool MyString::operator<(const MyString& rhs) const
{
	return strcmp(this->data, rhs.data) < 0;
}
