#pragma once
#include "Vehicle.h"

class Garage
{
	Vehicle** vehicles;
	size_t capacity;
	size_t numberOfVehicles;
	size_t occupied;
	void deleteAt(size_t pos);
public :
	Garage(size_t size);
	~Garage();
	Garage(const Garage& other);
	Garage& operator= (const Garage& other);
	void insert(Vehicle& v);
	void erase(const char* registration);
	const Vehicle& at(size_t pos) const;
	const Vehicle& operator[](size_t pos) const;
	bool empty() const;
	size_t size() const;
	void clear();
	const Vehicle* find(const char* registration) const;
};

