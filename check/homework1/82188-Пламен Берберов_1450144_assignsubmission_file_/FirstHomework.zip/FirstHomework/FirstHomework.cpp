// FirstHomework.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

#include "Garage.h"
#include "VehicleAllocator.h"

int main()
{
    size_t n;
    std::cout << "Enter garage capacity" << std::endl;
    std::cin >> n;

    VehicleAllocator allocator;
    Garage garage(n);

    bool running = true;
    while (running)
    {
        unsigned int menu;
        std::cout << "1. Add a vehicle to the garage" << std::endl;
        std::cout << "2. Earse a vehicle from the garage" << std::endl;
        std::cout << "3. Print all vehicles" << std::endl;
        std::cout << "0. Exit" << std::endl;
        std::cin >> menu;

        switch (menu)
        {
        case 0: 
            running = false;
            break;
        case 1: 
        {
            MyString registration;
            MyString description;
            size_t space;

            std::cout << "Entering vehicle information..." << std::endl;
            std::cout << "Enter vehicle registration:" << std::endl;
            std::cin.ignore();
            char buffer;
            std::cin.get(buffer);
            registration += buffer;
            while (buffer != '\n')
            {
                registration += buffer;
                std::cin.get(buffer);
            }
            registration.pop_back();

            std::cout << "Enter vehicle description:" << std::endl;
            std::cin.get(buffer);
            description += buffer;
            while (buffer != '\n')
            {
                description += buffer;
                std::cin.get(buffer);
            }
            description.pop_back();

            std::cout << "Enter vehicle space:" << std::endl;
            std::cin >> space;

            try
            {
                garage.insert(*allocator.allocate(registration.c_str(), description.c_str(), space));
            }
            catch (...)
            {
                std::cerr << "Could not add vehicle to garage" << std::endl;
            }
        }
            break;
        case 2:
        {
            std::cout << "Enter registration of the vehicle you want to remove:" << std::endl;

            MyString registration;
            std::cin.ignore();
            char buffer;
            std::cin.get(buffer);
            registration += buffer;
            while (buffer != '\n')
            {
                registration += buffer;
                std::cin.get(buffer);
            }
            registration.pop_back();

            garage.erase(registration.c_str());
        }
            break;
        case 3:
        {
            for (size_t k = 0; k < garage.size(); k++)
            {
                std::cout << garage[k] << std::endl;
            }
        }
            break;
        default:
            break;
        }
    }

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
