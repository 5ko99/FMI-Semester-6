#define CATCH_CONFIG_MAIN

#include "catch2/catch.hpp"

#include "MyString.h"
#include "MyString.cpp"

TEST_CASE("Test c style representation", "[string]")
{
	MyString str = "Hello";
	REQUIRE(!strcmp(str.c_str(), "Hello"));
}

TEST_CASE("Test assignment operator", "[string]")
{
	MyString str = "Hello";
	MyString test = "Hi";
	test = str;

	REQUIRE(!strcmp(test.c_str(), "Hello"));
}

TEST_CASE("Test copy-constructor", "[string]")
{
	MyString str = "Hello";
	MyString test = str;

	REQUIRE(!strcmp(test.c_str(), "Hello"));
}

TEST_CASE("Test equality operator", "[string]")
{
	MyString str = "Hello";
	MyString test = "Hi";
	test = str;

	bool result = test == str;
	bool control = (strcmp(str.c_str(), test.c_str()) == 0);

	REQUIRE(result == control);
}

TEST_CASE("Test at function", "[string]")
{
	MyString str = "Hello";
	REQUIRE_NOTHROW(str.at(0));
	REQUIRE(str.at(0) == 'H');

	REQUIRE_THROWS(str.at(20));
}

TEST_CASE("Test clear function", "[string]")
{
	MyString str = "Hello";
	str.clear();

	MyString test;
	REQUIRE(str == test);
}

TEST_CASE("Test plus operator", "[string]")
{
	MyString str = "Hello";
	MyString test = "World";

	MyString control = "HelloWorld";
	REQUIRE(control == str+test);
}