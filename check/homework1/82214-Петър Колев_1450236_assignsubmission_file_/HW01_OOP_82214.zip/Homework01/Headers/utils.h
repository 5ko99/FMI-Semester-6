#ifndef UTILS_H
#define UTILS_H

void introduction();

void whatToDo();

void menu();

void bye();

#endif