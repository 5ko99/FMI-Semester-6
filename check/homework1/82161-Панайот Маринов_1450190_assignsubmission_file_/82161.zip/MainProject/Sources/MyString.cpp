#include <iostream>
#include <cassert>
#include <cstring>
#include "../Headers/MyString.h"

MyString::MyString() {
	length = 0;
	capacity = 1;
	string = assignArray(capacity);
	string[0] = '\0';

}

MyString::~MyString() {
	delete[] string;
	length = 0;
	capacity = 0;
	string = nullptr;
}

MyString::MyString(const MyString& obj) {
	length = obj.length;
	string = assignArray(obj.capacity);
	capacity = obj.capacity;
	copyArray(string, obj.string, length);
	string[length] = '\0';
}

MyString& MyString::operator=(const MyString& obj) {
	if (this != &obj) {
		char* newStr = assignArray(obj.size()+1);
		if (newStr) {
			copyArray(newStr, obj.string, obj.size());
			delete[] string;
			string = newStr;
			capacity = obj.capacity;
			length = obj.length;
			newStr[size()] = '\0';
		}
	}

	return *this;
}

MyString::MyString(const char* strToCopy) {
	size_t strToCopyLength = strlen(strToCopy);
	string = assignArray(strToCopyLength+1);
	if (string) {
		this->length = strToCopyLength;
		this->capacity = strToCopyLength+1;
		copyArray(string, strToCopy, length+1);
	}
}

size_t MyString::size() const {
	return length;
}

size_t MyString::strlen(const char* str) {
	size_t len = 0;
	while (str[len] != '\0')
		len++;

	return len;
}

void MyString::print() {
	for (size_t i = 0; i < size(); i++) {
		std::cout << string[i];
	}
	std::cout<<std::endl;
}

size_t MyString::getCapacity() {
	return this->capacity;
}

char& MyString::at(size_t pos) {
	if (pos >= length)
		throw std::out_of_range("position index should be less than str length");
	return string[pos];
}

const char& MyString::at(size_t pos) const {
	if(pos < 0)
		throw std::out_of_range("position index should be positive");
	if (pos >= length)
		throw std::out_of_range("position index should be less than str length");
	return string[pos];
}

char& MyString::operator[](size_t pos) {
	assert(pos < length);
	return string[pos];
}

const char& MyString::operator[](size_t pos) const {
	assert(pos < length);
	return string[pos];
}

char& MyString::front() {
	if(empty())
		throw std::out_of_range("The string is empty");
	return string[0];
}

const char& MyString::front() const{
	if (empty())
		throw std::out_of_range("The string is empty");
	return string[0];
}

char& MyString::back() {
	if (empty())
		throw std::out_of_range("The string is empty");
	return string[size() - 1];
}

const char& MyString::back() const {
	if (empty())
		throw std::out_of_range("The string is empty");
	return string[size() - 1];
}

bool MyString::empty() const {
	return size() == 0;
}

void MyString:: clear() {
	delete[] string;
	capacity = 1;
	string = assignArray(capacity);
	string[0] = '\0';
	length = 0;

}

void MyString::push_back(char c) {
	if (size() == capacity-1) {
		increaseCapacity();
	}
	string[size()] = c;
	length++;
	string[size()] = '\0';
}

void MyString::pop_back() {
	if (empty())
		throw std::out_of_range("The string is empty");
	length--;
	string[length] = '\0';
}

MyString& MyString::operator+= (char c)  {
	if (size() == capacity-1) {
		increaseCapacity();
	}
	string[size()] = c;
	length++;
	string[length] = '\0';
	return (*this);
}

MyString& MyString::operator+= (const MyString& rhs)  {
	if (size() + rhs.size()  >= capacity-1) {
		increaseCapacity(rhs.size());
	}
	for (size_t i = 0; i <rhs.size(); i++) {
		string[size() + i] = rhs[i];
	}
	length += rhs.size();
	string[length] = '\0';

	return (*this);
}

bool MyString::operator== (const MyString& rhs) const {
	if (size() != rhs.size())
		return false;

	for (size_t i = 0; i < size(); i++)
	{
		if (string[i] != rhs.string[i])
			return false;
	}

	return true;
}

bool MyString::operator!= (const MyString& rhs) const {
	return !(*this == rhs);
}

bool MyString::operator<(const MyString& rhs) const {
	if (size() != rhs.size())
		return (size() < rhs.size());

	for (size_t i = 0; i < size(); i++)
	{
		if (string[i] != rhs.string[i])
			return string[i] < rhs.string[i];
	}

	return 0;
}

MyString MyString::operator+(char c) const {
	char* newStr = assignArray(length + 2);
	if (newStr) {
		copyArray(newStr, string, length);
		newStr[length] = c;
		newStr[length+1] = '\0';

		return MyString(newStr);
	}//TODO relook that

	return *this;//???
}

MyString MyString::operator+(const MyString& rhs) const {
	char* newStr = assignArray(length + rhs.length + 1);
	if (newStr) {
		copyArray(newStr, string, length); //Copying first string

		//Copying second string
		for (size_t i = length; i < length + rhs.length; i++) {
			newStr[i] = rhs.string[i-length];
		}
		newStr[length + rhs.length] = '\0';

		return MyString(newStr);
	}

	return *this;
}

const char* MyString::c_str() const {
	return string;
}

char* MyString::assignArray(size_t size) const {
	char* newArray = nullptr;

	try {
		newArray = new char[size];
	}
	catch (std::bad_alloc e) {
		std::cerr << "Memory fault!" << std::endl;
		throw;
	}		

	return newArray;
}

std::istream& operator>> (std::istream& stream, MyString& ms) {
	stream>>ms.string;
	ms.length = strlen(ms.string);
	ms.capacity = ms.length+1;
	return stream;
}

void MyString::copyArray(char* arr1, const char* arr2, size_t size) const {
	for (size_t i = 0; i < size; i++)
	{
		arr1[i] = arr2[i];
	}
}

bool MyString::increaseCapacity() {
	size_t newCapacity = (this->capacity == 1) ? 5 : 2 * (capacity);
	char* newStr = assignArray(newCapacity);
	if (!newStr)
		return false;

	copyArray(newStr, string, size());
	delete[] string;
	string = newStr;
	capacity = newCapacity;
	newStr = nullptr;


	return true;
}

bool MyString::increaseCapacity(size_t increased) {
	size_t newCapacity = capacity + increased;
	char* newStr = assignArray(newCapacity);
	if (!newStr)
		return false;

	copyArray(newStr, string, size());
	delete[] string;
	string = newStr;
	capacity = newCapacity;
	newStr = nullptr;


	return true;
}