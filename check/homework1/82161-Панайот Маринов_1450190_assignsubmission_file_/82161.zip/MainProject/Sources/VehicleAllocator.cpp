#include<iostream>
#include"../Headers/VehicleAllocator.h"

const unsigned START_CAPACITY = 4;

VehicleAllocator::VehicleAllocator() {
    this-> capacity = START_CAPACITY;
    this-> numberOfVehicles = 0;
    this-> vehicles = assignArray(4);
}

VehicleAllocator::~VehicleAllocator() {
    this->capacity = 0;
    this->numberOfVehicles = 0;
    
}

Vehicle* VehicleAllocator::allocate(const char* registration,
        const char* description, size_t space){
    return new Vehicle(
        registration, description, space);
}

void VehicleAllocator::addVehicle(const char* registration,
    const char* description, size_t space) {
        if(vehicleAlreadyExist(registration)) {
            throw std::logic_error("There is already a vehicle with the same license plate.");
        }
        if(numberOfVehicles == capacity)
            increaseCapacity();

        vehicles[numberOfVehicles] = allocate(
            registration, description, space
        );
        numberOfVehicles++;
    }

Vehicle& VehicleAllocator::at(size_t pos) {
	if (pos >= numberOfVehicles)
		throw std::out_of_range("position index should be less than numberOfVehicles");
	return *(vehicles[pos]);
}

const Vehicle& VehicleAllocator::at(size_t pos) const {
	if(pos < 0)
		throw std::out_of_range("position index should be positive");
	if (pos >= numberOfVehicles)
		throw std::out_of_range("position index should be less than numberOfVehicles");
	return *(vehicles[pos]);
}

size_t VehicleAllocator::getNumberOfVehicles() {
    return numberOfVehicles;
}

size_t VehicleAllocator::getCapacity() {
    return capacity;
}

Vehicle** VehicleAllocator::assignArray(size_t size) const {
	Vehicle** vehicles = new Vehicle*[size];

	try {
		vehicles = new Vehicle*[size];
	}
	catch (std::bad_alloc e) {
		std::cerr << "Memory fault!" << std::endl;
		throw;
	}		

	return vehicles;
}

void VehicleAllocator::clearVehiclesArray() {
    for (size_t i = 0; i < numberOfVehicles; i++)
	{
		delete[] vehicles[i];
	}

	delete[] vehicles;
}

void VehicleAllocator::copyArray(Vehicle** arr1, Vehicle** arr2, size_t size) const {
	for (size_t i = 0; i < size; i++)
	{
		arr1[i] = arr2[i];
	}
}

void VehicleAllocator::increaseCapacity() {
    Vehicle** newArr = assignArray(capacity*2);
    copyArray(newArr, vehicles, numberOfVehicles);
    clearVehiclesArray();
    vehicles = newArr;
}

bool VehicleAllocator::vehicleAlreadyExist (const char* registration) const {
	for (size_t i = 0; i < numberOfVehicles; i++)
	{
		if (vehicles[i]->registration() == registration) {
			return true;
		}
	}

	return false;
}