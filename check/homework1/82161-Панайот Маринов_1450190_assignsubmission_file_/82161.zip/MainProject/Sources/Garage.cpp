#include "../Headers/Garage.h"
#include <cassert>
#include <iostream>
#include <cstring>
Garage::Garage(size_t size) {
	if(sizeIsInvalid(size)) {
		throw std::invalid_argument("Size should be a positive number");
	}

	this->capacity = size;
	this->occupiedSpace = 0;
	this-> numberOfVehicles = 0;
	this-> vehicles = assignArray(size);
}

Garage::~Garage() {
	clear();
	delete[] vehicles;
	numberOfVehicles = 0;
	occupiedSpace = 0;
	capacity = 0;
}

Garage::Garage(const Garage& obj) {
	this->capacity = obj.capacity;
	this->numberOfVehicles = obj.numberOfVehicles;
	this->occupiedSpace = obj.occupiedSpace;

	this->vehicles = assignArray(capacity);

	for (size_t i = 0; i < obj.numberOfVehicles; i++) 
	{
		vehicles[i] = new Vehicle(obj.vehicles[i]->registration(),
		 obj.vehicles[i]->description(), obj.vehicles[i]->space());
	}
	
}

Garage& Garage::operator=(const Garage& obj) {
	if(this != &obj) {
		this->capacity = obj.capacity;
		this->numberOfVehicles = obj.numberOfVehicles;
		this->occupiedSpace = obj.occupiedSpace;

		clear();
		if(obj.numberOfVehicles > this->capacity)
			this->vehicles = assignArray(capacity);

		for (size_t i = 0; i < obj.numberOfVehicles; i++) 
		{
			vehicles[i] = new Vehicle(obj.vehicles[i]->registration(),
			obj.vehicles[i]->description(), obj.vehicles[i]->space());
		}
	}

	return *this;
}

void Garage::insert(Vehicle& v) {
	if (!canAddVehicleToGarage(v)) {
		throw std::logic_error("The vehicle cannot be added to the garage");
	}
	vehicles[numberOfVehicles] = &v;
	occupiedSpace += v.space();
	numberOfVehicles++;
}

const Vehicle& Garage::operator[](size_t pos) const {
	//assert(pos < numberOfVehicles);
	return *(vehicles[pos]);
}

const Vehicle& Garage::at(size_t pos) const {
	if (pos >= numberOfVehicles)
		throw std::out_of_range("position index should be less than numberOfVehicles");
	return *(vehicles[pos]);
}

bool Garage::empty() const {
	return (numberOfVehicles == 0);
}

size_t Garage::size() const {
	return numberOfVehicles;
}

void Garage::erase(const char* registration) {
	int vehicleToEraseIndex = findIndex(registration);
	if(vehicleToEraseIndex == -1)
		throw std::logic_error("Vehicle not found");
	

	for (size_t i = vehicleToEraseIndex; i < numberOfVehicles-1; i++)
	{
		vehicles[i] = vehicles[i+1];
	}
	
	numberOfVehicles--;
}

int Garage::findIndex(const char* registration) {
	for (size_t i = 0; i < numberOfVehicles; i++) {
		if (strcmp(vehicles[i]->registration(), registration) == 0)
			return i;			
	}
	
	return -1;
}

Vehicle* Garage::find(const char* registration) {
	for (size_t i = 0; i < numberOfVehicles; i++)
	{
		if (strcmp(vehicles[i]->registration(), registration) == 0)
			return vehicles[i];
	}

	return nullptr;
}

const Vehicle* Garage::find(const char* registration) const {
	for (size_t i = 0; i < numberOfVehicles; i++)
	{
		if (vehicles[i]->registration() == registration)
			return vehicles[i];
	}

	return nullptr;
}

bool Garage::canAddVehicleToGarage (const Vehicle& vehicle) {
	if (vehicle.space() + occupiedSpace > capacity)
		return false;

	for (size_t i = 0; i < numberOfVehicles; i++) {
		if (vehicles[i]->registration() == vehicle.registration()) 
			return false;
	}

	return true;
}

Vehicle** Garage::assignArray(size_t size) const {
	Vehicle** newVehicles = nullptr;
	try {
		newVehicles = new Vehicle*[size];
	}
	catch (std::bad_alloc e) {
		std::cerr << "Memory fault!" << std::endl;
		throw;
	}		

	return newVehicles;
}

void Garage::copyArray(Vehicle* arr1, Vehicle* arr2, size_t size) const {
	delete[] arr1;
	arr1 = arr2;
}

void Garage::clear() {
	for (size_t i = 0; i < size(); i++)
	{
		vehicles[i] = nullptr;
	}
	numberOfVehicles = 0;
}

bool Garage::sizeIsInvalid(size_t size) {
	if(size <= 0)
		return true;
	
	return false;
}