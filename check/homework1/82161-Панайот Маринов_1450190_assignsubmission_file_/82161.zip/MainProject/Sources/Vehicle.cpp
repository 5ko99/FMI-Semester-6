#include "../Headers/Vehicle.h"
#include <iostream>
Vehicle::Vehicle(const char* registration, const char* description,
	size_t space) {
	MyString regStr(registration);
	this->registrationStr = regStr;
	MyString descStr(description);
	this->descriptionStr = descStr;
	parkingSpaces = space;
}

Vehicle::Vehicle(const Vehicle& obj) {
	this->registrationStr = obj.registrationStr;
	this->descriptionStr = obj.descriptionStr;
	this->parkingSpaces = obj.parkingSpaces; 
}

const char* Vehicle::registration()const {
	return this->registrationStr.c_str();
}

const char* Vehicle::description() const {
	return this->descriptionStr.c_str();
}

size_t Vehicle::space() const {
	return parkingSpaces;
}