#pragma once
#include <iostream>
#include <cstddef>
class MyString
{
private:
	char* string;
	size_t capacity;
	size_t length;

public:
	MyString();
	~MyString();
	MyString(const MyString& obj);
	MyString& operator= (const MyString& obj);
	MyString(const char* str);

	char& at(size_t pos);
	const char& at(size_t pos) const;
	char& operator[](size_t pos);
	const char& operator[](size_t pos) const;
	char& front();
	const char& front() const;
	char& back();
	const char& back() const;
	bool empty() const;
	size_t size() const;
	void clear();
	void push_back(char c);
	void pop_back();
	MyString& operator+=(char c);
	MyString& operator+=(const MyString& rhs)  ;
	MyString operator+(char c) const ;
	MyString operator+(const MyString& rhs) const;
	const char* c_str() const;
	bool operator==(const MyString& rhs) const;
	bool operator!=(const MyString& rhs) const;
	bool operator<(const MyString& rhs) const;
	void print();

	friend std::istream& operator>> (std::istream& stream, MyString& ms);

	size_t getCapacity();//TODO: Remove

private:
	char* assignArray(size_t size) const;
	void copyArray(char* arr1, const char* arr2, size_t size) const;
	bool increaseCapacity();
	bool increaseCapacity(size_t increased);
	size_t strlen(const char* str);
};

