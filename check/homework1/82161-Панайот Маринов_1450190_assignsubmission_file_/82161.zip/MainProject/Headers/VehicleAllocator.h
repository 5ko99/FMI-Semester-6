#pragma once
#include "Vehicle.h"

class VehicleAllocator {
    Vehicle** vehicles;
	size_t numberOfVehicles;
	size_t capacity;
    
    public:
        VehicleAllocator();
        ~VehicleAllocator();
        
        void addVehicle(const char* registration,
        const char* description, size_t space);
        
        Vehicle& at(size_t pos);
	    const Vehicle& at(size_t pos) const;

        size_t getNumberOfVehicles();
        size_t getCapacity();

    private:
    	bool vehicleAlreadyExist(const char* vehicle) const;
    	Vehicle** assignArray(size_t size) const;
        void clearVehiclesArray();
        void increaseCapacity();
        void copyArray(Vehicle** arr1, Vehicle** arr2, size_t size) const;
        Vehicle* allocate(const char* registration,
        const char* description, size_t space);
};