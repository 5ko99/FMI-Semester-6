#pragma once
#include"Vehicle.h"
#include <cstddef>
class Garage
{
	Vehicle** vehicles;
	size_t numberOfVehicles;
	size_t occupiedSpace;
	size_t capacity;
	
public:
	Garage(size_t size);
	~Garage(); //Look for memory deletion
	Garage(const Garage& obj);
	Garage& operator=(const Garage& obj);


	void insert(Vehicle& v);
	void erase(const char* registration);
	const Vehicle& at(size_t pos) const;
	const Vehicle& operator[](size_t pos) const;
	bool empty() const;
	size_t size() const;
	void clear();
	Vehicle* find(const char* registration);
	const Vehicle* find(const char* registration) const;

private:
	bool canAddVehicleToGarage(const Vehicle& vehicle);
	Vehicle** assignArray(size_t size) const;
	void copyArray(Vehicle* arr1, Vehicle* arr2, size_t size) const;
	int findIndex(const char* registration);
	bool sizeIsInvalid(size_t size);
};

