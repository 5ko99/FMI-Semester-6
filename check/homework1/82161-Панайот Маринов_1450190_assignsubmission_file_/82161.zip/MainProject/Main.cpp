#include "Headers/Garage.h"
#include "Headers/VehicleAllocator.h"
#include <iostream>
#include <cstring>

using std::cout;
using std::cin;
using std::endl;

void inputCapacity(int& capacity);

int main()
{
    int garageCapacity;
    cout<<"Enter garage capacity: "<<endl;
    inputCapacity(garageCapacity);
    try{
        Garage garage(garageCapacity);

        VehicleAllocator vehicleAllocator;

        cout<<"Please enter:"<<std::endl;
        cout<<"'add' for adding a new vehicle in the garage"<<endl;
        cout<<"'remove' for removing a new vehicle from garage"<<endl;
        cout<<"'clear' for clearing the whole garage"<<endl;
        cout<<"'print' for showing garage availability"<<endl;
        cout<<"'exit' for exiting the program"<<endl;

        MyString command;
        cin>>command;
        while(strcmp(command.c_str(), "exit") != 0) {
            if(strcmp(command.c_str(), "add") == 0) {
                MyString licencePlate;
                cout<<"Enter license plate number: "<<endl;
                cin>>licencePlate;
                
                MyString description;
                cout<<"Enter description: "<<endl;
                cin>>description;

                size_t space;
                cout<<"Enter parking spaces count: "<<endl;
                cin>>space;

                try{
                    vehicleAllocator.addVehicle(licencePlate.c_str(), description.c_str(), space);
                    unsigned lastAddedVehicleIndex = vehicleAllocator.getNumberOfVehicles()-1;
                    garage.insert(vehicleAllocator.at(lastAddedVehicleIndex));
                    cout<<"Vehicle is sucsessfully inserted"<<std::endl;
                }
                catch(std::logic_error e) {
                    std::cout<<e.what()<<endl;
                }
            }

            else if(strcmp(command.c_str(), "remove") == 0) {
                MyString licensePlate;
                cout<<"Enter license plate number: "<<endl;
                cin>>licensePlate;
                try{
                    garage.erase(licensePlate.c_str());
                } 
                catch(std::logic_error e) {
                    std::cout<<e.what()<<endl;
                }
            
            }

            else if(strcmp(command.c_str(), "print") == 0) {
                
                cout<<"Parking: \n";
                if(garage.size() == 0)
                    cout<<"<empty>"<<endl;
                else {
                    for (size_t i = 0; i < garage.size(); i++) {
                        cout<<"----------------------------------"<<endl;
                        cout<<"Car number "<<i+1<<"\n";
                        cout<<"reg.plate: "<<garage.at(i).registration()<<"\n";
                        cout<<"description: "<<garage.at(i).description()<<"\n";
                        cout<<"parkingSpaces: "<<garage.at(i).space()<<"\n";
                    }
                    cout<<endl; 
                }
                
            }

            else if(strcmp(command.c_str(), "clear") == 0) {
                if(garage.size() == 0) {
                    cout<<"The garage is empty"<<endl;
                }
                else{
                    garage.clear();
                }
                
            }

            else {
                cout<<"Invalid command! Try again. (:"<<endl;
            }

            cin>>command;
        }

    }
    catch(std::bad_alloc e) {
        std::cout<<e.what()<<std::endl;
    }
    catch(std::invalid_argument e) {
        std::cout<<e.what()<<std::endl;
    }

    return 0;
  
}

void inputCapacity(int& capacity) {
    cin>>capacity;

    while(capacity <= 0) {
        std::cout<<"please enter a positive value"<<std::endl;
        cin>>capacity;
    }
}