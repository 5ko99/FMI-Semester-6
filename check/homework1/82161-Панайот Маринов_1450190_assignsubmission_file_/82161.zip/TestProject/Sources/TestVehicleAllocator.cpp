#include "catch2.hpp"
#include "../../MainProject/Headers/VehicleAllocator.h"
#include "cstring"

TEST_CASE( "Vehicle allocator instances can be created correctly") {
    SECTION("Testing constructor with a big number") {
        VehicleAllocator va;
        REQUIRE(va.getNumberOfVehicles() == 0);
        REQUIRE(va.getCapacity() == 4);
    }
}

TEST_CASE( "Testing adding vehicle and at functionalities") {
    SECTION("Testing with one vehicle") {
        VehicleAllocator va;
        
        va.addVehicle("CA AAAA AA", "PORSCHE", 1);

        REQUIRE(strcmp(va.at(0).registration(), "CA AAAA AA") == 0);
        REQUIRE(strcmp(va.at(0).description(), "PORSCHE") == 0);
        REQUIRE(va.at(0).space() == 1);
    }

    SECTION("Testing with two vehicles") {
        VehicleAllocator va;
        
        va.addVehicle("CA AAAA AA", "PORSCHE", 1);
        va.addVehicle("CA 5555 AA", "TRUCK", 3);

        REQUIRE(strcmp(va.at(0).registration(), "CA AAAA AA") == 0);
        REQUIRE(strcmp(va.at(0).description(), "PORSCHE") == 0);
        REQUIRE(va.at(0).space() == 1);

        REQUIRE(strcmp(va.at(1).registration(), "CA 5555 AA") == 0);
        REQUIRE(strcmp(va.at(1).description(), "TRUCK") == 0);
        REQUIRE(va.at(1).space() == 3);
    }
}