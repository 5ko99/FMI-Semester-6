#define CATCH_CONFIG_MAIN

#include "catch2.hpp"
#include "../../MainProject/Headers/MyString.h"
#include <cstring>

TEST_CASE( "MyString instances can be created correctly") {
    MyString string1;
    SECTION("Testing default constructor") {
        REQUIRE(strcmp(string1.c_str(), "") == 0);
        REQUIRE(string1.size() == 0);
        REQUIRE(string1.getCapacity() == 1);
    }

    MyString string2("abccc");
    SECTION("Testing constructor with 1 parameter 1st") {
        REQUIRE(strcmp(string2.c_str(), "abccc") == 0);
        REQUIRE(string2.size() == 5);
        REQUIRE(string2.getCapacity() == 6);
    }

    MyString string3("CAAAAAAA");
    SECTION("Testing constructor with 1 parameter 2nd") {
        REQUIRE(strcmp(string3.c_str(), "CAAAAAAA") == 0);
        REQUIRE(string3.size() == 8);
        REQUIRE(string3.getCapacity() == 9);
    }
}

TEST_CASE( "Testing assigning operations") {
    SECTION("Testing copy constructor") {
        MyString string1("abccc");
        MyString string2 = string1;
        REQUIRE(strcmp(string2.c_str(), "abccc") == 0);
        REQUIRE(string2.size() == 5);
        REQUIRE(string2.getCapacity() == 6);
    }

    SECTION("Testing operator= with larger string") {
        MyString string1("abccc");;
        MyString string2("cccbbaa");
        string1 = string2;
        REQUIRE(strcmp(string1.c_str(), "cccbbaa") == 0);
        REQUIRE(string1.size() == 7);
        REQUIRE(string1.getCapacity() == 8);
    }

    SECTION("Testing operator= with smaller string") {
        MyString string1("abccc");
        MyString string2("ccc");
        string1 = string2;
        REQUIRE(strcmp(string1.c_str(), "ccc") == 0);
        REQUIRE(string1.size() == 3);
        REQUIRE(string1.getCapacity() == 4);
    }
}

TEST_CASE("Testing getting certain symbol functionality") {
    SECTION("Testing function 'at'") {
        MyString string1("abcde");
        REQUIRE(string1.at(2) == 'c');
        REQUIRE_THROWS_AS(string1.at(-1), std::out_of_range);
        CHECK_THROWS_AS(string1.at(-1), std::out_of_range);
        REQUIRE_THROWS_AS(string1.at(5), std::out_of_range);
        CHECK_THROWS_AS(string1.at(5), std::out_of_range);
        REQUIRE_THROWS_AS(string1.at(12345678), std::out_of_range);
        CHECK_THROWS_AS(string1.at(12345678), std::out_of_range);
    }

    /*SECTION("Testing operator[]") {
        MyString string1("abcde");
        REQUIRE(string1[2] == 'c');
        REQUIRE_THROWS_AS(string1[-1], std::out_of_range);
        CHECK_THROWS_AS(string1[-1], std::out_of_range);
        REQUIRE_THROWS_AS(string1[5], std::out_of_range);
        CHECK_THROWS_AS(string1[5], std::out_of_range);
        REQUIRE_THROWS_AS(string1[12345678], std::out_of_range);
        CHECK_THROWS_AS(string1[12345678], std::out_of_range);
    }*/
}

TEST_CASE("Testing front function") {
    SECTION("Testing with non-empty string") {
        MyString string1("abcde");
        REQUIRE(string1.front() == 'a');
    }
    SECTION("Testing with empty string") {
        MyString string1;
        REQUIRE_THROWS_AS(string1.front(), std::out_of_range);
        CHECK_THROWS_AS(string1.front(), std::out_of_range);
    }
}

TEST_CASE("Testing front and back functions") {
    SECTION("Testing with non-empty string") {
        MyString string1("abcde");
        REQUIRE(string1.back() == 'e');
    }
    SECTION("Testing with empty string") {
        MyString string1;
        REQUIRE_THROWS_AS(string1.back(), std::out_of_range);
        CHECK_THROWS_AS(string1.back(), std::out_of_range);
    }
}

TEST_CASE("Testing clear function") {
    SECTION("Testing with non-empty string") {
        MyString string1("abcde");
        string1.clear();
        REQUIRE(strcmp(string1.c_str(), "") == 0);
        REQUIRE(string1.getCapacity() == 1);
        REQUIRE(string1.size() == 0);
    }
    SECTION("Testing with empty string"){
        MyString string1;
        string1.clear();
        REQUIRE(strcmp(string1.c_str(), "") == 0);
        REQUIRE(string1.getCapacity() == 1);
        REQUIRE(string1.size() == 0);
    }
}

TEST_CASE("Testing push_back function") {
    SECTION("Testing with non-empty string") {
        MyString string1("abcde");
        string1.push_back('f');
        REQUIRE(strcmp(string1.c_str(), "abcdef") == 0);
        REQUIRE(string1.getCapacity() == 12);
        REQUIRE(string1.size() == 6);
    }
    SECTION("Testing with empty string"){
        MyString string1;
        string1.push_back('f');
        REQUIRE(strcmp(string1.c_str(), "f") == 0);
        REQUIRE(string1.getCapacity() == 5);
        REQUIRE(string1.size() == 1);
    }
}

TEST_CASE("Testing pop_back function") {
    SECTION("Testing with non-empty string") {
        MyString string1("abcde");
        string1.pop_back();
        REQUIRE(strcmp(string1.c_str(), "abcd") == 0);
        REQUIRE(string1.getCapacity() == 6);
        REQUIRE(string1.size() == 4);
    }
    SECTION("Testing with empty string"){
        MyString string1;
        REQUIRE_THROWS_AS(string1.pop_back(), std::out_of_range);
        CHECK_THROWS_AS(string1.pop_back(), std::out_of_range);
    }
}

TEST_CASE("Testing operator+= function (with other Mystring)") {
    SECTION("Testing with 2 non-empty strings") {
        MyString string1("abcde");
        MyString string2("ghi");
        string1+=string2;
        REQUIRE(strcmp(string1.c_str(), "abcdeghi") == 0);
        REQUIRE(string1.getCapacity() == 9);
        REQUIRE(string1.size() == 8);
    }

    SECTION("Testing with 1 non-empty strings") {
        MyString string1("abcde");
        MyString string2;
        string1+=string2;
        REQUIRE(strcmp(string1.c_str(), "abcde") == 0);
        REQUIRE(string1.getCapacity() == 6);
        REQUIRE(string1.size() == 5);
    }
    SECTION("Testing with 2 empty strings"){
        MyString string1;
        MyString string2;
        string1+=string2;
        REQUIRE(strcmp(string1.c_str(), "") == 0);
        REQUIRE(string1.getCapacity() == 1);
        REQUIRE(string1.size() == 0);
    }
}

TEST_CASE("Testing operator+= function (with character)") {
    SECTION("Testing with non-empty string") {
        MyString string1("abcde");
        string1+='f';
        REQUIRE(strcmp(string1.c_str(), "abcdef") == 0);
        REQUIRE(string1.getCapacity() == 12);
        REQUIRE(string1.size() == 6);
    }

    SECTION("Testing with empty string"){
        MyString string1;
        string1+='a';
        REQUIRE(strcmp(string1.c_str(), "a") == 0);
        REQUIRE(string1.getCapacity() == 5);
        REQUIRE(string1.size() == 1);
    }
}

TEST_CASE("Testing operator== function") {
    SECTION("Testing with non-empty equal strings") {
        MyString string1("abcde");
        MyString string2("abcde");
        REQUIRE((string1 == string2) == true);
    }

    SECTION("Testing with non-empty non-equal strings") {
        MyString string1("abcde");
        MyString string2("abcd");
        REQUIRE((string1 == string2) == false);
    }

    SECTION("Testing with one empty string") {
        MyString string1;
        MyString string2("abcd");
        REQUIRE((string1 == string2) == false);
    }

    SECTION("Testing with empty strings"){
        MyString string1;
        MyString string2;
        REQUIRE((string1 == string2) == true);
    }
}

TEST_CASE("Testing operator<") {
    SECTION("Testing with non-empty equal strings") {
        MyString string1("abcde");
        MyString string2("abcde");
        REQUIRE((string1 < string2) == false);
    }

    SECTION("Testing with non-empty non-equal strings with different size (first greater)") {
        MyString string1("abcde");
        MyString string2("abcd");
        REQUIRE((string1 < string2) == false);
    }

    SECTION("Testing with non-empty non-equal strings with different size (second greater)") {
        MyString string1("a");
        MyString string2("abcde");
        REQUIRE((string1 < string2) == true);
    }

    SECTION("Testing with non-empty non-equal strings with same size (first greater)") {
        MyString string1("abce");
        MyString string2("abcd");
        REQUIRE((string1 < string2) == false);
    }

    SECTION("Testing with non-empty non-equal strings with same size (second greater)") {
        MyString string1("abcd");
        MyString string2("accd");
        REQUIRE((string1 < string2) == true);
    }

    SECTION("Testing with empty strings"){
        MyString string1;
        MyString string2;
        REQUIRE((string1 < string2) == false);
    }
}

TEST_CASE("Testing operator+") {
    SECTION("Testing with non-empty strings") {
        MyString string1("abcde");
        MyString string2("ghi");
        string2 = string1+string2;
        REQUIRE(strcmp(string2.c_str(), "abcdeghi") == 0);
    }

    SECTION("Testing with empty strings"){
        MyString string1;
        MyString string2;
        string2 = string1+string2;
        REQUIRE(strcmp(string2.c_str(), "") == 0);
    }
}