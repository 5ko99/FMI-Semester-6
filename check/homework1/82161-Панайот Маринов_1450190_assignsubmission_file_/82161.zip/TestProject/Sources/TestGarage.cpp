#include "catch2.hpp"
#include "../../MainProject/Headers/Garage.h"
#include <cstring>

TEST_CASE( "Garage instances can be created correctly") {
    SECTION("Testing constructor with a big number") {
        Garage garage(100000);
        REQUIRE(garage.size() == 0);
    }

    SECTION("Testing constructor with zero") {
        REQUIRE_THROWS_AS(new Garage(0), std::invalid_argument);
        CHECK_THROWS_AS(new Garage(0), std::invalid_argument);
    }

    SECTION("Testing constructor with a negative number") {
        REQUIRE_THROWS_AS(new Garage(-1), std::bad_alloc);
        CHECK_THROWS_AS(new Garage(-1), std::bad_alloc);
    }
}

TEST_CASE( "Testing insert function") {

    SECTION("Testing with one vehicle") {
        Garage garage(42);

        Vehicle v("CA AAAA AA", "PORSCHE", 2);

        garage.insert(v);

        REQUIRE(garage.empty() == false);
        REQUIRE(garage.size() == 1);
    }

    SECTION("Testing with two vehicles") {
        Garage garage(42);

        Vehicle v1("CA AAAA AA", "PORSCHE", 2);
        Vehicle v2("CВ ВВВВ AA", "MERCEDES", 1);

        garage.insert(v1);
        garage.insert(v2);

        REQUIRE(garage.empty() == false);
        REQUIRE(garage.size() == 2);
    }
}

TEST_CASE( "Testing erase function") {

    SECTION("Testing with one vehicle") {
        Garage garage(42);

        Vehicle v("CA AAAA AA", "PORSCHE", 2);

        garage.insert(v);
        garage.erase("CA AAAA AA");

        REQUIRE(garage.empty() == true);
        REQUIRE(garage.size() == 0);
    }

    SECTION("Testing with two vehicles") {
        Garage garage(42);

        Vehicle v1("CA AAAA AA", "PORSCHE", 2);
        Vehicle v2("CB BBBB AA", "MERCEDES", 1);

        garage.insert(v1);
        garage.insert(v2);
        garage.erase("CA AAAA AA");

        REQUIRE(garage.empty() == false);
        REQUIRE(garage.size() == 1);
    }
}

TEST_CASE( "Testing at function") {
    SECTION("Testing with valid index") {
        Garage garage(42);

        Vehicle v1("CB AAAA AA", "PORSCHE", 2);
        Vehicle v2("CB BBBB AA", "MERCEDES", 1);
        Vehicle v3("CB CCCC BB", "BMW", 1);

        garage.insert(v1);
        garage.insert(v2);
        garage.insert(v3);

        REQUIRE(strcmp(garage.at(0).registration(), "CB AAAA AA") == 0);
        REQUIRE(strcmp(garage.at(0).description(), "PORSCHE") == 0);
        REQUIRE(garage.at(0).space() == 2);

        REQUIRE(strcmp(garage.at(1).registration(), "CB BBBB AA") == 0);
        REQUIRE(strcmp(garage.at(1).description(), "MERCEDES") == 0);
        REQUIRE(garage.at(1).space() == 1);

        REQUIRE(strcmp(garage.at(2).registration(), "CB CCCC BB") == 0);
        REQUIRE(strcmp(garage.at(2).description(), "BMW") == 0);
        REQUIRE(garage.at(2).space() == 1);
    }

    SECTION("Testing with invalid index") {
        Garage garage(42);

        Vehicle v1("CA AAAA AA", "PORSCHE", 2);
        Vehicle v2("CВ ВВВВ AA", "MERCEDES", 1);
        Vehicle v3("CВ CCCC BB", "BMW", 1);

        garage.insert(v1);
        garage.insert(v2);
        garage.insert(v3);

        REQUIRE_THROWS_AS(garage.at(3), std::out_of_range);
        CHECK_THROWS_AS(garage.at(3), std::out_of_range);

        REQUIRE_THROWS_AS(garage.at(-1), std::out_of_range);
        CHECK_THROWS_AS(garage.at(-1), std::out_of_range);
    }
}

TEST_CASE( "Testing operator[]") {
    SECTION("Testing with valid index") {
        Garage garage(42);

        Vehicle v1("CB AAAA AA", "PORSCHE", 2);
        Vehicle v2("CB BBBB AA", "MERCEDES", 1);
        Vehicle v3("CB CCCC BB", "BMW", 1);

        garage.insert(v1);
        garage.insert(v2);
        garage.insert(v3);

        REQUIRE(strcmp(garage[0].registration(), "CB AAAA AA") == 0);
        REQUIRE(strcmp(garage[0].description(), "PORSCHE") == 0);
        REQUIRE(garage[0].space() == 2);

        REQUIRE(strcmp(garage[1].registration(), "CB BBBB AA") == 0);
        REQUIRE(strcmp(garage[1].description(), "MERCEDES") == 0);
        REQUIRE(garage[1].space() == 1);

        REQUIRE(strcmp(garage[2].registration(), "CB CCCC BB") == 0);
        REQUIRE(strcmp(garage[2].description(), "BMW") == 0);
        REQUIRE(garage[2].space() == 1);
    }
}

TEST_CASE( "Testing empty function") {
    SECTION("Testing with non-empty garage") {
        Garage garage(42);

        Vehicle v1("CB AAAA AA", "PORSCHE", 2);
        Vehicle v2("CB BBBB AA", "MERCEDES", 1);
        Vehicle v3("CB CCCC BB", "BMW", 1);

        garage.insert(v1);
        garage.insert(v2);
        garage.insert(v3);

        REQUIRE(garage.empty() == false);
    }
    SECTION("Testing with empty garage") {
        Garage garage(42);
        REQUIRE(garage.empty() == true);
    }
}

TEST_CASE( "Testing size function") {
    SECTION("Testing with non-empty garage") {
        Garage garage(42);

        Vehicle v1("CB AAAA AA", "PORSCHE", 2);
        Vehicle v2("CB BBBB AA", "MERCEDES", 1);
        Vehicle v3("CB CCCC BB", "BMW", 1);

        garage.insert(v1);
        garage.insert(v2);
        garage.insert(v3);

        REQUIRE(garage.size() == 3);
    }
    SECTION("Testing with empty garage") {
        Garage garage(42);
        REQUIRE(garage.size() == 0);
    }
}

TEST_CASE( "Testing clear function of garage") {
    SECTION("Testing with non-empty garage") {
        Garage garage(42);

        Vehicle v1("CB AAAA AA", "PORSCHE", 2);
        Vehicle v2("CB BBBB AA", "MERCEDES", 1);
        Vehicle v3("CB CCCC BB", "BMW", 1);

        garage.insert(v1);
        garage.insert(v2);
        garage.insert(v3);

        garage.clear();

        REQUIRE(garage.empty() == true);
        REQUIRE(garage.size() == 0);
    }
    SECTION("Testing with empty garage") {
        Garage garage(42);
        garage.clear();
        REQUIRE(garage.empty() == true);
        REQUIRE(garage.size() == 0);
    }
}

TEST_CASE( "Testing find function") {
    SECTION("Testing with non-empty garage") {
        Garage garage(42);

        Vehicle v1("CB AAAA AA", "PORSCHE", 2);
        Vehicle v2("CB BBBB AA", "MERCEDES", 1);
        Vehicle v3("CB CCCC BB", "BMW", 1);

        garage.insert(v1);
        garage.insert(v2);
        garage.insert(v3);

        REQUIRE(strcmp(garage.find("CB AAAA AA")->registration(), v1.registration()) == 0);
        REQUIRE(strcmp(garage.find("CB AAAA AA")->description(), v1.description()) == 0);
        REQUIRE(garage.find("CB AAAA AA")->space() == v1.space());

        REQUIRE(strcmp(garage.find("CB CCCC BB")->registration(), v3.registration()) == 0);
        REQUIRE(strcmp(garage.find("CB CCCC BB")->description(), v3.description()) == 0);
        REQUIRE(garage.find("CB CCCC BB")->space() == v3.space());
    }
    SECTION("Testing with empty garage") {
        Garage garage(42);
        garage.clear();
        REQUIRE(garage.empty() == true);
        REQUIRE(garage.size() == 0);
    }
}
