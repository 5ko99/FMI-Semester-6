#include "catch2.hpp"
#include "../../MainProject/Headers/Vehicle.h"

TEST_CASE( "Vehicle instances can be created correctly") {
    SECTION("(1)Testing constructor with parameters") {
        Vehicle vehicle("CB 0000 CB", "Audi A0", 3);
        REQUIRE(strcmp(vehicle.registration(), "CB 0000 CB") == 0);
        REQUIRE(strcmp(vehicle.description(), "Audi A0") == 0);
        REQUIRE(vehicle.space() == 3);
    }

    SECTION("(2)Testing constructor with parameters") {
            Vehicle vehicle("CAAAAAAA", "PORSCHE", 2);
            REQUIRE(strcmp(vehicle.registration(), "CAAAAAAA") == 0);
            REQUIRE(strcmp(vehicle.description(), "PORSCHE") == 0);
            REQUIRE(vehicle.space() == 2);
    }
}