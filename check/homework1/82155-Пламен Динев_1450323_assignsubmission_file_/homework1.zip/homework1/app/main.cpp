/*
 * main.cpp
 *
 *  Created on: 17.04.2021 г.
 *      Author: plamen
 */

#include <iostream>
#include <cstddef>
#include <cstdint>
#include <exception>
#include <stdexcept>
#include <limits>

#include <MyString.h>
#include <Vehicle.h>
#include <Garage.h>

#define ARRAY_SIZE(x) (sizeof((x))/sizeof((x)[0]))

bool handle_commands(Garage &g)
{
	std::cout << "0 - Add to garage | 1 - Remove from garage | 2 - Print contents of the garage | 3 - exit" << std::endl;
	char c;
	std::cin.clear();
	std::cout << "Enter command: "; std::cin>>c;
	std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
	switch(c)
	{
	case '0':
		{
			std::cout << "Adding vehicle to garage:\n";
			char reg[512], descr[512];
			std::size_t size;
			std::cout << "Enter the registration of the vehicle: "; std::cin.getline(reg, ARRAY_SIZE(reg));
			std::cout << "Enter the description of the vehicle: "; std::cin.getline(descr, ARRAY_SIZE(descr));
			std::cout << "Enter the size of the vehicle: "; std::cin >> size;
			Vehicle *v = new Vehicle (reg, descr, size);
			g.insert(*v);
			break;
		}
	case '1':
		{
			std::cout << "Removing vehicle from garage:\n";
			char reg[512];
			std::cout << "Enter the registration of the vehicle: "; std::cin.getline(reg, ARRAY_SIZE(reg));
			const Vehicle *v = g.find(reg);
			if(v == nullptr)
				throw std::runtime_error("Vehicle not found");
			g.erase(reg);
			delete v;

			break;
		}
	case '2':
		{
			for(std::size_t i=0; i<g.size(); i++)
			{
				std::cout << "Information for vehicle " << i << ":\n";
				std::cout << "\tRegistration:" << g[i].registration() << "\n";
				std::cout << "\tDescription:" << g[i].description() << "\n";
				std::cout << "\tSize:" << g[i].space() << "\n";
			}
			std::cout.flush();
			break;
		}
	case '3':
		{
			return true;
		}
	default:
		{
			throw std::runtime_error("Incorrect command");
		}
	}
	return false;
}

int main()
{
	std::size_t garage_capacity;
	std::cout << "Garage capacity: "; std::cin>>garage_capacity;
	Garage garage(garage_capacity);
	bool time_to_exit = false;

	do {
		try {
			time_to_exit = handle_commands(garage);
		}
		catch (std::bad_alloc&)
		{
			// just die
			throw;
		}
		catch (std::exception& e)
		{
			std::cout << "There was an error! More info " << e.what() << std::endl;
			time_to_exit = false;
		}
	} while(!time_to_exit);

	while(!garage.empty())
	{
		const Vehicle *v = &garage[0];
		garage.erase(v->registration());
		delete v;
	}

	return 0;
}


