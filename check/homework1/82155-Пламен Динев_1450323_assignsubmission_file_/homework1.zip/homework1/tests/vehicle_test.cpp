/*
 * vehicle_test.cpp
 *
 *  Created on: 17.04.2021 г.
 *      Author: plamen
 */

#include <catch2/catch.hpp>

#include <MyString.h>
#include <Vehicle.h>

#include <cstring>
#include <algorithm>
#include <random>
#include <cstdint>

//TODO:remove
#include <iostream>

static void generate_random_string(char str[], std::size_t size, std::uint_fast32_t seed)
{
	std::mt19937 g(seed);
	std::uniform_int_distribution<char> ud(' ', '~');
	for(std::size_t i=0; i<size; i++)
	{
		str[i] = ud(g);
	}
	str[size] = '\0';
}

SCENARIO("class Vehicle works")
{
	GIVEN("Two random strings and a random number") {
		std::size_t str_size1 = GENERATE(0, 1, 5, 69, 170, 356, 420);
		std::uint_fast32_t str_seed1 = GENERATE(180, 13, 167, 389, 420, 69);
		char cstr1[421];
		generate_random_string(cstr1, str_size1, str_seed1);
		MyString s1 = cstr1;
		std::size_t str_size2 = GENERATE(0, 1, 5, 69, 170, 356, 420);
		std::uint_fast32_t str_seed2 = GENERATE(180, 13, 167, 389, 420, 69);
		char cstr2[421];
		generate_random_string(cstr2, str_size2, str_seed2);
		WHEN("Vehicle constructor is called") {
			Vehicle v(cstr1, cstr2, str_seed1 + str_seed2);
			THEN("registration() description() space() should be correct") {
				REQUIRE(std::strcmp(cstr1, v.registration()) == 0);
				REQUIRE(std::strcmp(cstr2, v.description()) == 0);
				REQUIRE(v.space() == str_seed1+str_seed2);
			}
		}
	}
}
