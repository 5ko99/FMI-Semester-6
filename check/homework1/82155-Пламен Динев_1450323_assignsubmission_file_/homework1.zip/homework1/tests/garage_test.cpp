/*
 * garage_test.cpp
 *
 *  Created on: 17.04.2021 г.
 *      Author: plamen
 */

#include <catch2/catch.hpp>

#include <MyString.h>
#include <Vehicle.h>
#include <Garage.h>

#include <cstring>
#include <algorithm>
#include <random>
#include <cstdint>

//TODO:remove
#include <iostream>

static void generate_random_string(char str[], std::size_t size, std::mt19937 &g)
{
	std::uniform_int_distribution<char> ud(' ', '~');
	for(std::size_t i=0; i<size; i++)
	{
		str[i] = ud(g);
	}
	str[size] = '\0';
}

Vehicle* generate_and_allocate_random_vehicle (std::mt19937 &rg, std::uint_fast32_t seed)
{
	char reg[421], desc[421];
	// corner cases ;)
	if(seed == 0) {
		reg[0] = '\0';
		desc[0] = '\0';
	}
	else if(seed == 1) {
		reg[0] = '\0';
		generate_random_string(desc, std::uniform_int_distribution<std::size_t>(0, 420)(rg), rg);
	}
	else if(seed == 2) {
		generate_random_string(reg, std::uniform_int_distribution<std::size_t>(0, 420)(rg), rg);
		desc[0] = '\0';
	}
	else {
		generate_random_string(reg, std::uniform_int_distribution<std::size_t>(0, 420)(rg), rg);
		generate_random_string(desc, std::uniform_int_distribution<std::size_t>(0, 420)(rg), rg);
	}
	Vehicle *v = new Vehicle(reg, desc, std::uniform_int_distribution<std::size_t>(0, 120)(rg));

	return v;
}

SCENARIO("Vehicles can be inserted, accessed and deleted from Garage")
{
	std::uint_fast32_t seed = GENERATE(0, 1, 2, 3, 180, 13, 389, 420, 69, 213, 54, 621, 427, 6533, 6781, 1423);
	std::mt19937 rg(seed);
	GIVEN("An empty Garage") {
		const std::size_t max_capacity = 1024;
		Garage g(max_capacity);


		THEN("The Garage is empty") {
			REQUIRE(g.size() == 0);
			REQUIRE(g.empty() == true);
			REQUIRE(g.capacity() == max_capacity);
		}

		//TODO: sanitiy check for the same registration, it would be easy with std::set, but it is not now :(
		AND_GIVEN("A random Vehicle") {
			for(std::size_t nbr_veh=0; nbr_veh<20; nbr_veh++) { // something aint right about catch sections and loops
																// yea it reorders execution flow, but there
																// is something other wrong
				const Vehicle *v = generate_and_allocate_random_vehicle(rg, seed);

				if(g.find(v->registration()) == nullptr) {
					if(g.remaining_capacity() < v->space()) {
						REQUIRE_THROWS_AS(g.insert(*v), std::logic_error);
						delete v;
					}
					else {
						std::size_t old_size = g.size();
						std::size_t old_remaining_capacity = g.remaining_capacity();
						g.insert(*v);

							REQUIRE(g.size() == old_size+1);
							REQUIRE(g.empty() == ((old_size+1>0)? false: true));
							REQUIRE(&g.at(g.size()-1) == v);
							REQUIRE_THROWS_AS(g.at(g.size()), std::out_of_range);
							REQUIRE(&g[g.size()-1] == v);
							REQUIRE(g.find(v->registration()) == v);
							REQUIRE(old_remaining_capacity - g.remaining_capacity() == v->space());
//							AND_WHEN("Garage is cleared " << (nbr_veh+20)) {
//								g.clear();
//								REQUIRE(g.size() == 0);
//								REQUIRE(g.empty() == true);
//							}
					}
				}
				else {
					REQUIRE_THROWS_AS(g.insert(*v), std::logic_error);
					delete v;
				}
			}
		}

		while(g.size() > 0)
		{
			std::size_t old_size = g.size();
			const Vehicle *cp = &g[0];
			REQUIRE(cp != nullptr);
			REQUIRE(g.find(cp->registration()) == cp);
			g.erase(cp->registration());
			REQUIRE(old_size - 1 == g.size());
			if(g.size() > 0)
				REQUIRE(&g[0] != cp);
			REQUIRE(g.find(cp->registration()) == nullptr);

			delete (cp);
		}
	}
}
