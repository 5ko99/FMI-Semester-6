/*
 * mystring_test.cpp
 *
 *  Created on: 15.04.2021 г.
 *      Author: plamen
 */

//TODO: test

#include <catch2/catch.hpp>
#include <MyString.h>

#include <cstring>
#include <algorithm>
#include <random>
#include <cstdint>

//TODO:remove
#include <iostream>

static void generate_random_string(char str[], std::size_t size, std::uint_fast32_t seed)
{
	std::mt19937 g(seed);
	std::uniform_int_distribution<char> ud(' ', '~');
	for(std::size_t i=0; i<size; i++)
	{
		str[i] = ud(g);
	}
	str[size] = '\0';
}

SCENARIO("MyString can be sized and resized")
{
	GIVEN("An random c-string string")
	{
		std::size_t str_size = GENERATE(0, 1, 5, 69, 170, 356, 420);
		std::uint_fast32_t str_seed = GENERATE(180, 13, 167, 389, 420, 69);
		char cstr[421];
		generate_random_string(cstr, str_size, str_seed);
		MyString s = cstr;
		THEN("The size and capacity are valid") {
			REQUIRE(s.size() == str_size);
			REQUIRE(s.capacity() >= str_size);
			REQUIRE(s.empty() == ((str_size == 0)? true : false));
			if(str_size == 0)
			{
				REQUIRE(s.size() == 0);
				REQUIRE(s.capacity() == 0);
				REQUIRE(s.empty() == true);
			}
		}
		AND_GIVEN("Non-null character") {
			char c = GENERATE(take(3, random(' ', '~')));
			WHEN("push_back() is called") {
				s.push_back(c);
				THEN("The size and capacity changes") {
					REQUIRE(s.size() == str_size+1);
					REQUIRE(s.capacity() >= str_size+1);
					REQUIRE(s.empty() == ((str_size+1 == 0)? true : false));
				}
				AND_WHEN("clear() is called") {
					s.clear();
					THEN("The size is 0") {
						REQUIRE(s.size() == 0);
						REQUIRE(s.empty() == true);
					}
				}
				AND_WHEN("pop_back() is called") {
					s.pop_back();
					THEN("The size is 0") {
						REQUIRE(s.size() == str_size);
						REQUIRE(s.capacity() >= str_size);
						REQUIRE(s.empty() == ((str_size == 0)? true : false));
					}
				}
			}
			WHEN("operator+= is called") {
				s += c;
				THEN("The size and capacity changes") {
					REQUIRE(s.size() == str_size+1);
					REQUIRE(s.capacity() >= str_size+1);
					REQUIRE(s.empty() == ((str_size+1 == 0)? true : false));
				}
				AND_WHEN("clear() is called") {
					s.clear();
					THEN("The size is 0") {
						REQUIRE(s.size() == 0);
						REQUIRE(s.empty() == true);
					}
				}
			}
			WHEN("operator+ is called")
			{
				MyString r = s + c;
				THEN("The resulting string has valid size and capacity") {
					REQUIRE(r.size() == str_size+1);
					REQUIRE(r.capacity() >= str_size+1);
					REQUIRE(r.empty() == false);
				}
				AND_WHEN("clear() is called") {
					r.clear();
					THEN("The size is 0") {
						REQUIRE(r.size() == 0);
						REQUIRE(r.empty() == true);
					}
				}
			}
		}
		AND_GIVEN("Another random c-string")
		{
			std::size_t str1_size = GENERATE(0, 1, 5, 69, 170, 356, 420);
			std::uint_fast32_t str1_seed = GENERATE(180, 13, 167, 389, 420, 69);
			char cstr1[421];
			generate_random_string(cstr1, str1_size, str1_seed);
			MyString s1 = cstr1;
			WHEN("operator+= is called") {
				s += s1;
				THEN("The size and capacity changes") {
					REQUIRE(s.size() == str_size+str1_size);
					REQUIRE(s.capacity() >= str_size+str1_size);
					REQUIRE(s.empty() == ((str_size+str1_size == 0)? true : false));
				}
				AND_WHEN("clear() is called") {
					s.clear();
					THEN("The size is 0") {
						REQUIRE(s.size() == 0);
						REQUIRE(s.empty() == true);
					}
				}
			}
			WHEN("operator+ is called") {
				MyString r = s + s1;
				THEN("The resulting string has valid size and capacity") {
					REQUIRE(r.size() == str_size+str1_size);
					REQUIRE(r.capacity() >= str_size+str1_size);
					REQUIRE(r.empty() == ((str_size+str1_size == 0)? true : false));
				}
				AND_WHEN("clear() is called") {
					r.clear();
					THEN("The size is 0") {
						REQUIRE(r.size() == 0);
						REQUIRE(r.empty() == true);
					}
				}
			}
		}
	}
}

SCENARIO("MyString constructed from c-string gives the same c-string")
{
	GIVEN("MyString s constructed from c-string cstr") {
		std::size_t str_size = GENERATE(0, 1, 5, 69, 170, 356, 420);
		std::uint_fast32_t str_seed = GENERATE(180, 13, 167, 389, 420, 69);
		char cstr[421];
		generate_random_string(cstr, str_size, str_seed);
		MyString s = cstr;
		THEN("s.c_str() == cstr") {
			REQUIRE(std::strcmp(s.c_str(), cstr) == 0);
		}
	}
}

SCENARIO("MyString operator[], .at(), .back() and .front() operate correctly")
{
	GIVEN("MyString s constructed from c-string cstr") {
		std::size_t str_size = GENERATE(0, 1, 5, 69, 170, 356, 420);
		std::uint_fast32_t str_seed = GENERATE(180, 13, 167, 389, 420, 69);
		char cstr[421];
		generate_random_string(cstr, str_size, str_seed);
		MyString s = cstr;
		WHEN("s is accessed using operator[]") {
			THEN("for each i < string size: s[i] == cstr[i]") {
				for(std::size_t i=0; i<str_size; i++)
					REQUIRE(s[i] == cstr[i]);
			}
		}
		WHEN("s is accessed using .at()") {
			THEN("for each i < string size: s.at(i) == cstr[i]") {
				for(std::size_t i=0; i<str_size; i++)
					REQUIRE(s.at(i) == cstr[i]);
			}
			THEN("for each i >= string size: s.at(i) should throw an exception") {
				for(std::size_t i=str_size; i<str_size+20; i++)
					REQUIRE_THROWS_AS(s.at(i), std::out_of_range);
			}
		}
		if(s.size() > 0)
		{
			AND_GIVEN("s size is larger than 0") {
				THEN("s.front() == cstr[0]") {
					REQUIRE(s.front() == cstr[0]);
				}
				THEN("s.back() == cstr[str_size-1]") {
					REQUIRE(s.back() == cstr[str_size-1]);
				}
			}
		}

		WHEN("s is modified using operator[]") {
			for(std::size_t i=0; i<str_size; i++)
				s[i]='a';
			THEN("s should memorize and hold the new value") {
				for(std::size_t i=0; i<str_size; i++)
					REQUIRE(s.at(i) == 'a');
			}
		}
		WHEN("s is modified using .at()") {
			for(std::size_t i=0; i<str_size; i++)
				s[i]='b';
			THEN("s should memorize and hold the new value") {
				for(std::size_t i=0; i<str_size; i++)
					REQUIRE(s.at(i) == 'b');
			}
		}
		if(s.size() > 0)
		{
			AND_GIVEN("s size is larger than 0") {
				WHEN("s is modified using .front() and .back()") {
					s.front() = 'c';
					s.back() = 'd';
					THEN("s should memorize and hold the new value") {
						if(s.size() == 1) {
							REQUIRE(s.front() == s.back());
							REQUIRE(s.back() == 'd');
						}
						else
						{
							REQUIRE(s.front() == 'c');
							REQUIRE(s.back() == 'd');
						}
					}
				}
			}
		}
	}
}

SCENARIO("MyStrings can be compared")
{
	GIVEN("Two strings s1 and s2") {
		std::size_t str_size1 = GENERATE(0, 1, 5, 69, 170, 356, 420);
		std::uint_fast32_t str_seed1 = GENERATE(180, 13, 167, 389, 420, 69);
		char cstr1[421];
		generate_random_string(cstr1, str_size1, str_seed1);
		MyString s1 = cstr1;
		std::size_t str_size2 = GENERATE(0, 1, 5, 69, 170, 356, 420);
		std::uint_fast32_t str_seed2 = GENERATE(180, 13, 167, 389, 420, 69);
		char cstr2[421];
		generate_random_string(cstr2, str_size2, str_seed2);
		MyString s2 = cstr2;

		bool lesser = std::lexicographical_compare(cstr1, cstr1+str_size1, cstr2, cstr2+str_size2);
		bool larger = std::lexicographical_compare(cstr2, cstr2+str_size2, cstr1, cstr1+str_size1);
		bool equal = (!lesser) && (!larger);
		THEN("Compare s1 and s2") {
			REQUIRE((s1 < s2) == lesser);
			REQUIRE((s2 < s1) == larger);
			REQUIRE((s1 == s2) == equal);
			REQUIRE((s2 == s1) == equal);
		}
	}
}

SCENARIO("MyString can be copied and moved (rule of 5)")
{
	GIVEN("Two strings s1 and s2") {
		std::size_t str_size1 = GENERATE(0, 1, 5, 69, 170, 356, 420);
		std::uint_fast32_t str_seed1 = GENERATE(180, 13, 167, 389, 420, 69);
		char cstr1[421];
		generate_random_string(cstr1, str_size1, str_seed1);
		MyString s1 = cstr1;
		std::size_t str_size2 = GENERATE(0, 1, 5, 69, 170, 356, 420);
		std::uint_fast32_t str_seed2 = GENERATE(180, 13, 167, 389, 420, 69);
		char cstr2[421];
		generate_random_string(cstr2, str_size2, str_seed2);
		MyString s2 = cstr2;

		WHEN("s is copy constructed from s1") {
			MyString s(s1);
			THEN("s is equal to s1") {
				REQUIRE(s == s1);
				REQUIRE(s1 == s);
			}
			AND_WHEN("s is copy assigned to s2") {
				s = s2;
				THEN("s is equal to s2") {
					REQUIRE(s == s2);
					REQUIRE(s2 == s);
				}
			}
		}

		WHEN("s is move constructed from s1") {
			MyString cs1(s1), cs2(s2);
			MyString s(std::move(s1));
			THEN("s is equal to the copy of s1") {
				REQUIRE(s == cs1);
				REQUIRE(cs1 == s);
			}
			THEN("s1 is empty") {
				REQUIRE(s1.size() == 0);
				REQUIRE(s1.capacity() == 0);
				REQUIRE(s1.empty() == true);
				REQUIRE(s1.c_str()[0] == '\0');
			}
			AND_WHEN("s is move assigned to s2") {
				s = std::move(s2);
				THEN("s is equal to the copy of s2") {
					REQUIRE(s == cs2);
					REQUIRE(cs2 == s);
				}
				THEN("s2 is empty") {
					REQUIRE(s2.size() == 0);
					REQUIRE(s2.capacity() == 0);
					REQUIRE(s2.empty() == true);
					REQUIRE(s2.c_str()[0] == '\0');
				}
			}
		}

		WHEN("s is copy constructed from s1") {
			MyString cs2(s2);
			MyString s(s1);
			THEN("s is equal to s1") {
				REQUIRE(s == s1);
				REQUIRE(s1 == s);
			}
			AND_WHEN("s is move assigned to s2") {
				s = std::move(s2);
				THEN("s is equal to the copy of s2") {
					REQUIRE(s == cs2);
					REQUIRE(cs2 == s);
				}
				THEN("s2 is empty") {
					REQUIRE(s2.size() == 0);
					REQUIRE(s2.capacity() == 0);
					REQUIRE(s2.empty() == true);
					REQUIRE(s2.c_str()[0] == '\0');
				}
			}
		}

		WHEN("s is move constructed from s1") {
			MyString cs1(s1);
			MyString s(std::move(s1));
			THEN("s is equal to the copy of s1") {
				REQUIRE(s == cs1);
				REQUIRE(cs1 == s);
			}
			THEN("s1 is empty") {
				REQUIRE(s1.size() == 0);
				REQUIRE(s1.capacity() == 0);
				REQUIRE(s1.empty() == true);
				REQUIRE(s1.c_str()[0] == '\0');
			}
			AND_WHEN("s is copy assigned to s2") {
				s = s2;
				THEN("s is equal to s2") {
					REQUIRE(s == s2);
					REQUIRE(s2 == s);
				}
			}
		}
	}
}

SCENARIO("MyString push_back(), pop_back(), operator+ and operator+=")
{
	GIVEN("Two strings s1 and s2") {
		std::size_t str_size1 = GENERATE(0, 1, 5, 69, 170, 356, 420);
		std::uint_fast32_t str_seed1 = GENERATE(180, 13, 167, 389, 420, 69);
		char cstr1[421];
		generate_random_string(cstr1, str_size1, str_seed1);
		MyString s1 = cstr1;
		std::size_t str_size2 = GENERATE(0, 1, 5, 69, 170, 356, 420);
		std::uint_fast32_t str_seed2 = GENERATE(180, 13, 167, 389, 420, 69);
		char cstr2[421];
		generate_random_string(cstr2, str_size2, str_seed2);
		MyString s2 = cstr2;

		if(s2.size() > 0) {
			WHEN("s.push_back operator+= operator= is called with a character (s is copy of s1)") {
				MyString c1(s1), c2(s1), c3;
				c1.push_back(s2.front());
				c2 += s2.front();
				c3 = s1 + s2.front();
				THEN("The content of s must be correct") {
					std::size_t pos=0;
					for(std::size_t i=0; i<str_size1; i++,pos++)
					{
						REQUIRE(c1[pos] == s1[i]);
						REQUIRE(c2[pos] == s1[i]);
						REQUIRE(c3[pos] == s1[i]);
					}
					for(std::size_t i=0; i<1; i++,pos++)
					{
						REQUIRE(c1[pos] == s2[i]);
						REQUIRE(c2[pos] == s2[i]);
						REQUIRE(c3[pos] == s2[i]);
					}
					REQUIRE(c1.back() == s2.front());
					REQUIRE(c2.back() == s2.front());
					REQUIRE(c3.back() == s2.front());
				}
				AND_WHEN("s.pop_back is called") {
					c1.pop_back();
					c2.pop_back();
					c3.pop_back();
					THEN("The content of s must be correct") {
						std::size_t pos=0;
						for(std::size_t i=0; i<str_size1; i++,pos++)
						{
							REQUIRE(c1[pos] == s1[i]);
							REQUIRE(c2[pos] == s1[i]);
							REQUIRE(c3[pos] == s1[i]);
						}
					}
				}
			}
		}

		WHEN("s+=s2 and s1+s2 is called (s is copy of s1)") {
			MyString c1(s1), c2;
			c1 += s2;
			c2 = s1 + s2;
			THEN("The content of s and s1+s2 must be correct") {
				std::size_t pos=0;
				for(std::size_t i=0; i<str_size1; i++,pos++)
				{
					REQUIRE(c1[pos] == s1[i]);
					REQUIRE(c2[pos] == s1[i]);
				}
				for(std::size_t i=0; i<str_size2; i++,pos++)
				{
					REQUIRE(c1[pos] == s2[i]);
					REQUIRE(c2[pos] == s2[i]);
				}
			}
		}
	}
}
