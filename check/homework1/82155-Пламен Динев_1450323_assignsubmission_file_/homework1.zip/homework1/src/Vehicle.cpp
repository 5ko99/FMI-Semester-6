/*
 * Vehicle.cpp
 *
 *  Created on: 16.04.2021 г.
 *      Author: plamen
 */

#include "Vehicle.h"

Vehicle::Vehicle(const char* registration, const char* description, std::size_t space)
: regist(registration), desc(description), size(space)
{ }

const char* Vehicle::registration() const
{
	return regist.c_str();
}

const char* Vehicle::description() const
{
	return desc.c_str();
}

std::size_t Vehicle::space() const
{
	return size;
}
