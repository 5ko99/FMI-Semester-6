/*
 * MyString.cpp
 *
 *  Created on: 14.04.2021 г.
 *      Author: plamen
 */

#include "MyString.h"

#include <new>
#include <algorithm>
#include <cassert>
#include <cstring>
#include <exception>
#include <stdexcept>

//TODO: remove
#include <iostream>

void MyString::realocate_array(std::size_t new_required_size)
{
	if(new_required_size <= 0)
		return;

	// +1 to account for the '\0'
	std::size_t new_required_allocated = new_required_size+1;
	if(new_required_allocated <= this->str_allocated)
		return;
	std::size_t new_allocated;
	char* new_str = nullptr;
	if(new_required_allocated < 16)
	{
		new_allocated = std::max<std::size_t>(new_required_allocated*2, 16);
		new_str = new (std::nothrow) char[new_allocated];
	}
	else
	{
		{
			new_allocated = new_required_allocated*2;
			new_str = new (std::nothrow) char[new_allocated];
		}
		if(new_str == nullptr)
		{
			new_allocated = new_required_allocated+new_required_allocated/4;
			new_str = new (std::nothrow) char[new_allocated];
		}
		if(new_str == nullptr)
		{
			new_allocated = new_required_allocated;
			new_str = new (std::nothrow) char[new_allocated];
		}
	}

	if(new_str == nullptr)
		throw std::bad_alloc();
	std::strncpy(new_str, this->str, this->str_size);
	new_str[this->str_size] = '\0';
	delete[] this->str;
	this->str = new_str;
	this->str_allocated = new_allocated;
}

MyString::MyString()
{
}

MyString::~MyString() noexcept
{
	delete[] this->str;
}

MyString::MyString(const MyString &other)
{
	if(other.str_size == 0)
	{
		return;
	}
	 	 	 	 	 	 	 	 	 	 	 // +1 is to count the \0 symbol
	std::size_t new_allocated = std::max<std::size_t>((other.str_size+1)*2, 16);
	char* new_buf = new char [new_allocated]; // if an exception is thrown here
											  // the object is in valid state
	assert(other.str != nullptr);
	std::strncpy(new_buf, other.str, other.str_size);
	new_buf[other.str_size]='\0';
	this->str = new_buf;
	this->str_allocated = new_allocated;
	this->str_size = other.str_size;
}

MyString::MyString(MyString &&other) noexcept
: str(other.str), str_size(other.str_size), str_allocated(other.str_allocated)
{
	// invalidate other
	other.str = nullptr;
	other.str_allocated = 0;
	other.str_size = 0;
}

MyString& MyString::operator=(const MyString &other)
{
	if(this == &other)
		return *this;
	delete[] this->str;
	if(other.str_size == 0)
	{
		this->str = nullptr;
		this->str_size = 0;
		this->str_allocated = 0;
		return *this;
	}
	std::size_t new_allocated = std::max<std::size_t>((other.str_size+1)*2, 16);
	char* new_buf = new char [new_allocated]; // if an exception is thrown here
											  // the object is not modified
											  // (strong exception guarantee)
	assert(other.str != nullptr);
	std::strncpy(new_buf, other.str, other.str_size);
	new_buf[other.str_size]='\0';
	this->str = new_buf;
	this->str_allocated = new_allocated;
	this->str_size = other.str_size;

	return *this;
}

MyString& MyString::operator=(MyString &&other) noexcept
{
	if(this == &other)
		return *this;
	delete[] this->str;
	// move other to this
	this->str = other.str;
	this->str_allocated = other.str_allocated;
	this->str_size = other.str_size;
	// invalidate other
	other.str = 0;
	other.str_allocated = 0;
	other.str_size = 0;

	return *this;
}

MyString::MyString(const char *str)
{
	assert(str != nullptr);
	std::size_t new_size = std::strlen(str);
	if(new_size == 0)
	{
		this->str = 0;
		this->str_allocated = 0;
		this->str_size = 0;
		return;
	}
	std::size_t new_allocated = std::max<std::size_t>((new_size+1)*2, 16);
	char* new_buf = new char [new_allocated]; // if an exception is thrown here
											  // the object is in valid state
	std::strncpy(new_buf, str, new_size);
	new_buf[new_size]='\0';
	this->str = new_buf;
	this->str_allocated = new_allocated;
	this->str_size = new_size;
}

char& MyString::at(std::size_t pos)
{
	if(pos >= this->str_size)
		throw std::out_of_range("MyString::at");
	return str[pos];
}

const char& MyString::at(std::size_t pos) const
{
	if(pos >= this->str_size)
		throw std::out_of_range("MyString::at");
	return str[pos];
}

char& MyString::operator[](std::size_t pos) noexcept
{
	assert(pos < this->str_size);
	return str[pos];
}

const char& MyString::operator[](std::size_t pos) const noexcept
{
	assert(pos < this->str_size);
	return str[pos];
}

char& MyString::front() noexcept
{
	assert(this->str_size > 0);
	return str[0];
}

const char& MyString::front() const noexcept
{
	assert(this->str_size > 0);
	return str[0];
}

char& MyString::back() noexcept
{
	assert(this->str_size > 0);
	return str[this->str_size-1];
}

const char& MyString::back() const noexcept
{
	assert(this->str_size > 0);
	return str[this->str_size-1];
}

bool MyString::empty() const noexcept
{
	return (this->str_size == 0);
}

std::size_t MyString::size() const noexcept
{
	return this->str_size;
}

std::size_t MyString::capacity() const noexcept
{
	return this->str_allocated;
}

void MyString::clear() noexcept
{
	this->str_size = 0;
	if(this->str_allocated > 0)
		this->str[this->str_size]='\0';
}

void MyString::push_back(char c)
{
	assert(c != '\0');
	realocate_array(this->str_size + 1);
	this->str[this->str_size++] = c;
	this->str[this->str_size] = '\0';
}

void MyString::pop_back()
{
	assert(this->str_size > 0);
	this->str_size --;
	this->str[this->str_size] = '\0';
}

MyString& MyString::operator+=(char c)
{
	push_back(c);
	return *this;
}

MyString& MyString::operator+=(const MyString& rhs)
{
	if(rhs.str_size == 0)
		return *this;

	realocate_array(this->str_size + rhs.str_size);
	std::strncat(this->str + this->str_size, rhs.str, rhs.str_size);
	this->str_size += rhs.str_size;
	this->str[this->str_size] = '\0';
	return *this;
}

MyString MyString::operator+(char c) const
{
	assert(c != '\0');
	MyString res;
	res.realocate_array(this->str_size + 1);
	std::strncpy(res.str, this->str, this->str_size);
	res.str_size = this->str_size;
	res.str[res.str_size++] = c;
	res.str[res.str_size] = '\0';
	return res;
}

MyString MyString::operator+(const MyString& rhs) const
{
	MyString res;
	res.realocate_array(this->str_size + rhs.str_size);
	std::strncpy(res.str, this->str, this->str_size);
	std::strncpy(res.str + this->str_size, rhs.str, rhs.str_size);
	res.str_size = this->str_size + rhs.str_size;
	if(this->str_allocated > 0)
		res.str[res.str_size] = '\0';

	return res;
}

const char* MyString::c_str() const noexcept
{
	if(this->str_size != 0)
		return this->str;
	else
		return "";
}

bool MyString::operator==(const MyString &rhs) const noexcept
{
	if(this->str_size != rhs.str_size)
		return false;
	if(std::strncmp(this->c_str(), rhs.c_str(), this->str_size+1) == 0)
		return true;
	return false;
}

bool MyString::operator<(const MyString &rhs) const noexcept
{
	if(std::strncmp(this->c_str(), rhs.c_str(), std::min<std::size_t>(this->str_size, rhs.str_size)+1) < 0)
		return true;
	return false;
}
