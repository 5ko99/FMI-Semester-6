/*
 * Garage.cpp
 *
 *  Created on: 16.04.2021 г.
 *      Author: plamen
 */

#include "Garage.h"

#include <algorithm>
#include <utility>
#include <new>
#include <exception>
#include <stdexcept>
#include <cstring>
#include <cassert>

#include <MyString.h>

//TODO: use Red-Black or AVL self-balancing binary search tree

Garage::Garage(std::size_t size)
{
	this->_capacity = size;
	this->_capacity_left = size;
	this->parked = nullptr;
	this->parked_allocated = 0;
	this->parked_size = 0;
}

Garage::~Garage() noexcept
{
	delete[] this->parked;
}

Garage::Garage(const Garage &other)
{
	this->parked = new const Vehicle* [other.parked_allocated];
	std::memcpy(this->parked, other.parked, other.parked_size*sizeof(const Vehicle*));
	this->parked_allocated = other.parked_allocated;
	this->parked_size = other.parked_size;
	this->_capacity = other._capacity;
	this->_capacity_left = other._capacity_left;
}

Garage::Garage(Garage &&other) noexcept
: _capacity(other._capacity), _capacity_left(other._capacity_left),
  parked_size(other.parked_size), parked_allocated(other.parked_allocated),
  parked(other.parked)
{
	// invalidate other
	other._capacity = 0;
	other._capacity_left = 0;
	other.parked = nullptr;
	other.parked_allocated = 0;
	other.parked_size = 0;
}

Garage& Garage::operator=(const Garage &other)
{
	if(this == &other)
		return *this;
	delete[] this->parked;

	this->parked = new const Vehicle* [other.parked_allocated];
	std::memcpy(this->parked, other.parked, other.parked_size*sizeof(const Vehicle*));
	this->parked_allocated = other.parked_allocated;
	this->parked_size = other.parked_size;
	this->_capacity = other._capacity;
	this->_capacity_left = other._capacity_left;

	return *this;
}

Garage& Garage::operator=(Garage &&other) noexcept
{
	if(this == &other)
		return *this;

	delete[] this->parked;

	// move other to this
	this->_capacity = other._capacity;
	this->_capacity_left = other._capacity_left;
	this->parked = other.parked;
	this->parked_allocated = other.parked_allocated;
	this->parked_size = other.parked_size;

	// invalidate other
	other._capacity = 0;
	other._capacity_left = 0;
	other.parked = nullptr;
	other.parked_allocated = 0;
	other.parked_size = 0;

	return *this;
}

void Garage::reallocate_parked(std::size_t required_size)
{
	if(required_size <= 0)
		return;
	if(required_size <= this->parked_allocated) // do not shrink memory
		return;

	std::size_t new_allocated = std::min<std::size_t>(required_size, 16);
	new_allocated = std::max<std::size_t>(new_allocated, this->parked_allocated*2);
	const Vehicle **new_parked = new const Vehicle* [new_allocated];
	std::copy(this->parked, this->parked+this->parked_size, new_parked);
	delete[] this->parked;
	this->parked = new_parked;
	this->parked_allocated = new_allocated;
}

const Vehicle** Garage::find_in_parked(const char *registration) const noexcept
{
	for(std::size_t i=0; i<this->parked_size; i++)
	{
		const char *cur_car = this->parked[i]->registration();
		if(std::strcmp(cur_car, registration) == 0)
		{
			return this->parked+i;
		}
	}
	return nullptr;
}

std::size_t Garage::size() const noexcept
{
	return this->parked_size;
}

bool Garage::empty() const noexcept
{
	return (this->parked_size == 0);
}

const Vehicle& Garage::at(std::size_t pos) const
{
	if(pos >= this->parked_size)
		throw std::out_of_range("pos does not exist in Garage");

	return (*this->parked[pos]);
}

const Vehicle& Garage::operator[](std::size_t pos) const noexcept
{
	assert(pos < this->parked_size);
	return (*this->parked[pos]);
}

const Vehicle* Garage::find(const char* registration) const noexcept
{
	const Vehicle **cur = this->find_in_parked(registration);
	if(cur == nullptr)
		return nullptr;

	return (*cur);
}

void Garage::insert(const Vehicle& v)
{
	if(this->_capacity_left < v.space())
		throw std::logic_error("Garage: No space in garage");

	if(this->find_in_parked(v.registration()) != nullptr)
		throw std::logic_error("Garage: Car with the same registration already registered");

	this->reallocate_parked(this->parked_size+1);
	this->parked[this->parked_size++] = &v;
	this->_capacity_left -= v.space();
}

void Garage::erase(const char* registration)
{
	const Vehicle **cur = this->find_in_parked(registration);
	if(cur == nullptr)
		return;
	std::size_t idx = cur - this->parked;
	//TODO: this
	std::swap(this->parked[idx], this->parked[this->parked_size-1]);
	this->parked_size--;
}

void Garage::clear()
{
	this->_capacity_left = this->_capacity;
	this->parked_size = 0;
}

std::size_t Garage::capacity()
{
	return this->_capacity;
}

std::size_t Garage::remaining_capacity()
{
	return this->_capacity_left;
}
