/*
 * Garage.h
 *
 *  Created on: 16.04.2021 г.
 *      Author: plamen
 */

#ifndef SRC_GARAGE_H_
#define SRC_GARAGE_H_

#include <cstdlib>

#include <Vehicle.h>

class Garage final
{
private:
	std::size_t _capacity, _capacity_left;

	std::size_t parked_size, parked_allocated;
	const Vehicle ** parked;

	void reallocate_parked(std::size_t required_size);

	const Vehicle** find_in_parked(const char *registration) const noexcept;

public:
	Garage(std::size_t size);

	~Garage() noexcept;
	Garage(const Garage &other);
	Garage(Garage &&other) noexcept;
	Garage& operator=(const Garage &other);
	Garage& operator=(Garage &&other) noexcept;

	std::size_t size() const noexcept;
	bool empty() const noexcept;

	const Vehicle& at(std::size_t pos) const;
	const Vehicle& operator[](std::size_t pos) const noexcept;
	const Vehicle* find(const char* registration) const noexcept;

	void insert(const Vehicle& v);
	void erase(const char* registration);

	void clear();

	std::size_t capacity();
	std::size_t remaining_capacity();

};

#endif /* SRC_GARAGE_H_ */
