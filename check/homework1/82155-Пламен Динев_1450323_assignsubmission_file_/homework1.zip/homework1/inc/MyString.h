/*
 * MyString.h
 *
 *  Created on: 14.04.2021 г.
 *      Author: plamen
 */

#ifndef SRC_MYSTRING_H_
#define SRC_MYSTRING_H_

#include <cstdlib>

class MyString final
{
private:
	// size does not count the null terminating character
	// but allocated does
	std::size_t str_size=0, str_allocated=0;
	char *str=nullptr;

	void realocate_array(std::size_t new_required_size);

public:
	MyString();

	// rule of 5
	~MyString() noexcept;
	MyString(const MyString &other);
	MyString(MyString &&other) noexcept;
	MyString& operator=(const MyString &other);
	MyString& operator=(MyString &&other) noexcept;

	MyString(const char* str);

	char& at(std::size_t pos);
	const char& at(std::size_t pos) const;
	char& operator[](std::size_t pos) noexcept;
	const char& operator[](std::size_t pos) const noexcept;

	char& front() noexcept;
	const char& front() const noexcept;
	char& back() noexcept;
	const char& back() const noexcept;

	bool empty() const noexcept;
	std::size_t size() const noexcept;
	std::size_t capacity() const noexcept;

	void clear() noexcept;

	void push_back(char c);
	void pop_back();

	MyString& operator+=(char c);
	MyString& operator+=(const MyString& rhs);

	MyString operator+(char c) const;
	MyString operator+(const MyString& rhs) const;

	const char* c_str() const noexcept;

	bool operator==(const MyString &rhs) const noexcept;
	bool operator<(const MyString &rhs) const noexcept;
};

#endif /* SRC_MYSTRING_H_ */
