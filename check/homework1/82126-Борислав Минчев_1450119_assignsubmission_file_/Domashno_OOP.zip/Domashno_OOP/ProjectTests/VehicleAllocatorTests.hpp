#pragma once
#include "catch.hpp"
#include "../GarageWithVehicles/VehicleAllocator.h"

TEST_CASE("Testing contruction of vehicle allocator", "[allocator]")
{
	VehicleAllocator v;
	REQUIRE(&v != 0);//?
}

SCENARIO("Allocation of new vehicle is correct")
{
	GIVEN("Vehicle allocator")
	{
		VehicleAllocator allocator;
		WHEN("New vehicle is created")
		{
			Vehicle* v = 0;
			THEN("Vehicle is allocated correctly without errors")
			{
				REQUIRE_NOTHROW(v = allocator.allocate("1234", "a", 1));
				REQUIRE(!strcmp(v->registration(), "1234"));
				REQUIRE(!strcmp(v->description(), "a"));
				REQUIRE(v->space() == 1);
			}
		}
	}
}
