#define CATCH_CONFIG_MAIN 
#include "catch.hpp"

#include "GarageTests.hpp"
#include "VehicleTests.hpp"
#include "MyStringTests.hpp"
#include "VehicleAllocatorTests.hpp"