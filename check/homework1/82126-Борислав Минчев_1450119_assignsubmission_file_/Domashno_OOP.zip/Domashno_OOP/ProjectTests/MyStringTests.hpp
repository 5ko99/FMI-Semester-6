#pragma once

#include <cstring>
#include "catch.hpp"
#include "../GarageWithVehicles/MyString.h"


TEST_CASE("Testing convertion from MyString to cstring", "[string]")
{
	SECTION("Testing convertion from MyString to cstring with normal string")
	{
		REQUIRE(MyString("123456") == MyString("123456\0"));
		REQUIRE(!strcmp(MyString("123456").c_str(), "123456"));
		REQUIRE(!strcmp(MyString("qwerty").c_str(), "qwerty"));
		REQUIRE(!strcmp(MyString("ABCDE").c_str(), "ABCDE"));
		REQUIRE(!strcmp(MyString("ABC__EF").c_str(), "ABC__EF"));
		REQUIRE(!strcmp(MyString("AbC_??*123aaF").c_str(), "AbC_??*123aaF"));
		REQUIRE(!strcmp(MyString("123asd").c_str(), "123asd"));
		REQUIRE(!strcmp(MyString("1a2s3d").c_str(), "1a2s3d"));
		REQUIRE(!strcmp(MyString("hello world").c_str(), "hello world"));
	}
	SECTION("Testing convertion from MyString to cstring with long string")
	{
		REQUIRE(!strcmp(MyString("123687362187368712676726309319890238928").c_str(), "123687362187368712676726309319890238928"));
		REQUIRE(!strcmp(MyString("jdhkajshdjkhsjhdjkhsdkjhskjhd").c_str(), "jdhkajshdjkhsjhdjkhsdkjhskjhd"));
		REQUIRE(!strcmp(MyString("gjhadgsdjg7651236735yjjkahdkjhsad7686137613").c_str(), "gjhadgsdjg7651236735yjjkahdkjhsad7686137613"));
		REQUIRE(!strcmp(MyString("asdsdadsdggasdashello worldsdadggadsadads").c_str(), "asdsdadsdggasdashello worldsdadggadsadads"));
		REQUIRE(!strcmp(MyString("hello world hello world hello world hello world hello world").c_str(), "hello world hello world hello world hello world hello world"));
	}
	SECTION("Testing convertion from MyString to cstring with string with length 1")
	{
		REQUIRE(!strcmp(MyString("a").c_str(), "a"));
		REQUIRE(!strcmp(MyString("1").c_str(), "1"));
		REQUIRE(!strcmp(MyString(" ").c_str(), " "));
		REQUIRE(!strcmp(MyString("*").c_str(), "*"));
	}
	SECTION("Testing convertion from MyString to cstring with empty string")
	{
		REQUIRE(!strcmp(MyString("").c_str(), ""));
		REQUIRE(!strcmp(MyString().c_str(), ""));
	}
}


TEST_CASE("Testing constructing MyString", "[string]")
{
	SECTION("Testing constructing MyString (with default constructor)")
	{
		MyString s;
		REQUIRE(s.size() == 0);
		REQUIRE(strlen(s.c_str()) == strlen(""));
	}
	SECTION("Testing constructing MyString (with MyString(const char* str) constuctor)")
	{
		MyString s("asdfg");
		REQUIRE(s.size() == 5);
		REQUIRE(strlen(s.c_str()) == strlen("asdfg"));
	}
	SECTION("Testing constructing MyString (with copy constructor)")
	{
		MyString s1("1234");
		MyString s2(s1);
		
		REQUIRE(&s1 != &s2);
		REQUIRE(!strcmp(MyString(MyString("1234")).c_str(), "1234"));
		REQUIRE(!strcmp(MyString(MyString("")).c_str(), ""));
		REQUIRE(!strcmp(MyString(MyString()).c_str(), ""));
		REQUIRE(!strcmp(MyString(MyString("1234 abcd efgh")).c_str(), "1234 abcd efgh"));
	}
	SECTION("Testing constructing MyString (with copy assignment operator)")
	{
		MyString s1("1234");
		MyString s2 = s1;
		REQUIRE(&s1 != &s2);
		REQUIRE(!strcmp(s2.c_str(), "1234"));

		s2 = MyString();
		REQUIRE(!strcmp(s2.c_str(), ""));
		
		MyString s3(s1);
		s2 = s3;
		REQUIRE(&s1 != &s2);
		REQUIRE(!strcmp(s2.c_str(), "1234"));
	}
}

TEST_CASE("Tests about positions in string", "[string]")
{
	SECTION("Tests about positions in string using at")
	{
		SECTION("Tests about positions in string using at (constant version)")
		{
			REQUIRE_THROWS((const char&)MyString("12345").at(5));
			REQUIRE_THROWS((const char&)MyString("12345").at(100000000000000000));
			REQUIRE_THROWS((const char&)MyString("12345").at(-234));
			REQUIRE_THROWS((const char&)MyString("asddf").at(5));
			REQUIRE_THROWS((const char&)MyString("a").at(1));
			REQUIRE_THROWS((const char&)MyString(" ").at(1));
			REQUIRE_THROWS((const char&)MyString("helloooooo worlllllllllllld eeeeeeeeeeeeeee !!!!!!!!!!!!").at(56));

			REQUIRE((const char&)MyString("12345").at(0) == '1');
			REQUIRE((const char&)MyString("12345").at(4) == '5');
			REQUIRE((const char&)MyString("12345").at(2) == '3');
			REQUIRE((const char&)MyString("a").at(0) == 'a');
			REQUIRE((const char&)MyString(" ").at(0) == ' ');
			REQUIRE((const char&)MyString("helloooooo worlllllllllllld eeeeeeeeeeeeeee !!!!!!!!!!!!").at(21));
		}
		SECTION("Tests about positions in string using at (non-constant version)")
		{
			REQUIRE_THROWS((char&)MyString("12345").at(5));
			REQUIRE_THROWS((char&)MyString("12345").at(100000000000000000));
			REQUIRE_THROWS((char&)MyString("12345").at(-234));
			REQUIRE_THROWS((char&)MyString("asddf").at(5));
			REQUIRE_THROWS((char&)MyString("a").at(1));
			REQUIRE_THROWS((char&)MyString(" ").at(1));
			REQUIRE_THROWS((char&)MyString("helloooooo worlllllllllllld eeeeeeeeeeeeeee !!!!!!!!!!!!").at(56));

			REQUIRE((char&)MyString("12345").at(0) == '1');
			REQUIRE((char&)MyString("12345").at(4) == '5');
			REQUIRE((char&)MyString("12345").at(2) == '3');
			REQUIRE((char&)MyString("a").at(0) == 'a');
			REQUIRE((char&)MyString(" ").at(0) == ' ');
			REQUIRE((char&)MyString("helloooooo worlllllllllllld eeeeeeeeeeeeeee !!!!!!!!!!!!").at(21));

			MyString s("12345");
			s.at(0) = 'A';
			REQUIRE(s.at(0) == 'A');
		}
	}

	SECTION("Tests about positions in string using [] operator")
	{
		SECTION("Tests about positions in string using [] operator (constant version)")
		{
			REQUIRE((const char&)MyString("12345")[0] == '1');
			REQUIRE((const char&)MyString("12345")[4] == '5');
			REQUIRE((const char&)MyString("12345")[2] == '3');
			REQUIRE((const char&)MyString("a")[0] == 'a');
			REQUIRE((const char&)MyString(" ")[0] == ' ');
			REQUIRE((const char&)MyString("helloooooo worlllllllllllld eeeeeeeeeeeeeee !!!!!!!!!!!!")[21]);
		}
		SECTION("Tests about positions in string using [] operator (non-constant version)")
		{
			REQUIRE((char&)MyString("12345")[0] == '1');
			REQUIRE((char&)MyString("12345")[4] == '5');
			REQUIRE((char&)MyString("12345")[2] == '3');
			REQUIRE((char&)MyString("a")[0] == 'a');
			REQUIRE((char&)MyString(" ")[0] == ' ');
			REQUIRE((char&)MyString("helloooooo worlllllllllllld eeeeeeeeeeeeeee !!!!!!!!!!!!")[21]);

			MyString s("12345");
			s[0] = 'A';
			REQUIRE(s[0] == 'A');
		}
	}

	SECTION("Tests about positions in string using front()")
	{
		SECTION("Tests about positions in string using front() (constant version)")
		{
			REQUIRE((const char&)MyString("12345").front() == '1');
			REQUIRE((const char&)MyString("a").front() == 'a');
			REQUIRE((const char&)MyString(" ").front() == ' ');
			REQUIRE((const char&)MyString("helloooooo worlllllllllllld eeeeeeeeeeeeeee !!!!!!!!!!!!").front() == 'h');
		}
		SECTION("Tests about positions in string using front() (non-constant version)")
		{
			REQUIRE((char&)MyString("12345").front() == '1');
			REQUIRE((char&)MyString("a").front() == 'a');
			REQUIRE((char&)MyString(" ").front() == ' ');
			REQUIRE((char&)MyString("helloooooo worlllllllllllld eeeeeeeeeeeeeee !!!!!!!!!!!!").front() == 'h');

			MyString s("12345");
			s.front() = 'A';
			REQUIRE(s.front() == 'A');
		}
	}

	SECTION("Tests about positions in string using back()")
	{
		SECTION("Tests about positions in string using back() (constant version)")
		{
			REQUIRE((const char&)MyString("12345").back() == '5');
			REQUIRE((const char&)MyString("a").back() == 'a');
			REQUIRE((const char&)MyString(" ").back() == ' ');
			REQUIRE((const char&)MyString("helloooooo worlllllllllllld eeeeeeeeeeeeeee !!!!!!!!!!!!").back() == '!');
		}
		SECTION("Tests about positions in string using back() (non-constant version)")
		{
			REQUIRE((char&)MyString("12345").back() == '5');
			REQUIRE((char&)MyString("a").back() == 'a');
			REQUIRE((char&)MyString(" ").back() == ' ');
			REQUIRE((char&)MyString("helloooooo worlllllllllllld eeeeeeeeeeeeeee !!!!!!!!!!!!").back() == '!');

			MyString s("12345");
			s.back() = 'A';
			REQUIRE(s.back() == 'A');
		}
	}
}

TEST_CASE("Tests about size of given string", "[string]")
{
	SECTION("Tests about size of given string. Check size of that string")
	{
		REQUIRE(MyString("asdf").size() == 4);
		REQUIRE(MyString("123456789").size() == 9);
		REQUIRE(MyString("a").size() == 1);
		REQUIRE(MyString("").size() == 0);
		REQUIRE(MyString("  ").size() == 2);
		REQUIRE(MyString("\t").size() == 1);
		REQUIRE(MyString("1234 5678 9").size() == 11);
		REQUIRE(MyString("0123/123/123").size() == 12);
	}
	SECTION("Tests about size of given string. Check if that string is empty")
	{
		REQUIRE(!MyString("asdf").empty());
		REQUIRE(!MyString("123456789").empty());
		REQUIRE(!MyString("a").empty());
		REQUIRE(!MyString("  ").empty());
		REQUIRE(!MyString("\t").empty());
		REQUIRE(!MyString("1234 5678 9").empty());
		REQUIRE(!MyString("0123/123/123").empty());
		REQUIRE(MyString("").empty());
	}
}

SCENARIO("Clearing string is correct")
{
	GIVEN("Non-empty string")
	{
		MyString s("1234");
		WHEN("String is cleared")
		{
			s.clear();
			THEN("String is empty")
			{
				REQUIRE(!strcmp(s.c_str(), ""));
			}
		}
		WHEN("String is not cleared")
		{
			THEN("String remains the same")
			{
				REQUIRE(!strcmp(s.c_str(), "1234"));
			}
		}
	}
	GIVEN("Already empty string")
	{
		MyString s;
		WHEN("String is cleared")
		{
			s.clear();

			THEN("String is empty")
			{
				REQUIRE(!strcmp(s.c_str(), ""));
			}
		}
		WHEN("String is not cleared")
		{
			THEN("String is still empty")
			{
				REQUIRE(!strcmp(s.c_str(), ""));
			}
		}
	}
}

TEST_CASE("Testing other operators about MyString", "[string]")
{
	SECTION("Testing other operators about MyString (operator+=(char c))") 
	{
		MyString s("1234");
		s += '5';
		REQUIRE(s == MyString("12345"));
		s += '\0';
		REQUIRE(s == MyString("12345"));
		REQUIRE(s.size() == MyString("12345").size());
	}
	SECTION("Testing other operators about MyString (operator+=(const MyString& rhs))")
	{
		MyString s("1234");
		s += "5";
		REQUIRE(s == MyString("12345"));
		REQUIRE(s == MyString("12345"));
		s += "\0";
		REQUIRE(s == MyString("12345"));
		REQUIRE(s.size() == MyString("12345").size());
		s += "asdf";
		REQUIRE(s == MyString("12345asdf"));
		REQUIRE(s.size() == MyString("12345asdf").size());
	}
	SECTION("Testing other operators about MyString (operator+(char c))")
	{
		
		REQUIRE(MyString("1234") + '5' == MyString("12345"));
		REQUIRE(MyString("1234") + '\0' == MyString("1234"));
		REQUIRE(MyString("1234") + 'a' == MyString("1234a"));
	}
	SECTION("Testing other operators about MyString (operator+(const MyString& rhs))")
	{
		REQUIRE(MyString("1234") + "5" == MyString("12345"));
		REQUIRE(MyString("1234") + "\0" == MyString("1234"));
		REQUIRE(MyString("1234") + "asdf" == MyString("1234asdf"));
		REQUIRE(MyString("1234") + "111111111111111111" == MyString("1234111111111111111111"));
	}
	SECTION("Testing other operators about MyString (operator==(const MyString& rhs))")
	{
		//REQUIRE(&MyString("1234") != &MyString("1234"));
		REQUIRE(!strcmp(MyString("1234").c_str(), "1234"));
		REQUIRE(!strcmp(MyString("a").c_str(), "a"));
		REQUIRE(!strcmp(MyString("").c_str(), ""));
		REQUIRE(!strcmp(MyString("").c_str(), MyString().c_str()));
	}
	SECTION("Testing other operators about MyString (operator<(const MyString& rhs))")
	{
		REQUIRE(strcmp(MyString("1234").c_str(), MyString("12345").c_str()) < 0);
		REQUIRE(strcmp(MyString("1234").c_str(), MyString("2345").c_str()) < 0);
		REQUIRE(strcmp(MyString("a").c_str(), MyString("b").c_str()) < 0);
		REQUIRE(strcmp(MyString("a").c_str(), MyString("aaaa").c_str()) < 0);
		REQUIRE(strcmp(MyString("").c_str(), MyString("1").c_str()) < 0);
	}
}

SCENARIO("Pushing back char to string is correct")
{
	GIVEN("Non-empty string")
	{
		MyString s("1234");
		WHEN("Pushed letter")
		{
			s.push_back('a');
			REQUIRE(s == MyString("1234a"));
			s.push_back('A');
			REQUIRE(s == MyString("1234aA"));
		}
		WHEN("Pushed number")
		{
			s.push_back('1');
			REQUIRE(s == MyString("12341"));
			s.push_back('0');
			REQUIRE(s == MyString("123410"));
		}
		WHEN("Pushed whitespace")
		{
			s.push_back('\n');
			REQUIRE(s == MyString("1234\n"));
			s.push_back(' ');
			REQUIRE(s == MyString("1234\n "));
			s.push_back('\t');
			REQUIRE(s == MyString("1234\n \t"));
		}
		WHEN("Pushed '\0'")
		{
			s.push_back('\0');
			REQUIRE(s == MyString("1234\0"));
			REQUIRE(s == MyString("1234"));
		}
	}
	GIVEN("Empty string")
	{
		MyString s;
		WHEN("Pushed letter")
		{
			s.push_back('a');
			REQUIRE(s == MyString("a"));
			s.push_back('A');
			REQUIRE(s == MyString("aA"));
		}
		WHEN("Pushed number")
		{
			s.push_back('1');
			REQUIRE(s == MyString("1"));
			s.push_back('0');
			REQUIRE(s == MyString("10"));
		}
		WHEN("Pushed whitespace")
		{
			s.push_back('\n');
			REQUIRE(s == MyString("\n"));
			s.push_back(' ');
			REQUIRE(s == MyString("\n "));
			s.push_back('\t');
			REQUIRE(s == MyString("\n \t"));
		}
		WHEN("Pushed '\0'")
		{
			s.push_back('\0');
			REQUIRE(s == MyString("\0"));
			REQUIRE(s == MyString(""));
			REQUIRE(s == MyString());
		}
	}
}

SCENARIO("Popping back char to string is correct")
{
	GIVEN("Non-empty string")
	{
		MyString s("abcd");
		WHEN("is popped single char")
		{
			s.pop_back();
			REQUIRE(s == MyString("abc"));
		}
		WHEN("are popped more than one chars")
		{
			s.pop_back();
			s.pop_back();
			REQUIRE(s == MyString("ab"));
		}
		WHEN("are popped all chars")
		{
			s.pop_back();
			s.pop_back();
			s.pop_back();
			s.pop_back();
			REQUIRE(s == MyString());
			REQUIRE(s == MyString(""));
		}
	}
}
