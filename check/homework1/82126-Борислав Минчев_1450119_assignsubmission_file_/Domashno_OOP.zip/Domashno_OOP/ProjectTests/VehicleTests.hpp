#pragma once

#include "catch.hpp"
#include "../GarageWithVehicles/Vehicle.h"

TEST_CASE("Testing construction of vehicle", "[vehicle]")
{
	SECTION("Testing construction of vehicle. Check if setting registration is correct")
	{
		REQUIRE(!strcmp(Vehicle("a", "a", 1).registration(), "a"));
		REQUIRE(!strcmp(Vehicle("1", "a", 1).registration(), "1"));
		REQUIRE(!strcmp(Vehicle("", "a", 1).registration(), ""));
		REQUIRE(!strcmp(Vehicle("\0", "a", 1).registration(), ""));
		REQUIRE(!strcmp(Vehicle("hello world", "a", 1).registration(), "hello world"));
		REQUIRE(!strcmp(Vehicle("FqZi^LLJUYL4WqoH5tH_M=l2piAM@Lb?pe9*|3p6Zatk6wsnKnU48e-n", "a", 1).registration(),
			"FqZi^LLJUYL4WqoH5tH_M=l2piAM@Lb?pe9*|3p6Zatk6wsnKnU48e-n"));
	}
	SECTION("Testing construction of vehicle. Check if setting description is correct")
	{
		REQUIRE(!strcmp(Vehicle("a", "a", 1).description(), "a"));
		REQUIRE(!strcmp(Vehicle("a", "1", 1).description(), "1"));
		REQUIRE(!strcmp(Vehicle("a", "", 1).description(), ""));
		REQUIRE(!strcmp(Vehicle("a", "\0", 1).description(), ""));
		REQUIRE(!strcmp(Vehicle("a", "hello world", 1).description(), "hello world"));
		REQUIRE(!strcmp(Vehicle("a", "FqZi^LLJUYL4WqoH5tH_M=l2piAM@Lb?pe9*|3p6Zatk6wsnKnU48e-n", 1).description(),
			"FqZi^LLJUYL4WqoH5tH_M=l2piAM@Lb?pe9*|3p6Zatk6wsnKnU48e-n"));
	}
	SECTION("Testing construction of vehicle. Check if setting registration is correct")
	{
		REQUIRE(Vehicle("a", "a", 1).space() == 1);
		REQUIRE(Vehicle("a", "a", 6).space() == 6);
		REQUIRE(Vehicle("1", "a", 0).space() == 0);
		REQUIRE(Vehicle("1", "a", 10).space() == 10);
		REQUIRE(Vehicle("1", "a", SIZE_MAX).space() == SIZE_MAX);
	}
}

/*
	Vehicle(const char* registration, const char* description, std::size_t space);
	const char* registration() const;
	const char* description() const;
	std::size_t space() const;
*/