#pragma once

#include "catch.hpp"
#include "../GarageWithVehicles/VehicleAllocator.h"
#include "../GarageWithVehicles/Garage.h"

TEST_CASE("Testing constructing garage object", "[garage]")
{
	VehicleAllocator a;
	SECTION("Testing constructing garage object (using Garage(std::size_t) constructor)")
	{
		REQUIRE_THROWS(Garage(0));
		REQUIRE_NOTHROW(Garage(12));
		REQUIRE(Garage(1).size() == 0);
		REQUIRE(Garage(12).size() == 0);
		//slows tests
		//REQUIRE(Garage(INT_MAX).size() == 0);
	}
	SECTION("Testing constructing garage object (using copy constructor)")
	{
		Garage g1(5);
		Garage g2(g1);
		REQUIRE(&g1 != &g2);
		REQUIRE_THROWS(Garage(Garage(0)));
		REQUIRE_NOTHROW(Garage(Garage(12)));
		REQUIRE(Garage(Garage(1)).size() == 0);
		REQUIRE(Garage(Garage(12)).size() == 0);
	}
	SECTION("Testing constructing garage object (using copy assignment operator)")
	{
		Garage g1(12);
		Garage g2 = g1;
		Garage g3(1);
		REQUIRE(&g1 != &g2);
		REQUIRE(g2.size() == 0);
		g2 = g3;
		REQUIRE(g2.size() == 0);
		g2 = g1;
		REQUIRE(g2.size() == 0);
	}
}

TEST_CASE("Tests about positions in garage", "[garage]")
{
	Garage g(12);
	Vehicle v1("1234", "descr1", 4), v2("5678", "descr2", 4), v3("9876", "descr3", 4);
	g.insert(v1);
	g.insert(v2);
	g.insert(v3);
	SECTION("Tests about positions in string using at")
	{
		REQUIRE_THROWS(g.at(-1));
		REQUIRE_THROWS(g.at(4));
		REQUIRE_NOTHROW(g.at(1));
		REQUIRE_THROWS(g.at(100000000));

		REQUIRE(&g.at(0) == &v1);
		REQUIRE(&g.at(1) == &v2);
		REQUIRE(&g.at(2) == &v3);
	}
	SECTION("Tests about positions in string using operator[](std::size_t)")
	{
		REQUIRE(&g[0] == &v1);
		REQUIRE(&g[1] == &v2);
		REQUIRE(&g[2] == &v3);
	}
	SECTION("Tests about positions in string using find")
	{
		REQUIRE(g.find("") == nullptr);
		REQUIRE(g.find("12349") == nullptr);
		REQUIRE(g.find("1234") == &v1);
		REQUIRE(g.find("5678") == &v2);
		REQUIRE(g.find("9876") == &v3);
	}
}

TEST_CASE("Tests about size in garage.", "[garage]")
{
	Garage g(123);
	Vehicle v1("1234", "descr1", 4), v2("5678", "descr2", 4), v3("9876", "descr3", 4);
	SECTION("Tests about size in garage. Testing size() method")
	{
		REQUIRE(g.size() == 0);
		
		g.insert(v1);
		REQUIRE(g.size() == 1);
		
		g.insert(v2);
		REQUIRE(g.size() == 2);
		
		g.insert(v3);
		REQUIRE(g.size() == 3);
	}
	SECTION("Tests about size in garage. Testing empty() method")
	{
		REQUIRE(Garage(1).empty());
		REQUIRE(Garage(10).empty());
		REQUIRE(Garage(123).empty());
		//slows tests
		//REQUIRE(Garage(INT_MAX).empty());
	}
}

SCENARIO("Check if inserting vehicles from garage is correct")
{
	GIVEN("Empty garage")
	{
		Garage g(12);
		WHEN("Aren't inserted any vehicles")
		{
			THEN("Garage is empty")
			{
				REQUIRE(g.empty());
			}
		}
		WHEN("Is inserted single vehicle without size isues")
		{
			Vehicle v1("1234", "descr1", 4);
			THEN("Vehicle is insered in garage without exceptions thrown")
			{
				REQUIRE_NOTHROW(g.insert(v1));
				REQUIRE(g.size() == 1);
				REQUIRE(&g.at(0) == &v1);
			}
			
		}
		WHEN("Is inserted single vehicle with size isues")
		{
			Vehicle v1("1234", "descr1", 13);
			THEN("Vehicle isn't insered in garage because exception is thrown")
			{
				REQUIRE_THROWS(g.insert(v1));
				REQUIRE(g.empty());
			}

		}
		WHEN("Are inserted multiple vehicles without size isues")
		{
			Vehicle v1("1234", "descr1", 4), v2("5678", "descr2", 4), v3("9876", "descr3", 4);
			THEN("Vehicles are insered in garage without exceptions")
			{
				REQUIRE_NOTHROW(g.insert(v1));
				REQUIRE(g.size() == 1);
				REQUIRE(&g.at(0) == &v1);

				REQUIRE_NOTHROW(g.insert(v2));
				REQUIRE(g.size() == 2);
				REQUIRE(&g.at(1) == &v2);

				REQUIRE_NOTHROW(g.insert(v3));
				REQUIRE(g.size() == 3);
				REQUIRE(&g.at(2) == &v3);
			}

		}
		WHEN("Are inserted multiple vehicles with size isues")
		{
			Vehicle v1("1234", "descr1", 4), v2("5678", "descr2", 4), v3("9876", "descr3", 4), v4("9876", "descr3", 13);

			WHEN("The problem vehicle is the first that is inserted")
			{
				THEN("No vehicles aren't insered in garage because exception is thrown") 
				{
					REQUIRE_THROWS(g.insert(v4));
					REQUIRE(g.empty());
				}
			}
			WHEN("The problem vehicle is somewhere in middle of insertion sequence")
			{
				THEN("Problem vehicle isn't inserted but all other are inserted.")
				{
					REQUIRE_NOTHROW(g.insert(v1));
					REQUIRE_NOTHROW(g.insert(v2));
					REQUIRE_THROWS(g.insert(v4));
					REQUIRE_NOTHROW(g.insert(v3));

					REQUIRE(g.size() == 3);
					REQUIRE(&g[0] == &v1);
					REQUIRE(&g[1] == &v2);
					REQUIRE(&g[2] == &v3);
				}
			}
			WHEN("The problem vehicle at the end of insertion sequence")
			{
				THEN("Problem vehicle isn't inserted but all other are inserted.")
				{
					REQUIRE_NOTHROW(g.insert(v1));
					REQUIRE_NOTHROW(g.insert(v2));
					REQUIRE_NOTHROW(g.insert(v3));
					REQUIRE_THROWS(g.insert(v4));

					REQUIRE(g.size() == 3);
					REQUIRE(&g[0] == &v1);
					REQUIRE(&g[1] == &v2);
					REQUIRE(&g[2] == &v3);
				}
					
			}

		}
	}
}

SCENARIO("Check if removing vehicles from garage is correct")
{
	GIVEN("Empty garage and several vehicles")
	{
		Garage g(12);
		Vehicle v1("1234", "descr1", 4), v2("5678", "descr2", 4), v3("9876", "descr3", 4);
		WHEN("None vehicles are inserted in garage")
		{
			WHEN("We try to clear whole garage with clear()")
			{
				THEN("Nothing changes and no exceptions are thrown")
				{
					REQUIRE_NOTHROW(g.clear());
					REQUIRE(g.empty());
				}
			}
			WHEN("We try to clear a vehicle with erase()")
			{
				THEN("Nothing changes and no exceptions are thrown")
				{
					REQUIRE_NOTHROW(g.erase("1234"));
					REQUIRE(g.empty());
				}
			}
		}
		WHEN("There are vehicles in garage")
		{
			g.insert(v1);
			g.insert(v2);
			g.insert(v3);
			WHEN("We try to clear whole garage with clear()")
			{
				THEN("There are't vehicles in garage and no exceptions are thrown")
				{
					REQUIRE_NOTHROW(g.clear());
					REQUIRE(g.empty());
				}
			}
			WHEN("We try to clear single vehicle with erase()")
			{
				THEN("That vehicle is removed from garage and no exceptions are thrown")
				{
					REQUIRE_NOTHROW(g.erase("1234"));
					REQUIRE(g.size() == 2);
					REQUIRE(&g[0] == &v3);
					REQUIRE(&g[1] == &v2);

				}
			}
			WHEN("We try to clear all vehicles with erase()")
			{
				THEN("All vehicle are removed one by one from garage and no exceptions are thrown")
				{
					REQUIRE(g.size() == 3);

					REQUIRE_NOTHROW(g.erase("1234"));
					REQUIRE(g.size() == 2);
					REQUIRE(&g[0] == &v3);
					REQUIRE(&g[1] == &v2);
					
					REQUIRE_NOTHROW(g.erase("9876"));
					REQUIRE(g.size() == 1);
					REQUIRE(&g[0] == &v2);
					
					REQUIRE_NOTHROW(g.erase("5678"));
					REQUIRE(g.empty());
					

				}
			}
		}
	}
}



