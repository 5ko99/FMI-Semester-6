#include "VehicleAllocator.h"

VehicleAllocator::VehicleAllocator()
{
	this->size = 0;
	this->list = new Vehicle*[0];
}

VehicleAllocator::~VehicleAllocator()
{
	for (std::size_t i = 0; i < this->size; i++)
	{
		delete this->list[i];
	}
	delete[] list;
}

Vehicle* VehicleAllocator::allocate(const char* registration, const char* description, std::size_t space)
{
	Vehicle* v = new Vehicle(registration, description, space);
	
	Vehicle** temp = new Vehicle* [this->size + 1];
	for (std::size_t i = 0; i < this->size; i++)
	{
		temp[i] = this->list[i];
	}
	//std::copy(this->list, this->list + size, temp);
	temp[size] = v;

	delete[] this->list;
	
	this->list = temp;
	this->size++;
	return v;
}