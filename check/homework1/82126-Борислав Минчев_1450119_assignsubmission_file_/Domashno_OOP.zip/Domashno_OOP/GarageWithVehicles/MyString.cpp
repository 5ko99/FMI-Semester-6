#include "MyString.h"
#include <cstring>
#include <stdexcept>
#include <new>
#include <cassert>

MyString::MyString()
{
	this->string = new char[1];
	this->length = 0;
	this->string[length] = '\0';
}

MyString::~MyString()
{
	this->length = 0;
	delete[] this->string;
}

MyString::MyString(const MyString& cpy)
{
	this->length = cpy.length;
	
	this->string = new char[cpy.length + 1];
	
	for (std::size_t i = 0; i < cpy.length; i++)
	{
		this->string[i] = cpy.at(i);
	}
	this->string[cpy.length] = '\0';
	
}

MyString& MyString::operator=(const MyString& other)
{
	delete[] string;
	
	this->length = other.length;

	this->string = new char[other.length + 1];

	for (std::size_t i = 0; i < other.length; i++)
	{
		this->string[i] = other.at(i);
	}
	this->string[other.length] = '\0';
	return *this;
}

MyString::MyString(const char* str)
{
	this->length = strlen(str);
	this->string = new char[this->length + 1];
	
	for (std::size_t i = 0; i < this->length; i++)
	{
		this->string[i] = str[i];
	}
	this->string[this->length] = '\0';
}
char& MyString::at(std::size_t pos)
{
	if (pos >= this->length || pos < 0) {
		throw std::out_of_range("Given invalid or out of range index");
	}
	return string[pos];
}
const char& MyString::at(std::size_t pos) const
{
	if (pos >= this->length || pos < 0) {
		throw std::out_of_range("Given invalid or out of range index");
	}
	return string[pos];
}

char& MyString::operator[](std::size_t pos)
{
	assert(pos >= 0 && pos < this->length);
	return string[pos];
}
const char& MyString::operator[](std::size_t pos) const
{
	assert(pos >= 0 && pos < this->length);
	return string[pos];
}
char& MyString::front()
{
	assert(this->length > 0);
	return string[0];
}
const char& MyString::front() const
{
	assert(this->length > 0);
	return string[0];
}
char& MyString::back()
{
	assert(this->length > 0);
	return string[this->length - 1];
}
const char& MyString::back() const
{
	assert(this->length > 0);
	return string[this->length - 1];
}
bool MyString::empty() const
{
	return this->length == 0;
}
std::size_t MyString::size() const
{
	return this->length;
}
void MyString::clear()
{
	delete[] this->string;
	this->string = new char[1];
	this->string[0] = '\0';
	this->length = 0;

}
void MyString::push_back(char c)
{	
	if (c != '\0') 
	{
		char* str = new char[this->length + 2];
		this->length++;
		for (std::size_t i = 0; i < this->length - 1; i++)
		{
			str[i] = this->string[i];
		}
		str[this->length - 1] = c;
		str[this->length] = '\0';
	
		delete[] this->string;
		this->string = str;
	}
}
void MyString::pop_back()
{
	assert(this->length > 0);
	
	char* str = new char[this->length];
	this->length--;
	for (std::size_t i = 0; i < this->length; i++)
	{
		str[i] = this->string[i];
	}
	str[this->length] = '\0';
	delete[] this->string;

	this->string = str;
}

MyString& MyString::operator+=(char c)
{
	this->push_back(c);
	return *this;
}
MyString& MyString::operator+=(const MyString& rhs)
{
	std::size_t s = rhs.size();
	char* str = new char[this->length + 1 + s];
	this->length += s;
	for (std::size_t i = 0; i < this->length - s; i++)
	{
		str[i] = this->string[i];
	}
	for (std::size_t i = 0; i < s; i++)
	{
		str[this->length - s + i] =rhs[i];
	}
	str[this->length] = '\0';

	delete[] this->string;
	this->string = str;
	return *this;
}
MyString MyString::operator+(char c) const
{
	MyString res(*this);
	res += c;
	return res;
}
MyString MyString::operator+(const MyString& rhs) const
{
	MyString res(*this);
	res += rhs;
	return res;
}

const char* MyString::c_str() const
{
	return this->string;
}

bool MyString::operator==(const MyString& rhs) const
{
	if (this->size() != rhs.size())
	{
		return false;
	}
	return strcmp(this->string, rhs.c_str()) == 0;
}

bool MyString::operator<(const MyString& rhs) const
{
	return strcmp(this->string, rhs.c_str()) < 0;
}
