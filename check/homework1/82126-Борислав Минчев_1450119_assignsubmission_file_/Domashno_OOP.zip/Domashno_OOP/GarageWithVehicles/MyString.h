#pragma once

#include <iostream>
#include <cstring>

class MyString
{
	char* string;
	std::size_t length;
public:
	MyString();
	
	~MyString();
	MyString(const MyString& cpy);
	MyString& operator=(const MyString& other);

	MyString(const char* str);
	char& at(std::size_t pos);
	const char& at(std::size_t pos) const;
	char& operator[](std::size_t pos);
	const char& operator[](std::size_t pos) const;
	char& front();
	const char& front() const;
	char& back();
	const char& back() const;
	bool empty() const;
	std::size_t size() const;
	void clear();
	void push_back(char c);
	void pop_back();

	MyString& operator+=(char c);
	MyString& operator+=(const MyString& rhs);
	MyString operator+(char c) const;
	MyString operator+(const MyString& rhs) const;
	const char* c_str() const;
	bool operator==(const MyString& rhs) const;
	bool operator<(const MyString& rhs) const;

	
	friend std::ostream& operator<<(std::ostream& os, const MyString& str)
	{
		for (std::size_t i = 0; i < strlen(str.c_str()); i++)
		{
			os << str[i];
		}
		return os;
	}
	
	friend std::istream& operator >>(std::istream& is, MyString& str)
	{
		char c;
		is.ignore(is.rdbuf()->in_avail());
		c = is.get();
		while (c != '\n')
		{
			str.push_back(c);
			c = is.get();
		}
		return is;
	}
};

