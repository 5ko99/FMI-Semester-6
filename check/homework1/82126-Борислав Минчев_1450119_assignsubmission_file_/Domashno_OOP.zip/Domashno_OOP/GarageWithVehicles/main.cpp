#include <iostream>
#include <climits>
#include "MyString.h"
#include "Vehicle.h"
#include "Garage.h"
#include "VehicleAllocator.h"


void getSpaceInput(std::size_t& s)
{
	std::cout << "Enter space of your garage: ";
	std::cin >> s;
	if (!std::cin)
	{
		throw std::runtime_error("Invalid input! Please enter a number!");
	}
	if (!s) 
	{
		throw std::runtime_error("Invalid input! Please enter a non-zero number!");
	}
}

void newVehicleDialog(VehicleAllocator& allocator, Garage& garage)
{
	MyString regNum, descr;
	std::size_t space;
	std::cout << "Enter information for your vehicle:" << std::endl;
	std::cout << "Registration number: ";
	//std::cin.ignore();
	std::cin >> regNum;

	std::cout << "Description: ";
	std::cin >> descr;

	std::cout << "Parking space: ";
	std::cin >> space;
	
	if (!std::cin)
	{
		std::cout << "Invalid data!";
		return;
	}

	Vehicle* v = allocator.allocate(regNum.c_str(), descr.c_str(), space);
	try
	{
		garage.insert(*v);
	}
	catch (const std::exception& e)
	{
		throw e;
	}
	
}
void deleteVehicleDialog(Garage& garage)
{
	MyString regNum;
	std::cout << "Enter registration number of vehicle you want to delete: ";
	
	//std::cin.ignore();
	std::cin >> regNum;
	garage.erase(regNum.c_str());
}
void printVehicles(Garage& garage)
{
	for (std::size_t i = 0; i < garage.size(); i++)
	{
		std::cout << garage[i].registration() << " " << garage[i].description() << " " << garage[i].space() << std::endl;
	}
}


int main()
{
	VehicleAllocator allocator;
	std::size_t space;
	try
	{
		getSpaceInput(space);
	}
	catch (const std::exception& e)
	{
		std::cout << e.what();
		return 1;
	}
	Garage garage(space);
	const char comandList[] = "(0) Show list of commands.\n(1) Put new vehicle in your garage.\n(2) Delete vehicle.\n(3) Print contents of garage.\n(99) Exit the program";
	while (true)
	{
		int code;

		std::cout << std::endl << "To show list of commands type 0." << std::endl;
		std::cout << "What do you want to do?: ";
		std::cin >> code;
		switch (code)
		{
		case 0: {
			std::cout << std::endl << "#########################################" << std::endl;
			std::cout << comandList << std::endl;
			std::cout << "#########################################" << std::endl;
			break;
		}
		case 1: {
			std::cout << std::endl << "#########################################" << std::endl;
			try 
			{
				newVehicleDialog(allocator, garage);
			}
			catch (const std::exception& e)
			{
				std::cout << std::endl << e.what() << " Please try again.\n" << std::endl;
			}
			
			std::cout << "#########################################" << std::endl;
			break;
		}
		case 2: {
			std::cout << std::endl << "#########################################" << std::endl;
			deleteVehicleDialog(garage);
			std::cout << "#########################################" << std::endl;
			break;
		}
		case 3: {
			std::cout << std::endl << "#########################################" << std::endl;
			printVehicles(garage);
			std::cout << "#########################################" << std::endl;
			break;
		}
		case 99: {
			std::cout << std::endl << "#########################################" << std::endl;
			std::cout << "Thank you! See you again." << std::endl;
			std::cout << "#########################################" << std::endl;
			return 0;
		}
		default:
			std::cout << std::endl << "#########################################" << std::endl;
			std::cout << std::endl << "Invalid command! Please try again." << std::endl;
			std::cout << "#########################################" << std::endl;
			break;
		}
		
	}
	
}

