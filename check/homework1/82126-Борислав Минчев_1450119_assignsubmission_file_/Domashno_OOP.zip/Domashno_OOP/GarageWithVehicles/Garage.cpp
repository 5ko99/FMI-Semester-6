#include "Garage.h"
#include <cassert>
#include <cstring>
std::size_t Garage::getFreeSpace() const
{
	std::size_t free = this->capacity;
	for (std::size_t i = 0; i < this->size(); i++)
	{
		if (!this->vehicles[i])
		{
			return free;
		}
		free -= this->vehicles[i]->space();
	}
	return free;
}

Garage::Garage(std::size_t size): capacity(size)
{
	if (!size)
	{
		throw std::runtime_error("Invalid size of garage!");
	}
		
	this->vehicles = new Vehicle*[size];
	for (std::size_t i = 0; i < size; i++)
	{
		this->vehicles[i] = nullptr;
	}
}
Garage::~Garage()
{
	delete[] this->vehicles;
}
Garage::Garage(const Garage& cpy) :capacity(cpy.capacity)
{
	this->vehicles = new Vehicle* [cpy.capacity];
	for (std::size_t i = 0; i < cpy.capacity; i++)
	{
		this->vehicles[i] = cpy.vehicles[i];
	}
}
Garage& Garage::operator=(const Garage& other)
{
	if (this != &other)
	{
		delete[] vehicles;
		this->capacity = other.capacity;
		this->vehicles = new Vehicle * [other.capacity];
		for (std::size_t i = 0; i < other.capacity; i++)
		{
			this->vehicles[i] = other.vehicles[i];
		}
	}
	return *this;
}

void Garage::insert(Vehicle& v)
{
	std::size_t freeSpace = this->getFreeSpace();
	
	bool hasDuplicate = false;
	for (std::size_t i = 0; i < this->size(); i++)
	{
		if(!strcmp(this->vehicles[i]->registration(),v.registration()))
		{
			hasDuplicate = true;
			break;
		}
	}

	if(hasDuplicate || freeSpace < v.space())
	{
		throw std::runtime_error("Not enought space or already added vehicle with same registration number.");
	}

	this->vehicles[this->size()] = &v;
}

void Garage::erase(const char* registration)
{
	for (std::size_t i = 0; i < this->size(); i++)
	{
		if (!strcmp(this->vehicles[i]->registration(), registration))
		{
			std::size_t idx = this->size() - 1;
			Vehicle* v = this->vehicles[idx];
			this->vehicles[i] = v;
			this->vehicles[idx] = nullptr;
			break;
		}
	}
}

const Vehicle& Garage::at(std::size_t pos) const
{
	if (pos >= this->size() || pos < 0)
	{
		throw std::out_of_range("Given index out of range!");
	}
	return *this->vehicles[pos];
}

const Vehicle& Garage::operator[](std::size_t pos) const
{
	assert(pos>=0 && pos < this->size());
	return *this->vehicles[pos];
}
bool Garage::empty() const
{
	return (!this->vehicles[0]);
}
std::size_t Garage::size() const
{
	
	std::size_t s = 0;
	if (!this->vehicles[s])
	{
		return 0;
	}

	for (std::size_t i = 1; i < this->capacity; i++)
	{
		if (!this->vehicles[i])
		{
			return s + 1;
		}
		s = i;
	}

	return s + 1;
}
void Garage::clear()
{
	for (std::size_t i = 0; i < this->size(); i++)
	{
		this->vehicles[i] = nullptr;
	}
}

const Vehicle* Garage::find(const char* registration) const
{
	for (std::size_t i = 0; i < this->size(); i++)
	{
		if (!strcmp(this->vehicles[i]->registration(), registration))
		{
			return &this->at(i);
		}
	}
	return nullptr;
}
