#pragma once
#include <iostream>
#include "Vehicle.h"
#include "Garage.h"

class VehicleAllocator {
    
    std::size_t size;
    Vehicle** list;

public:
    VehicleAllocator();
    ~VehicleAllocator();
    Vehicle* allocate(const char* registration, const char* description, std::size_t space);
};
