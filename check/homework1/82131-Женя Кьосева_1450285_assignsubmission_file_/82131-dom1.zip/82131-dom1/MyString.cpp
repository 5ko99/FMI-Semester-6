#include <iostream>
#include "MyString.hpp"
#include <stdexcept>

MyString::MyString()
{
	string = NULL;
}


MyString::MyString(const char* str)
{
	this->str = new char[strlen(str) + 1];
	strcpy_s(this->str, strlen(str) + 1, str);
}



 MyString& operator+=( char c ) {
        *this = *this + MyString( c );
        return *this;
    }

MyString& operator+=( const MyString& rhs ) {
        *this = *this + rhs;
        return *this;
    }

 MyString operator+( const char c ) const {
        int temp = length + str.length + 1;
        char* ptr = new char[temp];
        strcpy( ptr, charArr);
        strcat(ptr, str.charArr);
        MyString s( ptr );
        delete[] ptr;
        return s;
    }
