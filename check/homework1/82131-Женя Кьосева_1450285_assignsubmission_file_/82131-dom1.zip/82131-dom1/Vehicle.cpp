#include<iostream>
#include"MyString.cpp"

class Vehicle {

    MyString regNm = nullptr;
    MyString descrp = nullptr;
    size_t parkSpots = 0;
};
