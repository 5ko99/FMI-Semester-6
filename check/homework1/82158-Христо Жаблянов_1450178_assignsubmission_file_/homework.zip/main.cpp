#include "src/garage.h"

using std::cin;
using std::cout;
using std::endl;

#define NDEBUG

// Reads input from the console. Splits
// it by spaces and returns argument count.
unsigned read(char args[50][20]);

// Concatenate arguments from @from to @to in @text
void concat(char args[50][20], char text[100], unsigned from, unsigned to);

// Converts string to an unsigned number
unsigned str_to_i(const char* str);

int main() {
    const char* commands =
        "\nCommands:\n"
        "insert [registration] [description] [size] : Add a vehicle\n"
        "erase [registration] : Remove a vehicle by registration\n"
        "clear : Remove all vehicles\n"
        "print : Print data\n"
        "end : Exit the program\n\n";
    const char* vehicle_alloc_err =
        "Vehicle not allocated in memory! Try another command!\n";

    size_t vol;
    cout << "Parking slots count: ";
    cin >> vol;

    Vehicle** vehicles = new (std::nothrow) Vehicle*[vol];
    if (!vehicles) {
        cout << "Memory Allocation Error! Exiting!" << endl;
        return -1;
    }
    size_t len = 0;

    Garage g(vol);

    char args[50][20];
    cin.ignore();

    while (true) {
        cout << commands;

        unsigned count = read(args);

        if (MyString::equal_c_str(args[0], "insert")) {
            if (count < 4) {
                cout << "Insufficient arguments\n";
                continue;
            }

            char desc[100];
            concat(args, desc, 2, count - 1);
            size_t size = str_to_i(args[count - 1]);

            Vehicle* v = new (std::nothrow) Vehicle(args[1], desc, size);
            if (!v) {
                cout << vehicle_alloc_err;
                continue;
            }

            try {
                g.insert(*v);
            } catch (std::invalid_argument& e) {
                cout << e.what() << endl;
                delete v;
                continue;
            }

            vehicles[len] = v;
            len++;
            cout << "Vehicle added\n";
        } else if (MyString::equal_c_str(args[0], "erase")) {
            if (count < 2) {
                cout << "Insufficient arguments\n";
                continue;
            }

            g.erase(args[1]);

            bool erased = false;
            for (size_t i = 0; i < len; i++)
                if (MyString::equal_c_str(vehicles[i]->get_registration(), args[1])) {
                    delete vehicles[i];
                    vehicles[i] = vehicles[len - 1];
                    len--;
                    erased = true;
                    cout << "Vehicle erased\n";
                    break;
                }

            if (!erased) cout << "No such vehicle\n";
        } else if (MyString::equal_c_str(args[0], "clear")) {
            g.clear();

            for (size_t i = 0; i < len; i++) delete vehicles[i];
            len = 0;
            cout << "All vehicles cleared\n";
        } else if (MyString::equal_c_str(args[0], "print")) {
            cout << g << endl;
        } else if (MyString::equal_c_str(args[0], "end")) {
            break;
        } else {
            cout << "Unknown command!\n";
        }
    }

    for (size_t i = 0; i < len; i++) delete vehicles[i];
    delete[] vehicles;

    return 0;
}

unsigned read(char args[50][20]) {
    char input[1000];
    cin.getline(input, 1000);

    unsigned len = 0;
    unsigned word_i = 0;
    unsigned input_i = 0;

    while (true) {
        if (input[input_i] != ' ' && input[input_i] != '\0') {
            args[len][word_i] = input[input_i];
            word_i++;

            if (word_i == 19)
                while (input[input_i] != '\0' || input[input_i] != ' ') input_i++;
        } else {
            args[len][word_i] = '\0';
            word_i = 0;
            len++;

            if (input[input_i] == '\0') break;
        }

        input_i++;
    }

    return len;
}

void concat(char args[50][20], char text[100], unsigned from, unsigned to) {
    unsigned text_i = 0;

    for (unsigned i = from; i < to; i++) {
        unsigned word_i = 0;

        while (args[i][word_i] != '\0') {
            text[text_i] = args[i][word_i];
            text_i++;
            word_i++;
        }

        text[text_i] = ' ';
        text_i++;
    }

    if (text_i > 0) text_i--;
    text[text_i] = '\0';
}

unsigned str_to_i(const char* str) {
    unsigned i = 0;
    unsigned number = 0;

    while (str[i] != '\0') {
        number *= 10;
        number += str[i] - '0';
        i++;
    }

    return number;
}