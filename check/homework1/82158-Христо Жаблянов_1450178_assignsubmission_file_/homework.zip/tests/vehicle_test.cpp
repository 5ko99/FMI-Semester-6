#include "../src/vehicle.h"

#include "catch.h"
#include "cstring"

#define CATCH_CONFIG_MAIN

TEST_CASE("Vehicle Constructor & Getters") {
    const char* REG = "0123";
    const char* DSC = "Vehicle description";

    Vehicle v(REG, DSC, 3);

    CHECK(v.get_size() == 3);
    CHECK(std::strcmp(v.get_registration(), REG) == 0);
    REQUIRE(std::strcmp(v.get_description(), DSC) == 0);
}