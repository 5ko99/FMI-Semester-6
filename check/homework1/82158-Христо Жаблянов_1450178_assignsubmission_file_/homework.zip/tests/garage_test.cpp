#include "../src/garage.h"

#include "catch.h"
#include "cstring"

#define CATCH_CONFIG_MAIN

TEST_CASE("Garage Constructor") {
    Garage g(10);
    CHECK(g.size() == 0);
    REQUIRE(g.empty());
}

TEST_CASE("Garage Getters") {
    Garage g(20);
    Vehicle v1("1", "first", 10);
    Vehicle v2("2", "second", 5);
    Vehicle v3("3", "third", 1);
    g.insert(v1);
    g.insert(v2);
    g.insert(v3);

    SECTION("Find") {
        const Vehicle* v_ptr;

        v_ptr = g.find("4");
        CHECK_FALSE(v_ptr);

        v_ptr = g.find("2");
        REQUIRE_FALSE(std::strcmp(v_ptr->get_description(), "second"));
    }

    SECTION("At") {
        CHECK_THROWS_AS(g.at(3), std::out_of_range);
        REQUIRE_FALSE(std::strcmp(g.at(2).get_description(), "third"));
    }

    SECTION("Square Brackets: []") {
        REQUIRE_FALSE(std::strcmp(g[0].get_description(), "first"));
    }
}

TEST_CASE("Garage Setters") {
    Garage g(5);
    Vehicle v1("1", "first", 3);
    Vehicle v2("2", "second", 1);
    Vehicle v3("3", "third", 2);

    g.insert(v1);
    CHECK(g.size() == 1);
    g.insert(v2);
    CHECK(g.size() == 2);

    CHECK_THROWS_WITH(g.insert(v3), "No space available");
    CHECK(g.size() == 2);
    CHECK_THROWS_WITH(g.insert(v2), "Already in garage");
    CHECK(g.size() == 2);

    g.erase(v2.get_registration());
    CHECK(g.size() == 1);

    g.insert(v3);
    CHECK(g.size() == 2);

    g.clear();
    REQUIRE(g.size() == 0);
}