#include "../src/my_string.h"

#include "catch.h"
#include "cstring"

#define CATCH_CONFIG_MAIN

TEST_CASE("MyString Constructors & Essential Getters") {
    SECTION("Default Constructor") {
        MyString s;
        CHECK(s.empty());
        CHECK(s.size() == 0);
        REQUIRE_FALSE(std::strcmp(s.c_str(), ""));
    }

    const char* CSTR = "test";

    SECTION("C String Constructor") {
        MyString s(CSTR);
        CHECK(s.size() == 4);
        CHECK_FALSE(s.empty());

        REQUIRE_FALSE(std::strcmp(s.c_str(), CSTR));
    }

    SECTION("Copy Constructor") {
        MyString from(CSTR);
        MyString s(from);
        CHECK(s.size() == 4);
        CHECK_FALSE(s.empty());

        CHECK_FALSE(std::strcmp(s.c_str(), CSTR));
        REQUIRE_FALSE(std::strcmp(from.c_str(), CSTR));
    }
}

TEST_CASE("MyString Getters & Setters") {
    MyString s("Abra Cadabra");

    SECTION("Front") {
        CHECK(s.front() == 'A');
        s.front() = 'U';
        REQUIRE(s.front() == 'U');
    }

    SECTION("Back") {
        CHECK(s.back() == 'a');
        s.back() = 'e';
        REQUIRE(s.back() == 'e');
    }

    SECTION("At") {
        CHECK(s.at(5) == 'C');
        s.at(5) = 'Z';
        REQUIRE(s.at(5) == 'Z');
    }

    SECTION("Pop, Push, Clear") {
        s.pop();
        CHECK(s.back() == 'r');
        s.push('o');
        CHECK(s.back() == 'o');
        s.clear();
        CHECK(s.empty());
        CHECK(s.size() == 0);

        REQUIRE_FALSE(std::strcmp(s.c_str(), ""));
    }
}

TEST_CASE("MyString Operators") {
    MyString s("Elephant in the room");

    SECTION("Assignment: =") {
        MyString c = s;
        CHECK_FALSE(std::strcmp(s.c_str(), c.c_str()));
        REQUIRE(c.size() == s.size());
    }

    SECTION("Brackets: []") {
        CHECK(s[13] == 'h');
        s[13] = 'R';
        REQUIRE(s[13] == 'R');
    }

    MyString c(s);

    SECTION("Compare: ==, <") {
        CHECK(s == c);
        CHECK(c == s);
        CHECK_FALSE(s < c);
        CHECK_FALSE(c < s);
        s.pop();
        CHECK(s < c);
        CHECK_FALSE(c < s);
        c[18] = 'n';
        CHECK_FALSE(s < c);
        REQUIRE(c < s);
    }

    SECTION("Addition: +, +=") {
        MyString a("one");

        MyString b = a + ' ';
        CHECK_FALSE(std::strcmp(b.c_str(), "one "));
        CHECK(b.size() == 4);

        MyString c = b + MyString("two");
        CHECK_FALSE(std::strcmp(c.c_str(), "one two"));
        CHECK(c.size() == 7);

        a += ' ';
        CHECK_FALSE(std::strcmp(a.c_str(), "one "));
        a += "two";
        REQUIRE_FALSE(std::strcmp(a.c_str(), "one two"));
    }
}