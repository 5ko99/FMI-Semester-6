#pragma once

#include "vehicle.h"

class Garage {
  private:
    Vehicle** vehicles;
    size_t volume;
    size_t occupied;
    size_t len;

  public:
    Garage(size_t vol);
    ~Garage();

    size_t size() const;
    const Vehicle& at(size_t pos) const;
    const Vehicle* find(const char* registration) const;

    bool empty() const;
    void insert(Vehicle& v);
    void erase(const char* registration);
    void clear();

    const Vehicle& operator[](size_t pos) const;

    friend std::ostream& operator<<(std::ostream& os, const Garage& g);
};