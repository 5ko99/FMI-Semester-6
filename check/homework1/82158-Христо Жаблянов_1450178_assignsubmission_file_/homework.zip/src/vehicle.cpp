#include "vehicle.h"

Vehicle::Vehicle(const char* registration,
                 const char* description,
                 size_t _size)
    : size(_size) {
    try {
        this->registration = MyString(registration);
        this->description = MyString(description);
    } catch (...) {
        throw std::current_exception();
    }
}

const char* Vehicle::get_registration() const { return registration.c_str(); }

const char* Vehicle::get_description() const { return description.c_str(); }

size_t Vehicle::get_size() const { return size; }

std::ostream& operator<<(std::ostream& os, const Vehicle& v) {
    os << "size: " << v.size << " reg: (" << v.registration << ") desc: ("
       << v.description << ")";
    return os;
}