#include "garage.h"

Garage::Garage(size_t vol) : volume(vol), occupied(0), len(0) {
    try {
        vehicles = new Vehicle*[volume];
    } catch (std::bad_alloc&) {
        vehicles = nullptr;
        volume = 0;
        throw;
    }
}

Garage::~Garage() { delete[] vehicles; }

size_t Garage::size() const { return len; }

const Vehicle& Garage::at(size_t pos) const {
    if (pos >= len) throw std::out_of_range("Out of bounds");
    return *vehicles[pos];
}

const Vehicle* Garage::find(const char* registration) const {
    for (size_t i = 0; i < len; i++)
        if (MyString::equal_c_str(vehicles[i]->get_registration(), registration))
            return vehicles[i];
    return nullptr;
}

bool Garage::empty() const { return len == 0; }

void Garage::insert(Vehicle& v) {
    if (occupied + v.get_size() > volume)
        throw std::invalid_argument("No space available");

    for (size_t i = 0; i < len; i++)
        if (MyString::equal_c_str(vehicles[i]->get_registration(), v.get_registration()))
            throw std::invalid_argument("Already in garage");

    occupied += v.get_size();
    vehicles[len] = &v;
    len++;
}

void Garage::erase(const char* registration) {
    for (size_t i = 0; i < len; i++)
        if (MyString::equal_c_str(vehicles[i]->get_registration(), registration)) {
            occupied -= vehicles[i]->get_size();
            vehicles[i] = vehicles[len - 1];
            len--;
            return;
        }
}

void Garage::clear() {
    occupied = 0;
    len = 0;
}

const Vehicle& Garage::operator[](size_t pos) const {
    assert(pos < len && "Index out of bounds");
    return *vehicles[pos];
}

std::ostream& operator<<(std::ostream& os, const Garage& g) {
    os << "volume: " << g.volume << " occupied: " << g.occupied << " size: " << g.len
       << std::endl;

    for (size_t i = 0; i < g.len; i++) os << "\t" << *g.vehicles[i] << std::endl;

    return os;
}