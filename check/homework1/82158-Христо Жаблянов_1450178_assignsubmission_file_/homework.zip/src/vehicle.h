#pragma once

#include "my_string.h"

class Vehicle {
  private:
    MyString registration;
    MyString description;
    size_t size;

  public:
    Vehicle(const char* registration, const char* description, size_t size);

    const char* get_registration() const;
    const char* get_description() const;
    size_t get_size() const;

    friend std::ostream& operator<<(std::ostream& os, const Vehicle& v);
};