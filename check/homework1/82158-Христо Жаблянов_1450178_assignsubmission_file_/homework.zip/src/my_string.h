#pragma once

#include <cassert>
#include <cstddef>
#include <iostream>
#include <new>
#include <stdexcept>

using std::size_t;

class MyString {
  private:
    char* data;
    size_t cap;
    size_t len;

    // Finds the length of a c-style string
    static size_t get_len(const char* str);
    
    // Checks whether there is a certain amount
    // of free space. Tries to allocate more
    // memory if needed. Returns false on failure.
    bool verify_expansion(size_t needed_space);

  public:
    MyString();
    MyString(const char* from);
    MyString(const MyString& from, size_t cap_bonus = 0);
    ~MyString();

    size_t size() const;
    const char* c_str() const;
    char& at(size_t pos);
    const char& at(size_t pos) const;
    char& front();
    const char& front() const;
    char& back();
    const char& back() const;

    bool empty() const;
    void push(char c);
    void pop();
    void clear();

    char& operator[](size_t pos);
    const char& operator[](size_t pos) const;
    MyString& operator=(const MyString& str);
    MyString& operator+=(char c);
    MyString& operator+=(const MyString& str);
    MyString operator+(char c) const;
    MyString operator+(const MyString& str) const;
    bool operator==(const MyString& str) const;
    bool operator<(const MyString& str) const;

    // Checks if 2 c-style strings are equal
    static bool equal_c_str(const char* l, const char* r);

    friend std::ostream& operator<<(std::ostream& os, const MyString& str);
};