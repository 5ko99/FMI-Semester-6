#include "my_string.h"

static const size_t CAP_BONUS = 10;

size_t MyString::get_len(const char* str) {
    size_t i = 0;
    while (str[i] != '\0') i++;
    return i;
}

bool MyString::equal_c_str(const char* l, const char* r) {
    size_t len = get_len(l);
    if (len != get_len(r)) return false;

    for (size_t i = 0; i < len; i++)
        if (l[i] != r[i]) return false;

    return true;
}

bool MyString::verify_expansion(size_t needed_space) {
    if (len + needed_space + 1 < cap) return true;

    char* mem = new (std::nothrow) char[len + needed_space + CAP_BONUS];
    if (!mem) return false;

    for (size_t i = 0; i < len; i++) mem[i] = data[i];
    delete[] data;
    data = mem;
    cap = len + needed_space + CAP_BONUS;
    return true;
}

MyString::MyString() : len(0), cap(CAP_BONUS) {
    try {
        data = new char[cap];
    } catch (std::bad_alloc&) {
        data = nullptr;
        throw;
    }
    data[0] = '\0';
}

MyString::MyString(const char* from) {
    size_t src_len = get_len(from);
    try {
        data = new char[src_len + CAP_BONUS];
    } catch (std::bad_alloc&) {
        data = nullptr;
        throw;
    }

    for (size_t i = 0; i < src_len; i++) data[i] = from[i];
    data[src_len] = '\0';

    cap = src_len + CAP_BONUS;
    len = src_len;
}

MyString::MyString(const MyString& from, size_t cap_bonus)
    : len(from.len), cap(from.cap + CAP_BONUS) {
    try {
        data = new char[from.cap + cap_bonus];
    } catch (std::bad_alloc&) {
        data = nullptr;
        throw;
    }

    for (size_t i = 0; i < from.len; i++) data[i] = from.data[i];
    data[from.len] = '\0';
}

MyString::~MyString() { delete[] data; }

size_t MyString::size() const { return len; }

const char* MyString::c_str() const { return data; }

char& MyString::at(size_t pos) {
    if (pos >= len) throw std::out_of_range("Index out of bounds");
    return data[pos];
}

const char& MyString::at(size_t pos) const {
    if (pos >= len) throw std::out_of_range("Index out of bounds");
    return data[pos];
}

char& MyString::front() {
    assert(len > 0 && "Empty string");
    return data[0];
}

const char& MyString::front() const {
    assert(len > 0 && "Empty string");
    return data[0];
}

char& MyString::back() {
    assert(len > 0 && "Empty string");
    return data[len - 1];
}

const char& MyString::back() const {
    assert(len > 0 && "Empty string");
    return data[len - 1];
}

bool MyString::empty() const { return len == 0; }

void MyString::push(char c) {
    if (verify_expansion(1)) {
        data[len] = c;
        len++;
        data[len] = '\0';
    }
}

void MyString::pop() {
    assert(len > 0 && "Empty String");
    len--;
    data[len] = '\0';
}

void MyString::clear() {
    for (size_t i = 0; i < len; i++) data[i] = '\0';
    len = 0;
}

char& MyString::operator[](size_t pos) {
    assert(pos < len && "Index out of bounds");
    return data[pos];
}

const char& MyString::operator[](size_t pos) const {
    assert(pos < len && "Index out of bounds");
    return data[pos];
}

MyString& MyString::operator=(const MyString& str) {
    if (cap < str.cap) {
        
        char* mem;
        try {
            mem = new char[str.cap];
        } catch (std::bad_alloc&) {
            throw;
        }
        delete[] data;
        data = mem;
    }

    cap = str.cap;
    len = str.len;
    for (size_t i = 0; i <= len; i++) data[i] = str.data[i];

    return *this;
}

MyString& MyString::operator+=(char c) {
    push(c);
    return *this;
}

MyString& MyString::operator+=(const MyString& str) {
    if (verify_expansion(str.len)) {
        for (size_t i = len, j = 0; j < str.len; i++, j++)
            data[i] = str.data[j];
        len += str.len;
        data[len] = '\0';
    }
    return *this;
}

MyString MyString::operator+(char c) const {
    MyString str(*this, 1);
    str.data[str.len] = c;
    str.len++;
    str.data[str.len] = '\0';
    return str;
}

MyString MyString::operator+(const MyString& str) const {
    MyString cpy(*this, str.len);
    for (size_t i = cpy.len, j = 0; j < str.len; i++, j++)
        cpy.data[i] = str.data[j];
    cpy.len += str.len;
    cpy.data[cpy.len] = '\0';
    return cpy;
}

bool MyString::operator==(const MyString& str) const {
    if (len != str.len) return false;

    for (size_t i = 0; i < len; i++)
        if (data[i] != str.data[i]) return false;

    return true;
}

bool MyString::operator<(const MyString& str) const {
    size_t min_len = len < str.len ? len : str.len;

    for (size_t i = 0; i < min_len; i++) {
        if (data[i] < str.data[i]) return true;
        if (data[i] > str.data[i]) return false;
    }

    return len < str.len;
}

std::ostream& operator<<(std::ostream& os, const MyString& str) {
    os << "len: " << str.len << " cap: " << str.cap << " str: " << str.data;
    return os;
}