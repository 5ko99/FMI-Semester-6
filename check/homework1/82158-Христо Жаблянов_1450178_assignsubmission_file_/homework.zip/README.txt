run  : g++ main.cpp src/*.cpp -I src
test : g++ src/*.cpp tests/catch.cpp tests/[test_name].cpp -I src -I tests