### Домашно 1 ###

**Compiler:** clang 7.0.1-8+deb10u2 (tags/RELEASE_701/final)

**Build Tool:** cmake 3.13.4

**IDE:** CLion 2020.1