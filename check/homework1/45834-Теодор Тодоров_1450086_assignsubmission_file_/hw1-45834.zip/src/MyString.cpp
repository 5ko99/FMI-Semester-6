#include <iostream>
#include <new>

#include "MyString.h"
#include "StringUtils.cpp"


// CLion has a bug with "unreachable code" actually being completely reachable
// This issue happens on try-catch blocks.
// In my case while using "new" and checking for bad_alloc.
#pragma clang diagnostic push
#pragma ide diagnostic ignored "UnreachableCode"


#define NDEBUG
#include <cassert>


// ---------------
// Private Methods
// ---------------

void Homework1::MyString::expand(std::size_t min) {
	if (arrCapacity == 0) {
		throw std::invalid_argument("Method called on invalid state");
	}
	if (min <= arrCapacity) {
		throw std::invalid_argument("min should be greater than current array capacity");
	}

	std::size_t newArrCapacity = arrCapacity;

	while (newArrCapacity < min) {
		switch (resizePolicy) {
			case ADD_1_0: {
				newArrCapacity += 1;
				break;
			}
			case MUL_2_0: {
				newArrCapacity *= 2;
				break;
			}
		}
	}

	char * newArr;
	try {
		newArr = new char[newArrCapacity];
	}
	catch (std::bad_alloc &) {
		newArr = nullptr;
		throw;
	}

	for (size_t i = 0; i < arrCapacity; i++) {
		newArr[i] = arr[i];
	}
	for (size_t i = arrCapacity; i < newArrCapacity; i++) {
		newArr[i] = 0;
	}

	delete[] arr;

	arr = newArr;
	arrCapacity = newArrCapacity;
}

void Homework1::MyString::expand() {
	expand(arrCapacity + 1);
}

void Homework1::MyString::allocateAndSetCapacity(const std::size_t capacity) {
	assert(capacity > 0);

	delete[] arr;

	arrSize = 0;
	arrCapacity = capacity;

	try {
		arr = new char[arrCapacity];
	}
	catch (std::bad_alloc &) {
		arr = nullptr;
		arrCapacity = 0;
		throw;
	}
}

void Homework1::MyString::add(const char c) {
	if (c == 0) {
		throw std::invalid_argument("Cannot append null character");
	}

	if (arrSize >= arrCapacity) { // Why not >= instead of == ?
		try {
			expand();
		}
		catch (std::bad_alloc &) {
			throw;
		}
	}
	arr[arrSize++] = c;
}

void Homework1::MyString::add(const char * c, const std::size_t max) {
	if (c == nullptr) {
		throw std::invalid_argument("Cannot append null character");
	}

	std::size_t stringLength;
	if (max != 0) {
		stringLength = max;
	}
	else {
		stringLength = strlenLocal(c);
	}

	for (std::size_t i = 0; i < stringLength; i++) {
		add(c[i]);
	}
}

// -------------
// Debug Methods
// -------------

void Homework1::MyString::print_debug() {
	std::cout
		<< "{\n"
		<< '\t' << "INITIAL_ARR_CAPACITY = " << INITIAL_ARR_CAPACITY << ",\n"
		<< '\t' << "resizePolicy = " << resizePolicy << ",\n"
		<< '\t' << "arr = \"" << &arr << "\",\n"
		<< '\t' << "arr = \"" << arr << "\",\n"
		<< '\t' << "arr = ";

	for (std::size_t i = 0; i < arrCapacity; i++) {
		std::cout << '(' << 1 * arr[i] << ')';
	}

	std::cout
		<< ",\n"
		<< '\t' << "arrSize = " << arrSize << ",\n"
		<< '\t' << "arrCapacity = " << arrCapacity << "\n"
		<< "}\n" << std::endl;
}

// ------------
// Constructors
// ------------

Homework1::MyString::MyString() {
	try {
		allocateAndSetCapacity();
	}
	catch (std::bad_alloc &) {
		throw;
	}
	clear();
}

Homework1::MyString::MyString(const char * str) {
	if (str == nullptr) {
		return;
	}

	std::size_t stringLength = strlenLocal(str);

	try {
		allocateAndSetCapacity(stringLength);
	}
	catch (std::bad_alloc &) {
		throw;
	}
	clear();

	arrSize = stringLength;
	for (std::size_t i = 0; i < arrSize; i++) {
		arr[i] = str[i];
	}
}

Homework1::MyString::MyString(const Homework1::MyString & s) {
	(*this) = s;
}

Homework1::MyString::MyString(Homework1::MyString && s) noexcept {
	arr = s.arr;
	arrCapacity = s.arrCapacity;
	arrSize = s.arrSize;

	s.arr = nullptr;
	s.arrCapacity = 0;
	s.arrSize = 0;
}

Homework1::MyString::~MyString() {
	clear();
	delete[] arr;
	arr = nullptr;
	arrSize = 0;
	arrCapacity = 0;
}

Homework1::MyString & Homework1::MyString::operator=(const Homework1::MyString & s) {
	char * newArr;
	try {
		newArr = new char[s.arrCapacity];
	}
	catch (std::bad_alloc &) {
		return *this;
	}

	for (std::size_t i = 0; i < s.arrCapacity; i++) {
		newArr[i] = s.arr[i];
	}

	delete[] arr;

	arr = newArr;
	arrCapacity = s.arrCapacity;
	arrSize = s.arrSize;

	return *this;
}

Homework1::MyString & Homework1::MyString::operator=(Homework1::MyString && s) noexcept {
	if (this == &s) {
		return *this;
	}

	arr = s.arr;
	arrCapacity = s.arrCapacity;
	arrSize = s.arrSize;

	s.arr = nullptr;
	s.arrCapacity = 0;
	s.arrSize = 0;

	return *this;
}

// --------------
// Public Methods
// --------------

char & Homework1::MyString::at(std::size_t pos) {
	if (pos >= arrSize) {
		throw std::out_of_range("Position is out of bounds");
	}
	return arr[pos];
}

const char & Homework1::MyString::at(std::size_t pos) const {
	if (pos >= arrSize) {
		throw std::out_of_range("Position is out of bounds");
	}
	return arr[pos];
}

char & Homework1::MyString::operator[](std::size_t pos) {
	assert(pos < arrSize);
	return arr[pos];
}

const char & Homework1::MyString::operator[](std::size_t pos) const {
	assert(pos < arrSize);
	return arr[pos];
}

char & Homework1::MyString::front() {
	assert(arrSize > 0);
	return arr[0];
}

const char & Homework1::MyString::front() const {
	assert(arrSize > 0);
	return arr[0];
}

char & Homework1::MyString::back() {
	assert(arrSize > 0);
	std::size_t lastIndex = 0;
	if (arrSize > 0) {
		lastIndex = arrSize - 1;
	}
	return arr[lastIndex];
}

const char & Homework1::MyString::back() const {
	assert(arrSize > 0);
	std::size_t lastIndex = 0;
	if (arrSize > 0) {
		lastIndex = arrSize - 1;
	}
	return arr[lastIndex];
}

bool Homework1::MyString::empty() const {
	return arrSize == 0;
}

std::size_t Homework1::MyString::size() const {
	return arrSize;
}

void Homework1::MyString::clear() {
	for (std::size_t i = 0; i < arrCapacity; i++) {
		arr[i] = 0;
	}
	arrSize = 0;
}

void Homework1::MyString::push_back(char c) {
	add(c);
}

void Homework1::MyString::pop_back() {
	assert(arrSize > 0);
	arr[arrSize] = 0;

	if (arrSize != 0) {
		arrSize--;
	}
}

const char * Homework1::MyString::c_str() const {
	char * str = new char[arrSize + 1];
	for (std::size_t i = 0; i < arrSize; i++) {
		str[i] = arr[i];
	}
	str[arrSize] = 0;
	return str;
}

Homework1::MyString::ResizePolicy Homework1::MyString::getResizePolicy() const {
	return resizePolicy;
}

void Homework1::MyString::setResizePolicy(Homework1::MyString::ResizePolicy policy) {
	resizePolicy = policy;
}

// ------------------
// Operator Overrides
// ------------------

Homework1::MyString & Homework1::MyString::operator+=(char c) {
	add(c);
	return *this;
}

Homework1::MyString & Homework1::MyString::operator+=(const Homework1::MyString & rhs) {
	add(rhs.arr, rhs.arrSize);
	return *this;
}

Homework1::MyString Homework1::MyString::operator+(char c) const {
	MyString s;
	if (this->arrSize != 0) {
		s.add(this->arr, this->arrSize);
	}
	s.add(c);
	return s;
}

Homework1::MyString Homework1::MyString::operator+(const Homework1::MyString & rhs) const {
	MyString s;
	if (this->arrSize != 0) {
		s.add(this->arr, this->arrSize);
	}
	if (rhs.arrSize != 0) {
		s.add(rhs.arr, rhs.arrSize);
	}
	return s;
}

bool Homework1::MyString::operator==(const Homework1::MyString & rhs) const {
	if (this->arrSize != rhs.arrSize) {
		return false;
	}

	for (std::size_t i = 0; i < rhs.arrSize; i++) {
		if (arr[i] != rhs.arr[i]) {
			return false;
		}
	}

	return true;
}

bool Homework1::MyString::operator!=(const Homework1::MyString & rhs) const {
	return !operator==(rhs);
}

bool Homework1::MyString::operator<(const Homework1::MyString & rhs) const {
	int cmp = strcmpLocal(this->arr, this->arrSize, rhs.arr, rhs.arrSize);
	return cmp < 0;
}

std::ostream & Homework1::operator<<(std::ostream & out, const Homework1::MyString & s) {
	for (std::size_t i = 0; i < s.arrSize; i++) {
		out << s[i];
	}
	return out;
}

std::istream & Homework1::operator>>(std::istream & in, Homework1::MyString & s) {
	char chars[128];
	in.getline(chars, 128);
	s += chars;

	return in;
}

// Clean-up for CLion bug
#pragma clang diagnostic pop