#pragma once

#include <cstddef>
#include <iostream>

namespace Homework1 {

	class MyString {
		enum ResizePolicy {
			ADD_1_0,
			MUL_2_0
		};

		static const std::size_t INITIAL_ARR_CAPACITY = 8;

		ResizePolicy resizePolicy = ResizePolicy::MUL_2_0;
		char * arr = nullptr;
		std::size_t arrSize = 0;
		std::size_t arrCapacity = 0;

		/**
		 * Increases size of underlying array by at least specified number.
		 *
		 * @throws std::bad_alloc
		 * 		When no memory
		 *
		 * @throws std::invalid_argument
		 * 		When specified minimum is not greater than current capacity
		 */
		void expand(std::size_t min);

		/**
		 * Increases size of underlying array by at least one.
		 *
		 * @throws std::bad_alloc
		 * 		When no memory
		 *
		 * @throws std::invalid_argument
		 * 		When specified minimum is not greater than current capacity.
		 * 		This should only happen when there is std::size_t overflow.
		 */
		void expand();

		/**
		 *
		 * @param capacity
		 *
		 * @throws std::bad_alloc
		 */
		void allocateAndSetCapacity(const std::size_t capacity = INITIAL_ARR_CAPACITY);

		/**
		 * @throws std::bad_alloc
		 * 		Ако няма памет
		 *
		 * @throws std::invalid_argument
		 * 		При невалиден символ (терм. нула)
		 */
		void add(const char c);

		/**
		 * @throws std::bad_alloc
		 * 		Ако няма памет
		 *
		 * @throws std::invalid_argument
		 * 		При невалиден символ (терм. нула)
		 */
		void add(const char * c, const std::size_t max = 0);

	public:
		void print_debug();

		/**
		 * @throws std::bad_alloc
		 */
		MyString();

		/**
		 * Създава нов обект и копира в него съдържанието на str.
		 *
		 * @param str
		 *
		 * @throws std::bad_alloc
		 */
		MyString(const char * str);

		/**
		 * Copy Constructor
		 *
		 * @throws std::bad_alloc
		 */
		MyString(const MyString & s);

		/**
		 * Move Constructor
		 *
		 * @throws std::bad_alloc
		 */
		MyString(MyString && s) noexcept;

		/**
		 * Destructor
		 */
		~MyString();

		/**
		 * Copy Assignment
		 *
		 * @throws std::bad_alloc
		 */
		MyString & operator=(const MyString & s);

		/**
		 * Move Assignment
		 *
		 * @throws std::bad_alloc
		 */
		MyString & operator=(MyString && s) noexcept;


		/**
		 * Достъп до елемента намиращ се на позиция pos.
		 * Ако такъв няма се хвърля изключение std::out_of_range.
		 *
		 * @param pos
		 * 		Index of character wanted.
		 *
		 * @throws std::out_of_range
		 *
		 * @return
		 * 		Character at specified position.
		 */
		char & at(std::size_t pos);

		/**
		 * Достъп до елемента намиращ се на позиция pos.
		 * Ако такъв няма се хвърля изключение std::out_of_range.
		 *
		 * @param pos
		 * 		Index of character wanted.
		 *
		 * @throws std::out_of_range
		 *
		 * @return
		 * 		Character at specified position.
		 */
		const char & at(std::size_t pos) const;

		/**
		 * Достъп до елемента намиращ се на позиция pos.
		 * Функцията да не прави проверка за коректност дали pos е валидна позиция.
		 * (В debug режим assert-вайте дали pos е валидна позиция).
		 *
		 * @param pos
		 * 		Index of character wanted.
		 *
		 * @return
		 * 		Character at specified position.
		 */
		char & operator[](std::size_t pos);

		/**
		 * Достъп до елемента намиращ се на позиция pos.
		 * Функцията да не прави проверка за коректност дали pos е валидна позиция.
		 * (В debug режим assert-вайте дали pos е валидна позиция).
		 *
		 * @param pos
		 * 		Index of character wanted.
		 *
		 * @return
		 * 		Character at specified position.
		 */
		const char & operator[](std::size_t pos) const;

		/**
		 * Достъп до първия символ в низа.
		 * Не се прави проверка за коректност дали такъв символ има.
		 *
		 * @return
		 * 		Character at the front of the array.
		 */
		char & front();

		/**
		 * Достъп до първия символ в низа.
		 * Не се прави проверка за коректност дали такъв символ има.
		 *
		 * @return
		 * 		Character at the front of the array.
		 */
		const char & front() const;

		/**
		 * Достъп до последния символ в низа.
		 * Не се прави проверка за коректност дали такъв символ има.
		 *
		 * @return
		 * 		Character at the back of the array.
		 */
		char & back();

		/**
		 * Достъп до последния символ в низа.
		 * Не се прави проверка за коректност дали такъв символ има.
		 *
		 * @return
		 * 		Character at the back of the array.
		 */
		const char & back() const;

		/**
		 * Проверява дали низът е празен.
		 *
		 * @return
		 */
		bool empty() const;

		/**
		 * Дължина на низа.
		 *
		 * @return
		 */
		std::size_t size() const;

		/**
		 * Изчиства съдържанието на низа.
		 */
		void clear();

		/**
		 * Добавя символа c в края на низа.
		 * Операцията да дава strong exception guarantee.
		 *
		 * @param c
		 *
		 * @throws std::bad_alloc
		 * 		Ако няма памет
		 *
		 * @throws std::invalid_argument
		 * 		При невалиден символ (терм. нула)
		 */
		void push_back(char c);

		/**
		 * Премахва последния символ от низа.
		 * Да не се прави проверка за коректност дали такъв символ има.
		 * (В debug режим assert-вайте че низът не е празен).
		 */
		void pop_back();

		/**
		 * Създава нов динамичен масив със съдържанието на низа.
		 * Нужно е да се изтрие след употреба!
		 *
		 * @return
		 */
		const char * c_str() const;

		/**
		 * Връща начина на преоразмеряване на низа.
		 *
		 * @return
		 */
		ResizePolicy getResizePolicy() const;

		/**
		 * Задача начина на преоразмеряване на низа в бъдеще.
		 *
		 * @param policy
		 */
		void setResizePolicy(ResizePolicy policy);

		/**
		 * Добавя символа c в края на низа.
		 * Операцията да дава strong exception guarantee.
		 * Връща *this.
		 *
		 * @param c
		 * @return
		 */
		MyString & operator+=(char c);

		/**
		 * Конкатенира съдържанието на str към текущия низ.
		 * Операцията да дава strong exception guarantee.
		 * Връща *this.
		 *
		 * @param rhs
		 * @return
		 */
		MyString & operator+=(const MyString & rhs);


		/**
		 * Връща нов символен низ, който се получава от текущия, конкатениран със символа c.
		 *
		 * @param c
		 * @return
		 */
		MyString operator+(char c) const;

		/**
		 * Връща нов символен низ, който се получава от текущия, конкатениран с низа rhs.
		 *
		 * @param rhs
		 * @return
		 */
		MyString operator+(const MyString & rhs) const;

		/**
		 * Проверява дали два символни низа са еднакви.
		 *
		 * @param rhs
		 * @return
		 */
		bool operator==(const MyString & rhs) const;

		/**
		 * Проверява дали два символни низа са различни.
		 *
		 * @param rhs
		 * @return
		 */
		bool operator!=(const MyString & rhs) const;

		/**
		 * Проверява дали текущият низ предхожда лексикографски rhs.
		 *
		 * @param rhs
		 * @return
		 */
		bool operator<(const MyString & rhs) const;

		/**
		 * За извеждане на MyString чрез std::ostream.
		 *
		 * @param out
		 * @param s
		 * @return
		 */
		friend std::ostream & operator<<(std::ostream & out, const MyString & s);

		/**
		 * Добавяне на символи към MyString, горна граница 127 символа (за едно повикване)
		 *
		 * @param in
		 * @param s
		 * @return
		 */
		friend std::istream & operator>>(std::istream & in, MyString & s);

	};
}
