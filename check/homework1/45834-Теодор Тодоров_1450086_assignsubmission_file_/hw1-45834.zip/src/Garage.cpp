#include <stdexcept>

#include "StringUtils.cpp"
#include "Garage.h"

// ---------------
// Private Methods
// ---------------

std::size_t Homework1::Garage::getIndexOf(const char * registration) const {
	for (std::size_t i = 0; i < size_; i++) {
		const char * currReg = vehicles_[i]->registration();
		bool areEqual = streqLocal(registration, currReg);

		if (areEqual) {
			delete[] currReg;
			return i;
		}

		delete[] currReg;
	}
	throw std::invalid_argument("Did not find vehicle with specified registration");
}

// ------------
// Constructors
// ------------

Homework1::Garage::Garage(std::size_t size) {
	// TODO: Fail if not enough memory
	vehicles_ = new Vehicle * [size];
	size_ = 0;
	capacity_ = size;

	clear();
}

Homework1::Garage::~Garage() {
	delete[] vehicles_;
	size_ = 0;
	capacity_ = 0;
}

// --------------
// Public Methods
// --------------

void Homework1::Garage::insert(Homework1::Vehicle & v) {
	if (!hasSpaceFor(v)) {
		throw std::out_of_range("Not enough space");
	}
	const char * reg;
	try {
		reg = v.registration();
	}
	catch (std::bad_alloc &) {
		throw;
	}

	try {
		std::size_t index = getIndexOf(reg);
	}
	catch (std::exception &) {
		// If exception is thrown, then could not find same registration,
		// so we continue here
		delete[] reg;
		vehicles_[size_++] = &v;
		return;
	}

	// Found same registration, throw error
	delete[] reg;
	throw std::invalid_argument("Registration already exists");
}

void Homework1::Garage::erase(const char * registration) {
	try {
		std::size_t eraseIndex = getIndexOf(registration);
		std::size_t lastIndex = size_ - 1;

		vehicles_[eraseIndex] = vehicles_[lastIndex];
		vehicles_[lastIndex] = nullptr;
		size_--;
	}
	catch (std::invalid_argument &) {
		throw;
	}
}

const Homework1::Vehicle & Homework1::Garage::at(std::size_t pos) const {
	if (capacity_ == 0) {
		throw std::invalid_argument("Capacity is zero");
	}
	if (pos >= size_) {
		throw std::out_of_range("Position is outside bounds of vehicle array");
	}
	return *vehicles_[pos];
}

const Homework1::Vehicle & Homework1::Garage::operator[](std::size_t pos) const {
	return *vehicles_[pos];
}

bool Homework1::Garage::empty() const {
	return size_ == 0 || capacity_ == 0;
}

std::size_t Homework1::Garage::size() const {
	return size_;
}

std::size_t Homework1::Garage::capacity() const {
	return capacity_;
}

void Homework1::Garage::clear() {
	for (std::size_t i = 0; i < capacity_; i++) {
		vehicles_[i] = nullptr;
	}
	size_ = 0;
}

const Homework1::Vehicle * Homework1::Garage::find(const char * registration) const {
	try {
		std::size_t index = getIndexOf(registration);
		return vehicles_[index];
	}
	catch (std::exception &) {
		return nullptr;
	}
}

std::size_t Homework1::Garage::takenSpace() const {
	std::size_t counter = 0;
	for (std::size_t i = 0; i < size_; i++) {
		counter += vehicles_[i]->space();
	}
	return counter;
}

std::size_t Homework1::Garage::freeSpace() const {
	return capacity_ - takenSpace();
}

bool Homework1::Garage::hasSpaceFor(const Vehicle & v) const {
	return v.space() <= freeSpace();
}

std::ostream & Homework1::operator<<(std::ostream & out, const Homework1::Garage & garage) {
	bool hasPrinted = false;
	out << '{' << "size: " << garage.size_ << ", capacity: " << garage.capacity_ << ", vehicles: [";
	for (std::size_t i = 0; i < garage.size_; i++) {
		if (hasPrinted) {
			out << ", ";
		}
		hasPrinted = true;
		out << *(garage.vehicles_[i]);
	}
	out << "]}";

	return out;
}
