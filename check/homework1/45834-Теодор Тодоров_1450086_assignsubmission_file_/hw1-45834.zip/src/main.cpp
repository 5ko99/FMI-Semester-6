#include <iostream>

#include "MyString.h"
#include "Garage.h"

using std::cin;
using std::cout;
using std::endl;
using std::size_t;

using namespace Homework1;

void printMenu() {
	cout << '\n'
		 << "0 - Exit" << '\n'
		 << "1 - Create Garage" << '\n'
		 << "2 - Create and add Vehicle" << '\n'
		 << "3 - Remove vehicle (does not delete, causes memory leak)" << '\n'
		 << "4 - Remove vehicle (does delete, does not cause memory leak)" << '\n'
		 << "5 - Print Garage" << '\n';

	cout << "Enter option: ";
}

int main() {
	Garage * garage = nullptr;
	int option;

	do {
		printMenu();
		cin >> option;
		cin.ignore();
		switch (option) {
			// 0 - Exit
			case 0: {
				break;
			}

			// 1 - Create Garage
			case 1: {
				if (garage != nullptr) {
					cout << "Could not create garage." << '\n';
					cout << "A garage already exists." << endl;
					break;
				}
				cout << "Enter garage capacity: ";

				size_t capacity;
				cin >> capacity;
				cin.ignore();
				cout << endl;

				try {
					garage = new Garage(capacity);
				}
				catch (std::exception & e) {
					cout << "Could not create garage." << '\n';
					cout << e.what() << endl;

					garage = nullptr;
					break;
				}

				cout << "Successfully created garage." << endl;
				break;
			}

			// 2 - Create and add Vehicle
			case 2: {
				if (garage == nullptr) {
					cout << "Cannot add vehicle, as a garage does not exist." << endl;
					break;
				}

				Vehicle * vehicle;
				try {
					char reg[64];
					char desc[64];
					size_t size;

					cout << "Enter registration: ";
					cin.getline(reg, 64);
					cout << endl;

					cout << "Enter description: ";
					cin.getline(desc, 64);
					cout << endl;

					cout << "Enter size: ";
					cin >> size;
					cin.ignore();
					cout << endl;

					vehicle = new Vehicle(reg, desc, size);
				}
				catch (std::exception & e) {
					cout << "Could not create Vehicle." << '\n';
					cout << e.what() << endl;
					break;
				}

				try {
					garage->insert(*vehicle);
				}
				catch (std::invalid_argument &) {
					cout << "Could not add vehicle, vehicle with the same registration already exists." << endl;
					delete vehicle;
					break;
				}
				catch (std::out_of_range &) {
					cout << "Could not add vehicle, garage is full." << endl;
					delete vehicle;
					break;
				}

				cout << "Successfully created and added vehicle to garage." << endl;
				break;
			}

			// 3 - Remove vehicle (does not delete, causes memory leak)
			case 3: {
				if (garage == nullptr) {
					cout << "Cannot remove vehicle, as a garage does not exist." << endl;
					break;
				}

				try {
					char reg[64];

					cout << "Enter registration: ";
					cin.getline(reg, 64);
					cout << endl;

					garage->erase(reg);
					cout << "Removed vehicle with registration \"" << reg << "\"" << endl;
				}
				catch (std::exception &) {
					cout << "Could not find vehicle." << endl;
					break;
				}

				break;
			}

			// 4 - Remove vehicle (does delete, does not cause memory leak)
			case 4: {
				if (garage == nullptr) {
					cout << "Cannot remove vehicle, as a garage does not exist." << endl;
					break;
				}

				try {
					char reg[64];

					cout << "Enter registration: ";
					cin.getline(reg, 64);
					cout << endl;

					const Vehicle * v = garage->find(reg);
					garage->erase(reg);

					delete v;
					cout << "Removed vehicle with registration \"" << reg << "\"" << endl;
				}
				catch (std::exception &) {
					cout << "Could not find vehicle." << endl;
				}

				break;
			}

			// 5 - Print Garage
			case 5: {
				if (garage == nullptr) {
					cout << "Cannot print garage, as a garage does not exist." << endl;
					break;
				}

				try {
					cout << *garage << endl;
				}
				catch (std::exception &) {
					cout << "Could not print garage." << endl;
				}

				break;
			}
			default: {
				break;
			}
		}
	}
	while (option != 0);

	delete garage;

	return 0;
}