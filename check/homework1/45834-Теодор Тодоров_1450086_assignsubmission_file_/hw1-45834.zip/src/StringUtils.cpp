#include <cstddef>

namespace Homework1 {
	/**
	 * Computes length of the specified string.
	 * Stops when '\0' is found.
	 *
	 * @return
	 */
	static std::size_t strlenLocal(const char * chars) {
		std::size_t len = 0;
		while (*chars++) {
			len++;
		}
		return len;
	}

	/**
	 * Checks if 2 strings are equal.
	 * If both are nullptr, returns true.
	 *
	 * @param a
	 * 		String 1
	 *
	 * @param b
	 * 		String 2
	 *
	 * @return
	 * 		true if strings are equal
	 */
	static bool streqLocal(const char * const a, const char * const b) {
		if (a == nullptr && b == nullptr) {
			return true;
		}
		if (a == nullptr || b == nullptr) {
			return false;
		}

		const std::size_t aLen = strlenLocal(a);
		const std::size_t bLen = strlenLocal(b);

		if (aLen != bLen) {
			return false;
		}

		for (std::size_t i = 0; i < aLen; i++) {
		    if (a[i] != b[i]) {
		    	return false;
		    }
		}

		return true;
	}

	/**
	 * Compares 2 strings lexicographically.
	 *
	 * @param a
	 *
	 * @param aSize
	 *
	 * @param b
	 *
	 * @param bSize
	 *
	 * @return
	 * 		-1 - A less than B, or A is nullptr <br>
	 * 		 0 - A equal to B, or A and B are nullptr <br>
	 * 		 1 - A less than B, or B is nullptr <br>
	 */
	static int strcmpLocal(const char * const a, std::size_t aSize, const char * const b, std::size_t bSize) {
		if (a == nullptr && b == nullptr) {
			return 0;
		}
		if (a == nullptr) {
			return -1;
		}
		if (b == nullptr) {
			return 1;
		}

		std::size_t maxLength = bSize > aSize ? bSize : aSize;

		for (std::size_t i = 0; i < maxLength; i++) {
			char leftChar = (i >= aSize ? '\0' : a[i]);
			char rightChar = (i >= bSize ? '\0' : b[i]);

			if (leftChar == rightChar) {
				continue;
			}

			// Can combine into one return statement, but less readable
			if (leftChar < rightChar) {
				return -1;
			}
			if (leftChar > rightChar) {
				return 1;
			}
		}
		return 0;
	}
}