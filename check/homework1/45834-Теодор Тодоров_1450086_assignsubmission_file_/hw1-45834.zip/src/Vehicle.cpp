#include "Vehicle.h"

// CLion has a bug with "unreachable code" actually being completely reachable
// This issue happens on try-catch blocks.
// In my case while using "new" and checking for bad_alloc.
#pragma clang diagnostic push
#pragma ide diagnostic ignored "UnreachableCode"

Homework1::Vehicle::Vehicle(const char * registration, const char * description, std::size_t space) {
	if (registration == nullptr) {
		throw std::invalid_argument("registration is nullptr");
	}
	if (description == nullptr) {
		throw std::invalid_argument("description is nullptr");
	}
	if (space == 0) {
		throw std::invalid_argument("space is 0");
	}

	registration_ = new MyString(registration);
	try {
		description_ = new MyString(description);
	}
	catch (std::bad_alloc &) {
		delete registration;
		throw;
	}
	space_ = space;
}

const char * Homework1::Vehicle::registration() const {
	return registration_->c_str();
}

const char * Homework1::Vehicle::description() const {
	return description_->c_str();
}

std::size_t Homework1::Vehicle::space() const {
	return space_;
}

Homework1::Vehicle::~Vehicle() {
	delete registration_;
	delete description_;
}

std::ostream & Homework1::operator<<(std::ostream & out, const Homework1::Vehicle & v) {
	const char * reg;
	try {
		reg = v.registration();
	}
	catch (std::bad_alloc &) {
		return out << "{}";
	}

	const char * desc;
	try {
		desc = v.description();
	}
	catch (std::bad_alloc &) {
		delete[] reg;
		return out << "{}";
	}
	out << "{reg: \"" << reg << "\", desc: \"" << desc << "\", space: " << v.space() << "}";

	delete[] reg;
	delete[] desc;

	return out;
}

#pragma clang diagnostic pop