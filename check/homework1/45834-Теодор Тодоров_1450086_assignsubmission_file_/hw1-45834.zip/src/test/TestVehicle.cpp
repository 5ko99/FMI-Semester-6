#include "catch.hpp"

#include <cstring>
#include "../Vehicle.h"

using namespace Homework1;

TEST_CASE("VehicleConstructor_NullParams_Throws") {
	// Arrange
	bool caughtException = false;
	try {

		// Act
		Vehicle v(nullptr, "ASD", 1);

	}
	catch (std::exception &) {
		caughtException = true;
	}

	// Assert
	REQUIRE(true == caughtException);
}

TEST_CASE("VehicleConstructor_NullFirstParam_Throws") {
	// Arrange
	bool caughtException = false;
	try {

		// Act
		Vehicle v(nullptr, "B", 1);

	}
	catch (std::exception &) {
		caughtException = true;
	}

	// Assert
	REQUIRE(true == caughtException);
}

TEST_CASE("VehicleConstructor_NullSecondParam_Throws") {
	// Arrange
	bool caughtException = false;
	try {

		// Act
		Vehicle v("A", nullptr, 1);

	}
	catch (std::exception &) {
		caughtException = true;
	}

	// Assert
	REQUIRE(true == caughtException);
}

TEST_CASE("VehicleConstructor_NullThirdParam_Throws") {
	// Arrange
	bool caughtException = false;
	try {

		// Act
		Vehicle v("A", "B", 0);

	}
	catch (std::exception &) {
		caughtException = true;
	}

	// Assert
	REQUIRE(true == caughtException);
}

TEST_CASE("VehicleConstructorAndGetters_GoodParams_ReturnedEqualsParams") {
	// Arrange
	const char * reg = "0001";
	const char * desc = "qka kola 0001";
	std::size_t space = 10;

	// Act
	Vehicle v(reg, desc, space);
	const char * actualReg = v.registration();
	const char * actualDesc = v.description();
	std::size_t actualSpace = v.space();

	// Assert
	bool regEqual = !strcmp(reg, actualReg);
	bool descEqual = !strcmp(desc, actualDesc);
	bool spaceEqual = (space == actualSpace);
	REQUIRE(true == regEqual);
	REQUIRE(true == descEqual);
	REQUIRE(true == spaceEqual);

	// Tear Down
	delete[] actualReg;
	delete[] actualDesc;
}