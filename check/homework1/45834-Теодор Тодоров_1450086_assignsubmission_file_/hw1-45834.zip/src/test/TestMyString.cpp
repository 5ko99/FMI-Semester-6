#include "catch.hpp"

#include <iostream>
#include "../MyString.h"

using namespace Homework1;

TEST_CASE("MyString()_DefaultParams_SizeIsZero") {
	// Arrange / Act
	MyString s1;

	// Assert
	REQUIRE(s1.size() == 0);
}

TEST_CASE("MyString(const char *)_GoodParams_SizeIsExpected") {
	// Arrange / Act
	MyString s1("asd");

	// Assert
	REQUIRE(s1.size() == 3);
}

TEST_CASE("MyString(const char *)_VariableParams_SizeIsExpected") {
	// Arrange / Act
	const char * constructorParam = "asd";
	MyString s1(constructorParam);

	// Assert
	REQUIRE(s1.size() == 3);
}

TEST_CASE("at(size_t)_GoodParams_ValuesMatch") {
	// Arrange
	MyString s1("asd");

	// Act / Assert
	REQUIRE('a' == s1.at(0));
	REQUIRE('s' == s1.at(1));
	REQUIRE('d' == s1.at(2));
}

TEST_CASE("at(size_t)_OutOfBounds_ExceptionThrown") {
	// Arrange
	MyString s1("asd");
	bool correctExceptionThrown = false;

	// Act
	try {
		s1.at(3);
	}
	catch (std::out_of_range & e) {
		correctExceptionThrown = true;
	}
	catch (std::exception & e) {
		correctExceptionThrown = false;
	}

	// Assert
	REQUIRE(true == correctExceptionThrown);
}

TEST_CASE("const-at(size_t)_GoodParams_ValuesMatch") {
	// Arrange
	const MyString s1("asd");

	// Act / Assert
	REQUIRE('a' == s1.at(0));
	REQUIRE('s' == s1.at(1));
	REQUIRE('d' == s1.at(2));
}

TEST_CASE("operator[]_GoodParams_ValuesMatch") {
	// Arrange
	MyString s1("asd");

	// Act / Assert
	REQUIRE('a' == s1[0]);
	REQUIRE('s' == s1[1]);
	REQUIRE('d' == s1[2]);
}

TEST_CASE("const-operator[]_GoodParams_ValuesMatch") {
	// Arrange
	const MyString s1("asd");

	// Act / Assert
	REQUIRE('a' == s1[0]);
	REQUIRE('s' == s1[1]);
	REQUIRE('d' == s1[2]);
}

TEST_CASE("operator[]_ChangeCharacter_Passes") {
	// Arrange
	MyString s1("asd");

	// Act
	s1[0] = 'f';

	// Assert
	REQUIRE('f' == s1[0]);
}

TEST_CASE("front()_GoodParamsNoChanges_GoodReference") {
	// Arrange
	MyString s1("asd");

	// Act
	char frontCharacter = s1.front();

	// Assert
	REQUIRE('a' == frontCharacter);
}

TEST_CASE("front()_EmptyString_ResultIsNullChar") {
	// Arrange
	MyString s1;

	// Act
	char frontCharacter = s1.front();

	// Assert
	REQUIRE('\0' == frontCharacter);
}

TEST_CASE("back()_EmptyString_ResultIsNullChar") {
	// Arrange
	MyString s1;

	// Act
	char backCharacter = s1.back();

	// Assert
	REQUIRE('\0' == backCharacter);
}

TEST_CASE("empty()_EmptyString_EmptyIsTrue") {
	// Arrange
	MyString s1;

	// Act
	bool b = s1.empty();

	// Assert
	REQUIRE(true == b);
}

TEST_CASE("empty()_NonEmptyString_EmptyIsFalse") {
	// Arrange
	MyString s1("asd");

	// Act
	bool b = s1.empty();

	// Assert
	REQUIRE(false == b);
}

TEST_CASE("size()_EmptyString_Equals") {
	// Arrange
	MyString s1;

	// Act
	std::size_t size = s1.size();

	// Assert
	REQUIRE(0 == size);
}

TEST_CASE("size()_NonEmptyString_Equals") {
	// Arrange
	const char * constructorParam = "asd";
	MyString s1(constructorParam);

	// Act
	std::size_t size = s1.size();

	// Assert
	REQUIRE(3 == size);
}

TEST_CASE("clear()_NonEmptyString_ZeroSize") {
	// Arrange
	MyString s1("asd");

	// Act
	s1.clear();

	// Assert
	REQUIRE(0 == s1.size());
}

TEST_CASE("push_back()_NonEmptyString_NonNullChar_CharacterAppended") {

	// Arrange
	MyString s1("asd");

	// Act
	s1.push_back('a');

	// Assert
	REQUIRE(4 == s1.size());
	REQUIRE('a' == s1.at(3));
}

TEST_CASE("push_back()_EmptyString_NonNullChar_CharacterAppended") {
	// Arrange
	MyString s1;

	// Act
	s1.push_back('a');

	// Assert
	REQUIRE(1 == s1.size());
	REQUIRE('a' == s1.at(0));
}

TEST_CASE("push_back()_NonEmptyString_NullChar_Throws") {
	// Arrange
	MyString s1("asd");

	// Act / Assert
	REQUIRE_THROWS(s1.push_back('\0'));
}

TEST_CASE("push_back()_EmptyString_NullChar_Throws") {
	// Arrange
	MyString s1;

	// Act / Assert
	REQUIRE_THROWS(s1.push_back('\0'));
}

TEST_CASE("pop_back()_NonEmptyString_CharacterRemoved") {
	// Arrange
	MyString s1("asd");

	// Act
	s1.pop_back();

	// Assert
	REQUIRE(2 == s1.size());
	REQUIRE('a' == s1.at(0));
	REQUIRE('s' == s1.at(1));
}

TEST_CASE("pop_back()_EmptyString_CharacterNotRemoved") {
	// Arrange
	MyString s1;

	// Act
	s1.pop_back();

	// Assert
	REQUIRE(0 == s1.size());
}

TEST_CASE("operator+=_NonEmptyLHS_NonNullChar_Combined") {
	// Arrange
	MyString s1("asd");
	char c = 'f';

	// Act
	s1 += c;

	// Assert
	REQUIRE(4 == s1.size());
	REQUIRE('a' == s1.at(0));
	REQUIRE('s' == s1.at(1));
	REQUIRE('d' == s1.at(2));
	REQUIRE('f' == s1.at(3));
}

TEST_CASE("operator+=_NonEmptyLHS_NullChar_Throws") {
	// Arrange
	MyString s1("asd");
	char c = '\0';

	// Act / Assert
	REQUIRE_THROWS(s1 += c);
	REQUIRE(3 == s1.size());
	REQUIRE('a' == s1.at(0));
	REQUIRE('s' == s1.at(1));
	REQUIRE('d' == s1.at(2));
}

TEST_CASE("operator+=_EmptyLHS_NonNullChar_CombinedIsChar") {
	// Arrange
	MyString s1;
	char c = 'f';

	// Act
	s1 += c;

	// Assert
	REQUIRE(1 == s1.size());
	REQUIRE('f' == s1.at(0));
}

TEST_CASE("operator+=_EmptyLHS_NullChar_Throws") {
	// Arrange
	MyString s1;
	char c = '\0';

	// Act / Assert
	REQUIRE_THROWS(s1 += c);
	REQUIRE(0 == s1.size());
}

TEST_CASE("operator+=_NonEmptyLHS_NonEmptyRHS_CombinedIsLHSRHS") {
	// Arrange
	MyString s1("asd");
	MyString s2("fgh");

	// Act
	s1 += s2;

	// Assert
	REQUIRE(6 == s1.size());
	REQUIRE('a' == s1.at(0));
	REQUIRE('s' == s1.at(1));
	REQUIRE('d' == s1.at(2));
	REQUIRE('f' == s1.at(3));
	REQUIRE('g' == s1.at(4));
	REQUIRE('h' == s1.at(5));
}

TEST_CASE("operator+=_NonEmptyLHS_EmptyRHS_CombinedIsLHS") {
	// Arrange
	MyString s1("asd");
	MyString s2;

	// Act
	s1 += s2;

	// Assert
	REQUIRE(3 == s1.size());
	REQUIRE('a' == s1.at(0));
	REQUIRE('s' == s1.at(1));
	REQUIRE('d' == s1.at(2));
}


TEST_CASE("operator+=_EmptyLHS_NonEmptyRHS_CombinedIsRHS") {
	// Arrange
	MyString s1;
	MyString s2("asd");

	// Act
	s1 += s2;

	// Assert
	REQUIRE(3 == s1.size());
	REQUIRE('a' == s1.at(0));
	REQUIRE('s' == s1.at(1));
	REQUIRE('d' == s1.at(2));
}

TEST_CASE("operator+=_EmptyLHS_EmptyRHS_CombinedIsEmpty") {
	// Arrange
	MyString s1;
	MyString s2;

	// Act
	s1 += s2;

	// Assert
	REQUIRE(0 == s1.size());
}

TEST_CASE("operator+_NonEmptyLHS_NonEmptyRHS_CombinedIsLHSRHS") {
	// Arrange
	MyString s1("asd");
	MyString s2("fgh");

	// Act
	MyString s3 = s1 + s2;

	// Assert
	REQUIRE(6 == s3.size());
	REQUIRE('a' == s3.at(0));
	REQUIRE('s' == s3.at(1));
	REQUIRE('d' == s3.at(2));
	REQUIRE('f' == s3.at(3));
	REQUIRE('g' == s3.at(4));
	REQUIRE('h' == s3.at(5));
}

TEST_CASE("operator+_NonEmptyLHS_EmptyRHS_CombinedIsLHS") {
	// Arrange
	MyString s1("asd");
	MyString s2;

	// Act
	MyString s3 = s1 + s2;

	// Assert
	REQUIRE(3 == s3.size());
	REQUIRE('a' == s3.at(0));
	REQUIRE('s' == s3.at(1));
	REQUIRE('d' == s3.at(2));
}

TEST_CASE("operator+_EmptyLHS_NonEmptyRHS_CombinedIsRHS") {
	// Arrange
	MyString s1;
	MyString s2("asd");

	// Act
	MyString s3 = s1 + s2;

	// Assert
	REQUIRE(3 == s3.size());
	REQUIRE('a' == s3.at(0));
	REQUIRE('s' == s3.at(1));
	REQUIRE('d' == s3.at(2));
}

TEST_CASE("operator+_EmptyLHS_EmptyRHS_CombinedIsEmpty") {
	// Arrange
	MyString s1;
	MyString s2;

	// Act
	MyString s3 = s1 + s2;

	// Assert
	REQUIRE(0 == s3.size());
}

TEST_CASE("c_str()_NonEmptyString_Equals") {
	// Arrange
	MyString s1("asd");

	// Act
	const char * str = s1.c_str();

	// Assert
	REQUIRE('a' == str[0]);
	REQUIRE('s' == str[1]);
	REQUIRE('d' == str[2]);
	REQUIRE('\0' == str[3]);

	// Tear Down
	delete[] str;
}

TEST_CASE("c_str()_EmptyString_EqualsNullChar") {
	// Arrange
	MyString s1;

	// Act
	const char * str = s1.c_str();

	// Assert
	REQUIRE('\0' == str[0]);

	// Tear Down
	delete[] str;
}

TEST_CASE("operator==_EmptyLHS_EmptyRHS_Equal") {
	// Arrange
	MyString s1;
	MyString s2;

	// Act
	bool isEqual = (s1 == s2);

	// Assert
	REQUIRE(true == isEqual);
}

TEST_CASE("operator==_EmptyLHS_EmptyStringRHS_Equal") {
	// Arrange
	MyString s1;
	MyString s2("");

	// Act
	bool isEqual = (s1 == s2);

	// Assert
	REQUIRE(true == isEqual);
}

TEST_CASE("operator==_EmptyStringLHS_EmptyStringRHS_Equal") {
	// Arrange
	MyString s1("");
	MyString s2("");

	// Act
	bool isEqual = (s1 == s2);

	// Assert
	REQUIRE(true == isEqual);
}

TEST_CASE("operator==_NonEmptyLHS_NonEmptyRHS_Equal") {
	// Arrange
	MyString s1("asd");
	MyString s2("asd");

	// Act
	bool isEqual = (s1 == s2);

	// Assert
	REQUIRE(true == isEqual);
}

TEST_CASE("operator==_NonEmptyLHS_SimilarNonEmptyRHS_Equal") {
	// Arrange
	MyString s1("asd");
	MyString s2("asd\0");

	// Act
	bool isEqual = (s1 == s2);

	// Assert
	REQUIRE(true == isEqual);
}

TEST_CASE("operator==_NonEmptyLHS_NonEmptyRHS_SameLength_NotEqual") {
	// Arrange
	MyString s1("asd");
	MyString s2("asf");

	// Act
	bool isEqual = (s1 == s2);

	// Assert
	REQUIRE(false == isEqual);
}

TEST_CASE("operator==_NonEmptyLHS_NonEmptyRHS_DifferentLength_NotEqual") {
	// Arrange
	MyString s1("asdf");
	MyString s2("asd");

	// Act
	bool isEqual = (s1 == s2);

	// Assert
	REQUIRE(false == isEqual);
}

TEST_CASE("operator<_NonEmptyLHS_NonEmptyRHS_DifferentLength_Less") {
	// Arrange
	MyString s1("asd");
	MyString s2("asdf");

	// Act
	bool isLess = s1 < s2;

	// Assert
	REQUIRE(true == isLess);
}

TEST_CASE("operator<_NonEmptyLHS_NonEmptyRHS_SameLength_Less") {
	// Arrange
	MyString s1("asd");
	MyString s2("asf");

	// Act
	bool isLess = s1 < s2;

	// Assert
	REQUIRE(true == isLess);
}

TEST_CASE("operator<_EmptyLHS_NonEmptyRHS_Less") {
	// Arrange
	MyString s1;
	MyString s2("asdf");

	// Act
	bool isLess = s1 < s2;

	// Assert
	REQUIRE(true == isLess);
}

TEST_CASE("operator<_EmptyLHS_EmptyRHS_NotLess") {
	// Arrange
	MyString s1;
	MyString s2;

	// Act
	bool isLess = s1 < s2;

	// Assert
	REQUIRE(false == isLess);
}

TEST_CASE("operator<_NonEmptyLHS_NonEmptyRHS_NotLess") {
	// Arrange
	MyString s1("asd");
	MyString s2("asd\0");

	// Act
	bool isLess = s1 < s2;

	// Assert
	REQUIRE(false == isLess);
}

TEST_CASE("MyString(const MyString &)_GoodParams_Copied") {
	// Arrange
	MyString s1("asd");

	// Act
	MyString s2 = s1;

	// Assert
	bool copyIsEqual = (s1 == s2);
	REQUIRE(true == copyIsEqual);
}

TEST_CASE("const-MyString(const MyString &)_GoodParams_Copied") {
	// Arrange
	const MyString s1("asd");

	// Act
	const MyString s2 = s1;

	// Assert
	bool copyIsEqual = (s1 == s2);
	REQUIRE(true == copyIsEqual);
}

TEST_CASE("operator<<") {
	// Can't really test this easily without a bunch of includes?
}