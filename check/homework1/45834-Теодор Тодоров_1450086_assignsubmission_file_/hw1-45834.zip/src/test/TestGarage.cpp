#include "catch.hpp"

#include <iostream>
#include "../Garage.h"

using namespace Homework1;

// TODO: Add more tests, even though they wouldn't matter

TEST_CASE("GarageExampleUses") {
	//
	// Arrange
	//
	std::size_t garageCapacity = 10;

	const char * v1Reg = "0001";
	const char * v1Desc = "Audi A1";
	std::size_t v1Space = 4;

	const char * v2Reg = "0002";
	const char * v2Desc = "Audi A3";
	std::size_t v2Space = 6;

	const char * v3Reg = "0003";
	const char * v3Desc = "Audi RS7";
	std::size_t v3Space = 10;

	Vehicle v1(v1Reg, v1Desc, v1Space);
	Vehicle v2(v2Reg, v2Desc, v2Space);
	Vehicle v3(v3Reg, v3Desc, v3Space);

	//
	// Act / Assert
	//
	SECTION("Empty garage") {
		Garage g(garageCapacity);
		REQUIRE(garageCapacity == g.capacity());
	}

	SECTION("Add one vehicle to garage") {
		Garage g(garageCapacity);
		REQUIRE(garageCapacity == g.capacity());

		g.insert(v1);
		REQUIRE(1 == g.size());
		REQUIRE(garageCapacity == g.capacity());
	}

	SECTION("Add two vehicles to garage") {
		Garage g(garageCapacity);
		REQUIRE(garageCapacity == g.capacity());

		g.insert(v1);
		REQUIRE(1 == g.size());
		REQUIRE(garageCapacity == g.capacity());

		g.insert(v2);
		REQUIRE(2 == g.size());
		REQUIRE(garageCapacity == g.capacity());
	}

	SECTION("Add too many vehicles to garage") {
		Garage g(garageCapacity);
		REQUIRE(garageCapacity == g.capacity());

		g.insert(v1);
		REQUIRE(1 == g.size());
		REQUIRE(garageCapacity == g.capacity());

		g.insert(v2);
		REQUIRE(2 == g.size());
		REQUIRE(garageCapacity == g.capacity());

		REQUIRE_THROWS_AS(g.insert(v3), std::out_of_range);
	}

	SECTION("Add same vehicle to garage") {
		Garage g(garageCapacity);
		REQUIRE(garageCapacity == g.capacity());

		g.insert(v1);
		REQUIRE(1 == g.size());
		REQUIRE(garageCapacity == g.capacity());

		REQUIRE_THROWS_AS(g.insert(v1), std::invalid_argument);
	}
}
