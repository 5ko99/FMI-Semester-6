#pragma once

#include <cstddef>
#include "MyString.h"

namespace Homework1 {
	class Vehicle {
		MyString * registration_;
		MyString * description_;
		std::size_t space_;
	public:
		/**
		 *
		 * @param registration
		 * @param description
		 * @param space
		 *
		 * @throws std::invalid_argument
		 */
		Vehicle(const char * registration, const char * description, std::size_t space);
		~Vehicle();

		/**
		 * Нужно е да се изтрие след употреба!
		 * Връща регистрационния номер като C-style символен низ.
		 *
		 * @throws std::bad_alloc
		 *
		 * @return
		 */
		const char * registration() const;

		/**
		 * Нужно е да се изтрие след употреба!
		 * Връща описанието на превозното средство като C-style символен низ.
		 *
		 * @throws std::bad_alloc
		 *
		 * @return
		 */
		const char * description() const;

		/**
		 * Връща мястото, което заема превозното средство при паркиране.
		 *
		 * @return
		 */
		std::size_t space() const;

		friend std::ostream & operator<<(std::ostream & out, const Vehicle & v);
	};
}
