#pragma once

#include <iostream>
#include <cstddef>

#include "Vehicle.h"

namespace Homework1 {
	class Garage {
		Vehicle ** vehicles_;
		std::size_t size_;
		std::size_t capacity_;

		/**
		 *
		 * @param registration
		 *
		 * @throws std::invalid_argument
		 * 		If vehicle with specified registration does not exist
		 *
		 * @return
		 */
		std::size_t getIndexOf(const char * registration) const;

	public:
		/*
		 * Гарантирайте, че обектите могат да се копират и унищожават коректно.
		 * Ако е нужно, реализирайте експлицитно всички функции от rule of 3
		 * (бонус: гарантирайте, че работят коректно всички от rule of 5).
		 * Ако това не е нужно, следвайте rule of 0.
		 */

		/**
		 * Създава гараж с максимално място за паркиране size.
		 *
		 * @param size
		 */
		Garage(std::size_t size);

		~Garage();

		/**
		 * Добавя превозното средство v в гаража.
		 * Ако операцията не успее (например няма достатъчно памет,
		 * в гаража няма повече място за паркиране,
		 * вече има кола със същия регистрационен номер),
		 * да се хвърля изключение.
		 *
		 * Операцията да дава strong exception guarantee.
		 *
		 * @param v
		 *
		 * @throws std::out_of_range
		 * 		Ако няма достатъчно място в гаража.
		 *
		 * @throws std::invalid_argument
		 * 		Ако вече съществува превозно средство с такава регистрация.
		 */
		void insert(Vehicle & v);

		/**
		 * Премахва колата с регистрационен номер registration от гаража.
		 * Ако такава няма, да не се прави нищо.
		 * При премахването на кола от гаража е допустимо да се промени редът на останалите в гаража.
		 * Това условие ще ви позволи при премахване на елемент
		 * да поставите последния елемент от масива на мястото на премахнатия,
		 * вместо да правите left shift.
		 *
		 * @param registration
		 *
		 * @throws std::invalid_argument
		 * 		Ако не съществува такова превозно средство
		 */
		void erase(const char * registration);


		/**
		 * Достъп до елемента намиращ се на позиция pos.
		 * Ако такъв няма, да се хвърля изключение std::out_of_range.
		 *
		 * @param pos
		 * @return
		 */
		const Vehicle & at(std::size_t pos) const;

		/**
		 * достъп до елемента намиращ се на позиция pos.
		 * Функцията да не прави проверка за коректност дали pos е валидна позиция.
		 * (В debug режим assert-вайте дали pos е валидна позиция).
		 *
		 * @param pos
		 * @return
		 */
		const Vehicle & operator[](std::size_t pos) const;


		/**
		 * Проверява дали гаражът е празен.
		 *
		 * @return
		 */
		bool empty() const;

		/**
		 * Брой елементи (превозни средства) в гаража.
		 *
		 * @return
		 */
		std::size_t size() const;

		/**
		 * Капацитет на гаража.
		 *
		 * @return
		 */
		std::size_t capacity() const;

		/**
		 * Изчиства съдържанието на гаража.
		 * Това означава, че в него не се съдържа нито една кола.
		 * Капацитетът му обаче остава непроменен.
		 * Така в него могат отново да се добавят нови коли.
		 */
		void clear();

		/**
		 * Намира и връща превозното средство с регистрационен номер registration в гаража.
		 * Ако такова няма, да се върне nullptr.
		 *
		 * @param registration
		 * @return
		 */
		const Vehicle * find(const char * registration) const;

		/**
		 *
		 * @return
		 */
		std::size_t takenSpace() const;

		/**
		 *
		 * @return
		 */
		std::size_t freeSpace() const;

		bool hasSpaceFor(const Vehicle & v) const;

		friend std::ostream & operator<<(std::ostream & out, const Garage & garage);
	};
}