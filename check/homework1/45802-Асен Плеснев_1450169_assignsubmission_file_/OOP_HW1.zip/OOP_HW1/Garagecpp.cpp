#include<iostream>
#include "./MyString.hpp"
#include "./Vehicle.hpp"

using namespace std;