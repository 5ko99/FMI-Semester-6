#pragma once
#include <iostream>

using namespace std;

class MyString {

	size_t textSize = 0;
	char* text = nullptr;

	size_t CalculateSize(const char* str);

public:
	MyString();

	MyString(const char* str);

	MyString(const MyString& str);

	MyString& operator=(const MyString& str);

	~MyString();

	char& at(size_t pos);

	const char& at(size_t pos) const;

	char& operator[](size_t pos);

	const char& operator[](size_t pos) const;

	char& front();

	const char& front() const;

	char& back();

	const char& back() const;

	bool empty() const;

	size_t size() const;

	void clear();

	void push_back(char c);

	void pop_back();

	MyString& operator+=(char c);

	MyString& operator+=(const MyString& rhs);

	MyString operator+(char c) const;

	MyString operator+(const MyString& rhs) const;

	const char* c_str() const;

	bool operator==(const MyString& rhs) const;

	bool operator<(const MyString& rhs) const;
};