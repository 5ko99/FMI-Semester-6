#include<iostream>
#include "./MyString.hpp"
#include "./Vehicle.hpp"

using namespace std;


Vehicle::Vehicle(const char* registration, const char* description, size_t space)
{
	MyString str(registration);

	this->regNumber = str;

	MyString str1(description);
	this->desc = str1;

	this->parkedCapacity = space;
}

const char* Vehicle::registration() const
{
	return this->regNumber.c_str();
}

const char* Vehicle::description() const
{
	return this->desc.c_str();
}

size_t Vehicle::space() const
{
	return this->parkedCapacity;
}

//int main()
//{
//	Vehicle car("E 2020 MH", "Opel Zafira", 5);
//
//	cout << car.registration() << endl << car.description() << endl << car.space();
//
//
//	return 0;
//}