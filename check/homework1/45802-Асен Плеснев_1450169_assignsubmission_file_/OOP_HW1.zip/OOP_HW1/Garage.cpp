#include<iostream>
#include "./MyString.hpp"
#include "./Vehicle.hpp"
#include "./Garage.hpp"

using namespace std;

Garage::Garage(size_t size)
{
	this->garageCapacity = size;
	this->originalCapacity = size;
}

Garage::Garage(const Garage& g)
{
	(*this) = g;
}

Garage& Garage::operator=(const Garage& g)
{
	delete[] this->vehicles;

	this->carCount = g.carCount;
	this->garageCapacity = g.garageCapacity;
	this->originalCapacity = g.originalCapacity;

	this->vehicles = new Vehicle * [g.carCount];

	for (size_t i = 0; i < g.carCount; i++)
	{
		this->vehicles[i] = g.vehicles[i];
	}

	return *this;
}

Garage::~Garage()
{
	delete[] this->vehicles;
}

size_t Garage::hasRegNumber(const char* regNumber) const
{
	if (this->carCount == 0)
	{
		return -1;
	}

	for (size_t i = 0; i < carCount; i++)
	{
		MyString str(this->vehicles[i]->registration());

		if (str == regNumber)
		{
			return i;
		}
	}

	return -1;
}

void Garage::addToGarage(Vehicle& v)
{
		Vehicle** arr = new Vehicle * [this->carCount + 1];
		this->carCount += 1;

		for (size_t i = 0; i < this->carCount - 1; i++)
		{
			arr[i] = this->vehicles[i];
		}

		arr[this->carCount - 1] = &v;


		delete[] this->vehicles;

		this->vehicles = arr;
}

void Garage::insert(Vehicle& v)
{
	try
	{
		if (this->garageCapacity < v.space())
		{
			throw exception("Garage does not have enough capacity");
		}

		if (this->hasRegNumber(v.registration()) != -1)
		{
			throw exception("Vehicle with this registration number already exsists");
		}
	}
	catch (const exception& e)
	{
		cerr << e.what();
		return;
	}

	addToGarage(v);

	for (size_t i = 0; i < this->carCount; i++)
	{
		cout << this->vehicles[i]->registration() << " " << this->vehicles[i]->description() << " " << this->vehicles[i]->space() << endl << endl;
	}

	this->garageCapacity -= v.space();
}

void Garage::erase(const char* registration)
{
	size_t index = this->hasRegNumber(registration);

	if (index != -1)
	{
			Vehicle** arr = new Vehicle* [this->carCount - 1];

			size_t arrIndex = 0;

			for (size_t i = 0; i < this->carCount; i++)
			{
				if (i == index)
				{
					continue;
				}

				arr[arrIndex] = this->vehicles[i];

				arrIndex++;
			}

		this->carCount -= 1;
		this->garageCapacity += this->vehicles[index]->space();

		delete[] this->vehicles;

		this->vehicles = arr;

		for (size_t i = 0; i < this->carCount; i++)
		{
			cout << this->vehicles[i]->registration() << " " << this->vehicles[i]->description() << " " << this->vehicles[i]->space() << endl << endl;
		}

	}
}

const Vehicle& Garage::at(size_t pos) const
{
	if (pos < 0 || pos >= this->carCount)
	{
		throw out_of_range("Index is out of range");
	}

	return *(this->vehicles[pos]);
}

const Vehicle& Garage::operator[](size_t pos) const
{
	return *(this->vehicles[pos]);
}

bool Garage::empty() const
{
	return this->carCount == 0;
}

size_t Garage::size() const
{
	return this->carCount;
}

void Garage::clear()
{
	delete[] this->vehicles;
	this->vehicles = nullptr;
	this->carCount = 0;
	this->garageCapacity = this->originalCapacity;
}

const Vehicle* Garage::find(const char* registration) const
{
	size_t index = this->hasRegNumber(registration);

	if (index != -1)
	{
		return this->vehicles[index];
	}

	return nullptr;
}

//
//int main()
//{
//	Vehicle v1("123", "BMW", 1);
//	Vehicle v2("222", "VW", 1);
//	Vehicle v3("111", "Opel", 1);
//
//	Garage g(5);
//
//	g.insert(v1);
//	g.insert(v2);
//	g.insert(v3);
//
//	return 0;
//}
