#include<iostream>
#include"./Garage.hpp"
#include"./MyString.hpp"
#include"./Vehicle.hpp"

using namespace std;

int main()
{
	size_t garageSize;

	cout << "Enter garage size: ";

	cin >> garageSize;

	Garage g(garageSize);

	cout << "Enter the number of vehicles you want to create: ";

	size_t vNum;

	cin >> vNum;

	for (size_t i = 0; i < vNum; i++)
	{
		string reg, desc;
		size_t size;
	
		cout << "Enter registration: ";
		cin >> reg;

		char* reg_arr = &reg[0];

		cout << "Enter description: ";
		cin >> desc;

		char* desc_arr = &desc[0];

		cout << "Enter size: ";
		cin >> size;

		Vehicle v(reg_arr, desc_arr, size);

		string add;

		cout << "Do you want to add the vehicle to the garage?(yes or no) ";

		cin >> add;

		if (add == "yes")
		{
			g.insert(v);
		}

	}
	return 0;
}