#pragma once
#include<iostream>
#include "./Vehicle.hpp"

using namespace std;

class Garage {
	size_t carCount=0;

	size_t garageCapacity;

	size_t originalCapacity;

	Vehicle** vehicles = nullptr;

	size_t hasRegNumber(const char* regNumber) const;

	void addToGarage(Vehicle& v);

public:
	Garage(size_t size);

	Garage(const Garage& g);

	Garage& operator=(const Garage& g);

	~Garage();

	void insert(Vehicle& v);

	void erase(const char* registration);

	const Vehicle& at(std::size_t pos) const;

	const Vehicle& operator[](std::size_t pos) const;

	bool empty() const;

	std::size_t size() const;

	void clear();

	const Vehicle* find(const char* registration) const;
};
