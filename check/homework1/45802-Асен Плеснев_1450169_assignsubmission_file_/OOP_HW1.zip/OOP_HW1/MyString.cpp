#include <iostream>
#include "./MyString.hpp";

using namespace std;

size_t MyString::CalculateSize(const char* str)
{
	size_t i = 0;

	while (str[i] != '\0')
	{
		i++;
	}

	return i;
}

MyString::MyString() {};

MyString::MyString(const char* str)
{
	size_t size = CalculateSize(str);

	char* text = new char[size + 1];

	for (size_t i = 0; i < size; i++)
	{
		text[i] = str[i];
	}

	text[size] = '\0';

	this->textSize = size + 1;
	this->text = text;
}

MyString::MyString(const MyString& str)
{
	(*this) = str;
}

MyString& MyString::operator=(const MyString& str)
{
	delete[] this->text;

	this->textSize = str.textSize;

	this->text = new char[str.textSize];

	for (size_t i = 0; i < str.textSize - 1; i++)
	{
		this->text[i] = str.text[i];
	}

	this->text[str.textSize - 1] = '\0';

	return *this;
}

MyString::~MyString()
{
	delete[] this->text;
}

char& MyString::at(size_t pos)
{
	try
	{
		if (pos < 0 || pos >= this->textSize - 1)
		{
			throw out_of_range("Index out of range!");
		}
	}
	catch (const out_of_range & e)
	{
		cerr << e.what();
	}

	return this->text[pos];
}

const char& MyString::at(size_t pos) const
{
	try
	{
		if (pos < 0 || pos >= this->textSize - 1)
		{
			throw out_of_range("Index out of range!");
		}
	}
	catch (const out_of_range & e)
	{
		cerr << e.what();
	}

	return this->text[pos];
}

char& MyString::operator[](size_t pos)
{
	return this->text[pos];
}

const char& MyString::operator[](size_t pos) const
{
	return this->text[pos];
}

char& MyString::front()
{
	return this->text[0];
}

const char& MyString::front() const
{
	return this->text[0];
}

char& MyString::back()
{
	return this->text[this->textSize - 2];
}

const char& MyString::back() const
{
	return this->text[this->textSize - 2];
}

bool MyString::empty() const
{
	return this->textSize == 0;
}

size_t MyString::size() const
{
	return this->textSize;
}

void MyString::clear()
{
	this->textSize = 0;
	delete[] this->text;
	this->text = nullptr;
}

void MyString::push_back(char c)
{
	size_t newSize = this->textSize + 1;

	char* newText = new char[newSize];


	for (size_t i = 0; i < this->textSize - 1; i++)
	{
		newText[i] = this->text[i];
	}

	delete[] this->text;

	newText[newSize - 2] = c;
	newText[newSize - 1] = '\0';

	this->text = newText;
	this->textSize = newSize;
}

void MyString::pop_back()
{
	this->textSize -= 1;
	this->text[textSize - 1] = '\0';

	cout << this->text << endl << this->textSize << endl;
}

MyString& MyString::operator+=(char c)
{
	this->push_back(c);

	cout << this->text << endl << this->textSize << endl;

	return *this;
}

MyString& MyString::operator+=(const MyString& rhs)
{
	size_t newSize = rhs.textSize + this->textSize - 1;

	char* newText = new char[newSize];

	size_t textIndex = 0;

	for (size_t i = 0; i < this->textSize - 1; i++)
	{
		newText[textIndex] = this->text[i];
		textIndex++;
	}

	for (size_t i = 0; i < rhs.textSize - 1; i++)
	{
		newText[textIndex] = rhs.text[i];
		textIndex++;
	}

	newText[textIndex] = '\0';

	delete[] this->text;

	this->textSize = newSize;
	this->text = newText;

	cout << this->text << endl << this->textSize << endl;

	return *this;
}

MyString MyString::operator+(char c) const
{
	MyString newStr;

	size_t newSize = this->textSize + 1;

	char* newText = new char[newSize];

	for (size_t i = 0; i < this->textSize; i++)
	{
		newText[i] = this->text[i];
	}

	newText[newSize - 2] = c;
	newText[newSize - 1] = '\0';

	newStr.textSize = newSize;
	newStr.text = newText;

	cout << newStr.text << endl << newStr.textSize << endl;

	return newStr;
}

MyString MyString::operator+(const MyString& rhs) const
{
	MyString newStr;

	size_t newSize = this->textSize + rhs.textSize - 1;

	char* newText = new char[newSize];

	size_t textIndex = 0;

	for (size_t i = 0; i < this->textSize - 1; i++)
	{
		newText[textIndex] = this->text[i];
		textIndex++;
	}

	for (size_t i = 0; i < rhs.textSize - 1; i++)
	{
		newText[textIndex] = rhs.text[i];
		textIndex++;
	}

	newText[textIndex] = '\0';

	newStr.textSize = newSize;
	newStr.text = newText;

	return newStr;
}

const char* MyString::c_str() const
{
	return this->text;
}

bool MyString::operator==(const MyString& rhs) const
{
	if (this->textSize != rhs.textSize)
	{
		return false;
	}

	for (size_t i = 0; i < this->textSize - 1; i++)
	{
		if (this->text[i] != rhs.text[i])
		{
			return false;
		}
	}

	return true;
}

bool MyString::operator<(const MyString& rhs) const
{

	for (size_t i = 0; i < this->textSize - 1 && i < rhs.textSize - 1; i++)
	{
		if (this->text[i] < rhs.text[i])
		{
			return true;
		}
	}

	if (this->textSize < rhs.textSize)
	{
		return true;
	}

	return false;

}

//int main()
//{
//	MyString myStr("tess");
//	MyString myStr2("test");
//
//	MyString myStr3 = (myStr + 's');
//
//	bool res = myStr < myStr2;
//
//	if (res)
//	{
//		cout << "yes" << endl;
//	}
//	else
//	{
//		cout << "no" << endl;
//	}
//
//	return 0;
//}