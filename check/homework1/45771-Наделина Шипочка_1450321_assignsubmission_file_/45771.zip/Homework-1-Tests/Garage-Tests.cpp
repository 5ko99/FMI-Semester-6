#include "../Homework-1/Garage.h"
#include "catch.hpp"

TEST_CASE("Garage ctor") {
	Garage g(1);
	Vehicle v("1234", "a car", 1);

	REQUIRE_NOTHROW(g.insert(v));
}

TEST_CASE("Garage insert") {

	Vehicle v("1234", "a car", 1);

	SECTION("enough space") {

		const size_t sz = 5;

		Garage g(sz);
		g.insert(v);

		REQUIRE(g.empty() == false);
		REQUIRE(g.size() == 1); //one added vehicle

		SECTION("repeating registration") {
			
			REQUIRE_THROWS_AS(g.insert(v), std::exception);
		}
	}

	SECTION("not enough space") {
		Garage g(0);
		REQUIRE_THROWS_AS(g.insert(v), std::exception);
	}
}

TEST_CASE("Garage erase a vehicle") {

	const size_t sz = 5;

	Garage g(sz);
	Vehicle v("1234", "a car", 1);

	g.insert(v);

	SECTION("The vehicle is in the garage") {
		g.erase(v.registration());
		REQUIRE(g.empty() == true);
	}

	SECTION("That vehicle is not in the garage") {
		g.erase("1331");
		REQUIRE(g.size() == 1);
	}
}

TEST_CASE("Garage get element at position") {

	const size_t sz = 5;

	Garage g(sz);
	Vehicle v("1234", "a car", 1);

	g.insert(v);

	SECTION("Element is in the garage") {

		SECTION("at(pos)") {
			Vehicle vehicle = g.at(0);
			REQUIRE(strcmp(vehicle.registration(), v.registration()) == 0);
			REQUIRE(strcmp(vehicle.description(), v.description()) == 0);
			REQUIRE(vehicle.space() == v.space());
		}

		SECTION("operatior[]") {
			Vehicle vehicle = g[0];
			REQUIRE(strcmp(vehicle.registration(), v.registration()) == 0);
			REQUIRE(strcmp(vehicle.description(), v.description()) == 0);
			REQUIRE(vehicle.space() == v.space());
		}
	}

	SECTION("There is no such an element") {
		SECTION("at(pos)") {
			REQUIRE_THROWS_AS(g.at(g.size() + 5), std::out_of_range);
		}
	}
}

TEST_CASE("Garage clear") {

	Garage g(4);

	SECTION("Elemnts in garage") {
		Vehicle v("1234", "a car", 1);
		g.insert(v);
		g.clear();
		REQUIRE(g.size() == 0);
	}

	SECTION("Empty garage") {
		REQUIRE_NOTHROW(g.clear());
	}
}

TEST_CASE("Garage find") {
	
	Garage g(4);
	Vehicle v("1234", "a car", 1);
	
	SECTION("Vehicle in garage") {
		g.insert(v);

		const Vehicle* vehicle = g.find("1234");
		REQUIRE(strcmp(vehicle->registration(), v.registration()) == 0);
		REQUIRE(strcmp(vehicle->description(), v.description()) == 0);
		REQUIRE(vehicle->space() == v.space());
	}

	SECTION("Vehicle not in garage") {
		const Vehicle* vehicle = g.find("1234");
		REQUIRE(vehicle == nullptr);
	}
}