#include "catch.hpp"
#include "../Homework-1/Garage.h"
#include "../Homework-1/VehicleAllocator.h"

TEST_CASE("VehicleAllocator default ctor") {
	
	VehicleAllocator va;
	REQUIRE_NOTHROW(va.allocate("a", "a", 1));
}

TEST_CASE("VehicleAllocator allocate") {
	
	VehicleAllocator va;
	Vehicle* v = va.allocate("a", "a", 1);
	
	REQUIRE(strcmp(v->registration(), "a") == 0);
	REQUIRE(strcmp(v->description(), "a") == 0);
	REQUIRE(v->space() == 1);
}

TEST_CASE("VehicleAllocator resize") {
	VehicleAllocator va;

	va.allocate("a", "a", 1);
	va.allocate("a", "a", 1);
	va.allocate("a", "a", 1);
	va.allocate("a", "a", 1);
	va.allocate("a", "a", 1);

	REQUIRE_NOTHROW(va.allocate("a", "a", 1));
}