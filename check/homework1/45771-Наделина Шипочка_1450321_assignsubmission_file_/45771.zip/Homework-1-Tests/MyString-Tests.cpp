#include "../Homework-1/MyString.h"
#include "catch.hpp"

TEST_CASE("MyString constructors") {

	SECTION("default constructor") {

		MyString mstr;

		REQUIRE(mstr.size() == 0);
		REQUIRE(strcmp(mstr.c_str(), "") == 0);
	}

	SECTION("parametrized constructor") {

		const char ch[] = "abc";
		MyString mstr(ch);

		REQUIRE(mstr.size() == strlen(ch));
		REQUIRE(strcmp(mstr.c_str(), ch) == 0);
	}
}

TEST_CASE("MyString get element at position") {

	const char ch[] = "abc";

	const size_t pos = 1;
	const size_t frontEl = 0;
	const size_t backEl = strlen(ch) - 1;
	
	SECTION("non-constant objects") {
		
		MyString mstr(ch);

		REQUIRE(mstr.at(pos) == ch[pos]);
		REQUIRE(mstr[pos] == ch[pos]);
		REQUIRE(mstr.front() == ch[frontEl]);
		REQUIRE(mstr.back() == ch[backEl]);
	}

	SECTION("constant objects") {
		
		const MyString mstr(ch);

		REQUIRE(mstr.at(pos) == ch[pos]);
		REQUIRE(mstr[pos] == ch[pos]);
		REQUIRE(mstr.front() == ch[frontEl]);
		REQUIRE(mstr.back() == ch[backEl]);
	}
}

TEST_CASE("MyString size-related") {
	
	const char ch[] = "abc";
	MyString mstr(ch);

	REQUIRE(mstr.empty() == false);

	MyString mstrEmpty;

	REQUIRE(mstrEmpty.empty() == true);
}

TEST_CASE("MyString clear") {
	
	const char ch[] = "abc";
	MyString mstr(ch);

	mstr.clear();
	REQUIRE(mstr.empty() == true);
}

TEST_CASE("MyString push and pop") {

	const char character = 'd';
	const char ch[] = "abc";
	MyString mstr(ch);
	MyString empty;

	SECTION("push back") {

		SECTION("non-empty MyString") {
			mstr.push_back(character);
			REQUIRE(mstr.back() == character);
		}

		SECTION("empty MyString") {
			empty.push_back(character);
			REQUIRE(empty.back() == character);
		}
	}

	SECTION("pop back") {
		SECTION("non-empty MyString") {
			mstr.pop_back();
			REQUIRE(mstr.back() != character);
		}

		SECTION("empty MyString") {
			//we do an assertion in the program
		}
	}
}

TEST_CASE("MyString operator+=") {
	
	const char ch[] = "abc";
	const char character = 'd';
	
	MyString mstr;

	SECTION("+=character") {
		mstr += ch;
		REQUIRE(strcmp(mstr.c_str(), ch) == 0);
	}

	SECTION("+=MyString") {
		mstr += character;
		REQUIRE(mstr.back() == character);
	}
}

TEST_CASE("MyString operator+") {

	const char ch[] = "abc";
	const char chArr[] = "d";
	const char character = 'd';

	MyString mstr;
	MyString mstr1(ch);
	MyString mstr2(chArr);
	
	MyString res;

	SECTION("Empty MyString + character") {
		res = mstr + character;
		REQUIRE(res == mstr2);
	}

	SECTION("Empty MyString + MyString") {
		res = mstr + mstr1;
		REQUIRE(res == mstr1);
	}

	SECTION("MyString + MyString") {
		res = mstr1 + mstr2;
		mstr1.push_back(character);
		REQUIRE(res == mstr1);
	}
}

TEST_CASE("MyString to string") {
	
	const char ch[] = "abc";
	MyString mstr(ch);


	REQUIRE(strcmp(mstr.c_str(), ch) == 0);
}


TEST_CASE("MyString operator==") {
	
	const char ch[] = "abc";
	MyString mstr(ch);
	MyString mstr2(ch);

	REQUIRE(mstr == mstr2);

	mstr.empty();
	mstr2.empty();

	REQUIRE(mstr == mstr2);
}

TEST_CASE("MyString operator<") {
	
	MyString mstr("abc");
	MyString mstr2("acb");
	MyString mstr3("abcc");

	REQUIRE(mstr < mstr2);
	REQUIRE(mstr < mstr3);
}
