#include "catch.hpp"
#include "../Homework-1/Vehicle.h"

TEST_CASE("Vehicle ctor") {
	SECTION("valid input") {
		Vehicle v("CA1526CA", "red car", 1);
		REQUIRE(strcmp(v.registration(), "CA1526CA") == 0);
		REQUIRE(strcmp(v.description(), "red car") == 0);
		REQUIRE(v.space() == 1);
	}
};