#include "Vehicle.h"

//Default ctor
Vehicle::Vehicle(const char* registration, const char* description, size_t space)
	:regNum(registration), descr(description) {

	parkingSpace = space;
}

Vehicle::~Vehicle() {}

//Returns the registration as a const char* array
const char* Vehicle::registration() const {
	return regNum.c_str();
}

//Returns the description as a const char* array
const char* Vehicle::description() const {
	return descr.c_str();
}

//Returns the space of the vehicle
size_t Vehicle::space() const {
	return parkingSpace;
}
