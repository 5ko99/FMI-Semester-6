#include "ParkingManager.h"
#include <iostream>

ParkingManager::ParkingManager(size_t capacity) {}
ParkingManager::~ParkingManager() {

	delete[] garage;
	
	for (size_t i = 0; i < sz; ++i)
		delete[] vehicles[i];

	delete[] vehicles;
}

void ParkingManager::insert(const char* registration, const char* description, size_t space) {
	
	if (sz >= capacity)
		resize();

	Vehicle* v = new Vehicle(registration, description, space);
	vehicles[sz] = v;
	++sz;

	garage->insert(*v);
}

void ParkingManager::erase(const char* registration) {

	garage->erase(registration);

	for (size_t i = 0; i < sz; ++i)
		if (vehicles[i]->registration() == registration) {
			delete[] vehicles[i];
			for (; i < sz - 1; ++i)
				vehicles[i] = vehicles[i + 1];
		}
}

const Vehicle& ParkingManager::at(size_t pos) const {
	return garage->at(pos);
}
const Vehicle& ParkingManager::operator[](size_t pos) const {
	//return garage->operator[pos];
}

bool ParkingManager::empty() const {
	return garage->empty();
}

size_t ParkingManager::size() const {
	return garage->size();
}

void ParkingManager::clear() {
	garage->clear();

	for (size_t i = 0; i < sz; ++i)
		delete[] vehicles[i];

	sz = 0;
}

const Vehicle* ParkingManager::find(const char* registration) const {
	return garage->find(registration);
}

void ParkingManager::print() const {

}