#ifndef __GARAGE__HEADER__
#define __GARAGE__HEADER__

#include "Vehicle.h"

class Garage {

public:
	Garage(size_t capacity);
	~Garage();

	void insert(Vehicle& v);
	void erase(const char* registration);
	const Vehicle& at(size_t pos) const;
	const Vehicle& operator[](size_t pos) const;
	bool empty() const;
	size_t size() const;
	void clear();
	const Vehicle* find(const char* registration) const;

private:
	bool canAddVehicle(Vehicle& v);

	size_t capacity;
	size_t spaceLeft;
	size_t vehicleCnt;
	Vehicle** vehicles;
};

#endif
