#include "Vehicle.h"
class VehicleAllocator {
   
public:
    VehicleAllocator();
    ~VehicleAllocator();

    Vehicle* allocate(const char* registration, const char* description, size_t space);

private:
    void resize();

    Vehicle** vehicles;
    size_t size;
    size_t capacity;
};
