#include "MyString.h"

#define _CRT_SECURE_NO_WARNINGS

#include <cassert>
#include <stdexcept>

//Creates an empty string with capacity 5
MyString::MyString()
	:len(0) {

	capacity = 5;
	string = new char[capacity];
	*string = '\0';
}

//Parameter ctor
MyString::MyString(const char* str) {

	len = strlen(str);
	capacity = len + 1;

	string = new char[capacity];
	strcpy(string, str);
}

MyString::~MyString() {
	delete[] string;
}

//Copy ctor
MyString::MyString(const MyString& other) {
	
	copy(*this, other);
}

//Operator= redefinition
MyString& MyString::operator=(const MyString& other) {
	
	if (this != &other) {
		
		delete[] string;
		copy(*this, other);
	}

	return *this;
}

//Returns element at "pos" position, throws out_of_range exception
char& MyString::at(size_t pos) {

	if (pos >= 0 && pos <= len)
		return string[pos];

	else
		throw std::out_of_range("out of range");
}

//For constant objects: Returns element at "pos" position, throws out_of_range exception
const char& MyString::at(size_t pos) const {
	if (pos >= 0 && pos <= len)
		return string[pos];

	else
		throw std::out_of_range("out of range");
}

//Returns element at "pos" position but doesn't check if pos is valid, only asserts
char& MyString::operator[](size_t pos) {
	assert(pos >= 0 && pos < len);
	return string[pos];
}

//For constant objects: Returns element at "pos" position but doesn't check if pos is valid, only asserts
const char& MyString::operator[](size_t pos) const {
	assert(pos >= 0 && pos < len);
	return string[pos];
}

//Returns first element
char& MyString::front() {
	assert(len > 0);
	return string[0];
}

//For constant objects: Returns first element
const char& MyString::front() const {
	assert(len > 0);
	return string[0];
}

//Returns last element
char& MyString::back() {
	assert(len > 0);
	return string[len - 1];
}

//For constant objects: Returns last elemtn
const char& MyString::back() const {
	assert(len > 0);
	return string[len - 1];
}

//Returns whether the string is empty
bool MyString::empty() const {
	if (len > 0)
		return false;

	return true;
}

//Returns the size of the string
size_t MyString::size() const {
	return len;
}

//Clears the array content
void MyString::clear() {

	delete[] string;
	string = new char[capacity];
	*string = '\0';

	len = 0;
}

//Adds symbol to end of array
void MyString::push_back(char c) {

	if (len + 1 >= capacity)
		resize();

	string[len] = c;
	string[len + 1] = '\0';
	len++;
}

//Removes last symbol from array
void MyString::pop_back() {

	assert(len > 0);
	string[len] = '\0';
	len--;
}

//Adds symbol to end of array
//Strong exception safety because if resize() 
//cant's allocate new memory, the obj won't change
MyString& MyString::operator+=(char c) {
	this->push_back(c);
	return *this;
}

//Concats rhs to string
MyString& MyString::operator+=(const MyString& rhs) {
	
	size_t rhsLen = rhs.size();

	for (size_t i = 0; i < rhsLen; ++i)
		this->push_back(rhs[i]);

	return *this;
}

//Returns new string that has this symbol at the end
MyString MyString::operator+(char c) const {

	MyString temp(string);
	temp += c;
	return temp;
}

//Concats rhs to a new string and returns it
MyString MyString::operator+(const MyString& rhs) const {

	MyString temp(string);
	temp += rhs;
	return temp;
}

//Returns a null-terminated char string that has the same content as the string
const char* MyString::c_str() const {
	
	return string;
}

//Checks if two strings are equal
bool MyString::operator==(const MyString& rhs) const {

	size_t rhsLen = rhs.size();

	if (rhsLen != len)
		return false;

	for (size_t i = 0; i < rhsLen; ++i)
		if (rhs[i] != string[i])
			return false;

	return true;
}

//Checks if current string is before rhs lexicographically
bool MyString::operator<(const MyString& rhs) const {
	return (strcmp(string, rhs.string) < 0);
}

//Makes a deep copy of src into dest
void MyString::copy(MyString& dest, const MyString& src) {
	
	dest.string = new char[src.capacity];
	strcpy(dest.string, src.string);

	dest.capacity = src.capacity;
	dest.len = src.len;
}

//Resizes string
void MyString::resize() {

	capacity *= 2;
	char* temp = new char[capacity];
	strcpy(temp, string);

	delete[] string;
	string = temp;
}
