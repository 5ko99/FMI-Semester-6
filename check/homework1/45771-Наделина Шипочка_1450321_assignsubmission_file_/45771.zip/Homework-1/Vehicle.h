#ifndef __VEHICLE__HEADER__
#define __VEHICLE__HEADER__

#include "MyString.h"

class Vehicle {

public:
	Vehicle(const char* registration, const char* description, size_t space);
	~Vehicle();

	const char* registration() const;
	const char* description() const;
	size_t space() const;

private:

	MyString regNum;
	MyString descr;
	size_t parkingSpace;
};

#endif