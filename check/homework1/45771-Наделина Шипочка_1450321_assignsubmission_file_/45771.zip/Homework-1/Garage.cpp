#include "Garage.h"

#define _CRT_SECURE_NO_WARNINGS

#include<cassert>
#include<stdexcept>
#include<iostream>

//Parameter ctor
Garage::Garage(size_t capacity)
	:capacity(capacity), spaceLeft(capacity), vehicleCnt(0) {
	vehicles = new Vehicle * [capacity];
}

//dtor
Garage::~Garage() {
	delete[] vehicles;
}

//Inserts this vehicle into the array of the garage, if insertion is impossible, throws an exception
void Garage::insert(Vehicle& v) {
	if (canAddVehicle(v)) {
		vehicles[vehicleCnt] = &v;
		vehicleCnt++;
		spaceLeft -= v.space();
	}

	else
		throw std::exception("insertion failed");
}

//Removes a vehicle with that registration from the garage
void Garage::erase(const char* registration) {
	
	for (size_t i = 0; i < vehicleCnt; ++i)
		if (strcmp(vehicles[i]->registration(), registration) == 0) {
			for(;i < vehicleCnt - 1; ++i)
			vehicles[i] = vehicles[i + 1];

			vehicleCnt--;
		}

}

//Returns the element at "pos" position, if the position is invalid, throws out_of_range exception
const Vehicle& Garage::at(size_t pos) const {
	if (pos < 0 || pos >= vehicleCnt)
		throw std::out_of_range("out of range");

	return *vehicles[pos];
}

//Returns the element at "pos" position, asserts if the position is invalid,
const Vehicle& Garage::operator[](size_t pos) const {
	assert(pos >= 0 && pos < vehicleCnt);
	return *vehicles[pos];
}

//Checks if there are vehicles in the garage
bool Garage::empty() const {
	return !vehicleCnt;
}

//Returns how many vehicles are in the garage
size_t Garage::size() const {
	return vehicleCnt;
}

//Clears the contents of the garage
void Garage::clear() {
	delete[] vehicles;
	vehicles = new Vehicle*[capacity];
	spaceLeft = capacity;
	vehicleCnt = 0;
}

//Returns a pointer to the vehicle with that registration, if it's not in the garage, returns nullptr
const Vehicle* Garage::find(const char* registration) const {
	for (size_t i = 0; i < vehicleCnt; ++i)
		if (strcmp(vehicles[i]->registration(), registration) == 0)
			return vehicles[i];
	
	return nullptr;
}

//Checks if vehicle can be added, i.e. if there is enough space and if the vehicle is already in the garage
bool Garage::canAddVehicle(Vehicle& v) {

	if (v.space() > spaceLeft)
		return false;

	for (size_t i = 0; i < vehicleCnt; ++i) {
		if (strcmp(v.registration(), vehicles[i]->registration()) == 0) {
			return false;
		}
	}

	return true;
}