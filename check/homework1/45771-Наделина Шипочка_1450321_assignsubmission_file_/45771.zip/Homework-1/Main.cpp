#include<iostream>
#include "Garage.h"
#include "VehicleAllocator.h"

void printGarage(const Garage& g) {

	size_t size = g.size();

	for (size_t i = 0; i < size; ++i) {
		std::cout << g[i].registration() << std::endl;
		std::cout << g[i].description() << std::endl;
		std::cout << g[i].space() << std::endl;
		std::cout << std::endl;
	}

	std::cout << "---" << std::endl;
}

int main() {

	VehicleAllocator va;

	Garage g(6);
	
	try {
		g.insert(*va.allocate("CA1234BA", "A white Lada Niva", 2));
		g.insert(*va.allocate("CA0000BB", "BB's jipka", 5));
	}
	catch (std::exception) {}

	printGarage(g);
	g.clear();

	try {
		g.insert(*va.allocate("CA1234BA", "A white Lada Niva", 2));
		g.insert(*va.allocate("CA4324BA", "VW Golf", 1));
		g.insert(*va.allocate("CA1234BA", "A black Lada Niva", 2));
	}
	catch (std::exception) {}

	printGarage(g);

	try {
		g.erase("CA4324BA");
	}
	catch (std::exception) {}

	printGarage(g);

	return 0;
}