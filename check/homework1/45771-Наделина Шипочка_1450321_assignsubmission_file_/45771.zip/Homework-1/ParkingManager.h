#ifndef __PARKING__MANAGER__HEADER__
#define __PARKING__MANAGER__HEADER__

#include "Vehicle.h"
#include "Garage.h"

class ParkingManager {
public:
	ParkingManager(size_t capacity);
	~ParkingManager();

	void insert(const char* registration, const char* description, size_t space);
	void erase(const char* registration);
	const Vehicle& at(size_t pos) const;
	const Vehicle& operator[](size_t pos) const;
	bool empty() const;
	size_t size() const;
	void clear();
	const Vehicle* find(const char* registration) const;

	void print() const;

private:
	void resize();

	Garage* garage;
	Vehicle** vehicles;
	size_t sz;
	size_t capacity;
};

#endif