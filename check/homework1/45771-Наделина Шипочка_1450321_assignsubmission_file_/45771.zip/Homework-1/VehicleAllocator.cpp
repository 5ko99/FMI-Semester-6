#include "VehicleAllocator.h"

//Default ctor, allocates a container with default capacity 5
VehicleAllocator::VehicleAllocator() {
	size = 0;
	capacity = 5;
	vehicles = new Vehicle* [capacity];
}

//Destructor
VehicleAllocator::~VehicleAllocator() {
	for (size_t i = 0; i < size; ++i)
		delete vehicles[i];

	delete[] vehicles;
}

//Creates new Vehicle* and stores it in the container
Vehicle* VehicleAllocator::allocate(const char* registration,
	const char* description, size_t space) {

	Vehicle* v = new Vehicle(registration, description, space);

	if (size >= capacity)
		resize();

	vehicles[size] = v;
	size++;
	return v;
}

//
//Private functions:
//

//Resizes Vehicle** vehicles container
void VehicleAllocator::resize() {
	capacity *= 2;

	Vehicle** tmp = new Vehicle*[capacity];

	for (size_t i = 0; i < size; ++i)
		tmp[i] = vehicles[i];

	delete[] vehicles;
	vehicles = tmp;
}