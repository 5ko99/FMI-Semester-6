#include <iostream>
#include <cassert>
#include <cstring>

template <typename T>
class MyString
{
private:
	T* myArray;
	unsigned m_size;
	unsigned m_capacity;

	unsigned counter = 0;
public:
	MyString();
	MyString(const char* str);
	MyString(const MyString<T>& other);
	MyString<T>& operator=(const MyString<T>& other);
	~MyString();
	void resize(bool);
	void print();
	char& at(size_t pos);
	char& operator[](size_t pos);
	char& front();
	char& front() const;
	char& back();
	bool empty() const;
	size_t size() const;
	void clear();
	void push_back(char c);
	void pop_back();

	MyString operator+(const MyString& rhs) {
		MyString<char> myWord;

		myWord.m_size = m_size + rhs.m_size;
		myWord.myArray = new char[myWord.m_size + 1];

		strcpy_s(myWord.myArray, myWord.m_size, myArray);
		strcat_s(myWord.myArray, myWord.m_size + 1, rhs.myArray);

		return myWord;
	}

	MyString& operator+=(const MyString& rhs) {
		*this = *this + rhs;
		return *this;
	}

	MyString(const char character) {
		m_size = 1;
		m_capacity = 2;

		myArray = new char[2];
		*myArray = character;
		*(myArray + 1) = '\0';
	}

	MyString& operator+=(char c) {
		*this = *this + MyString(c);
		return *this;
	}

	bool operator==(const MyString& rhs) const {
		return strcmp(myArray, rhs.myArray) == 0;
	}

	bool operator<(const MyString str) const {
		return strcmp(myArray, str.myArray) < 0;
	}
};

template <typename T>
MyString<T>::MyString() {
	unsigned int otherCapacity = 1;
	myArray = new T[otherCapacity];
	myArray[0] = '\0';
	assert(myArray);
	m_size = 1;
	m_capacity = otherCapacity;
}

template <typename T>
MyString<T>::MyString(const char* str) {
	unsigned dynamicArrayCapacity = 10;
	myArray = new T[dynamicArrayCapacity];
	m_capacity = dynamicArrayCapacity;
	m_size = strlen(str);

	if (m_capacity <= strlen(str)) {
		resize(1);
	}

	strcpy_s(myArray, strlen(str) + 1, str);
}

template <typename T>
MyString<T>::MyString(const MyString<T>& other) {
	myArray = new T[other.m_size * 2];
	assert(myArray);
	m_capacity = other.m_capacity;

	strcpy_s(myArray, other.m_size * 2, other.myArray);

	m_size = other.m_size;
}

template <typename T>
MyString<T>& MyString<T>::operator=(const MyString<T>& other) {
	if (this != &other) {

		if (myArray) {
			delete[] this->myArray;
			myArray = nullptr;
			m_capacity = 0;
			m_size = 0;
		}

		this->myArray = new T[other.m_size * 2];
		assert(myArray);

		strcpy_s(myArray, other.m_size * 2, other.myArray);

		m_capacity = other.m_capacity;
		m_size = other.m_size;
	}
	return *this;
}

template <typename T>
void MyString<T>::resize(bool flag) {
	T* otherArray;
	otherArray = new T[m_capacity * 2];
	assert(otherArray);

	for (unsigned i = 0; i < m_size + counter; i++) {
		otherArray[i] = myArray[i];
	}

	delete[] myArray;
	myArray = otherArray;

	m_capacity *= 2;

}

template <typename T>
void MyString<T>::print() {
	for (unsigned i = 0; i < m_size + counter; i++) {
		std::cout << myArray[i];
	}
}

template <typename T>
MyString<T>::~MyString() {
	delete[] myArray;
}

template <typename T>
char& MyString<T>::at(size_t pos) {
	bool flag = true;
	for (unsigned i = 0; i < strlen(this->myArray) + counter; i++) {
		if (pos == i) {
			return myArray[i];
			flag = false;
		}
	}
	try {
		if (flag) {
			throw std::out_of_range("Out of range");
		}
	}
	catch (const std::out_of_range& e) {
		std::cout << e.what();
	}
	return myArray[strlen(this->myArray) + counter + 1];
}

template <typename T>
char& MyString<T>::operator[](size_t pos) {
	if (m_capacity == pos) {
		resize(1);
	}
	++counter;
	return myArray[pos];
}

template <typename T>
char& MyString<T>::front() {
	return myArray[0];
}

template <typename T>
char& MyString<T>::front() const {
	return myArray[0];
}

template <typename T>
char& MyString<T>::back() {
	unsigned length = m_size + counter;
	return myArray[length - 1];
}

template <typename T>
bool MyString<T>::empty() const {
	if (!strlen(myArray)) {
		return true;
	}
	return false;
}

template <typename T>
size_t MyString<T>::size() const {
	std::size_t length = m_size + counter;
	return length;
}

template <typename T>
void MyString<T>::clear() {
	size_t length = m_size + counter;

	for (unsigned i = 0; i < length; i++) {
		myArray[i] = NULL;
	}
	m_size = 0;
	counter = 0;
}

template <typename T>
void MyString<T>::push_back(char c) {
	size_t length = m_size + counter;
	myArray[length] = c;
	counter++;
}

template <typename T>
void MyString<T>::pop_back() {
	counter--;
	size_t length = m_size + counter;

	T* oldArray = myArray;
	myArray = new T[length *= 2];

	for (size_t i = 0; i < length--; i++) {
		myArray[i] = oldArray[i];
	}

	delete[] oldArray;
}