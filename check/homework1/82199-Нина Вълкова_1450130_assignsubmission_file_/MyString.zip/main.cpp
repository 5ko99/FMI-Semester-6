#include <iostream>
#include <cassert>
#include <cstring>
#include <iomanip>
#include "MyString.cpp"

int main() {
	MyString<char> myString("Hello");
	MyString<char> mySecoundString("");

	myString.print();

	myString[5] = ' ';
	myString[6] = 'W';
	myString[7] = 'o';
	myString[8] = 'r';
	myString[9] = 'l';
	myString[10] = 'd';
	myString[11] = '!';


	std::cout << myString.at(5);
	std::cout << myString.at(6);
	std::cout << myString.at(7);
	std::cout << myString.at(8);
	std::cout << myString.at(9);
	std::cout << myString.at(10);
	std::cout << myString.at(11);

	std::cout << std::endl;

	std::cout << myString.front();

	std::cout << std::endl;

	std::cout << myString.back();

	std::cout << std::endl;

	std::cout << std::boolalpha << myString.empty() << std::endl;
	std::cout << std::boolalpha << mySecoundString.empty();

	std::cout << std::endl;

	std::cout << myString.size();

	std::cout << std::endl;

	//myString.clear();

	std::cout << std::endl;

	myString.print();

	std::cout << std::endl;

	myString.push_back('c');
	myString.print();

	std::cout << std::endl;

	myString.pop_back();
	myString.print();

	std::cout << std::endl;

	MyString<char> firstWord("abcef");
	MyString<char> secoundWord("abcde");

	firstWord.print();
	std::cout << std::endl;
	secoundWord.print();

	MyString<char> newWord;

	std::cout << std::endl;

	newWord = firstWord + secoundWord;
	newWord.print();

	std::cout << std::endl;

	newWord += newWord;
	newWord.print();

	std::cout << std::endl;

	newWord += '!';
	newWord.print();

	std::cout << std::endl;

	if (firstWord == secoundWord) {
		std::cout << "Words are same";
	}
	else {
		std::cout << "Words are not same";
	}

	std::cout << std::endl;

	if (firstWord < secoundWord) {
		std::cout << "True";
	}
	else {
		std::cout << "False";
	}

	std::cout << std::endl;


	return 0;
}