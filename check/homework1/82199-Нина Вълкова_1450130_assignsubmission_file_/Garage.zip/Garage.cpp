#include "Garage.h"
#include <iostream>
#include <cstring>
#include <cassert>

Garage::Garage(size_t size) {
	this->m_size = size;
	vehicles = new Vehicle[size];
}

void Garage::insert(Vehicle& v) {

	capacity += v.getSpace();

	if (m_size > capacity) {
		vehicles[counter] = v;
		counter++;
	}
}


Vehicle* Garage::find(const char* registration) const {
	for (unsigned i = 0; i < counter; i++) {
		if (strcmp(registration, vehicles[i].getRegistration()) == 0) {
			return vehicles + i;
		}
	}
	return nullptr;
}

void  Garage::erase(const char* registration) {
	auto getVehicle = find(registration);

	if (getVehicle != nullptr) {
		for (auto i = getVehicle + 1; i != vehicles + counter; i++) {
			*(i - 1) = *i;
		}
		counter--;
	}
}

const Vehicle& Garage::at(size_t pos) const {
	bool flag = true;
	for (unsigned i = 0; i < counter; i++) {
		if (pos == i) {
			flag = false;
			return vehicles[i];
		}
	}
	try {
		if (flag) {
			throw std::out_of_range("Out of range");
		}
	}
	catch (const std::out_of_range& e) {
		std::cout << e.what();
	}
}

const Vehicle& Garage::operator[](std::size_t pos) const {
	vehicles[pos].print();
	return vehicles[pos];
}

void Garage::show() {
	for (unsigned i = 0; i < counter; i++) {
		vehicles[i].print();
	}
}

bool  Garage::empty() const {
	if (counter == 0) {
		return true;
	}
	return false;
}

size_t Garage::size() const {
	return counter;
}

void  Garage::clear() {

	Vehicle* oldArray = new Vehicle[this->m_size];
	for (unsigned i = 0; i < m_size; i++) {
		vehicles[i] = oldArray[i];
	}
	delete[] oldArray;

	counter = 0;
	capacity = 0;
}