#pragma once
#include "Vehicle.h"

class Garage
{
private:
	size_t m_size;
	Vehicle* vehicles;
	unsigned counter = 0;
	unsigned capacity = 0;
public:
	Garage(size_t size);
	void insert(Vehicle& v);
	void erase(const char* registration);
	const Vehicle& at(size_t pos) const;
	const Vehicle& operator[](size_t pos) const;
	bool empty() const;
	size_t size() const;
	void clear();
	Vehicle* find(const char*) const;

	void show();
};

