#include "Vehicle.h"
#include <cstring>
#include <iostream>

Vehicle::Vehicle(const char* registration, const char* description, size_t space) {
	setRegistration(registration);
	setDescription(description);
	setSpace(space);
}

void Vehicle::setRegistration(const char* registration) {
	m_registrationNumber = new char[strlen(registration) + 1];
	strcpy_s(m_registrationNumber, strlen(registration) + 1, registration);
}

void Vehicle::setDescription(const char* description) {
	m_description = new char[strlen(description) + 1];
	strcpy_s(m_description, strlen(description) + 1, description);
}

void Vehicle::setSpace(size_t space) {
	m_parkingPlaces = space;
}

const char* Vehicle::getRegistration() {
	return m_registrationNumber;
}

const char* Vehicle::getDescription() {
	return m_description;
}

size_t Vehicle::getSpace() {
	return m_parkingPlaces;
}

Vehicle::Vehicle(const Vehicle& another) {
	setRegistration(another.m_registrationNumber);
	setDescription(another.m_description);
	setSpace(another.m_parkingPlaces);
}

Vehicle& Vehicle::operator = (const Vehicle& another) {
	if (this != &another) {
		if (this->m_registrationNumber) {
			delete[] m_registrationNumber;
		}
		if (this->m_description) {
			delete[]  m_description;
		}
		setRegistration(another.m_registrationNumber);
		setDescription(another.m_description);
		setSpace(another.m_parkingPlaces);
	}
	return *this;
}


void Vehicle::print() {
	std::cout << m_registrationNumber << '\t' << m_description << '\t' << m_parkingPlaces << std::endl;
}

Vehicle::~Vehicle() {
	delete[] m_registrationNumber;
	delete[] m_description;
}