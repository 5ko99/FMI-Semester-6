#include <iostream>
#include <iostream>
#include <iomanip>
#include "Garage.h"

int main() {

	Vehicle myFirstVehicle("7777", "motorbike", 1);
	Vehicle mySecoundVehicle("8888", "motorbike", 1);
	Vehicle myThirdVehicle("9999", "motorbike", 1);
	Vehicle myForthVehicle("1111", "car", 2);
	Vehicle myFifthVehicle("3333", "car", 3);

	myFirstVehicle.print();
	mySecoundVehicle.print();
	myThirdVehicle.print();
	myForthVehicle.print();
	myFifthVehicle.print();

	std::cout << std::endl;

	Garage myGarage(6);

	myGarage.insert(myFirstVehicle);
	myGarage.insert(mySecoundVehicle);
	myGarage.insert(myThirdVehicle);
	myGarage.insert(myForthVehicle);
	myGarage.insert(myFifthVehicle);
	myGarage.show();

	std::cout << std::endl;

	myGarage.erase("1111");
	myGarage.show();

	std::cout << std::endl;

	myGarage.erase("8888");
	myGarage.show();

	std::cout << std::endl;

	myGarage.at(2);

	std::cout << std::endl;
	myGarage[0];
	myGarage[1];
	myGarage[2];
	myGarage[3];
	std::cout << std::endl;

	std::cout << myGarage.size();

	std::cout << std::endl;

	std::cout << std::boolalpha << myGarage.empty();

	std::cout << std::endl;

	myGarage.show();

	std::cout << std::endl;

	myGarage.clear();

	std::cout << std::endl;

	myGarage.show();

	std::cout << std::endl;

	std::cout << std::boolalpha << myGarage.empty();

	std::cout << std::endl;

	myGarage.insert(mySecoundVehicle);
	myGarage.insert(myFifthVehicle);

	std::cout << std::endl;

	myGarage.show();


	return 0;
}