#pragma once
class Vehicle
{
private:
	char* m_registrationNumber;
	char* m_description;
	size_t m_parkingPlaces;

public:
	Vehicle() :m_parkingPlaces(0) {
		m_registrationNumber = new char[1];
		m_registrationNumber[0] = '\0';

		m_description = new char[1];
		m_description[0] = '\0';
	}

	Vehicle(const char* registration, const char* description, size_t space);
	Vehicle(const Vehicle& another);
	Vehicle& operator = (const Vehicle& another);
	~Vehicle();

	void setRegistration(const char*);
	void setDescription(const char*);
	void setSpace(size_t);

	const char* getRegistration();
	const char* getDescription();
	size_t getSpace();

	void print();
};

