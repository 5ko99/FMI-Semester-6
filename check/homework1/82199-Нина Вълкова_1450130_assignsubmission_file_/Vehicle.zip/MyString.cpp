#include <cstring>

class MyString
{
private:
	char* text;
public:
	MyString() {
		text = new char[1];
		text[0] = '\0';
	}
	MyString(const char* str) {
		text = new char[strlen(str) + 1];
		strcpy_s(text, strlen(str) + 1, str);
	}
	MyString(const MyString& another) {
		text = new char[strlen(another.text) + 1];
		strcpy_s(text, strlen(another.text) + 1, another.text);
	}

	MyString& operator=(const MyString& another) {
		if (this != &another) {
			if (this->text) {
				delete[] text;
			}
			text = new char[strlen(another.text) + 1];
			strcpy_s(text, strlen(another.text) + 1, another.text);
		}
		return *this;
	}

	const char* getText() const {
		return text;
	}

	~MyString() {
		delete[] text;
	}
};
