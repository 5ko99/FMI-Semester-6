#include <iostream>
#include <cstring>
#include <algorithm>
#include "Vehicle.h"

Vehicle::Vehicle(const char* registration = "", const char* description = "", size_t space = 0) :m_registrationNumber(registration), m_description(description), m_parkingPlaces(space) {
	/*setRegistration(registration);
	setDescription(description);
	setSpace(space);*/
}

//void Vehicle::setRegistration(const char* registration) {
//	m_registrationNumber = registration;
//}
//void Vehicle::setDescription(const char* description) {
//	m_description = description;
//}
//void Vehicle::setSpace(size_t space) {
//	m_parkingPlaces = space;
//}

const char* Vehicle::registration() const {
	return m_registrationNumber.getText();
}

const char* Vehicle::description() const {
	return m_description.getText();

	return 0;
}

size_t  Vehicle::space() const {
	return m_parkingPlaces;
}