#include <iostream>
#include "Vehicle.h"



int main()
{
	Vehicle vehicle("7777", "motorbike", 1);



	std::cout << vehicle.registration() << "\t";
	std::cout << vehicle.description() << "\t";
	std::cout << vehicle.space();

	return 0;
}