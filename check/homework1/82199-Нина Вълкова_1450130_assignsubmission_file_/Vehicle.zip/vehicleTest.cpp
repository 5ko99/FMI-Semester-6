#include "Vehicle.h"
#define CATCH_CONFIG_MAIN 
#include "catch.hpp"

TEST_CASE("vehicle information") {

	Vehicle vehicle("7777", "motorbike", 1);

	CHECK(strcmp(vehicle.registration(), "7777") == 0);
	CHECK(strcmp(vehicle.description(), "motorbike") == 0);
	REQUIRE(vehicle.space() == 1);
}