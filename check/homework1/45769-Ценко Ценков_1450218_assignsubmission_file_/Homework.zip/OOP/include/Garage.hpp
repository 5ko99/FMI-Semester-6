#ifndef GARAGE_HPP
#define GARAGE_HPP

#include "Vehicle.hpp"

namespace V
{
    class Garage
    {
    private:
        size_t capacity;
        B::Vehicle** vehicles;
    public:
        Garage(std::size_t size);
        Garage& operator=(const Garage& str);
        void insert(B::Vehicle& v);
        void erase(const char* registration);
        const B::Vehicle& at(std::size_t pos) const;
        const B::Vehicle& operator[](std::size_t pos) const;
        bool empty() const;
        std::size_t size() const;
        void clear();
        const B::Vehicle* find(const char* registration) const;
        ~Garage();
    };

}

#endif //GARAGE_HPP