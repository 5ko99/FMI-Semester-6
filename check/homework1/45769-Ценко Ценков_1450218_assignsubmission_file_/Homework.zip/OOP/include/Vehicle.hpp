#ifndef VEHICLE_HPP
#define VEHICLE_HPP

#include "MyString.hpp"

namespace B
{
    class Vehicle
    {
    private:
        A::MyString regNum;
        A::MyString desc;
        size_t  parkCapacity;

    public:
        Vehicle(const char* registration, const char* description, std::size_t space);
        const char* registration() const;
        const char* description() const;
        std::size_t space() const;
    };
}

#endif //VEHICLE_HPP