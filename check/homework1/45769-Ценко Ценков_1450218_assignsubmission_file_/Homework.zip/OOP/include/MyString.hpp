#ifndef MYSTRING_HPP
#define MYSTRING_HPP

#include <stdlib.h>
#include <iostream>
#include <cstring>
#include <algorithm>
#include <stdexcept>

namespace A
{
    class MyString
    {
    private:
        char *string;
        size_t sz;
        size_t top;

    public:
        MyString();
        explicit MyString(const char *str);
        MyString(const MyString& str);
        MyString(MyString&& str);

        MyString& operator=(const MyString& str);
        MyString& operator=(MyString&& str);
        char& at(std::size_t pos);
        char& operator[](std::size_t pos);
        const char& operator[](std::size_t pos) const;
        char& front();
        const char& front() const;
        char& back();
        const char& back() const;
        bool empty() const;
        std::size_t size() const;
        void clear();
        void push_back(char c);
        void pop_back();
        MyString& operator+=(char c);
        MyString& operator+=(const MyString& rhs);
        MyString operator+(char c) const;
        MyString operator+(const MyString& rhs) const;
        const char* c_str() const;
        bool operator==(const MyString &rhs) const;
        bool operator<(const MyString &rhs) const;

        ~MyString();
    };
}

#endif /* MYSTRING_HPP */