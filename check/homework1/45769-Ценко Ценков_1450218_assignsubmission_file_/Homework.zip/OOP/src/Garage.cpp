#include "Garage.hpp"

using namespace V;

Garage::Garage(size_t size) : vehicles{new B::Vehicle*[size]}, capacity{size}
{

}

Garage::~Garage()
{
    delete[] vehicles;
}

