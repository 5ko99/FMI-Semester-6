#include "MyString.hpp"

using namespace A;

MyString::MyString()
    : string{new char[1]}, sz{0}, top{0}
{
    string[0] = '\0';
}

MyString::MyString(const char *str)
{
    sz = strlen(str) + 1;
    top = sz - 1;
    string = new char[sz];

    if (string)
        strcpy_s(string, sz, str);
}

MyString::MyString(const MyString &str)
    : sz{str.sz}, top{str.top}, string{new char[str.sz]}
{
    std::copy(str.string, str.string + str.sz, string);
}

MyString::MyString(MyString &&str)
    : sz{str.sz}, top{str.top}, string{str.string}
{
    str.sz = 0;
    str.top = 0;
    str.string = nullptr;
}

MyString &MyString::operator=(const MyString &str)
{
    char *newStr = new char[str.sz];
    std::copy(str.string, str.string + str.sz, newStr);
    delete[] string;
    string = newStr;
    sz = str.sz;
    top = str.top;
    return *this;
}

MyString &MyString::operator=(MyString &&str)
{
    delete[] string;
    string = str.string;
    sz = str.sz;
    str.string = nullptr;
    str.sz = 0;
    str.top = 0;
    return *this;
}

char& MyString::at(std::size_t pos)
{
    if (pos < sz)
      return string[pos];
    throw std::out_of_range("Inxed out of range");
}

const char& MyString::operator[](std::size_t pos) const
{
    return string[pos];
}

char& MyString::operator[](std::size_t pos)
{
    return string[pos];
}

char& MyString::front()
{
    return string[0];
}

const char& MyString::front() const
{
    return string[0];
}

char& MyString::back()
{
    return string[top-1];
}

const char& MyString::back() const
{
    return string[top-1];
}

bool MyString::empty() const
{
    return top > 0;
}

size_t MyString::size() const
{
    return top;
}

void MyString::clear()
{
    string[0] = '\0';
    top = 0;
}

void MyString::push_back(char c)
{
    if(top == sz) {
        throw "The string is filled";
    }
    string[top++] = c;
    string[top] = '\0';
}

void MyString::pop_back()
{
    string[--top] = '\0';
}

MyString& MyString::operator+=(char c)
{
    this->push_back(c);
    return *this;
}

MyString& MyString::operator+=(const MyString &rhs)
{
    for (int i = 0; i < rhs.top; i++)
    {
        this->push_back(rhs[i]);
    }
    return *this;
}

MyString MyString::operator+(char c) const
{
    char* newStr = new char[sz + 1];
    strcpy(newStr, string);
    newStr[sz-1] = c;
    newStr[sz] = '\0';
    return MyString(newStr);
}

MyString MyString::operator+(const MyString& rhs) const
{
    char* newStr = new char[sz + rhs.sz - 1];
    strcpy(newStr, string);
    strcat(newStr, rhs.string);
    return MyString(newStr);
}

const char* MyString::c_str() const
{
    return string;
}

bool MyString::operator==(const MyString &rhs) const
{
    return strcmp(string, rhs.string) == 0 ? true : false;
}

bool MyString::operator<(const MyString &rhs) const
{
    return strcmp(string, rhs.string) > 0 ? true : false;
}

MyString::~MyString()
{
    delete[] string;
}