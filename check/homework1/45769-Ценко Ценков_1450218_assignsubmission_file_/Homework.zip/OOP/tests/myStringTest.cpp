#define CATCH_CONFIG_MAIN
#include <catch2/catch.hpp>
#include "../include/MyString.hpp"

TEST_CASE("DefaultConstructorTest", "[MyString]")
{
    A::MyString myStr;

    REQUIRE(!strcmp(myStr.c_str(), ""));

    myStr.clear();
    REQUIRE(myStr.size() == 0);

    REQUIRE(myStr.front() == '\0');
}

TEST_CASE("ConstructorStringParamTest", "[MyString2]")
{
    A::MyString myStr("Test string");

    REQUIRE(!strcmp(myStr.c_str(), "Test string"));
    REQUIRE(myStr.front() == 'T');
    REQUIRE(myStr.size() == 11);
    REQUIRE(myStr.back() == 'g');
}

TEST_CASE("CopyConstructorTest", "[MyString3]")
{
    A::MyString myStr("Test string");
    A::MyString myStr2(myStr);

    REQUIRE(!strcmp(myStr.c_str(), myStr2.c_str()));
    REQUIRE(myStr.c_str() != myStr2.c_str());

    myStr2.clear();
    REQUIRE(strcmp(myStr.c_str(), myStr2.c_str()));
}

TEST_CASE("AccumulationTest", "[MyString4]")
{
    A::MyString myStr("Test string");
    myStr.clear();
    myStr.push_back('V');
    REQUIRE(myStr.front() == 'V');
    REQUIRE(myStr.front() == myStr.back());

    REQUIRE(myStr + A::MyString("One more ") == A::MyString("VOne more "));   
}