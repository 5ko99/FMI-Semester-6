#include "Garage.h"

int main()
{
	size_t cmd;
	size_t size_of_garage;

	std::cout << "Choose the size of your garage:\n";
	std::cin >> size_of_garage;


		Garage custom_garage(size_of_garage);

		std::cout << "Your garage is created!\n" << "Choose a command:\n" << "To create a vehicle - press 1 and enter\n" << "To insert your vehicles in the garage - press 2 and enter\n";
		std::cout << "To remove a vehicle from the garage - press 3 and enter\n" << "To print the content of your garage - press 4 and enter\n" << "To exit the program - press 0 and enter\n";

		Vehicle** vehicles = new Vehicle * [size_of_garage];
		size_t vehicle_counter = 0;
		size_t vehicles_in_garage = 0;
	do {
		std::cin >> cmd;

		if (cmd == 1) { //create vehicle
			std::cout << "=======================================================================" << std::endl << std::endl;
			char licence[200];
			char model[200];
			size_t parking_space;
			std::cout << "What's the registration of your vehicle?:\n";
			std::cin >> licence;
			std::cout << "What's the description of your vehicle?:\n";
			std::cin >> model;
			std::cout << "How much parking space does your vehicle occupy?:\n";
			std::cin >> parking_space;
			
			Vehicle* v = new Vehicle(licence, model, parking_space);
			
			
			vehicles[vehicle_counter] = v;
			vehicle_counter += 1;

			std::cout << "Vehicle created!\n" << "Choose a new command:\n";

		}
		else if (cmd == 2) { // insert vehicle in garage
			std::cout << "=======================================================================" << std::endl << std::endl;
			for (size_t i = vehicles_in_garage; i < vehicle_counter; i++) {
				custom_garage.insert(*vehicles[i]);
				vehicles_in_garage += 1;
				
			}
			std::cout << "Your vehicles are in the garage!\n" << "Choose a new command:\n";
			
		}
		else if (cmd == 3) { // remove vehicle from garage
			std::cout << "=======================================================================" << std::endl << std::endl;
			char licence_to_remove[200];
			std::cout << "What is the registration of the vehicle you want to remove?:\n";
			std::cin >> licence_to_remove;
			custom_garage.erase(licence_to_remove);
			bool cant_find = false;

			if (vehicle_counter == 0) {
				std::cout << "Cannot remove the given vehicle, because the garage is already empty! Try another command:\n";
				continue;
			}

			for (size_t i = 0; i < vehicle_counter; i++) {
				if (strcmp(vehicles[i]->registration(), licence_to_remove) == 0) {
					if (i == vehicle_counter - 1) {
						vehicles[i] = nullptr;
						vehicle_counter -= 1;
					}
					else {
						vehicles[i] = nullptr;
						vehicles[i] = vehicles[vehicle_counter - 1];
						vehicles[vehicle_counter - 1] = nullptr;
						vehicle_counter -= 1;
					}
				}
				else if (i == vehicle_counter - 1) {
					std::cout << "Couldn't find the vehicle with the given registration. Try again?:\n";
					cant_find = true;
					break;
				}
			}
			if (cant_find == true) {
				continue;
			}

			std::cout << "Vehicle removed!\n" << "Choose a new command:\n";
			
		}
		else if (cmd == 4) { // print garage
			std::cout << "=======================================================================" << std::endl << std::endl;
			if (custom_garage.empty() == 1) {
				std::cout << "There are no vehicles in your garage!\n";
				
			}
			else {
				for (size_t i = 0; i < vehicle_counter; i++) {
					
					std::cout << "Vehicle #" << i + 1 << std::endl;
					std::cout << "Registration - " << vehicles[i]->registration() << std::endl;;
					std::cout << "Description - " << vehicles[i]->description() << std::endl;
					std::cout << "Space - " << vehicles[i]->space() << std::endl << std::endl;
				}
			}
			std::cout << "Choose a new command:\n";
		}
		else if (cmd < 0 || cmd > 4) {
			std :: cout << "Invalid command! Try again:\n";
		}

	} while(cmd != 0);





	delete[] vehicles;


}

