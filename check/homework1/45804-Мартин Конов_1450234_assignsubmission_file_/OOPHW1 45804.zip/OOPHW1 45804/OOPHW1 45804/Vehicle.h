#pragma once
#include "MyString.h";
#include <iostream>;

class Vehicle {
private:
	MyString licence_plate;
	MyString model;
	size_t parking_space;
public:
	Vehicle(const char* registration, const char* description, std::size_t space);
	const char* registration() const;
	const char* description() const;
	size_t space() const;
};