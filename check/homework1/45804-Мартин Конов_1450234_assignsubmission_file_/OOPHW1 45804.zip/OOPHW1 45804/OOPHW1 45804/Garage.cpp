#include"Garage.h"

Garage::Garage() {
	this->capacity = 0;
	this->vehicle_count = 0;
	this->cars_in_garage = nullptr;
}

Garage :: Garage(size_t size) {
	this->capacity = size;
	this->vehicle_count = 0;
	this->cars_in_garage = new Vehicle*[capacity];
	for (size_t i = 0; i < this->capacity; i++) {
		this->cars_in_garage[i] = nullptr;
	}

}

Garage :: ~Garage() {
	delete[] cars_in_garage;
	this->capacity = 0;
	this->vehicle_count = 0;
}

Garage::Garage(const Garage& old_garage) {
	this->capacity = old_garage.capacity;
	this->vehicle_count = old_garage.vehicle_count;
	for (int i = 0; i < this->vehicle_count; i++) {
		this->cars_in_garage[i] = old_garage.cars_in_garage[i];
	}
}

bool Garage :: reg_check(const char* reg) {
	for (size_t i = 0; i < this->vehicle_count; i++) {
		if (strcmp(this->cars_in_garage[i]->registration(), reg) == 0) {
			return false;//The car is in the garage
		}
	}
	return true;//The car is not in the garage
}

void Garage::insert(Vehicle& v) {
	if (reg_check(v.registration()) &&  this->capacity >= v.space()) {
		this->capacity -= v.space();
		this->cars_in_garage[vehicle_count] = &v;
		vehicle_count += 1;
	}
	else {
		throw std::out_of_range("Not enough space!/ The car is already in the garage!");
	}
}

void Garage::erase(const char* registration) {
	if (reg_check(registration) != 0) {
		return;
	}
	else {
		for (size_t i = 0; i < this->vehicle_count; i++) {
			if (strcmp(this->cars_in_garage[i]->registration(), registration) == 0) {

				if (i == vehicle_count - 1) {
					this->capacity += cars_in_garage[i]->space();
					this->cars_in_garage[i] = nullptr;
					this->vehicle_count -= 1;
				}
				else {
					//Vehicle last_vehic_cpy(*this->cars_in_garage[i]);
					this->capacity += cars_in_garage[i]->space();
					this->cars_in_garage[i] = nullptr;
					this->cars_in_garage[i] = this->cars_in_garage[vehicle_count - 1];
					this->cars_in_garage[vehicle_count - 1] = nullptr;
					this->vehicle_count -= 1;
				}


			
				return;
			}
		}
	}

}

const Vehicle& Garage::at(std::size_t pos) const {
	if (this->cars_in_garage[pos] != nullptr) {
		return *cars_in_garage[pos];
	}
	else {
		throw std::out_of_range("out of range");
	}
}

const Vehicle& Garage::operator[](std::size_t pos) const {
	return *cars_in_garage[pos];
}

bool Garage::empty() const {
	if (vehicle_count == 0) {
		return true; // if the garage is empty
	}
	else {
		return false; // if the garage isnt empty
	}
}


size_t Garage::size() const {
	return vehicle_count;
}

void Garage::clear() {
	size_t vehicles = this->vehicle_count;
	for (int i = 0; i < vehicles; i++) {
		this->capacity += this->cars_in_garage[i]->space();
		vehicle_count -= 1;
		this->cars_in_garage[i] = nullptr;
	}
}

const Vehicle* Garage::find(const char* registration) const{
	
	for (size_t i = 0; i < vehicle_count; i++) {
		if (strcmp(this->cars_in_garage[i]->registration(), registration) == 0) {
			return this->cars_in_garage[i];
		}
	}
	return nullptr;
	
}