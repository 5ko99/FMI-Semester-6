#define CATCH_CONFIG_MAIN 
#include"Catch.h"
#include "Garage.h"


//=========================================================================================================================================================
//MyString tests:


TEST_CASE("Testing MyString(const char* str)", "[MyString(const char* str)]") {
	MyString a("CoPi3d");
	REQUIRE(strcmp(a.c_str(), "CoPi3d") == 0);
	REQUIRE(a.size() == 6);
}

TEST_CASE("Test copy constructor", "[MyString(const MyString &str)]") {
	MyString old_string("Old_String");
	
	MyString new_string(old_string);

	REQUIRE(strcmp(new_string.c_str(), "Old_String") == 0);
	REQUIRE(new_string.size() == 10);
}

TEST_CASE("Test operator []", "[char& operator[](size_t pos)]") {
	MyString test_string("reTurn");
	REQUIRE(test_string[2] == 'T');
}

TEST_CASE("Test at func", "[char& at(size_t pos)]") {
	MyString test_string("reTurn");
	REQUIRE(test_string.at(2) == 'T');
	CHECK_THROWS(test_string.at(-2));
	CHECK_THROWS(test_string.at(10));
}

TEST_CASE("Test front func", "[char& front()]") {
	MyString test_string("Return");
	REQUIRE(test_string.front() == 'R');
}

TEST_CASE("Test back func", "[char& back()]") {
	MyString test_string("returN");
	REQUIRE(test_string.back() == 'N');
}

TEST_CASE("Test empty func", "[bool empty() const]") {
	MyString test_string("Not_an_empty_string");
	MyString test_empty_string("");
	MyString scnd_empty_string;
	REQUIRE(test_string.empty() == 0);
	REQUIRE(test_empty_string.empty() == 1);
	REQUIRE(scnd_empty_string.empty() == 1);
}

TEST_CASE("Test size func", "[size_t size() const]") {
	MyString test_string("this_string_is_28_chars_long");
	REQUIRE(test_string.size() == 28);
}

TEST_CASE("Test clear func", "[void clear()]") {
	MyString test_string("clear_this");
	test_string.clear();
	REQUIRE(test_string.empty() == 1);
}

TEST_CASE("Test push_back func", "[void push_back(char c)]") {
	MyString test_string("retur");
	test_string.push_back('N');
	REQUIRE(strcmp(test_string.c_str(), "returN") == 0);
}

TEST_CASE("Test pop_back func", "[void pop_back()]") {
	MyString test_string("returnN");
	test_string.pop_back();
	REQUIRE(strcmp(test_string.c_str(), "return") == 0);
}

TEST_CASE("Test += operator for char", "[MyString& operator+=(char c)]") {
	MyString test_string("retur");
	test_string += 'N';
	REQUIRE(strcmp(test_string.c_str(), "returN") == 0);
}

TEST_CASE("Test += operator for null terminated char array", "[MyString& operator+=(const MyString& rhs)]") {
	MyString test_string("ret");
	test_string += "urn";
	REQUIRE(strcmp(test_string.c_str(), "return") == 0);
}

TEST_CASE("Test + operator for char", "[MyString operator+(char c) const]") {
	MyString test_string("retur");
	REQUIRE(strcmp((test_string+'N').c_str(), "returN") == 0);
}

TEST_CASE("Test + operator for null terminated char array", "[MyString operator+(const MyString& rhs) const]") {
	MyString test_string("ret");
	REQUIRE(strcmp((test_string + "urn").c_str(), "return") == 0);
}

TEST_CASE("Test c_str func", "[const char* c_str() const]") {
	MyString test_string("return");
	MyString tst_string;
	REQUIRE(strcmp(test_string.c_str(), "return") == 0);
	REQUIRE(tst_string.c_str() == nullptr);
}

TEST_CASE("Test == operator for two null terminated char arrays", "[bool operator==(const MyString& rhs) const]") {
	MyString test_string("equal");
	MyString tst_string("equal");
	MyString test_strng("not_equal"); // test for different legnht
	MyString tst_strng("ntequ"); // test for the same lenght
	
	REQUIRE((test_string == tst_string) == 1);
	REQUIRE((test_string == test_strng) == 0);
	REQUIRE((test_string == tst_strng) == 0);
}

TEST_CASE("Test < operator for two null terminated char arrays", "[bool operator<(const MyString& rhs) const]") {
	MyString superior_string("return");
	MyString inferior_string("RETURN");
	REQUIRE((superior_string < inferior_string) == 0);
	REQUIRE((inferior_string < superior_string) == 1);
}



//=================================================================================================================================================
// Vehicle tests:


TEST_CASE("Test Vehicle class functions"){
	Vehicle test_vehicle("CA6969CB", "Tesla", 2);

	SECTION("Testing registration func") {
		REQUIRE(strcmp(test_vehicle.registration(), "CA6969CB") == 0);
	}

	SECTION("Testing description func") {
		REQUIRE(strcmp(test_vehicle.description(), "Tesla") == 0);
	}

	SECTION("Testing space func") {
		REQUIRE(test_vehicle.space() == 2);
	}

}


//=====================================================================================================================================================
// Garage tests:


TEST_CASE("Testing copy constructor.", "[Garage(const Garage& old_garage)]") {
	Garage test_garage(5);
	Garage copy(test_garage);
	REQUIRE(copy.size() == 0);
}

TEST_CASE("Testing insert func", "[void insert(Vehicle& v)]") {
	Garage test_garage(5);
	Vehicle test_vehicle("CA6969CB", "Tesla", 3);
	test_garage.insert(test_vehicle);
	CHECK_THROWS(test_garage.insert(test_vehicle)); // test if throw when a vehicle is inserted twice
	REQUIRE(test_garage.size() == 1);
	REQUIRE(test_garage.reg_check("CA6969CB") == 0); // reg_check checks if there is a vehicle with the same registration in the garage
	Vehicle scnd_test_vehicle("PB4200KM", "Lada", 3);
	CHECK_THROWS(test_garage.insert(scnd_test_vehicle));

}

TEST_CASE("Testing erase func", "[void erase(const char* registration)]") {
	Garage test_garage(5);
	Vehicle test_vehicle("CA6969CB", "Tesla", 3);
	test_garage.insert(test_vehicle);
	Vehicle scnd_test_vehicle("PB4200KM", "Lada", 2);
	test_garage.insert(scnd_test_vehicle);
	REQUIRE(test_garage.size() == 2);

	//garage is filled with 2 vehicles and has 0 capacity

	test_garage.erase("CA6969CB");
	REQUIRE(test_garage.size() == 1);  // testing if the vehicle count of the garage is 1 after one vehicle is erased
	REQUIRE(test_garage.reg_check("CA6969CB") == 1); // testing is the registration of the erased vehicle is still in the garage array
	test_garage.erase("PB4200KM");
	REQUIRE(test_garage.size() == 0);
	REQUIRE(test_garage.reg_check("PB4200KM") == 1);
}

TEST_CASE("Testing at func", "[const Vehicle& at(std::size_t pos) const]") {
	Garage test_garage(5);
	Vehicle test_vehicle("CA6969CB", "Tesla", 2);
	Vehicle scnd_test_vehicle("PB4200KM", "Lada", 2);
	Vehicle thrd_test_vehicle("TX6942", "Mercedes", 1);

	test_garage.insert(test_vehicle);
	test_garage.insert(scnd_test_vehicle);
	test_garage.insert(thrd_test_vehicle);

	REQUIRE(test_garage.at(1).registration() == scnd_test_vehicle.registration());
	REQUIRE(test_garage.at(1).description() == scnd_test_vehicle.description());
	REQUIRE(test_garage.at(1).space() == scnd_test_vehicle.space());

}

TEST_CASE("Testing [] operator", "[const Vehicle& operator[](std::size_t pos) const]") {
	Garage test_garage(5);
	Vehicle test_vehicle("CA6969CB", "Tesla", 2);
	Vehicle scnd_test_vehicle("PB4200KM", "Lada", 2);
	Vehicle thrd_test_vehicle("TX6942", "Mercedes", 1);

	test_garage.insert(test_vehicle);
	test_garage.insert(scnd_test_vehicle);
	test_garage.insert(thrd_test_vehicle);

	REQUIRE(test_garage[1].registration() == scnd_test_vehicle.registration());
	REQUIRE(test_garage[1].description() == scnd_test_vehicle.description());
	REQUIRE(test_garage[1].space() == scnd_test_vehicle.space());
}

TEST_CASE("Testing empty func", "[bool empty() const]") {
	Garage test_garage(5);
	Vehicle test_vehicle("CA6969CB", "Tesla", 2);
	REQUIRE(test_garage.empty() == 1);

	test_garage.insert(test_vehicle);
	REQUIRE(test_garage.empty() == 0);

}

TEST_CASE("Testing size func", "[size_t size() const]") {
	Garage test_garage(5);
	Vehicle test_vehicle("CA6969CB", "Tesla", 2);
	Vehicle scnd_test_vehicle("PB4200KM", "Lada", 2);
	
	REQUIRE(test_garage.size() == 0);

	test_garage.insert(test_vehicle);

	REQUIRE(test_garage.size() == 1);

	test_garage.insert(scnd_test_vehicle);

	REQUIRE(test_garage.size() == 2);
}

TEST_CASE("Testing clear func", "[void clear()]") {
	Garage test_garage(5);
	Vehicle test_vehicle("CA6969CB", "Tesla", 2);
	Vehicle scnd_test_vehicle("PB4200KM", "Lada", 2);

	test_garage.insert(test_vehicle);
	test_garage.insert(scnd_test_vehicle);

	REQUIRE(test_garage.empty() == 0); // 0 - if the garage is not empty

	test_garage.clear();

	REQUIRE(test_garage.empty() == 1); // 1 - if the garage is empty
}

TEST_CASE("Testing find func", "[const Vehicle* find(const char* registration) const]") {
	Garage test_garage(5);
	Vehicle test_vehicle("CA6969CB", "Tesla", 2);
	Vehicle scnd_test_vehicle("PB4200KM", "Lada", 2);

	test_garage.insert(test_vehicle);
	test_garage.insert(scnd_test_vehicle);

	REQUIRE((*test_garage.find("CA6969CB")).registration() == test_vehicle.registration());
	REQUIRE((*test_garage.find("CA6969CB")).description() == test_vehicle.description());
	REQUIRE((*test_garage.find("CA6969CB")).space() == test_vehicle.space());

	REQUIRE((*test_garage.find("PB4200KM")).registration() == scnd_test_vehicle.registration());
	REQUIRE((*test_garage.find("PB4200KM")).description() == scnd_test_vehicle.description());
	REQUIRE((*test_garage.find("PB4200KM")).space() == scnd_test_vehicle.space());
}

//==========================================================================================================================================================