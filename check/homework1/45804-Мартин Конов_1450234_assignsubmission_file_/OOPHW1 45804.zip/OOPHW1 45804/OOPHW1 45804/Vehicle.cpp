#include "Vehicle.h";
//using namespace std;


Vehicle::Vehicle(const char* registration, const char* description, std::size_t space)
	: licence_plate(registration), model(description)
{
	this->parking_space = space;
	if (parking_space == 0) {
		throw std::invalid_argument("invalid argument");
	}
}

const char* Vehicle::registration() const {
	return this->licence_plate.c_str();
}


const char* Vehicle :: description() const {
	return this->model.c_str();
}

size_t Vehicle::space() const {
	return this->parking_space;
}





