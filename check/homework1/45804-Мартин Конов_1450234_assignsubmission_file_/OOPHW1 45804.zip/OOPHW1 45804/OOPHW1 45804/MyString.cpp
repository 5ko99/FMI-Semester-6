#include "MyString.h"
using namespace std;



MyString::MyString() {
	mystr = nullptr;
	sz = 0;
}

MyString::MyString(const char* str) {
	sz = strlen(str);
	mystr = new char[sz + 1];
	for (size_t i = 0; i <= sz; i++) {
		mystr[i] = str[i];
	}
}

MyString :: ~MyString() {
	delete[] mystr;
	sz = 0;
}
MyString::MyString(const MyString& old_str) {
	this->sz = old_str.sz;
	this->mystr = new char [sz + 1];
	for (size_t i = 0; i <= sz; i++) {
		this->mystr[i] = old_str.mystr[i];
	}
}

char& MyString::at(size_t pos) {
	try {
		if (sz > pos || pos > -1) {
			return mystr[pos];
		}
		else {
			throw out_of_range("Index out of range");
		}
	}
	catch (...) {
		throw out_of_range("Index out of range");
	}
}

const char& MyString :: at(std::size_t pos) const {

	if (sz > pos || pos > -1) {
		return mystr[pos];
		}
	else {
		throw out_of_range("Index out of range");
		}
}

char& MyString  :: operator[](std::size_t pos) {
	
	return mystr[pos];
}

const char& MyString :: operator[](std::size_t pos) const {
	
	return mystr[pos];
}

char& MyString::front() {
	
	return mystr[0];
}
const char& MyString::front() const {
	
	return mystr[0];
}

char& MyString::back() {
	return mystr[sz - 1];
}

const char& MyString::back() const {
	return mystr[sz - 1];
}

bool MyString::empty() const {
	if (sz == 0 ) {
		return true;
	}
	else {
		return false;
	}
}
size_t MyString::size() const {
	return strlen(mystr);
}

void MyString::clear() {
	for (size_t i = 0; i < sz; i++) {
		mystr[i] = '\0';
	}
	this->sz = 0;
}

void MyString::push_back(char c) {
	char* newszstr = new char[sz + 2];
	for (size_t i = 0; i < sz; i++) {
		newszstr[i] = mystr[i];
	}
	newszstr[sz] = c;
	newszstr[sz + 1] = '\0';
	delete[] mystr;
	mystr = newszstr;
	sz += 1;
}

void MyString::pop_back() {
	
	mystr[sz-1] = '\0';
	sz -= 1;
}

MyString& MyString :: operator+=(char c) {
	char* newszstr = new char[sz + 2];
	for (size_t i = 0; i < sz; i++) {
		newszstr[i] = mystr[i];
	}
	newszstr[sz] = c;
	newszstr[sz + 1] = '\0';
	delete[] mystr;
	mystr = newszstr;
	sz += 1;
	return *this;
}

MyString& MyString :: operator+=(const MyString& rhs) {
	int newsz = rhs.sz + this->sz;
	char* newszstr = new char[newsz+1];
	int index = 0;
	for (size_t i = 0; i < sz; i++) {
		newszstr[i] = mystr[i];
	}
	for (int i = this->sz; i < newsz; i++) {
		newszstr[i] = rhs.mystr[index];
		index += 1;
	}
	newszstr[newsz] = '\0';
	delete[]this->mystr;
	mystr = newszstr;
	sz = newsz;
	return *this;

}



MyString MyString :: operator+(char c) const {
	MyString newszstr(*this);
	newszstr.push_back(c);
	return newszstr;
}

MyString MyString :: operator+(const MyString& rhs) const {
	MyString newszstr(*this);
	newszstr += rhs;
	return newszstr;
	
}

const char* MyString :: c_str() const {
	return this->mystr;
	}

bool MyString :: operator==(const MyString& rhs) const {
	if (this->sz != rhs.sz) {
		return false;
	}
	else {
		for (size_t i = 0; i < sz; i++) {
			if (this->mystr[i] != rhs.mystr[i]) {
				return false;
			}
		}
		return true;
	}
}

bool MyString :: operator<(const MyString& rhs) const {
	int smaller_size;
	if (this->sz >= rhs.sz) {
		smaller_size = rhs.sz;
	}
	else {
		smaller_size = this->sz;
	}

	for (int i = 0; i < smaller_size; i++) {
		if (this->mystr[i] < rhs.mystr[i]) {
			return true;
		}
	}
	return false;
}	



	
	
