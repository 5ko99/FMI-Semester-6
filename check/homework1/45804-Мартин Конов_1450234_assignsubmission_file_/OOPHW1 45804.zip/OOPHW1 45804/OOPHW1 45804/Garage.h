#pragma once
#include "Vehicle.h"
#include<iostream>



class Garage {
private:
	size_t capacity;
	size_t vehicle_count;
	Vehicle** cars_in_garage;

public:
	Garage();
	Garage(size_t size);
	~Garage();
	Garage(const Garage& old_garage);
	void insert(Vehicle& v);
	void erase(const char* registration);
	bool reg_check(const char* reg);
	const Vehicle& at(std::size_t pos) const;
	const Vehicle& operator[](std::size_t pos) const;
	bool empty() const;
	size_t size() const;
	void clear();
	const Vehicle* find(const char* registration) const;
};
