#include "Vehicle.hpp"

Vehicle::Vehicle(const char* registration, const char* description, std::size_t space)
    :f_registration(registration), f_description(description), f_space(space) {}

const char* Vehicle::registration() const
{
    return this->f_registration.c_str();
}

const char* Vehicle::description() const
{
    return this->f_description.c_str();
}

std::size_t Vehicle::space() const
{
    return this->f_space;
}
