#include "Garage.hpp"

Garage::Garage(unsigned carCapacity, unsigned capacity)
    :f_capacity(capacity), f_carCapacity(carCapacity), f_currentCarCapacity(carCapacity), f_size(0)
{
    this->f_vehicles = new Vehicle*[capacity];
}

Garage::Garage(const Garage& other) : Garage()
{
    if (this != &other)
    {
        del();
        copy(other);
    }
}

Garage& Garage::operator=(const Garage& other)
{
    if (this != &other)
    {
        del();
        copy(other);
    }

    return *this;
}

Garage::~Garage()
{
    del();
}

void Garage::copy(const Garage& other)
{
    this->f_vehicles = new Vehicle * [other.f_capacity];

    for (unsigned i = 0; i < other.f_size; i++)
        this->f_vehicles[i] = other.f_vehicles[i]->clone();

    this->f_capacity = other.f_capacity;
    this->f_size = other.f_size;
    this->f_carCapacity = other.f_carCapacity;
    this->f_currentCarCapacity = other.f_currentCarCapacity;
}

void Garage::resize(unsigned newCapacity)
{
    this->f_capacity = newCapacity;

    Vehicle** newVehicles = new Vehicle * [newCapacity];

    if (!newVehicles)
    {
        throw std::exception("Bad allocation.");
    }

    for (unsigned i = 0; i < f_size; i++)
        newVehicles[i] = f_vehicles[i]->clone();

    for (unsigned i = 0; i < f_size; i++)
        delete this->f_vehicles[i];
    delete[] this->f_vehicles;
    
    this->f_vehicles = newVehicles;
}

void Garage::del()
{
    for (unsigned i = 0; i < f_size; i++)
        delete this->f_vehicles[i];
    delete[] this->f_vehicles;

    this->f_size = 0;
    this->f_capacity = 0;
    this->f_carCapacity = 0;
    this->f_currentCarCapacity = 0;
}

void Garage::checkRegistration(const char* registration)
{
    for (unsigned i = 0; i < f_size; i++)
    {
        if (strcmp(this->f_vehicles[i]->registration(), registration) == 0)
        {
            throw std::exception("Vehicle with this registration already exist.");
        }
    }
}

void Garage::checkForSpace(unsigned space)
{
    if ((f_carCapacity - space) < 0)
    {
        throw std::exception("There is not enough space in the garage.");
    }
}

void Garage::insert(Vehicle& v)
{
    checkRegistration(v.registration());
    checkForSpace(v.space());

    if (f_size >= f_capacity)
    {
        resize(f_capacity * 2);
    }

    this->f_vehicles[f_size++] = v.clone();
    this->f_currentCarCapacity -= v.space();
}

void Garage::erase(const char* registration)
{
    for (unsigned i = 0; i < f_size; i++)
    {
        if (strcmp(f_vehicles[i]->registration(), registration) == 0)
        {
            this->f_currentCarCapacity += f_vehicles[i]->space();

            if (i < f_size - 1)
            {
                delete f_vehicles[i];
                f_vehicles[i] = f_vehicles[f_size - 1]->clone();
                delete f_vehicles[f_size - 1];
            }
            else
            {
                delete f_vehicles[i];
            }

            --f_size;
            break;
        }
    }
}

const Vehicle& Garage::at(std::size_t pos) const
{
    if (pos >= f_size || pos < 0)
    {
        throw std::out_of_range("Index was outside the bounds of the array.");
    }

    return *(f_vehicles[pos]);
}

const Vehicle& Garage::operator[](std::size_t pos) const
{
    return *(f_vehicles[pos]);
}

bool Garage::empty() const
{
    return this->f_size == 0;
}

std::size_t Garage::size() const
{
    return this->f_size;
}

void Garage::clear()
{
    for (unsigned i = 0; i < f_size; i++)
        delete this->f_vehicles[i];
    delete[] this->f_vehicles;

    this->f_size = 0;
    this->f_currentCarCapacity = f_carCapacity;
}

const Vehicle* Garage::find(const char* registration) const
{
    for (unsigned i = 0; i < f_size; i++)
    {
        if (strcmp(f_vehicles[i]->registration(), registration) == 0)
        {
            return this->f_vehicles[i];
        }
    }

    return nullptr;
}