#pragma warning(disable: 4996)
#include "MyString.hpp"

MyString::MyString()
	:length(0)
{
	setData(nullptr);
}

MyString::MyString(const char* str)
	:length(strlen(str))
{
	setData(str);
}

MyString::MyString(const MyString& str) : MyString()
{
	if (this != &str)
	{
		del();
		copy(str);
	}
}

MyString& MyString::operator=(const MyString& str)
{
	if (this != &str)
	{
		del();
		copy(str);
	}

	return *this;
}

MyString::~MyString()
{
	del();
}

void MyString::copy(const MyString& str)
{
	setData(str.data);
	this->length = str.length;
}

void MyString::setData(const char* str)
{
	if (str == nullptr)
	{
		this->data = new char[1];
		strcpy(this->data, "");
		return;
	}
	this->data = new char[strlen(str) + 1];
	strcpy(this->data, str);
}

void MyString::del()
{
	delete[] data;
}

char& MyString::at(unsigned index)
{
	if (index >= length)
	{
		throw std::out_of_range("Index was outside the bounds of the array.");
	}

	return this->data[index];
}

char& MyString::at(unsigned index) const
{
	if (index >= length)
	{
		throw std::out_of_range("Index was outside the bounds of the array.");
	}

	return this->data[index];
}

char& MyString::operator[](unsigned index)
{
	return this->data[index];
}

const char& MyString::operator[](unsigned index) const
{
	return this->data[index];
}

char& MyString::front()
{
	return this->data[0];
}

const char& MyString::front() const
{
	return this->data[0];
}

char& MyString::back()
{
	return this->data[length - 1];
}

const char& MyString::back() const
{
	return this->data[length - 1];
}

bool MyString::empty() const
{
	return this->length == 0;
}

unsigned MyString::size() const
{
	return this->length;
}

void MyString::clear()
{
	del();
	this->setData(nullptr);
}

void MyString::push_back(char c)
{
	char* newStr = new char[length + 2];

	if (!newStr)
	{
		throw std::exception("Bad allocation");
	}

	for (int i = 0; i < length; i++)
		newStr[i] = this->data[i];

	newStr[length] = c;
	newStr[length + 1] = '\0';

	delete[] this->data;
	this->data = newStr;

	++length;
}

void MyString::pop_back()
{
	this->data[length - 1] = '\0';
	--length;
}

const char* MyString::c_str() const
{
	return this->data;
}

MyString& MyString::operator+=(char c)
{
	char* newStr = new char[length + 1];

	if (!newStr)
	{
		throw std::exception("Bad allocation");
	}

	for (int i = 0; i < length; i++)
		newStr[i] = this->data[i];

	newStr[length] = c;
	newStr[length + 1] = '\0';

	delete[] this->data;
	this->data = newStr;

	++length;

	return *this;
}

MyString& MyString::operator+=(const MyString& str)
{
	unsigned newLength = length + strlen(str.data);
	char* newStr = new char[newLength + 1];

	if (!newStr)
	{
		throw std::exception("Bad allocation");
	}

	for (unsigned int i = 0; i < length; i++)
	{
		newStr[i] = data[i];
	}

	for (unsigned int i = length; i < newLength; i++)
	{
		newStr[i] = str[i - length];
	}

	newStr[newLength] = '\0';

	delete[] data;
	this->data = newStr;

	this->length = newLength;

	return *this;
}

MyString MyString::operator+(char c) const
{
	return MyString(this->data) += c;
}

MyString MyString::operator+(const MyString& rhs) const
{
	return MyString(this->data) += rhs;
}

bool MyString::operator==(const MyString& rhs) const
{
	return strcmp(this->data, rhs.data) == 0;
}

bool MyString::operator<(const MyString& rhs) const
{
	return strcmp(this->data, rhs.data) < 0;
}
