#include <iostream>

#include "Garage.hpp"
#include "Vehicle.hpp"

int main()
{
	Vehicle vehicle1 = Vehicle("BT 2663 BT", "Audi", 5);
	Vehicle vehicle2 = Vehicle("BT 0034 BT", "Vauxhall", 7);
	Vehicle vehicle3 = Vehicle("BT 2777 BT", "VW", 5);
	Vehicle vehicle4 = Vehicle("BT 5901 BT", "Audi", 5);
	Vehicle vehicle5 = Vehicle("BT 5537 BT", "Audi", 5);
	Vehicle vehicle6 = Vehicle("BT 9999 BT", "Audi", 5);
	Vehicle vehicle7 = Vehicle("BT 5733 BT", "Nissan", 2);

	Garage garage = Garage();

	garage.insert(vehicle1);
	garage.insert(vehicle2);
	garage.insert(vehicle3);
	garage.insert(vehicle4);
	garage.insert(vehicle5);
	garage.insert(vehicle6);
	garage.insert(vehicle7);

	return 0;
}