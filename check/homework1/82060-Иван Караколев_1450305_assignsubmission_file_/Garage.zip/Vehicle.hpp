#pragma once

#include "MyString.hpp"
class Vehicle
{
public:
	Vehicle(const char* registration, const char* description, std::size_t space);

	Vehicle* clone()
	{
		return new Vehicle(*this);
	}

	const char* registration() const;
	const char* description() const;
	std::size_t space() const;
private:
	MyString f_registration;
	MyString f_description;
	size_t f_space;
};