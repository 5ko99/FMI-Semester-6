#pragma once

#include<iostream>
#include<string.h>

class MyString
{
public:
	MyString();
	MyString(const char* str);
	MyString(const MyString& str);
	MyString& operator=(const MyString& str);
	~MyString();

	char& at(unsigned index);
	char& at(unsigned index) const;

	char& operator[](unsigned index);
	const char& operator[](unsigned index) const;

	char& front();
	const char& front() const;

	char& back();
	const char& back() const;

	bool empty() const;
	unsigned size() const;

	void clear();

	void push_back(char c);
	void pop_back();

	const char* c_str() const;

	MyString& operator+= (char c);
	MyString& operator+= (const MyString& str);

	MyString operator+(char c) const;
	MyString operator+(const MyString& rhs) const;

	bool operator==(const MyString& rhs) const;
	bool operator<(const MyString& rhs) const;

private:
	void copy(const MyString& str);
	void setData(const char* str);
	void del();

private:
	char* data;
	unsigned length;
};