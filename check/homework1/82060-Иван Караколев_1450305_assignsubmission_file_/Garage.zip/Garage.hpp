#pragma once

#include "Vehicle.hpp"

class Garage
{
public:
	Garage(unsigned carCapacity = 50, unsigned capacity = 10);
	Garage(const Garage& other);
	Garage& operator=(const Garage& other);
	~Garage();

	void insert(Vehicle& v);
	void erase(const char* registration);

	const Vehicle& at(std::size_t pos) const;
	const Vehicle& operator[](std::size_t pos) const;

	bool empty() const;
	std::size_t size() const;

	void clear();
	const Vehicle* find(const char* registration) const;
private:
	void checkRegistration(const char* registration);
	void checkForSpace(unsigned space);
private:
	void copy(const Garage& other);
	void resize(unsigned newCapacity);
	void del();
private:
	unsigned f_size;
	unsigned f_capacity;
	unsigned f_carCapacity;
	unsigned f_currentCarCapacity;

	Vehicle** f_vehicles;
};