#define CATCH_CONFIG_MAIN  // This tells Catch to provide a main() - only do this in one cpp file
#include "catch.hpp"
#include "../Homework1/MyString.h"
#include<cstring>
using namespace std;

TEST_CASE("Creating string correctly", "[MyString]") {

	const char* str = "abcd";
	MyString string(str);
	REQUIRE(strcmp(string.c_str(), str) == 0);
	REQUIRE(string.size() == strlen(str));
}

TEST_CASE("OPERATOR[]", "[MyString]") {

	const char* str = "abcd";
	MyString string(str);

	SECTION("First element: ") {
		char expected = 'a';
		char result = string[0];
		REQUIRE(expected == result);
	}
	SECTION("Second element: ") {
		char expected = 'b';
		char result = string[1];
		REQUIRE(expected == result);
	}
	SECTION("First element: ") {
		char expected = 'c';
		char result = string[2];
		REQUIRE(expected == result);
	}
	SECTION("First element: ") {
		char expected = 'd';
		char result = string[3];
		REQUIRE(expected == result);
	}
}

TEST_CASE("OPERATOR== return true when string are equal", "MyString") {
	MyString string("abc");
	MyString string2("abc");

	bool expected = true;
	bool result = string == string2;

	REQUIRE(expected == result);
}

TEST_CASE("OPERATOR== return false when the first string is smaller", "MyString") {
	MyString string("abc");
	MyString string2("abcd");

	bool expected = false;
	bool result = string == string2;

	REQUIRE(expected == result);
}

TEST_CASE("OPERATOR== return false when first string is bigger", "MyString") {
	MyString string("abcd");
	MyString string2("abcc");

	bool expected = false;
	bool result = string == string2;

	REQUIRE(expected == result);
}

TEST_CASE("OPERATOR== return false when string are the same size but not equal", "MyString") {
	MyString string("abc");
	MyString string2("abd");

	bool expected = false;
	bool result = string == string2;

	REQUIRE(expected == result);
}

TEST_CASE("OPERATOR+= works correctly when trying to add char element to the end of the string", "[MyString]") {

	MyString string("abc");
	size_t oldLenght = string.size();
	const char* oldStr = string.c_str();

	string.operator+=('d');

	size_t newLenghtExpect = oldLenght + 1;
	const char* newStrExpect = "abcd";

	REQUIRE(strcmp(newStrExpect, string.c_str()) == 0);
	REQUIRE(newLenghtExpect == string.size());
	REQUIRE(strcmp(oldStr, string.c_str()) < 0);
	REQUIRE(oldLenght < string.size());
}

TEST_CASE("OPERATOR+= works correctly when trying to concatenate two strings", "[MyString]") {

	MyString string("abc");
	size_t oldLenght = string.size();
	const char* oldStr = string.c_str();

	MyString string2("df");
	string += string2;

	size_t newLenghtExpect = oldLenght + string2.size();
	const char* newStrExpect = "abcdf";

	REQUIRE(strcmp(newStrExpect, string.c_str()) == 0);
	REQUIRE(newLenghtExpect == string.size());
	REQUIRE(strcmp(oldStr, string.c_str()) < 0);
	REQUIRE(oldLenght < string.size());
}

TEST_CASE("OPERATOR< returns true when the first character that does not match has a lower value in first string than in second string when the size of str1 is smeller",
	"[MyString]") {

	MyString string1("abc");
	MyString string2("abcd");

	bool expected = true;
	bool result = string1 < string2;

	REQUIRE(expected == result);
}

TEST_CASE("OPERATOR< returns true when the first character that does not match has a lower value in first string than in second string when the size of the strings in the same",
	"[MyString]") {

	MyString string1("abc");
	MyString string2("abd");

	bool expected = true;
	bool result = string1 < string2;

	REQUIRE(expected == result);

}

TEST_CASE("OPERATOR< returns false when the first character that does not match has a lower value in second string than in first string when the size of the str1 is smaller",
	"[MyString]") {

	MyString string1("abcd");
	MyString string2("abc");

	bool expected = false;
	bool result = string1 < string2;

	REQUIRE(expected == result);
}

TEST_CASE("OPERATOR< returns false when the first character that does not match has a lower value in second string than in first string when the size of the str1 is smaller when the size of the string is the same",
	"[MyString]") {

	MyString string1("abd");
	MyString string2("abc");

	bool expected = false;
	bool result = string1 < string2;

	REQUIRE(expected == result);
}

TEST_CASE("OPERATOR< returns false when the string are equal",
	"[MyString]") {

	MyString string1("abc");
	MyString string2("abc");

	bool expected = false;
	bool result = string1 < string2;

	REQUIRE(expected == result);
}


TEST_CASE("OPERATOR+ : with char element", "[MyString]") {

	MyString string("abc");

	const char* currentStrExpected = string.c_str();
	size_t currentLenghtExpected = string.size();

	MyString result = string.operator+('d');

	const char* newStrExpected = "abcd";
	size_t newLenghtExpected = string.size() + 1;

	SECTION("The new instance is successfully created") {
		REQUIRE(strcmp(result.c_str(), newStrExpected) == 0);
		REQUIRE(result.size() == newLenghtExpected);
	}

	SECTION("The original intance is not changed") {
		REQUIRE(strcmp(string.c_str(), currentStrExpected) == 0);
		REQUIRE(string.size() == currentLenghtExpected);
	}
}

TEST_CASE("OPERATOR+: with object MyString", "[MySrting]") {

	MyString string("abc");
	const char* first_currentStrExpected = string.c_str();
	size_t first_currentLenghtExpected = string.size();

	MyString string2("df");
	const char* second_currentStrExpected = string2.c_str();
	size_t second_currentLenghtExpected = string2.size();

	MyString result = string.operator+(string2);

	const char* newStrExpected = "abcdf";
	size_t newLenghtExpected = string.size() + string2.size();

	SECTION("The new instance is successfully created") {
		REQUIRE(strcmp(result.c_str(), newStrExpected) == 0);
		REQUIRE(result.size() == newLenghtExpected);
	}

	SECTION("The original intance is not changed") {
		REQUIRE(strcmp(string.c_str(), first_currentStrExpected) == 0);
		REQUIRE(string.size() == first_currentLenghtExpected);
	}

	SECTION("The parameter instance is not changed") {
		REQUIRE(strcmp(string2.c_str(), second_currentStrExpected) == 0);
		REQUIRE(string2.size() == second_currentLenghtExpected);
	}
}

TEST_CASE("C_STR returns correct value", "[MyString]") {

	MyString string("abcd");

	const char* expected = "abcd";
	const char* result = string.c_str();

	REQUIRE(strcmp(expected, result) == 0);
}

TEST_CASE("C_STR returns correct value when object is empty", "[MyString]") {

	MyString string("");

	const char* expected = "";
	const char* result = string.c_str();

	REQUIRE(strcmp(expected, result) == 0);
}

TEST_CASE("EMPTY() returns true when the object is empty", "[MyString]") {

	MyString string("");

	bool expected = true;
	bool result = string.empty();

	REQUIRE(expected == result);
}


TEST_CASE("EMPTY() returns false when the object is not empty", "[MyString]") {

	MyString string("abc");

	bool expected = false;
	bool result = string.empty();

	REQUIRE(expected == result);
}
// TODO test with default constructor

TEST_CASE("SIZE() returs correct value when string is not empty", "[MyString]") {

	MyString string("abc");

	size_t expected = 3;
	size_t result = string.size();

	REQUIRE(expected == result);
}

TEST_CASE("SIZE() returs 0 when string is empty", "[MyString]") {

	MyString string("");

	size_t expected = 0;
	size_t result = string.size();

	REQUIRE(expected == result);
}

TEST_CASE("BACK() return correct value", "[MyString]") {

	MyString string("abc");

	char expected = 'c';
	char result = string.back();

	REQUIRE(expected == result);
}


TEST_CASE("BACK() return correct value with constants", "[MyString]") {

	MyString string("abc");

	const char expected = 'c';
	const char result = string.back();

	REQUIRE(expected == result);
}

TEST_CASE("POP_BACK() correctly delete the last element of the string", "[MyString]") {

	MyString string("abc");

	const char* expected = "ab";
	string.pop_back();
	const char* result = string.c_str();

	REQUIRE(strcmp(expected, result) == 0);
}

TEST_CASE("POP_BACK() correctly change the lenght of the string", "[MyString]") {

	MyString string("abc");

	size_t expected = 2;
	string.pop_back();
	size_t result = string.size();

	REQUIRE(expected == result);
}

TEST_CASE("FRONT() return corect value", "[MyString]") {

	MyString string("abc");

	char expected = 'a';
	char result = string.front();

	REQUIRE(expected == result);
}

TEST_CASE("FRONT() return corect value with constants", "[MyString]") {

	MyString string("abc");

	const char expected = 'a';
	const char result = string.front();

	REQUIRE(expected == result);
}

TEST_CASE("AT() throws out_of_range exception when possiton not available", "[MyString]") {

	MyString string("abc");

	REQUIRE_THROWS(string.at(6));
}

TEST_CASE("AT() return correct value when possition is correct", "[MyString]") {

	MyString string("abc");

	char expected = 'a';
	char result = string.at(0);

	REQUIRE(expected == result);
}

TEST_CASE("AT() return correct value when possition is correct with constants", "[MyString]") {

	MyString string("abc");

	const char expected = 'a';
	const char result = string.at(0);

	REQUIRE(expected == result);
}









