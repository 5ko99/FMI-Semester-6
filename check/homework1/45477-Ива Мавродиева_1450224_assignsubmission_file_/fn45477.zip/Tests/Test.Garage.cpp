#include "catch.hpp"
#include "../Homework1/Garage.h"
#include "../Homework1/Vehicle.h"
#include "../Homework1/Factory.h"
#include<cstring>
using namespace std;

TEST_CASE("Insertion works correctly", "[Garage]") {

	Garage garage(5);
	Vehicle vehicle("12345", "test", 2);
	garage.insert(vehicle);

	SECTION("The size of the garage should increase") {
		size_t expected = 1;
		size_t result = garage.size();
		REQUIRE(expected == result);
	}
	SECTION("The vehicle is inserted correctly") {
		const char* expectedReg = "12345";
		const char* expectedDesc = "test";
		size_t expextedSpace = 2;

		const Vehicle result = garage[0];

		const char* resultReg = result.registration();
		const char* resultDesc = result.description();
		size_t resultSpace = result.space();

		REQUIRE(strcmp(expectedReg, resultReg) == 0);
		REQUIRE(strcmp(expectedDesc, resultDesc) == 0);
		REQUIRE(expextedSpace == resultSpace);
	}
}

TEST_CASE("Find method works correctly", "[Garage]") {

	Garage garage(5);
	Vehicle vehicle("12345", "test", 2);
	garage.insert(vehicle);

	const Vehicle* result = garage.find("12345");

	const char* expectedReg = "12345";
	const char* expectedDesc = "test";
	size_t expextedSpace = 2;

	const char* resultReg = result->registration();
	const char* resultDesc = result->description();
	size_t resultSpace = result->space();

	REQUIRE(result == &vehicle);
	REQUIRE(strcmp(expectedReg, resultReg) == 0);
	REQUIRE(strcmp(expectedDesc, resultDesc) == 0);
	REQUIRE(expextedSpace == resultSpace);
}

TEST_CASE("Erase method delete reference correctly from the garage", "[Garage]") {

	Garage garage(5);
	Vehicle vehicle("12345", "test", 2);
	garage.insert(vehicle);
	garage.erase("12345");

	const Vehicle* result = garage.find("12345");

	size_t expectedSize = 0;
	const Vehicle* expectedPtr = nullptr;

	size_t resultSize = garage.size();
	const Vehicle* resultPtr = garage.find("12345");

	REQUIRE(resultSize == expectedSize);
	REQUIRE(resultPtr == expectedPtr);
}

TEST_CASE("At()  method return correct data when possition is valid", "[Garage]") {

	Garage garage(5);
	Vehicle vehicle("12345", "test", 2);
	garage.insert(vehicle);

	const Vehicle result = garage.at(0);

	const char* expectedReg = "12345";
	const char* expectedDesc = "test";
	size_t expextedSpace = 2;

	const char* resultReg = result.registration();
	const char* resultDesc = result.description();
	size_t resultSpace = result.space();

	REQUIRE(strcmp(expectedReg, resultReg) == 0);
	REQUIRE(strcmp(expectedDesc, resultDesc) == 0);
	REQUIRE(expextedSpace == resultSpace);
}

TEST_CASE("At() method throw exception when possition is not valid", "[Garage]") {
	Garage garage(5);
	Vehicle vehicle("12345", "test", 2);
	garage.insert(vehicle);

	REQUIRE_THROWS(garage.at(2));
}

TEST_CASE("Operator[] return correct data when possition is valid", "[Garage]") {

	Garage garage(5);
	Vehicle vehicle("12345", "test", 2);
	garage.insert(vehicle);

	const Vehicle result = garage[0];

	const char* expectedReg = "12345";
	const char* expectedDesc = "test";
	size_t expextedSpace = 2;

	const char* resultReg = result.registration();
	const char* resultDesc = result.description();
	size_t resultSpace = result.space();

	REQUIRE(strcmp(expectedReg, resultReg) == 0);
	REQUIRE(strcmp(expectedDesc, resultDesc) == 0);
	REQUIRE(expextedSpace == resultSpace);
}

TEST_CASE("Size method return correct number of vehicle in the garage", "[Garage]") {

	Garage garage(5);
	Vehicle vehicle("12345", "test", 2);
	garage.insert(vehicle);

	size_t expected = 1;
	size_t result = garage.size();

	REQUIRE(expected == result);
}

TEST_CASE("Empty method return true when the garage is empty", "[Garage]") {
	Garage garage(5);
	Vehicle vehicle("12345", "test", 2);

	bool expected = true;
	bool result = garage.empty();

	REQUIRE(expected == result);
}

TEST_CASE("Empty method return false when the garage is not empty", "[Garage]") {
	Garage garage(5);
	Vehicle vehicle("12345", "test", 2);
	garage.insert(vehicle);

	bool expected = false;
	bool result = garage.empty();

	REQUIRE(expected == result);
}



