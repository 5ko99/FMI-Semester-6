#include "../Homework1/Vehicle.h"
#include "catch.hpp"
#include<cstring>
using namespace std;

TEST_CASE("Getters return correct data", "[Vehicle]") {
	size_t expectedSpace = 2;

	Vehicle vehicle("12345", "test", 2);

	SECTION("Registration number") {
		char* expectedReg = "12345";
		const char* result = vehicle.registration();
		REQUIRE(strcmp(expectedReg, result) == 0);
	}
	SECTION("Description") {
		char* expectedDesc = "test";
		const char* result = vehicle.description();
		REQUIRE(strcmp(expectedDesc, result) == 0);
	}
	SECTION("Space") {
		size_t expectedSpace = 2;
		size_t result = vehicle.space();
		REQUIRE(expectedSpace == result);
	}
}

TEST_CASE("Creating Vehicle correctly", "[Vehicle]") {

	char* expectedReg = "12345";
	char* expectedDesc = "test";
	size_t expectedSpace = 2;

	Vehicle vehicle(expectedReg, expectedDesc, expectedSpace);

	const char* resultReg = vehicle.registration();
	const char* resultDesc = vehicle.description();
	size_t resultSpace = vehicle.space();

	REQUIRE(strcmp(expectedReg, resultReg) == 0);
	REQUIRE(strcmp(expectedDesc, resultDesc) == 0);
	REQUIRE(expectedSpace == resultSpace);
}

