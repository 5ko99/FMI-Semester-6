#include "Factory.h"
#include<iostream>
#include<cstring>
using namespace std;

#define INCREMENT_CAPACITY 10
#define REGISTRATON_ALREADY_EXIST "Vehicle with this registration number already exist"

VehicleFactory::VehicleFactory(size_t capacity) {
	this->capacity = capacity;
	this->factory = new Vehicle*[this->capacity];
	this->size = 0;
}

Vehicle* VehicleFactory::createVehicle(const char* registration, const char* description, size_t space) {

	if (this->size == this->capacity) {
		resize();
	}
	if (contains(registration)) {
		throw invalid_argument(REGISTRATON_ALREADY_EXIST);
	}

	this->factory[size] = new Vehicle(registration, description, space);
	size++;
	return this->factory[size - 1];
}

bool VehicleFactory::contains(const char* registration) {
	for (size_t index = 0; index < this->size; index++) {
		if (strcmp(this->factory[index]->registration(), registration) == 0) {
			return true;
		}
	}
	return false;
}

VehicleFactory::~VehicleFactory() {
	clean();
}

void VehicleFactory::resize() {

	size_t bufferLen = this->capacity + INCREMENT_CAPACITY;
	Vehicle** buffer = new Vehicle*[bufferLen];

	for (size_t index = 0; index < this->size; index++) {
		buffer[index] = this->factory[index];
	}

	delete[] this->factory;
	this->factory = buffer;
	this->capacity = bufferLen;
}

void VehicleFactory::clean() {

	for (size_t index = 0; index < this->size; index++) {
		delete this->factory[index];
	}
	delete[] factory;
}
