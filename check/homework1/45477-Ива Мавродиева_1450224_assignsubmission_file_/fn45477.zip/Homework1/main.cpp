#include "MyString.h"
#include "Vehicle.h"
#include "Factory.h"
#include "Garage.h"
#include <iostream>
using namespace std;

int main() {


	// ============ MY STRING==============

	MyString string("String object");
	cout << "String value: " << string.c_str() << "\n";
	cout << "String size: " << string.size() << "\n";
	cout << "Is the string empty: " << string.empty() << "\n";
	cout << "First element of the string: " << string.front() << "\n";
	cout << "Last element of the string:" << string.back() << "\n";
	cout << "Element at possition 2 by operator: " << string[1] << "\n";

	try {
		cout << "Element at possition 1 by method: " << string.at(0) << "\n";
	}
	catch (const exception& ex) {
		cerr << "Something is wrong: " << ex.what() << '\n';
	}

	string += 's';
	cout << "The string after adding one char to it via operator+=:\n" << "   String value: " << string.c_str() << "\n"
		<< "   String size: " << string.size() << "\n";

	MyString string2 = string + '!';
	cout << "Created new string via operator+:\n" << "   String value: " << string2.c_str() << "\n"
		<< "   String size: " << string2.size() << "\n";

	MyString equal = string == string2 ? "Yes" : "No";
	cout << "Are the two string equal: " << equal.c_str() << "\n";


	// ============ VEHICLE ==============
	try {

		VehicleFactory factory(15);

		Vehicle* vehicle = factory.createVehicle("CA64731NN", "Not very good condition", 2);
		Vehicle* vehicle2 = factory.createVehicle("CA64732NN", "Very good condition", 1);
		Vehicle* vehicle3 = factory.createVehicle("CA64733NN", "Very big vehicle", 3);
		Vehicle* vehicle4 = factory.createVehicle("CA64734NN", "WOW", 3);
		Vehicle* vehicle5 = factory.createVehicle("CA64735NN", "WOW", 3);

		Garage garage(10);

		garage.insert(*vehicle);
		garage.insert(*vehicle2);
		garage.insert(*vehicle3);
		garage.insert(*vehicle4);

		garage.erase("CA64731NN");


	}
	catch (const exception& ex) {

		cerr << "Something is wrong: " << ex.what() << '\n';

	}
	return 0;
}
