#include "Vehicle.h"
#include "MyString.h"
#include<iostream>
using namespace std;

Vehicle::Vehicle(const char* registration, const char* description, size_t space) {
	setRegistration(MyString(registration));
	setDescription(MyString(description));
	setSpace(space);
}
Vehicle::~Vehicle() {}

const char* Vehicle::registration() const {
	return this->registrationNumber.c_str();
}

const char* Vehicle::description() const {
	return this->vehicleDescription.c_str();
}

size_t Vehicle::space() const {
	return this->vehicleSpace;
}

void Vehicle::setRegistration(const MyString& registration) {
	this->registrationNumber = registration;
}
void Vehicle::setDescription(const MyString& description) {
	this->vehicleDescription = description;
}
void Vehicle::setSpace(size_t space) {
	this->vehicleSpace = space;
}
void Vehicle::print() const {

	cout << "VEHICLE:\n";
	cout << "Registration number: " << registration() << "\n";
	cout << "Description: " << description() << "\n";
	cout << "Space for parking: " << space() << "\n";
}


