#include "Garage.h"
#include <assert.h>
#include <iostream>
#include <cstring>

using namespace std;

#define OUT_OF_RANGE_ERR_MESSAGE "The specified position can't be reached!"
#define FULL_GARAGE_MESSAGE "The garage is full!"
#define NO_ENOUGH_SPACE_MESSAGE "There is no enough space for this vehicle"
#define ALREADY_EXISTS "This vehicle is already in the garage"

Garage::Garage(size_t capacity) {
	this->capacity = capacity;
	this->occupiedPlaces = 0;
	this->numberOfVehicles = 0;
	this->vehicles = new Vehicle*[capacity];
}
Garage::~Garage() {
	clean();
}

void Garage::insert(Vehicle& v) {

	if (find(v.registration()) != nullptr) {
		throw invalid_argument(ALREADY_EXISTS);
	}

	if (this->occupiedPlaces == this->capacity) {
		throw underflow_error(FULL_GARAGE_MESSAGE);
	}
	if (this->capacity - this->occupiedPlaces < v.space()) {
		throw underflow_error(NO_ENOUGH_SPACE_MESSAGE);
	}

	this->vehicles[numberOfVehicles] = &v;
	this->numberOfVehicles++;
	this->occupiedPlaces += v.space();
}

void Garage::erase(const char* registration) {

	for (size_t index = 0; index < this->numberOfVehicles; index++) {
		if (strcmp(this->vehicles[index]->registration(), registration) == 0) {

			this->occupiedPlaces -= this->vehicles[index]->space();

			this->vehicles[index] = this->vehicles[this->numberOfVehicles - 1];
			this->vehicles[this->numberOfVehicles - 1] = nullptr;
			this->numberOfVehicles -= 1;

			return;
		}
	}
}

const Vehicle& Garage::at(size_t pos) const {
	if (!isValid(pos)) {
		throw out_of_range(OUT_OF_RANGE_ERR_MESSAGE);
	}
	return *this->vehicles[pos];
}

const Vehicle& Garage::operator[](size_t pos) const {

	assert(pos < this->numberOfVehicles);
	return *this->vehicles[pos];
}


const Vehicle* Garage::find(const char* registration) const {
	for (size_t index = 0; index < this->numberOfVehicles; index++) {
		if (strcmp(this->vehicles[index]->registration(), registration) == 0) {
			return this->vehicles[index];
		}
	}
	return nullptr;
}

void Garage::clean() {
	delete[] this->vehicles;
	this->occupiedPlaces = 0;
	this->numberOfVehicles = 0;
}

size_t Garage::size() {
	return this->numberOfVehicles;
}

bool Garage::empty() const {
	return this->occupiedPlaces == 0;
}


bool Garage::isValid(size_t pos) const {
	return this->numberOfVehicles > pos;
}



