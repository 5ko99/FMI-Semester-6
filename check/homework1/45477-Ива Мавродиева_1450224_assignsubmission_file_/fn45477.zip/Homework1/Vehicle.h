#ifndef VEHICLE_H
#define VEHICLE_H
#include "MyString.h"

using namespace std;

class Vehicle{

public:

	Vehicle(const char* registration, const char* description, size_t space);
	~Vehicle();
	const char* registration() const;
	const char* description() const;
	size_t space() const;

	void print() const; // iztrij go posle

private:
	void setRegistration(const MyString& registration);
	void setDescription(const MyString& description);
	void setSpace(const size_t size);
		

private:
	MyString registrationNumber;
	MyString vehicleDescription;
	size_t vehicleSpace;

};

#endif
