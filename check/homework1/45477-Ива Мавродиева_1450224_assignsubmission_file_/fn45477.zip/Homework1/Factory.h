#ifndef FACTORY_H
#define FACTORY_H

#include "Vehicle.h"

using namespace std;

class VehicleFactory {

public:

	VehicleFactory(size_t capacity);
	~VehicleFactory();
	Vehicle* createVehicle(const char* registration, const char* description, size_t space);

private:
	bool contains(const char* registration);
	void resize();
	void clean();

private:
	size_t capacity;
	size_t size;
	Vehicle** factory;

};

#endif // !FACTORY_H
