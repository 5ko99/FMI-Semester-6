#include"MyString.h"
#include <assert.h>
#include <iostream>
#include <cstring>
using namespace std;

#define OUT_OF_RANGE_ERR_MESSAGE "The specified position can't be reached!"

MyString::MyString(const char* str) {
	if (str == nullptr) {
		this->str = new char[1];
		this->str[0] = '\0';
		this->lenght = 0;
	}
	else {
		copyArrayToObjectStr(str, strlen(str));
	}
}

MyString::MyString(const MyString& other) {
	copyArrayToObjectStr(other.c_str(), other.size());
}

MyString::MyString(MyString&& other) noexcept {

	copyArrayToObjectStr(other.c_str(), other.size());
	other.str = nullptr;
	other.lenght = 0;
}

MyString::~MyString() {
	clear();
}

char& MyString::operator[](size_t pos) {
	assert(pos < this->lenght);
	return this->str[pos];
}

const char& MyString::operator[](size_t pos) const {
	assert(pos < this->lenght);
	return this->str[pos];
}

bool MyString::operator==(const MyString& rhs) const {

	if (this->lenght != rhs.size()) {
		return false;
	}

	for (size_t index = 0; index < this->lenght; index++) {
		if (this->str[index] != rhs.str[index]) {
			return false;
		}
	}
	return true;
}

MyString& MyString::operator=(const MyString& rhs) {

	if (this == &rhs) {
		return *this;
	}
	copyArrayToObjectStr(rhs.c_str(), rhs.size());

	return *this;
}

MyString& MyString::operator+=(char c) {

	size_t bufferLenght = this->lenght + 1;
	char* buffer = new char[bufferLenght + 1];

	for (size_t index = 0; index < this->lenght; index++) {
		buffer[index] = this->str[index];
	}
	buffer[bufferLenght - 1] = c;
	buffer[bufferLenght] = '\0';

	delete[] this->str;
	this->str = buffer;
	this->lenght = bufferLenght;
	return *this;
}

MyString& MyString::operator+=(const MyString& rhs) {

	size_t bufferLenght = this->lenght + rhs.size();
	char* buffer = new char[bufferLenght + 1];

	size_t index;
	for (index = 0; index < this->lenght; index++) {
		buffer[index] = this->str[index];
	}

	size_t j = 0;
	for (index; index < bufferLenght; index++) {
		buffer[index] = rhs.str[j++];
	}
	buffer[bufferLenght] = '\0';

	delete[] this->str;
	this->str = buffer;
	this->lenght = bufferLenght;
	return *this;
}

bool MyString::operator<(const MyString& rhs) const {

	if (this->lenght < rhs.size()) {
		return true;
	}

	for (size_t index = 0; index < this->lenght; index++) {
		if (this->str[index] < rhs.str[index]) {
			return true;
		}
	}

	return false;
}

MyString MyString::operator+(char c) const {

	size_t bufferLenght = this->lenght + 1;
	char* buffer = new char[bufferLenght + 1];
	for (size_t index = 0; index < bufferLenght - 1; index++) {
		buffer[index] = this->str[index];
	}
	buffer[bufferLenght - 1] = c;
	buffer[bufferLenght] = '\0';

	return MyString(buffer);
}

MyString MyString::operator+(const MyString& rhs) const {

	size_t bufferLenght = this->lenght + rhs.size();
	char* buffer = new char[bufferLenght + 1];

	size_t index;
	for (index = 0; index < this->lenght; index++) {
		buffer[index] = this->str[index];
	}

	size_t j = 0;

	for (index; index < bufferLenght; index++) {
		buffer[index] = rhs.str[j++];
	}

	buffer[bufferLenght] = '\0';

	return MyString(buffer);
}


char& MyString::at(size_t pos) {
	if (!isValidPosition(pos)) {
		throw out_of_range(OUT_OF_RANGE_ERR_MESSAGE);
	}
	return this->str[pos];
}

const char& MyString::at(size_t pos) const {
	if (!isValidPosition(pos)) {
		throw out_of_range(OUT_OF_RANGE_ERR_MESSAGE);
	}
	return this->str[pos];
}

char& MyString::front() {
	return this->str[0];
}

const char& MyString::front() const {
	return this->str[0];
}

char& MyString::back() {
	return this->str[this->lenght - 1];
}

const char& MyString::back() const {
	return this->str[this->lenght - 1];
}

void MyString::pop_back() {
	this->str[this->lenght - 1] = '\0';
	this->lenght -= 1;
}

void MyString::push_back(char c) {

	size_t bufferLenght = this->lenght + 1;
	char* buffer = new char[bufferLenght + 1];
	for (size_t index = 0; index < bufferLenght - 1; index++) {
		buffer[index] = this->str[index];
	}
	buffer[bufferLenght - 1] = c;
	buffer[bufferLenght] = '\0';

	delete[] this->str;
	this->str = buffer;
	this->lenght = bufferLenght;
}

bool MyString::empty() const {
	return this->lenght == 0 && (this->str == nullptr || strcmp(this->str, "") == 0);
}

size_t MyString::size() const {
	return this->lenght;
}

const char* MyString::c_str() const {

	char* buffer = new char[this->lenght + 1];

	for (size_t index = 0; index < this->lenght; index++) {
		buffer[index] = this->str[index];
	}

	buffer[this->lenght] = '\0';
	return buffer;
}

bool MyString::isValidPosition(size_t pos) const {
	return this->lenght - 1 >= pos;
}

bool MyString::isValidPosition(size_t pos) {
	return this->lenght - 1 >= pos;
}

void MyString::clear() {
	delete[] this->str;
	this->str = nullptr;
	this->lenght = 0;
}

void MyString::copyArrayToObjectStr(const char* str, size_t lenght) {

	char* buffer = new char[lenght + 1];

	for (size_t index = 0; index < lenght; index++)
	{
		buffer[index] = str[index];
	}
	buffer[lenght] = '\0';

	delete[] this->str;
	this->str = buffer;
	this->lenght = lenght;
}

bool MyString::campareCharArray(const char* first, const char* second) {

	if (strlen(first) != strlen(second)) {
		return false;
	}

	for (size_t index = 0; index < strlen(first); index++) {
		if (first[index] != second[index]) {
			return false;
		}
	}
	return true;
}



