#ifndef MYSTRING_H
#define MYSTRING_H

using namespace std;

class MyString {

public:

	MyString() = default;
	MyString(const char* other);
	MyString(const MyString& string);
	MyString(MyString&& other) noexcept;
	~MyString();

	char& operator[](size_t pos);
	const char& operator[](size_t pos) const;
	MyString& operator=(const MyString& rhs);
	MyString& operator+=(char c);
	MyString& operator+=(const MyString& rhs);
	MyString operator+(char c) const;
	MyString operator+(const MyString& rhs) const;
	const char* c_str() const;
	bool operator==(const MyString& rhs) const;
	bool operator<(const MyString& rhs) const;

	bool empty() const;
	size_t size() const;
	void push_back(char c);
	void pop_back();
	char& front();
	const char& front() const;

	char& back();
	const char& back() const;

	char& at(size_t pos);
	const char& at(size_t pos) const;

private:
	bool isValidPosition(size_t pos);
	bool isValidPosition(size_t pos) const;
	void copyArrayToObjectStr(const char* str, size_t lenght);
	bool campareCharArray(const char* first, const char* second);
	void clear();


public:
	char* str{ nullptr };
	size_t lenght{ 0 };
};

#endif 
