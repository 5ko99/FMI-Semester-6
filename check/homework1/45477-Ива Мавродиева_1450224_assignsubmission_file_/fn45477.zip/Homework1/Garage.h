#ifndef	GARAGE_H
#define GARAGE_H

#include "Vehicle.h"
using namespace std;

class Garage {

public:

	Garage(size_t capacity);
	~Garage();

	void insert(Vehicle& v);
	void erase(const char* registration);
	const Vehicle& at(size_t pos) const;
	const Vehicle& operator[](size_t pos) const;
	bool empty() const;
	const Vehicle* find(const char* registration) const;
	void clean();
	size_t size();

private:
	bool isValid(size_t pos) const;

private:
	Vehicle** vehicles;
	size_t capacity;
	size_t numberOfVehicles;
	size_t occupiedPlaces;
};

#endif