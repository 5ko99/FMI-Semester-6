#include "garage.hpp"

#include <cassert>
#include <new>

Garage::Garage(std::size_t capacity)
    : m_capacity{capacity}, m_occupied{0}, m_vcount{0}, m_vehicles{nullptr} {}

Garage::~Garage() noexcept {
    if (m_vehicles != nullptr) delete[] m_vehicles;
}

Garage::Garage(const Garage &other) {
    m_capacity = other.m_capacity;
    m_occupied = other.m_occupied;

    m_vehicles = new Vehicle *[m_occupied];

    for (std::size_t i = 0; i < m_occupied; i++) {
        m_vehicles[i] = other.m_vehicles[i];
    }
}

Garage &Garage::operator=(const Garage &other) {
    if (this == &other) return *this;

    Vehicle **temp = new Vehicle *[other.m_occupied];
    for (std::size_t i = 0; i < m_vcount; i++) {
        temp[i] = m_vehicles[i];
    }

    delete[] m_vehicles;

    m_vehicles = temp;
    m_occupied = other.m_occupied;
    m_capacity = other.m_capacity;

    return *this;
}

Garage::Garage(Garage &&other) {
    m_vehicles = other.m_vehicles;
    m_capacity = other.m_capacity;
    m_occupied = other.m_occupied;

    other.m_vehicles = nullptr;
    other.m_capacity = 0;
    other.m_occupied = 0;
}

Garage &Garage::operator=(Garage &&other) {
    if (this == &other) return *this;

    delete[] m_vehicles;

    m_vehicles = other.m_vehicles;
    m_capacity = other.m_capacity;
    m_occupied = other.m_occupied;

    other.m_vehicles = nullptr;
    other.m_capacity = 0;
    other.m_occupied = 0;

    return *this;
}

void Garage::insert(Vehicle &v) {
    if (find(v.registration()) != nullptr)
        throw std::runtime_error("Error: vehicle already in garage");

    std::size_t new_occupied = m_occupied + v.space();

    if (new_occupied > m_capacity)
        throw std::runtime_error("Error: maximum capacity exceeded");

    std::size_t new_vcount = m_vcount + 1;
    Vehicle **temp = new Vehicle *[new_vcount];
    for (std::size_t i = 0; i < m_vcount; i++) {
        temp[i] = m_vehicles[i];
    }
    temp[m_vcount] = &v;
    delete[] m_vehicles;
    m_vehicles = temp;
    m_occupied = new_occupied;
    m_vcount = new_vcount;
}

void Garage::erase(const char *registration) {
    const Vehicle *to_erase = find(registration);

    if (to_erase == nullptr) return;

    std::size_t new_occupied = m_occupied - to_erase->space();
    std::size_t new_vcount = m_vcount - 1;
    Vehicle **temp = new Vehicle *[new_vcount];

    std::size_t current = 0;
    for (std::size_t i = 0; i < m_vcount; i++) {
        if (m_vehicles[i] != to_erase) temp[current++] = m_vehicles[i];
    }

    delete[] m_vehicles;
    m_vehicles = temp;
    m_occupied = new_occupied;
    m_vcount = new_vcount;
}

const Vehicle &Garage::at(std::size_t pos) const {
    if (pos >= m_vcount || pos < 0)
        throw std::out_of_range("Error: Invalid position");

    return *(m_vehicles[pos]);
}

const Vehicle &Garage::operator[](std::size_t pos) const {
    // assert(pos <= m_vcount && pos > 0);

    return *(m_vehicles[pos]);
}

bool Garage::empty() const { return m_vcount == 0; }

std::size_t Garage::size() const { return m_vcount; }

void Garage::clear() {
    if (m_vcount > 0) delete[] m_vehicles;

    m_vcount = 0;
    m_occupied = 0;
    m_vehicles = nullptr;
}

const Vehicle *Garage::find(const char *registration) const {
    if (m_vcount == 0) return nullptr;

    for (std::size_t i = 0; i < m_vcount; i++) {
        if (!std::strcmp(m_vehicles[i]->registration(), registration)) {
            return m_vehicles[i];
        }
    }

    return nullptr;
}