#include "mystring.hpp"

#include <cassert>
#include <iostream>
#include <new>

MyString::MyString()
    : m_len{0}, m_capacity{DEFAULT_ALLOC}, m_data{new char[m_capacity + 1]} {
    for (std::size_t i = 0; i < m_capacity; i++) {
        m_data[i] = '\0';
    }
}

MyString::MyString(const char *str)
    : m_len{std::strlen(str)},
      m_capacity{m_len}, m_data{new char[m_capacity + 1]} {

    for (std::size_t i = 0; i < m_len; i++) {
        m_data[i] = str[i];
    }

    m_data[m_len] = '\0';
}

MyString::~MyString() noexcept {
    if (m_data != nullptr) delete[] m_data;
}

MyString::MyString(const MyString &other) : MyString(other.m_data) {}

MyString &MyString::operator=(const MyString &other) {
    if (this == &other) return *this;
    char *temp = new char[other.m_capacity + 1];
    std::memcpy(temp, other.m_data, other.m_len + 1);
    delete[] m_data;
    m_data = temp;
    m_len = other.m_len;
    m_capacity = other.m_capacity;
    return *this;
}

MyString::MyString(MyString &&other) noexcept {
    m_data = other.m_data;
    m_len = other.m_len;
    m_capacity = other.m_capacity;
    other.m_data = nullptr;
    other.m_len = 0;
    other.m_capacity = 0;
}

MyString &MyString::operator=(MyString &&other) noexcept {
    if (this == &other) return *this;

    delete[] m_data;
    m_data = other.m_data;
    m_len = other.m_len;
    m_capacity = other.m_capacity;
    other.m_data = nullptr;
    other.m_len = 0;
    other.m_capacity = 0;
    return *this;
}

MyString &MyString::operator+=(char c) {
    push_back(c);
    return *this;
}

MyString &MyString::operator+=(const MyString &str) {
    for (std::size_t i = 0; i < str.m_len; i++) {
        push_back(str.at(i));
    }

    return *this;
}

MyString MyString::operator+(char c) const {
    MyString res;
    res += *this;
    res += c;
    return res;
}

MyString MyString::operator+(const MyString &str) const {
    MyString res;
    res += *this;
    res += str;
    return res;
}

bool MyString::operator==(const MyString &str) const {
    if (m_len != str.m_len) return false;

    for (std::size_t i = 0; i < m_len; i++) {
        if (m_data[i] != str[i]) return false;
    }

    return true;
}

bool MyString::operator<(const MyString &str) const {
    if (empty() && !str.empty()) return true;

    std::size_t compare_len = m_len < str.m_len ? m_len : str.m_len;

    for (std::size_t i = 0; i < compare_len; i++) {
        if (m_data[i] < str.at(i)) {
            return true;
        } else if (m_data[i] > str.at(i)) {
            return false;
        }
    }

    return false;
}

char &MyString::at(std::size_t pos) {
    if (pos >= m_len) throw std::out_of_range("Error: Invalid position");

    return m_data[pos];
}

const char &MyString::at(std::size_t pos) const {
    if (pos >= m_len) throw std::out_of_range("Error: Invalid position");

    return m_data[pos];
}

char &MyString::operator[](std::size_t pos) {
    // assert(pos < m_len);
    return m_data[pos];
}

const char &MyString::operator[](std::size_t pos) const {
    // assert(pos < m_len);
    return m_data[pos];
}

char &MyString::front() {
    // assert(m_len > 0);
    return m_data[0];
}

const char &MyString::front() const {
    // assert(m_len > 0);
    return m_data[0];
}

char &MyString::back() {
    // assert(m_len > 0);
    return m_data[m_len - 1];
}

const char &MyString::back() const {
    // assert(m_len > 0);
    return m_data[m_len - 1];
}

bool MyString::empty() const { return m_len == 0; }

std::size_t MyString::size() const { return m_len; }

std::size_t MyString::capacity() const { return m_capacity; }

const char *MyString::c_str() const { return m_data; }

void MyString::clear() {
    for (std::size_t i = 0; i < m_len; i++) {
        m_data[i] = '\0';
    }

    m_len = 0;
}

void MyString::push_back(char c) {
    if (m_len == m_capacity) {
        m_capacity *= 2;
        char *temp = new char[m_capacity + 1];
        std::memcpy(temp, m_data, m_len);
        delete[] m_data;
        m_data = temp;
    }

    m_data[m_len++] = c;
    m_data[m_len] = '\0';
}

void MyString::pop_back() {
    // assert(m_len > 0);
    if (m_len > 0) m_data[--m_len] = '\0';
}