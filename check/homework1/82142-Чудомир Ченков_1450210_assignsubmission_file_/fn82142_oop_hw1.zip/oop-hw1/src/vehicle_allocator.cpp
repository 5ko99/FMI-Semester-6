#include "vehicle_allocator.hpp"

#include <iostream>

VehicleAllocator::VehicleAllocator() : vehicles{nullptr}, count{0} {}

VehicleAllocator::~VehicleAllocator() noexcept {
    for (std::size_t i = 0; i < count; i++) {
        delete vehicles[i];
    }

    delete[] vehicles;
}

Vehicle *VehicleAllocator::allocate(const char *registration,
                                    const char *description,
                                    std::size_t space) {
    Vehicle *v = new Vehicle(registration, description, space);

    std::size_t new_count = count + 1;
    Vehicle **temp = new Vehicle *[new_count];

    for (std::size_t i = 0; i < count; i++) {
        temp[i] = vehicles[i];
    }

    temp[count] = v;
    delete[] vehicles;
    vehicles = temp;
    count = new_count;

    return v;
}