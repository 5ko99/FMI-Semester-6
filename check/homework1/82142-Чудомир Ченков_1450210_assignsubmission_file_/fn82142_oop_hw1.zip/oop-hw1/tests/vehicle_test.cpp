#define CATCH_CONFIG_MAIN

#include "catch.hpp"
#include "vehicle.hpp"

// Collective test of the constructor and the three getters
// Nothing more to test about that class

TEST_CASE("Vehicle creation test", "[vehicle]") {
    Vehicle v{"1705XM", "volkswagen passat", 1};

    REQUIRE(strcmp(v.registration(), "1705XM") == 0);
    REQUIRE(strcmp(v.description(), "volkswagen passat") == 0);
    REQUIRE(v.space() == 1);
}