#define CATCH_CONFIG_MAIN

#include "catch.hpp"
#include "mystring.hpp"

TEST_CASE("MyString at method", "[mystring]") {
    MyString str{"hello"};

    SECTION("Using at with valid position returns the correct character") {
        REQUIRE(str.at(0) == 'h');
        REQUIRE(str.at(1) == 'e');
        REQUIRE(str.at(2) == 'l');
        REQUIRE(str.at(3) == 'l');
        REQUIRE(str.at(4) == 'o');
    }

    SECTION("Using at with invalid position throws exception") {
        REQUIRE_THROWS(str.at(-1));
        REQUIRE_THROWS(str.at(5));
        REQUIRE_THROWS(str.at(1000));
        REQUIRE_THROWS(str.at(-1000));
    }
}

TEST_CASE("MyString operator []", "[mystring]") {
    MyString str{"hello"};

    SECTION("Using [] with valid position returns the correct character") {
        REQUIRE(str[0] == 'h');
        REQUIRE(str[1] == 'e');
        REQUIRE(str[2] == 'l');
        REQUIRE(str[3] == 'l');
        REQUIRE(str[4] == 'o');
    }

    SECTION("Using [] with invalid position does not throw") {
        REQUIRE_NOTHROW(str[-1]);
        REQUIRE_NOTHROW(str[5]);
        REQUIRE_NOTHROW(str[1000]);
        REQUIRE_NOTHROW(str[-1000]);
    }
}

TEST_CASE("MyString front method", "[mystring]") {
    SECTION("Using front on an empty string does not throw") {
        MyString str;

        REQUIRE_NOTHROW(str.front());
    }

    SECTION("Using front on non-empty string returns the correct character") {
        MyString str{"hello"};

        REQUIRE(str.front() == 'h');
    }
}

TEST_CASE("MyString back method", "[mystring]") {
    SECTION("Using back on an empty string does not throw") {
        MyString str;

        REQUIRE_NOTHROW(str.back());
    }

    SECTION("Using back on non-empty string returns the correct character") {
        MyString str{"hello"};

        REQUIRE(str.back() == 'o');
    }
}

TEST_CASE("MyString empty method", "[mystring]") {
    SECTION("Using empty on an empty string returns true") {
        MyString str;

        REQUIRE(str.empty());
    }

    SECTION("Using empty on non-empty string returns false") {
        MyString str{"hello"};

        REQUIRE_FALSE(str.empty());
    }
}

TEST_CASE("MyString size method", "[mystring]") {
    SECTION("Size on an empty string is zero") {
        MyString str;

        REQUIRE(str.size() == 0);
    }

    SECTION("Size on non-empty string returns correct value") {
        MyString str{"hello"};

        REQUIRE(str.size() == 5);
    }
}

TEST_CASE("MyString capacity method", "[mystring]") {
    SECTION("Capacity on an empty string is DEFAULT_ALLOC") {
        MyString str;

        REQUIRE(str.capacity() == DEFAULT_ALLOC);
    }

    SECTION("Capacity on non-empty string is equal to the size") {
        MyString str{"hello there my friend"};

        REQUIRE(str.capacity() == str.size());
        REQUIRE(str.capacity() == 21);
    }
}

TEST_CASE("MyString c_str method", "[mystring]") {
    SECTION("Using c_str on an empty string returns empty char*") {
        MyString str;

        REQUIRE(std::strlen(str.c_str()) == 0);
    }

    SECTION("Using c_str on non-empty string returns exact copy of it") {
        MyString str{"hello"};

        REQUIRE(std::strlen(str.c_str()) == str.size());
        REQUIRE(std::strcmp(str.c_str(), "hello") == 0);
    }
}

TEST_CASE("MyString clear method", "[mystring]") {
    SECTION("Using clear changes size to zero, but keeps capacity") {
        MyString str{"hello"};

        std::size_t expected_capacity = str.capacity();

        str.clear();

        REQUIRE(str.size() == 0);
        REQUIRE(str.capacity() == expected_capacity);
    }

    SECTION("Using clear and c_str afterwards results in an empty string") {
        MyString str{"hello"};

        str.clear();

        REQUIRE(std::strlen(str.c_str()) == 0);
    }
}

TEST_CASE("MyString push_back method", "[mystring]") {
    SECTION(
        "Using push_back on an empty string results in string with one char") {
        MyString str;

        str.push_back('c');

        REQUIRE_FALSE(str.empty());
        REQUIRE(str.size() == 1);
        REQUIRE(str.back() == str.front());
        REQUIRE(str.back() == 'c');
    }

    SECTION("Using push_back on non-empty string") {
        MyString str{"hello"};

        str.push_back('c');

        REQUIRE_FALSE(str.empty());
        REQUIRE(str.size() == 6);
        REQUIRE(str.back() != str.front());
        REQUIRE(str.back() == 'c');
    }
}

TEST_CASE("MyString pop_back method", "[mystring]") {
    SECTION("Using pop_back on an empty string does not throw") {
        MyString str;

        REQUIRE_NOTHROW(str.pop_back());
        REQUIRE(str.empty());
        REQUIRE(str.size() == 0);
    }

    SECTION("Using pop_back on non-empty string") {
        MyString str{"hello"};

        str.pop_back();

        REQUIRE_FALSE(str.empty());
        REQUIRE(str.size() == 4);
        REQUIRE(str.back() == 'l');
    }
}

TEST_CASE("MyString operator==", "[mystring]") {
    SECTION("Two empty strings are equal") {
        MyString str1;
        MyString str2;

        REQUIRE(str1 == str2);
    }

    SECTION("Two non-empty strings with same content are equal") {
        MyString str1{"hello"};
        MyString str2{"hello"};

        REQUIRE(str1 == str2);
    }

    SECTION("Two non-empty strings with different content are not equal") {
        MyString str1{"hello"};
        MyString str2{"there"};

        REQUIRE_FALSE(str1 == str2);
    }
}

TEST_CASE("MyString operator<", "[mystring]") {
    SECTION("One empty string is not < another empty string") {
        MyString str1;
        MyString str2;

        REQUIRE_FALSE(str1 < str2);
    }

    SECTION("Empty string is < non-empty string") {
        MyString str1;
        MyString str2{"hello"};

        REQUIRE(str1 < str2);
    }

    SECTION("Non-empty is not < empty string") {
        MyString str1{"hello"};
        MyString str2;

        REQUIRE_FALSE(str1 < str2);
    }

    SECTION("Using operator< on non-empty strings") {
        MyString str1{"hello"};
        MyString str2{"there"};
        MyString str3{"help"};

        REQUIRE(str1 < str2);
        REQUIRE(str3 < str2);
        REQUIRE(str1 < str3);
    }
}

TEST_CASE("MyString operator+=", "[mystring]") {
    SECTION("Using operator+= on empty string with another empty string") {
        MyString str1;
        MyString str2;

        str1 += str2;

        REQUIRE(str1.empty());
    }

    SECTION("Using operator+= on empty string with non-empty string") {
        MyString str1;
        MyString str2{"hello"};

        str1 += str2;

        REQUIRE(str1 == str2);
    }

    SECTION("Using operator+= on non-empty string with empty string") {
        MyString str1{"hello"};
        MyString str2;

        str1 += str2;

        REQUIRE(str1.size() == 5);
        REQUIRE(str1.at(0) == 'h');
        REQUIRE(str1.at(1) == 'e');
        REQUIRE(str1.at(2) == 'l');
        REQUIRE(str1.at(3) == 'l');
        REQUIRE(str1.at(4) == 'o');
    }

    SECTION(
        "Using operator+= on non-empty string with another non-empty string") {
        MyString str1{"hello"};
        MyString str2{"there"};

        str1 += str2;

        REQUIRE(str1.size() == 10);
        REQUIRE(str1.at(0) == 'h');
        REQUIRE(str1.at(1) == 'e');
        REQUIRE(str1.at(2) == 'l');
        REQUIRE(str1.at(3) == 'l');
        REQUIRE(str1.at(4) == 'o');
        REQUIRE(str1.at(5) == 't');
        REQUIRE(str1.at(6) == 'h');
        REQUIRE(str1.at(7) == 'e');
        REQUIRE(str1.at(8) == 'r');
        REQUIRE(str1.at(9) == 'e');
    }
}

TEST_CASE("MyString operator+", "[mystring]") {
    SECTION("Using operator+ with two empty strings") {
        MyString str1;
        MyString str2;
        MyString str3 = str1 + str2;

        REQUIRE(str3.empty());
    }

    SECTION("Using operator+ with one empty and one non-empty string") {
        MyString str1{"hello"};
        MyString str2;
        MyString str3 = str1 + str2;

        REQUIRE(str3 == str1);
    }

    SECTION("Using operator+ with two non-empty strings") {
        MyString str1{"hello"};
        MyString str2{"there"};
        MyString str3 = str1 + str2;

        REQUIRE(str3.size() == 10);
        REQUIRE(str3.at(0) == 'h');
        REQUIRE(str3.at(1) == 'e');
        REQUIRE(str3.at(2) == 'l');
        REQUIRE(str3.at(3) == 'l');
        REQUIRE(str3.at(4) == 'o');
        REQUIRE(str3.at(5) == 't');
        REQUIRE(str3.at(6) == 'h');
        REQUIRE(str3.at(7) == 'e');
        REQUIRE(str3.at(8) == 'r');
        REQUIRE(str3.at(9) == 'e');
    }
}