#define CATCH_CONFIG_MAIN

#include "catch.hpp"
#include "garage.hpp"

TEST_CASE("Garage insert method", "[garage]") {
    Garage garage{5};

    SECTION("Insert non-existing vehicle") {
        Vehicle v{"1705XM", "volkswagen passat", 1};

        REQUIRE_NOTHROW(garage.insert(v));
        REQUIRE_FALSE(garage.empty());
        REQUIRE(garage.size() == 1);
        REQUIRE(garage.find(v.registration()) != nullptr);
    }

    SECTION("Insert existing results in exception") {
        Vehicle v1{"1705XM", "volkswagen passat", 1};
        Vehicle v2{"1705XM", "renault clio", 1};

        REQUIRE_NOTHROW(garage.insert(v1));
        REQUIRE_THROWS(garage.insert(v2));
    }

    SECTION("Insert over capacity results in exception") {
        Vehicle big_vehicle{"7777AO", "renault laguna", 3};
        Vehicle bigger_vehicle{"1903PT", "big thing", 4};

        REQUIRE_NOTHROW(garage.insert(big_vehicle));
        REQUIRE_THROWS(garage.insert(bigger_vehicle));
    }
}

TEST_CASE("Garage erase method", "[garage]") {
    Garage garage{5};

    Vehicle v1{"1705XM", "volkswagen passat", 1};
    Vehicle v2{"1903PT", "renault clio", 1};
    Vehicle v3{"7777AO", "renault laguna", 2};

    garage.insert(v1);
    garage.insert(v2);
    garage.insert(v3);

    SECTION("Erasing existing car removes it") {
        garage.erase("1705XM");

        REQUIRE(garage.size() == 2);
        REQUIRE(garage.find("1705XM") == nullptr);
    }

    SECTION("Erasing non-existing car does nothing") {
        garage.erase("5551TA");

        REQUIRE(garage.size() == 3);
    }
}

TEST_CASE("Garage find method", "[garage]") {
    Garage garage{5};

    SECTION("Find in empty garage returns nullptr") {
        REQUIRE(garage.find("1705XM") == nullptr);
    }

    SECTION("Find non-existing vehicle returns nullptr") {
        Vehicle v1{"1705XM", "volkswagen passat", 1};
        Vehicle v2{"1903PT", "renault clio", 1};
        Vehicle v3{"7777AO", "renault laguna", 2};

        garage.insert(v1);
        garage.insert(v2);
        garage.insert(v3);

        REQUIRE(garage.find("5551TA") == nullptr);
    }

    SECTION("Find existing vehicle returns pointer to the vehicle") {
        Vehicle v1{"1705XM", "volkswagen passat", 1};
        Vehicle v2{"1903PT", "renault clio", 1};
        Vehicle v3{"7777AO", "renault laguna", 2};

        garage.insert(v1);
        garage.insert(v2);
        garage.insert(v3);

        const Vehicle *found = garage.find("1705XM");

        REQUIRE(found == &v1);
        REQUIRE(found->registration() == v1.registration());
        REQUIRE(found->description() == v1.description());
        REQUIRE(found->space() == v1.space());
    }
}

TEST_CASE("Garage clear method", "[garage]") {
    Garage garage{5};

    SECTION("Clear empty garage results in empty garage") {
        garage.clear();

        REQUIRE(garage.empty());
    }

    SECTION("Clear non-empty garage results in empty garage") {
        Vehicle v1{"1705XM", "volkswagen passat", 1};
        Vehicle v2{"1903PT", "renault clio", 1};
        Vehicle v3{"7777AO", "renault laguna", 2};

        garage.insert(v1);
        garage.insert(v2);
        garage.insert(v3);

        garage.clear();

        REQUIRE(garage.empty());
    }
}

TEST_CASE("Garage empty method", "[garage]") {
    Garage garage{5};

    SECTION("Using empty on an empty garage returns true") {
        REQUIRE(garage.empty());
    }

    SECTION("Using empty on non-empty garage returns false") {
        Vehicle v{"1705XM", "volkswagen passat", 1};

        garage.insert(v);

        REQUIRE_FALSE(garage.empty());
    }
}

TEST_CASE("Garage size method", "[garage]") {
    Garage garage{5};

    SECTION("Size on an empty garage is zero") { REQUIRE(garage.size() == 0); }

    SECTION("Size on non-empty garage returns correct value") {
        Vehicle v1{"1705XM", "volkswagen passat", 1};
        Vehicle v2{"1903PT", "renault clio", 1};
        Vehicle v3{"7777AO", "renault laguna", 2};

        garage.insert(v1);
        garage.insert(v2);
        garage.insert(v3);

        REQUIRE(garage.size() == 3);
    }
}

TEST_CASE("Garage at method", "[garage]") {
    Garage garage{5};

    Vehicle v1{"1705XM", "volkswagen passat", 1};
    Vehicle v2{"1903PT", "renault clio", 1};
    Vehicle v3{"7777AO", "renault laguna", 2};

    garage.insert(v1);
    garage.insert(v2);
    garage.insert(v3);

    SECTION("Using at with valid position returns the correct Vehicle") {
        REQUIRE(garage.at(0).registration() == v1.registration());
        REQUIRE(garage.at(0).description() == v1.description());
        REQUIRE(garage.at(0).space() == v1.space());
        REQUIRE(garage.at(1).registration() == v2.registration());
        REQUIRE(garage.at(1).description() == v2.description());
        REQUIRE(garage.at(1).space() == v2.space());
        REQUIRE(garage.at(2).registration() == v3.registration());
        REQUIRE(garage.at(2).description() == v3.description());
        REQUIRE(garage.at(2).space() == v3.space());
    }

    SECTION("Using at with invalid position throws exception") {
        REQUIRE_THROWS(garage.at(-1));
        REQUIRE_THROWS(garage.at(5));
        REQUIRE_THROWS(garage.at(1000));
        REQUIRE_THROWS(garage.at(-1000));
    }
}

TEST_CASE("Garage operator []", "[garage]") {
    Garage garage{5};

    Vehicle v1{"1705XM", "volkswagen passat", 1};
    Vehicle v2{"1903PT", "renault clio", 1};
    Vehicle v3{"7777AO", "renault laguna", 2};

    garage.insert(v1);
    garage.insert(v2);
    garage.insert(v3);

    SECTION("Using [] with valid position returns the correct Vehicle") {
        REQUIRE(garage[0].registration() == v1.registration());
        REQUIRE(garage[0].description() == v1.description());
        REQUIRE(garage[0].space() == v1.space());
        REQUIRE(garage[1].registration() == v2.registration());
        REQUIRE(garage[1].description() == v2.description());
        REQUIRE(garage[1].space() == v2.space());
        REQUIRE(garage[2].registration() == v3.registration());
        REQUIRE(garage[2].description() == v3.description());
        REQUIRE(garage[2].space() == v3.space());
    }

    SECTION("Using [] with invalid position does not throw") {
        REQUIRE_NOTHROW(garage[-1]);
        REQUIRE_NOTHROW(garage[5]);
        REQUIRE_NOTHROW(garage[1000]);
        REQUIRE_NOTHROW(garage[-1000]);
    }
}