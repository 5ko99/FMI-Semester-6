#include "garage.hpp"
#include "vehicle_allocator.hpp"

#include <iostream>
#include <limits>

void print_options() {
    std::cout << "1. Insert a vehicle in the garage" << std::endl
              << "2. Erase a vehicle from the garage" << std::endl
              << "3. Show vehicles currently in the garage" << std::endl
              << "4. Exit" << std::endl;
}

int main() {
    constexpr int MAX_STRLEN = 256;

    std::size_t n;
    std::cout << "Enter garage capacity: ";
    std::cin >> n;

    Garage garage{n};
    VehicleAllocator allocator;

    unsigned int option;

    do {
        print_options();
        std::cout << "Choose an option: ";
        std::cin >> option;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        switch (option) {
        case 1: {
            char reg[MAX_STRLEN];
            char desc[MAX_STRLEN];
            std::size_t len;
            std::size_t space;

            std::cout << "Enter vehicle information" << std::endl;

            std::cout << "Registration: ";
            std::cin.getline(reg, MAX_STRLEN);
            std::cout << "Description: ";
            std::cin.getline(desc, MAX_STRLEN);
            std::cout << "Space: ";
            std::cin >> space;

            Vehicle *v = allocator.allocate(reg, desc, space);

            try {
                garage.insert(*v);
            } catch (const std::runtime_error &ex) {
                std::cout << ex.what() << std::endl;
            }

            break;
        }
        case 2: {
            char reg[MAX_STRLEN];

            std::cout << "Enter vehicle registration: ";
            std::cin.getline(reg, MAX_STRLEN);

            garage.erase(reg);

            break;
        }
        case 3: {
            for (std::size_t i = 0; i < garage.size(); i++) {
                std::cout << garage.at(i).registration() << " "
                          << garage.at(i).description() << std::endl;
            }

            break;
        }
        }

    } while (option != 4);

    return 0;
}
