#ifndef _VEHICLE_HPP_
#define _VEHICLE_HPP_

#include "mystring.hpp"

class Vehicle {
  public:
    Vehicle(const char *registration, const char *description,
            std::size_t space);

    const char *registration() const;
    const char *description() const;
    std::size_t space() const;

  private:
    MyString m_registration;
    MyString m_description;
    std::size_t m_space;
};

#endif // _VEHICLE_HPP_