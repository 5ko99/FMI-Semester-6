#include "vehicle.hpp"

#include <cstddef>

class VehicleAllocator {
  public:
    VehicleAllocator();
    ~VehicleAllocator() noexcept;

    Vehicle *allocate(const char *registration, const char *description,
                      std::size_t space);

  private:
    Vehicle **vehicles;
    std::size_t count;
};