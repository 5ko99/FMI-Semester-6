#ifndef _GARAGE_HPP_
#define _GARAGE_HPP_

#include "vehicle.hpp"

#include <cstddef>

class Garage {
  public:
    Garage(std::size_t capacity);
    ~Garage() noexcept;
    Garage(const Garage &other);
    Garage &operator=(const Garage &other);
    Garage(Garage &&other);
    Garage &operator=(Garage &&other);

    void insert(Vehicle &v);
    void erase(const char *registration);
    const Vehicle &at(std::size_t pos) const;
    const Vehicle &operator[](std::size_t pos) const;
    bool empty() const;
    std::size_t size() const;
    void clear();
    const Vehicle *find(const char *registration) const;

  private:
    std::size_t m_capacity;
    std::size_t m_occupied;
    std::size_t m_vcount;
    Vehicle **m_vehicles;
};

#endif // _GARAGE_HPP_