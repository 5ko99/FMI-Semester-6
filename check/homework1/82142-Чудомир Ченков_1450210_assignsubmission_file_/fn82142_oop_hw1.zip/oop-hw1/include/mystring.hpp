#ifndef _MY_STRING_HPP_
#define _MY_STRING_HPP_

#define DEFAULT_ALLOC 15

#include <cstddef>
#include <cstring>
#include <new>
#include <stdexcept>

class MyString {

  public:
    MyString();
    MyString(const char *str);
    ~MyString() noexcept;
    MyString(const MyString &other);
    MyString &operator=(const MyString &other);
    MyString(MyString &&other) noexcept;
    MyString &operator=(MyString &&other) noexcept;

    MyString &operator+=(char c);
    MyString &operator+=(const MyString &str);
    MyString operator+(char c) const;
    MyString operator+(const MyString &str) const;

    bool operator==(const MyString &str) const;
    bool operator<(const MyString &str) const;

    char &at(std::size_t pos);
    const char &at(std::size_t pos) const;

    char &operator[](std::size_t pos);
    const char &operator[](std::size_t pos) const;

    char &front();
    const char &front() const;

    char &back();
    const char &back() const;

    bool empty() const;
    std::size_t size() const;
    std::size_t capacity() const;

    const char *c_str() const;

    void clear();
    void push_back(char c);
    void pop_back();

  private:
    std::size_t m_len;
    std::size_t m_capacity;
    char *m_data;
};

#endif // _MY_STRING_HPP_
