#include <iostream>
#include "Vehicle.h"
using namespace std;

Vehicle::Vehicle(const char* registration, const char* description, size_t space)
{
    this->registration = new char[strlen(registration) + 1];
    strcpy(this->registration, registration);

    this->description = new char[strlen(description) + 1];
    strcpy(this->description, description);

    this->space = space;
}

const char* Vehicle:: registration()const
{
    return registration.c_str();
}

const char* Vehicle:: description()const
{
    return description.c_str();
}

size_t Vehicle::space() const
{
    return space;
}
