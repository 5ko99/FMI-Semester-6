#include <iostream>
#include "MyString.h"
using namespace std;

MyString::MyString()
{
	str = NULL;
}

MyString::MyString(const char *str)
{
	this->str = new char[strlen(str) + 1];
	strcpy_s(this->str, strlen(str) + 1, str);
}

size_t MyString::size() const {
	if (str)
		return strlen(str);
	else
		return 0;
}

char& MyString::at(size_t pos)
{
	if (pos > length() - 1 || pos<0) {
		throw out_of_range("out of range");
	}

	return str[pos];
}
bool MyString::empty() const
{
    return strlen(str) == 0;
}

const char& MyString::at(size_t pos) const
{
    if (pos > length() - 1 || pos<0) {
		throw out_of_range("out of range");
	}

	return str[pos];
}

 char& operator[] (size_t pos)
    {
      if(pos < 0 || pos > length ) {
	cerr << "Invalid position";
	exit(-1);

      }
      return str[pos];
    }

    char& operator[] (size_t pos) const
    {
      if(pos < 0 || pos > length ) {
	cerr << "Invalid position";
	exit(-1);

      }
      return str[pos];
    }

     char& MyString::front()
     {
    return (*this)[0];
  }

bool MyString::operator==(const MyString &rhs) const
{
	if (strcmp(this->rhs, other.rhs) == 0) {
		return true;
	}
	return false;
}

bool MyString::operator<(const MyString & string) const
{
	if (strcmp(this->rhs, other.rhs) < 0) {
		return true;
	}
	return false;
}

MyString MyString::operator+(const MyString& rhs)
{
	if (this->rhs == NULL) {
		*this = rhs;
		return *this;
	}
	else {
		char *temp;
		temp = new char[strlen(this->rhs) + strlen(other.rhs) + 1];
		strcpy_s(temp, strlen(this->rhs) + 1, this->rhs);
		strcat(temp, other.rhs);
		MyString myString(temp);
		delete temp;
		return myString;
	}

}

MyString& MyString::operator+= (char c)
    {
   *this = *this + c;
    return *this;
}

MyString& MyString::operator+= (const MyString& rhs) {
   *this = *this + rhs;
    return *this;
}

void MyString:: clear()
{
    delete [] str;
    this->str= NULL;

}

