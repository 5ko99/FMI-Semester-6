#ifndef MYSTRING_H_INCLUDED
#define MYSTRING_H_INCLUDED

class MyString
{
     private:
     char *str;

        public:
        MyString ();
        MyString(const char* str);
        const MyString  operator+(const MyString& rhs);
        size_t size() const;
        char& at(size_t pos);
        const char& at(size_t pos) const;
        bool empty() const;
        char& operator[](size_t pos);
        const char& operator[](size_t pos) const;
        bool operator==(const MyString &rhs) const;
        bool operator<(const MyString &rhs) const;
        MyString operator+(const MyString& rhs) const;
        MyString& operator+=(char c);
        MyString& operator+=(const MyString& rhs);
        void clear();

};

#endif // MYSTRING_H_INCLUDED
