#ifndef VEHICLE_H_INCLUDED
#define VEHICLE_H_INCLUDED
class Vehicle
{
private:
    char* registration;
    char* description;
    size_t space;

public:
    Vehicle(const char* registration, const char* description, std::size_t space);
    const char* registration() const;
    const char* description() const;
     size_t space() const;
};


#endif // VEHICLE_H_INCLUDED
