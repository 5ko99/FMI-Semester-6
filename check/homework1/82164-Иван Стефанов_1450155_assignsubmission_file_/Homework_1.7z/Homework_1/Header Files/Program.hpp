#include <iostream>

#define ADD_VEHICLE 0
#define REMOVE_VEHICLE 1
#define PRINT 2
#define EXIT 3
const size_t MAX = 500;

class Program{
private:
    char userInput_reg[MAX] = {'\0',};
    char userInput_desc[MAX] = {'\0',};
    size_t userInput_spaces = 0;
    int auxValue = 0;
    bool terminateProgram = false;
public:
    static size_t getInitialCapacity();
    static void printOptions();
    int getOption();
    void enterVehicleReg();
    void enterVehicleDesc();
    void enterVehicleSpaces();
    char* getInput_reg();
    char* getInput_desc();
    size_t getInput_spaces() const;
    bool getProgramState() const;
    void endProgram();
};