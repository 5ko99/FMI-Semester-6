#pragma once
#include "MyString.hpp"
class Vehicle{
private:
    MyString reg;
    MyString desc;
    size_t spaces;
public:
    Vehicle(const char* registration,
            const char* description,
            std::size_t space);
    const char* registration() const;
    const char* description() const;
    size_t space() const;
};