#pragma once
#include "VehicleAllocator.hpp"

class Garage{
private:
    Vehicle** cars = nullptr;
    size_t capacity = 0;
    size_t current = 0;
    size_t carCount = 0;
public:
    explicit Garage(size_t size);
    ~Garage();

    void insert(Vehicle& v);
    void erase(const char* registration);
    const Vehicle& at(size_t pos) const;
    const Vehicle& operator[](size_t pos) const;
    bool empty() const;
    size_t size() const;
    void clear();
    const Vehicle* find(const char* registration) const;
};