#pragma once
#include "Vehicle.hpp"
const size_t INITIAL = 16;

class VehicleAllocator {
private:
    Vehicle** available = nullptr;
    size_t capacity_ = INITIAL;
    size_t carCount_ = 0;
public:
    VehicleAllocator();
    ~VehicleAllocator();
    void clear();
    void double_capacity();
    Vehicle* allocate(const char* registration,
                      const char* description,
                      std::size_t space);
    Vehicle* search(const char* registration) const;
};