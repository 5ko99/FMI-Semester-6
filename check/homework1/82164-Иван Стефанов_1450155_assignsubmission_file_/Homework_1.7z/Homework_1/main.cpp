#include "Garage.hpp"
#include "Program.hpp"

int main()
{
    Program garageManager;
    VehicleAllocator allCars;
    Garage myGarage(Program::getInitialCapacity());
    int decision;
    while(!garageManager.getProgramState())
    {
        Program::printOptions();
        decision = garageManager.getOption();
        switch(decision)
        {
            case ADD_VEHICLE:
            {
                garageManager.enterVehicleReg();
                garageManager.enterVehicleDesc();
                garageManager.enterVehicleSpaces();
                allCars.allocate(garageManager.getInput_reg(),
                                 garageManager.getInput_desc(),
                                 garageManager.getInput_spaces());
                try{
                    myGarage.insert(*allCars.search(garageManager.getInput_reg()));
                }
                catch(const std::invalid_argument& e){
                    std::cerr<<"Your car was not added to the garage : "<<e.what()<<std::endl;
                }
                break;
            }
            case REMOVE_VEHICLE:
            {
                garageManager.enterVehicleReg();
                myGarage.erase(garageManager.getInput_reg());
                break;
            }
            case PRINT:
            {
                for(size_t i = 0;i < myGarage.size();++i)
                {
                    std::cout<<"-----------------------------\n";
                    std::cout<<"Registration : ";
                    std::cout<<myGarage.at(i).registration();
                    std::cout<<"\nDescription : ";
                    std::cout<<myGarage.at(i).description();
                    std::cout<<"\nSpaces : ";
                    std::cout<<myGarage.at(i).space();
                    std::cout<<std::endl;
                }
                std::cout<<"-----------------------------\n";
                break;
            }
            case EXIT:
            {
                garageManager.endProgram();
                break;
            }
            default:
            {
                return 1;
            }
        }
    }
    return 0;
}

