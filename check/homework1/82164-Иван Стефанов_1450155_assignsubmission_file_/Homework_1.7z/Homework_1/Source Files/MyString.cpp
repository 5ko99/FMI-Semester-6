#include "MyString.hpp"
#include <stdexcept>
#include <cassert>
#include <cstring>
void copy(char* dest,const char* src,size_t from,size_t len)
{
    for(size_t i = from;i < from + len;++i)
    {
       dest[i] = src[i - from];
    }
}


MyString::MyString() : str(nullptr),length(0){}


MyString::MyString(const MyString& other)
{
    copyFrom(other);
}

MyString& MyString::operator=(const MyString& other)
{
    if(this != &other)
    {
        copyFrom(other);
    }
    return *this;
}

MyString::MyString(MyString&& other) noexcept
{
    length = other.length;
    str = other.str;
    other.length = 0;
    other.str = nullptr;
}

MyString& MyString::operator=(MyString&& other) noexcept
{
    if(this != &other)
    {
        clear();
        length = other.length;
        str = other.str;
        other.length = 0;
        other.str = nullptr;
    }
    return *this;
}

MyString::MyString(const char* str)
{
    length = strlen(str);
    try{
        this->str = new char[length + 1];
    }
    catch(const std::bad_alloc& e){
        std::cerr<<"Constructor failed : "<<e.what()<<std::endl;
        str = nullptr;
        length = 0;
        return;
    }
    copy(this->str,str,0,length);
    this->str[length] = '\0';
}

char& MyString::at(size_t pos)
{
    if(pos >= length)
    {
        throw std::out_of_range("MyString::at() out_of_range");
    }
    return str[pos];
}

const char& MyString::at(size_t pos) const
{
    if(pos >= length)
    {
        throw std::out_of_range("MyString::at() out_of_range");
    }
    return str[pos];
}

char& MyString::operator[](size_t pos)
{
    assert(pos < length);
    return str[pos];
}

const char& MyString::operator[](size_t pos) const
{
    assert(pos < length);
    return str[pos];
}

char& MyString::front()
{
    assert(length > 0);
    return str[0];
}

const char& MyString::front() const
{
    assert(length > 0);
    return str[0];
}

char& MyString::back()
{
    assert(length > 0);
    return str[length-1];
}

const char& MyString::back()const
{
    assert(length > 0);
    return str[length-1];
}

bool MyString::empty() const
{
    return length == 0;
}

size_t MyString::size() const
{
    return length;
}

void MyString::clear()
{
    delete[] str;
    str = nullptr;
    length = 0;
}

void MyString::copyFrom(const MyString& other)
{
    char* buffer = nullptr;
    try{
        buffer  = new char[other.length + 1];
    }
    catch(const std::bad_alloc& e){
        std::cerr<<"Copying failed : "<<e.what()<<std::endl;
        return;
    }
    delete[] str;
    copy(buffer,other.str,0,other.length + 1);
    str = buffer;
    length = other.length;
    buffer = nullptr;
}

void MyString::push_back(char c)
{
    char* buffer = nullptr;
    try{
        buffer = new char[length + 2];
    }
    catch(const std::bad_alloc& e){
        std::cerr<<"push_back failed : "<<e.what()<<std::endl;
        return;
    }
    copy(buffer,str,0,length);
    buffer[length] = c;
    buffer[length + 1] = '\0';
    delete[] str;
    str = buffer;
    ++length;
    buffer = nullptr;
}

void MyString::pop_back()
{
    str[length-1] = '\0';
    --length;
}

MyString& MyString::operator+=(char c)
{
    push_back(c);
    return *this;
}

MyString& MyString::operator+=(const MyString& rhs)
{
    char* buffer = nullptr;
    try{
        buffer = new char[length + rhs.length + 1];
    }
    catch(const std::bad_alloc& e){
        std::cerr<<"operator+= failed : "<<e.what()<<std::endl;
        return *this;
    }
    copy(buffer,str,0,length);
    copy(buffer,rhs.str,length,rhs.length + 1);
    delete[] str;
    str = buffer;
    length += rhs.length;
    buffer = nullptr;
    return *this;
}
MyString MyString::operator+(char c) const
{
    char* buffer = nullptr;
    try{
        buffer = new char[length + 2];
    }
    catch(const std::bad_alloc& e){
        std::cerr<<"operator+ failed : "<<e.what()<<std::endl;
        return *this;
    }
    copy(buffer,str,0,length);
    buffer[length] = c;
    buffer[length + 1] = '\0';
    MyString newStr(buffer);
    delete[] buffer;
    return newStr;
}

MyString MyString::operator+(const MyString& rhs) const
{
    char* buffer = nullptr;
    try{
        buffer = new char[length + rhs.length + 1];
    }
    catch(const std::bad_alloc& e){
        std::cerr<<"operator+ failed : "<<e.what()<<std::endl;
        return *this;
    }
    copy(buffer,str,0,length);
    copy(buffer,rhs.str,length,rhs.length + 1);
    MyString newStr(buffer);
    delete[] buffer;
    return newStr;
}

const char* MyString::c_str() const
{
    return str;
}

bool MyString::operator==(const MyString& rhs) const
{
    if(str == nullptr && rhs.str == nullptr) return true;
    else if(str == nullptr && rhs.str != nullptr ||
            str != nullptr && rhs.str == nullptr)
    return false;
    return strcmp(str,rhs.str) == 0;
}

bool MyString::operator<(const MyString& rhs) const
{
    if(str == nullptr && rhs.str == nullptr) return false;
    else if(str == nullptr && rhs.str != nullptr) return true;
    else if(str != nullptr && rhs.str == nullptr) return false;
    return strcmp(str,rhs.str) < 0;
}

void print(const MyString& rhs)
{
    for(size_t i = 0;i < rhs.length;++i)
    {
        std::cout<<rhs.str[i];
    }
}

//destructor
MyString::~MyString(){
    clear();
}

