#include "Garage.hpp"
#include <cstring>
#include <cassert>

Garage::Garage(const size_t size): capacity(size)
{
    try{
        cars = new Vehicle*[capacity];
    }
    catch(const std::bad_alloc& e){
        std::cerr<<"Memory allocation failed!"<<e.what()<<std::endl;
        cars = nullptr;
        return;
    }
}

Garage::~Garage()
{
    clear();
    delete[] cars;
    capacity = 0;
}


void Garage::clear()
{
    for (size_t i = 0;i < carCount;++i)
    {
        cars[i] = nullptr;
    }
    current = carCount = 0;
}

void Garage::insert(Vehicle& v)
{
    if(v.space() + current > capacity){
        throw std::invalid_argument("Not enough space for this vehicle.");
    }
    for(size_t i = 0;i < carCount;++i)
    {
        if(strcmp(cars[i]->registration(),v.registration()) == 0)
        {
            throw std::invalid_argument("A vehicle with this registration is already in the garage.");
        }
    }
    cars[carCount] = &v;
    current += cars[carCount]->space();
    ++carCount;
}

void Garage::erase(const char* registration)
{
    if(registration == nullptr) return;
    for(size_t i = 0;i < carCount;++i)
    {
        if(strcmp(cars[i]->registration(),registration) == 0)
        {
            current -= cars[i]->space();
            cars[i] = cars[carCount - 1];
            cars[carCount - 1] = nullptr;
            --carCount;
            return;
        }
    }
}

const Vehicle& Garage::at(size_t pos) const
{
    if(pos >= carCount)
    {
        throw std::out_of_range("Invalid index : out_of_range");
    }
    return *cars[pos];
}

const Vehicle& Garage::operator[](size_t pos) const
{
    assert(pos < carCount);
    return *cars[pos];
}

bool Garage::empty() const
{
    return carCount == 0;
}

size_t Garage::size() const
{
    return carCount;
}

const Vehicle* Garage::find(const char* registration) const
{
    for(size_t i = 0;i < carCount;++i)
    {
        if(strcmp(cars[i]->registration(),registration) == 0){
            return cars[i];
        }
    }
    return nullptr;
}