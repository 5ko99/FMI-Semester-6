#include "Program.hpp"

void Program::printOptions()
{
    std::cout<<"\nWhat do you want to do?"<<std::endl;
    std::cout<<"Enter the number in the brackets."<<std::endl;
    std::cout<<"I want to add a vehicle to my garage (0)"<<std::endl;
    std::cout<<"I want to remove a vehicle from my garage (1)"<<std::endl;
    std::cout<<"I want to print the contents of my garage (2)"<<std::endl;
    std::cout<<"I want to exit the program (3)\n"<<std::endl;
}

int Program::getOption()
{
    do{
        std::cin>>auxValue;
        if(!std::cin)
        {
            std::cin.clear();
            std::cin.ignore();
            auxValue = -1;
        }
    } while (auxValue < 0 || auxValue > 3);
    std::cin.ignore();
    return auxValue;
}

void Program::enterVehicleReg()
{
    std::cout<<"Enter vehicle registration : ";
    std::cin.getline(userInput_reg,MAX,'\n');
}
void Program::enterVehicleDesc()
{
    std::cout<<"Enter vehicle description : ";
    std::cin.getline(userInput_desc,MAX,'\n');
}
void Program::enterVehicleSpaces()
{
    std::cout<<"Enter how many spaces the vehicle takes : ";
    std::cin>>userInput_spaces;
}

char* Program::getInput_reg()
{
        return userInput_reg;
}

char* Program::getInput_desc()
{
    return userInput_desc;
}

size_t Program::getInput_spaces() const
{
    return userInput_spaces;
}

bool Program::getProgramState() const
{
    return terminateProgram;
}

void Program::endProgram()
{
    terminateProgram = true;
}

size_t Program::getInitialCapacity()
{
    size_t input;
    std::cout<<"Enter garage capacity : ";
    std::cin>>input;
    return input;
}
