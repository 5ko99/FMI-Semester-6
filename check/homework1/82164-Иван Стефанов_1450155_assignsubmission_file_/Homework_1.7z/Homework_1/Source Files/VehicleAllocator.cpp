#include "VehicleAllocator.hpp"
#include <cstring>

VehicleAllocator::VehicleAllocator()
{
    try{
        available = new Vehicle*[capacity_];
    }
    catch(const std::bad_alloc& e){
        std::cerr<<"Memory allocation failed!"<<e.what()<<std::endl;
        available = nullptr;
        return;
    }
}

VehicleAllocator::~VehicleAllocator()
{
    clear();
    capacity_ = carCount_ = 0;
}

void VehicleAllocator::clear()
{
    for(size_t i = 0;i < carCount_;++i)
    {
        delete available[i];
    }
    delete[] available;
}

void VehicleAllocator::double_capacity()
{
    Vehicle** buffer = nullptr;
    try{
        buffer = new Vehicle*[2*capacity_];
    }
    catch(const std::bad_alloc& e){
        std::cerr<<"Memory allocation failed!"<<e.what()<<std::endl;
        return;
    }
    for(size_t i = 0;i < carCount_;++i)
    {
        buffer[i] = available[i];
        available[i] = nullptr;
    }
    delete[] available;
    available = buffer;
    buffer = nullptr;
    capacity_ *= 2;
}

Vehicle* VehicleAllocator::allocate(const char* registration,
                                    const char* description,
                                    size_t space)
{
    if(carCount_ >= capacity_) double_capacity();

    try{
        available[carCount_] = new Vehicle(registration,
                                          description,
                                          space);
    }
    catch(const std::bad_alloc& e){
        std::cerr<<"Memory allocation failed!"<<e.what()<<std::endl;
        available[carCount_] = nullptr;
        return nullptr;
    }

    ++carCount_;
    return available[carCount_];
}

Vehicle* VehicleAllocator::search(const char* registration) const
{
    for(size_t i = 0;i < carCount_;++i)
    {
        if(strcmp(available[i]->registration(),registration) == 0)
        {
            return available[i];
        }
    }
    return nullptr;
}