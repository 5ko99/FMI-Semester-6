#include "catch_amalgamated.hpp"
#include "VehicleAllocator.hpp"

TEST_CASE("General tests for VehicleAllocator")
{
    VehicleAllocator allCars;
    Vehicle car1("1234","slow",12);
    Vehicle car2("9876","fast",31);
    allCars.allocate(car1.registration(),
                     car1.description(),
                     car1.space());
    Vehicle* aux = allCars.search(car2.registration());
    REQUIRE(aux == nullptr);
    aux = allCars.search(car1.registration());
    REQUIRE(strcmp(aux->registration(),car1.registration()) == 0);
}
