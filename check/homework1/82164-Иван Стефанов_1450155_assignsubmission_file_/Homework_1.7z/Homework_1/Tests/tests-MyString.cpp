#include "catch_amalgamated.hpp"
#include "MyString.hpp"

TEST_CASE("Constructor tests")
{
    SECTION("Default")
    {
        MyString string;
        REQUIRE(string.empty() == true);
    }
    SECTION("Constructor that takes const char* as argument")
    {
        MyString string("hello world!");
        REQUIRE(string.empty() == false);
        REQUIRE(string.size() == strlen("hello world!"));
    }
    SECTION("Copy assignment constructor")
    {
        MyString string1("John Smith");
        MyString string2(string1);
        REQUIRE(string2.empty() == false);
        REQUIRE(string1.size() == string2.size());
        REQUIRE(string2 == string1);
        string2.at(0) = 'A';
        REQUIRE(string2 < string1);
    }
    SECTION("Move assignment constructor")
    {
        MyString string1("Sponge Bob");
        MyString string2(std::move(string1));
        REQUIRE(string1.empty() == true);
        REQUIRE(string2.empty() == false);
        REQUIRE(string2.size() == strlen("Sponge Bob"));
    }
}

TEST_CASE("Assignment operators")
{
    SECTION("copy assignment operator")
    {
        MyString string("John Smith");
        MyString defaultString;
        REQUIRE(defaultString.empty() == true);
        MyString string1("Sponge Bob");
        REQUIRE(!(string == string1));
        REQUIRE(!(string == defaultString));
        defaultString = string1 = string;
        REQUIRE(defaultString.empty() == false);
        REQUIRE(defaultString == string);
        REQUIRE(string1 == string);
        REQUIRE(string1 == defaultString);
        REQUIRE(string1.size() == defaultString.size());
        REQUIRE(string1.size() == strlen("John Smith"));
    }
    SECTION("move assignment operator")
    {
        MyString defaultString;
        REQUIRE(defaultString.empty() == true);
        MyString string2("blue");
        REQUIRE(!(string2 == defaultString));
        defaultString = std::move(string2);
        REQUIRE(defaultString.empty() == false);
        REQUIRE(string2.empty() == true);
        REQUIRE(defaultString.size() == strlen("blue"));
        REQUIRE(defaultString[0] == 'b');
        REQUIRE(defaultString[1] == 'l');
        REQUIRE(defaultString[2] == 'u');
        REQUIRE(defaultString[3] == 'e');
        REQUIRE_THROWS_AS(defaultString.at(4) == 'a',std::out_of_range);
    }
}

TEST_CASE("Public methods tests")
{
   MyString defaultString;
   REQUIRE(defaultString.empty() == true);
   defaultString.push_back('E');
   defaultString += defaultString;
   REQUIRE(defaultString.empty() == false);
   REQUIRE(defaultString.size() == strlen("EE"));
   defaultString += 'A';
   defaultString.push_back(defaultString.front());
   defaultString = defaultString + defaultString;
   defaultString.pop_back();
   MyString expectedResult("EEAEEEA");
   REQUIRE(defaultString.size() == expectedResult.size());
   REQUIRE(defaultString == expectedResult);
   expectedResult.at(expectedResult.size() - 1) = 'E';
   REQUIRE(defaultString < expectedResult);
   defaultString = expectedResult + 'E';
   defaultString.pop_back();
   REQUIRE(defaultString == expectedResult);
   REQUIRE(defaultString.back() == expectedResult.back());
}
