#define CATCH_CONFIG_MAIN
#include "catch_amalgamated.hpp"
