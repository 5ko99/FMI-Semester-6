#include "catch_amalgamated.hpp"
#include "Vehicle.hpp"

TEST_CASE("General tests for Vehicles")
{
    Vehicle car1("1234","fast",12);
    Vehicle car2("1235","fast",12);
    REQUIRE(strcmp(car1.description(),car2.description()) == 0);
    REQUIRE_FALSE(strcmp(car1.registration(),car2.registration()) == 0);
    REQUIRE(car1.space() == car2.space());
    REQUIRE(strcmp(car1.registration(),"1234") == 0);
}