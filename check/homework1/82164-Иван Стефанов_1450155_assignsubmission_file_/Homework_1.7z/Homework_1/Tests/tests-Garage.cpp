#include "catch_amalgamated.hpp"
#include "Garage.hpp"

TEST_CASE("Garage tests")
{
    Garage myGarage(100);
    Vehicle car1("1111","fast",12);
    Vehicle car2("1122","slow",13);
    Vehicle car3("1333","in poor condition",14);
    Vehicle car4("6969","hopeless",16);
    Vehicle car5("1515","ugly",25);
    Vehicle car6("1191","Lada Niva",67);
    REQUIRE_THROWS_AS(strcmp(myGarage.at(2).description(),
                             car3.description()) == 0,
                      std::out_of_range);
    myGarage.insert(car1);
    myGarage.insert(car2);
    myGarage.insert(car3);
    myGarage.insert(car4);
    myGarage.insert(car5);
    //invalid argument : there is no place for this vehicle
    REQUIRE_THROWS_AS(myGarage.insert(car6),std::invalid_argument);
    //invalid argument : there is already a vehicle with this registration
    REQUIRE_THROWS_AS(myGarage.insert(car1),std::invalid_argument);
    REQUIRE(strcmp(myGarage.at(2).description(),car3.description()) == 0);
    REQUIRE(myGarage.empty() == false);
    REQUIRE(myGarage.size() == 5);
    myGarage.erase(car3.registration());
    REQUIRE(myGarage.size() == 4);
    REQUIRE(myGarage.find(car3.registration()) == nullptr);
    myGarage.clear();
    REQUIRE(myGarage.empty() == true);
}