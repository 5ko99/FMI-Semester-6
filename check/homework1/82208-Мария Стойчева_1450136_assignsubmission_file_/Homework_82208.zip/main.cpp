#include <iostream>
#include <cstring>
#include "MyString.h"
#include "Vehicle.h"
#include "Garage.h"
#include "VehicleAllocator.h"

const int MAX_REG_NUM = 100;
const int MAX_DESCRIPTION = 100;

int main()
{
    char answer;
    size_t capacity = 0;
    VehicleAllocator vcle;

    std::cout << "Hello! Create your garage!" << std::endl;
    std::cout << "Enter the capacity of your garage: ";
    std::cin >> capacity;
    std::cin.ignore();
    Garage gar(capacity);
    do
    {
        std::cout << "Hello! You have opened your garage!" << std::endl;
        std::cout << "These are your options! Please select one!" << std::endl;
        std::cout << "1.Create your vehicle" << std::endl;
        std::cout << "2.Put your vehicle in the garage" << std::endl;
        std::cout << "3.Remove your vehicle from the garage" << std::endl;
        std::cout << "4.Destroy your vehicle" << std::endl;
        std::cout << "5.Destroy all of your vehicles" << std::endl;
        std::cout << "6.Print your garage" << std::endl;
        std::cout << "7.Clear your garage" << std::endl;
        std::cout << "8.Leave menu" << std::endl;

        std::cin >> answer;
        std::cin.ignore();

        if (answer == '1')
        {
            std::cout << "Let's create your vehicle" << std::endl;

            size_t occSp;
            char regNum[MAX_REG_NUM];
            char descr[MAX_DESCRIPTION];

            
            std::cout << "Enter the license plate of your vehicle: ";
            std::cin.getline(regNum, MAX_REG_NUM);
            std::cout << "Enter the description of your vehicle: ";
            std::cin.getline(descr, MAX_DESCRIPTION);
            std::cout << "Enter how many parking lots you will need: ";
            std::cin >> occSp;
            std::cin.ignore();

            vcle.newVcle(regNum, descr, occSp);
        }

        if (answer == '2')
        {
            char licpl[MAX_REG_NUM];
            std::cout << "Enter the license plate of the vehicle you want to put in the garage: ";
            std::cin.getline(licpl, MAX_REG_NUM);
            Vehicle *temp = vcle.find(licpl);
            if (temp != nullptr)
            {
                gar.insert(*vcle.find(licpl));
            }
        }

        if (answer == '3')
        {
            char licpl[MAX_REG_NUM];
            std::cout << "Enter the license plate of the vehicle you want to remove from the garage: ";
            std::cin.getline(licpl, MAX_REG_NUM);
            Vehicle *temp = vcle.find(licpl);
            if (temp != nullptr)
            {
                gar.erase(temp->getRegNum());
            }
        }

        if (answer == '4')
        {
            char licpl[MAX_REG_NUM];
            std::cout << "Enter the license plate of the vehicle you want to destroy: ";
            std::cin.getline(licpl, MAX_REG_NUM);
            vcle.delVcle(vcle.find(licpl)->getRegNum());
        }

        if (answer == '5')
        {
            vcle.del();
            std::cout << "You have destroyed all of your vehicles! ";
        }

        if (answer == '6')
        {
            std::cout << "You have " << vcle.getOccpd() << " vehicles in your garage" << std::endl;
            for (int i = 0; i < vcle.getOccpd(); i++)
            {
                std::cout << "Vehicle " << i + 1 << vcle[i].getRegNum() << " " << vcle[i].getDescription() << " " << vcle[i].getOccSpace() << std::endl;
            }
        }

        if (answer == '7')
        {
            gar.clear();
            std::cout << "You have succefully cleared you garage!";
        }
    }

    while (answer != '8');

    return 0;
}
