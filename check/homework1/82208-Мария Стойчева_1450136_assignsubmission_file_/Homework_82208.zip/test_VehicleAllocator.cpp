#include "catch2.hpp"
#include "VehicleAllocator.h"

TEST_CASE("Testing the default constructor")
{
    VehicleAllocator vcleAll;
    REQUIRE(vcleAll.getOccpd() == 0);
    REQUIRE(vcleAll.getCapcty() == 2);
    REQUIRE(vcleAll.empty());
}   

TEST_CASE("Testing the newVcle function")
{
    VehicleAllocator vcleAll;
    vcleAll.newVcle("A 7981 KH", "Black BMW", 2);

    SECTION("Adding a vehicle")
    {
        REQUIRE(vcleAll.getCapcty() == 2);
        REQUIRE(vcleAll.getOccpd() == 1);
        REQUIRE(!vcleAll.empty());
        REQUIRE(strcmp(vcleAll[0].getDescription(), "Black BMW") == 0);
        REQUIRE(strcmp(vcleAll[0].getRegNum(), "A 7981 KH") == 0);
    }

    vcleAll.newVcle("PV 3460 EK", "Grey Mazda", 1);

    SECTION("Trying to add another vehicle")
    {
        REQUIRE(vcleAll.getCapcty() == 2);
        REQUIRE(vcleAll.getOccpd() == 2);
        REQUIRE(!vcleAll.empty());
        REQUIRE(strcmp(vcleAll[1].getDescription(), "Grey Mazda") == 0);
        REQUIRE(strcmp(vcleAll[1].getRegNum(), "PV 3460 EK") == 0);
    }

    vcleAll.newVcle("SA 7402 KH", "Blue porsche", 3);

    SECTION("Testing adding a third vehicle and resizing")
    {
        REQUIRE(vcleAll.getCapcty() == 4);
        REQUIRE(vcleAll.getOccpd() == 3);
        REQUIRE(!vcleAll.empty());
        REQUIRE(strcmp(vcleAll[2].getDescription(), "Blue porsche") == 0);
        REQUIRE(strcmp(vcleAll[2].getRegNum(), "SA 7402 KH") == 0);
    }

    vcleAll.newVcle("SA 7402 KH", "Blue porsche", 3);

    SECTION("Testing adding the same vehicle")
    {
        REQUIRE(vcleAll.getCapcty() == 4);
        REQUIRE(vcleAll.getOccpd() == 3);
        REQUIRE(!vcleAll.empty());
        REQUIRE(strcmp(vcleAll[2].getDescription(), "Blue porsche") == 0);
        REQUIRE(strcmp(vcleAll[2].getRegNum(), "SA 7402 KH") == 0);
    }
}

TEST_CASE("Testing the delVcle function")
{
    VehicleAllocator vcleAll;
    vcleAll.newVcle("SA 7402 KH", "Blue porsche", 3);
    vcleAll.newVcle("PV 3460 EK", "Grey Mazda", 1);
    vcleAll.newVcle("A 7981 KH", "Black BMW", 2);

    SECTION("Testing deleting an existing vehicle")
    {
        vcleAll.delVcle("SA 7402 KH");
        REQUIRE(vcleAll.getCapcty() == 4);
        REQUIRE(vcleAll.getOccpd() == 2);
        REQUIRE(!vcleAll.empty());
        REQUIRE(strcmp(vcleAll[2].getDescription(), "Blue porsche") == 0);
        REQUIRE(strcmp(vcleAll[2].getRegNum(), "SA 7402 KH") == 0);
    }

    SECTION("Testing deleting a vehicle that does not exist")
    {
        vcleAll.delVcle("PA 9482 KH");
        REQUIRE(vcleAll.getCapcty() == 4);
        REQUIRE(vcleAll.getOccpd() == 2);
        REQUIRE(!vcleAll.empty());
    }
}

TEST_CASE("Testing the find function")
{
    VehicleAllocator vcleAll;
    vcleAll.newVcle("A 7981 KH", "Black BMW", 2);
    vcleAll.newVcle("SA 7402 KH", "Blue porsche", 3);
    vcleAll.newVcle("PV 3460 EK", "Grey Mazda", 1);

    SECTION("Testing searching an existing vehicle")
    {
        Vehicle *v1 = vcleAll.find("A 7981 KH");
        REQUIRE(strcmp(v1->getRegNum(), "A 7981 KH") == 0);
        REQUIRE(strcmp(v1->getDescription(),  "Black BMW") == 0);
        REQUIRE(v1->getOccSpace() == 2);

    }

    SECTION("Testing searching a non-existing vehicle")
    {
        Vehicle* invalid=vcleAll.find("PK 6503 KH");
        REQUIRE(invalid==nullptr);
    }
}

TEST_CASE("Testing the delete function")
{
    VehicleAllocator vcleAll;
    vcleAll.newVcle("A 7981 KH", "Black BMW", 2);
    vcleAll.newVcle("SA 7402 KH", "Blue porsche", 3);

    vcleAll.del();

    REQUIRE(vcleAll.getOccpd() == 0);
    REQUIRE(vcleAll.getCapcty() == 2);
    REQUIRE(vcleAll.empty());


}