#ifndef VEHICLE_ALLOCATOR_H
#define VEHICLE_ALLOCATOR_H
#include "Vehicle.h"

const int FIRST_CAPCTY = 2;
const int GROW_STEP = 2;

class VehicleAllocator
{
private:
    std::size_t capcty;
    std::size_t occpd;
    Vehicle **vehicles;

    void resize();
    void deallocate();
    void copy(const VehicleAllocator &other);

public:
    //Constructors
    VehicleAllocator();
    VehicleAllocator(const VehicleAllocator &other);

    //Destructor
    ~VehicleAllocator();

    //Getters
    std::size_t getCapcty() const;
    std::size_t getOccpd() const;

    //Class functions
    void newVcle(const char *_regNum, const char *_description, std::size_t _occSpace);
    Vehicle *find(const char *_regNum);
    void delVcle(const char* _regNum);

    void del();
    bool empty() const;

    //Operator overloading
    VehicleAllocator &operator=(const VehicleAllocator &other);
    const Vehicle &operator[](std::size_t pos) const;
};

#endif