#include "VehicleAllocator.h"
#include <cstring>
#include <cassert>
//Private methods
void VehicleAllocator::resize()
{
    Vehicle **currVehicles = nullptr;

    try
    {
        currVehicles = new Vehicle *[this->capcty * GROW_STEP];
    }
    catch (std::bad_alloc &e)
    {
        std::cout << "Cannot allocate memory";
    }
    for (int i = 0; i < this->capcty *GROW_STEP; i++)
    {
        if (i < this->occpd)
        {
            try
            {
                currVehicles[i] = new Vehicle(*(this->vehicles[i]));
            }
            catch (std::bad_alloc &e)
            {
                std::cout << "Cannot allocate memory";
                for (int j = 0; j < i; j++)
                {
                    delete currVehicles[i];
                }
                delete[] currVehicles;
                return;
            }
        }
        else
        {
            currVehicles = nullptr;
        }
    }
    this->deallocate();
    this->capcty *= GROW_STEP;
    this->vehicles = currVehicles;
}

void VehicleAllocator::deallocate()
{

    if (this->vehicles)
    {
        for (int i = 0; i < this->capcty; i++)
        {
            this->vehicles[i] == nullptr;
        }
        delete[] this->vehicles;
    }
}

void VehicleAllocator::copy(const VehicleAllocator &other)
{
    if (this==&other)
    {
        
        return;
    }
    Vehicle **temp=nullptr;
    try
    {
        temp = new Vehicle *[other.capcty];
    }
    catch (std::bad_alloc &e)
    {
        std::cout << "Cannot allocate memory";
        return;
    }
    for (int i = 0; i < other.capcty; i++)
    {
        if (i < other.occpd)
        {
            try
            {
                temp[i] = new Vehicle(*(other.vehicles[i]));
            }
            catch (std::bad_alloc &e)
            {
                std::cout << "Cannot allocate memory";
                return;
                for (int j = 0; j < i; j++)
                {
                    delete temp[j];
                }
                delete temp;
                return;
            }
        }
        else
        {
            temp[i] == nullptr;
        }
    }
    this->vehicles = temp;
    this->capcty = other.capcty;
    this->occpd = other.occpd;
}

//Constructors
VehicleAllocator::VehicleAllocator()
{
    this->capcty = FIRST_CAPCTY;
    this->occpd = 0;

    try
    {
        this->vehicles = new Vehicle *[FIRST_CAPCTY];
    }
    catch (std::bad_alloc &e)
    {
        std::cout << "Cannot allocate memory";
        return;
    }
    for (int i = 0; i < FIRST_CAPCTY; i++)
    {
        this->vehicles[i] = nullptr;
    }
}

VehicleAllocator::VehicleAllocator(const VehicleAllocator &other)
{
    this->copy(other);
}

VehicleAllocator::~VehicleAllocator()
{
    this->deallocate();
}

std::size_t VehicleAllocator::getCapcty() const
{
    return this->capcty;
}

std::size_t VehicleAllocator::getOccpd() const
{
    return this->occpd;
}

void VehicleAllocator::newVcle(const char *_regNum, const char *_description, std::size_t _occSpace)
{
    if (this->occpd >= this->capcty)
    {
        this->resize();
    }

    if (this->find(_regNum))
    {
        std::cout << "This license plate is already taken!" << std::endl;
        return;
    }
    try
    {
        this->vehicles[this->occpd] = new Vehicle(_regNum, _description, _occSpace);
    }
    catch (std::bad_alloc &e)
    {
        std::cout << "Cannot allocate memory" << std::endl;
        return;
    }
    this->occpd++;
    std::cout << "Your vehicle has been created successfully!" << std::endl;
}

Vehicle *VehicleAllocator::find(const char *_regNum)
{
    for (int i = 0; i < this->occpd; i++)
    {
        if (strcmp(_regNum, this->vehicles[i]->getRegNum()) == 0)
        {
            return this->vehicles[i];
        }
    }
    return nullptr;
}

void VehicleAllocator::delVcle(const char *_regNum)
{
    for (int i = 0; i < this->capcty; i++)
    {
        if (strcmp(_regNum, this->vehicles[i]->getRegNum()) == 0)
        {
            delete this->vehicles[i];
            this->vehicles[i] = this->vehicles[this->occpd - 1];
            this->vehicles[this->occpd - 1] = nullptr;
            this->occpd -= 1;

            std::cout << "You have deleted your vehicle successfully!" << std::endl;
            std::cout<<std::endl;
            return;
        }
    }
}

void VehicleAllocator::del()
{
    for (int i = 0; i < this->capcty; i++)
    {
        if (i<this->getOccpd())
        {
            delete this->vehicles[i];
        }
    }
    delete[]this->vehicles;
    this->occpd = 0;
    this->capcty=FIRST_CAPCTY;
    try
    {
        this->vehicles = new Vehicle *[FIRST_CAPCTY];
    }
    catch (std::bad_alloc &e)
    {
        std::cout << "Cannot allocate memory";
        return;
    }
    for (int i = 0; i < FIRST_CAPCTY; i++)
    {
        this->vehicles[i] = nullptr;
    }
    std::cout << "You have removed all of the vehicles" << std::endl;
}
bool VehicleAllocator::empty() const
{
    return this->occpd == 0;
}

VehicleAllocator &VehicleAllocator::operator=(const VehicleAllocator &other)
{

        this->deallocate();
        this->copy(other);

    return *this;
}

const Vehicle &VehicleAllocator::operator[](std::size_t pos) const
{
    if (pos < this->occpd)
    {
        return *(this->vehicles[pos]);
    }
    else
    {
        throw std::out_of_range("This postion does not exist in the garage");
    }
}