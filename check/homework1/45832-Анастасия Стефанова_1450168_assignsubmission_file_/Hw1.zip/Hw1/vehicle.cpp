#include <iostream>
#include "mystring.h"

class Vehicle
{
    private:
    MyString regNumber;
    MyString descr;
    std::size_t places;

    public:
    Vehicle(const char* registration, const char* description, std::size_t space);
    const char* registration() const;
    const char* description() const;
    std::size_t space() const;
};

Vehicle::Vehicle(const char* registration, const char* description, std::size_t space)
{
    if(registration)
    {
        this-> regNumber = registration;
    }
    else
    {
        regNumber = nullptr;
    }
    if(description)
    {
        this-> descr = description;
    }
    else
    {
        descr = nullptr;
    }
    if(space)
    {
        this-> places = space;
    }
    else
    {
        space = 0;
    }
}

const char* Vehicle::registration() const
{
    return regNumber.c_str();
}

const char* Vehicle::description() const
{
    return descr.c_str();
}

 std::size_t Vehicle::space() const
 {
    return places;
 }