#include "mystring.h"
#include <iostream>
#include <cstring>
#include <assert.h>
#include <cassert>

MyString::MyString()
{
    this->string = nullptr;
    this->length = 0;
}

MyString::MyString(const MyString &myString)
{
    if (myString.string)
    {
        this->string = new char[myString.length+1];
        strcpy(this->string, myString.string);
        length = myString.length;
    }
    else
    {
        string = nullptr;
        length = 0;
    }
}

MyString::~MyString()
{
    if (string)
    {
        delete[] string;
        string = nullptr;
    }
}

MyString& MyString::operator=(const MyString& other)
{
    if (this != &other)
    {
        delete[] string;
        string = nullptr;

        if (other.string)
        {
            this->string = new char[other.length+1];
            strcpy(this->string, other.string);
            length = other.length;
        }
    }

    return *this;

}

MyString::MyString(const char* str)
{
    if (str)
    {
        this->length = strlen(str);
        this->string = new char[length+1];
        strcpy(this->string, str);
    }
    else 
    {
        this->string = nullptr;
        this->length = 0;
    }
}

char& MyString::at(std::size_t pos)
{
    if (length <= pos)
    {
        throw std::out_of_range("Index out of range");
    }
    return this->string[pos];
}

const char& MyString::at(std::size_t pos) const
{
    return this->at(pos);
}

char& MyString::operator[](std::size_t pos)
{
    assert(length > pos);
    return at(pos);
}

const char& MyString::operator[](std::size_t pos) const
{
    return this->operator[](pos);
}

char& MyString::front()
{
    assert(this->length > 0);
    return at(0);
}

const char& MyString::front() const
{
    return this->front();
}

char& MyString::back()
{
    assert(this->length > 0);
    return at(length - 1);
}

const char& MyString::back() const
{
    return this->back();
}

bool MyString::empty() const
{
    if (length == 0)
    {
        return true;
    }

    return false;
}

std::size_t MyString::size() const
{
    return length;
}

void MyString::clear()
{
    delete[] this->string;
    this->string = nullptr;
    length = 0;
}

void MyString::push_back(char c)
{
    char* buffer = new (std::nothrow) char[length + 1];
    if (buffer != nullptr)
    {
        if (this->string != nullptr)
        {
            strcpy_s(buffer, length+1, this->string);
        }
        buffer[length] = c;
        buffer[length+1] = '\0';
        this->string = nullptr;
        this->string = new char[length + 2];
        strcpy_s(this->string,length+2, buffer);
        length++;
    }
}

void MyString::pop_back()
{
    assert(length > 0);
    char* buffer = new char[length];
    this->string[length-1] = '\0';
    strcpy(buffer, this->string);
    this->string = nullptr;
    this->string = new char[length];
    strcpy(this->string,buffer);
    this->length = length-1;
}

MyString& MyString::operator+=(char c)
{
    push_back(c);
    return *this;
}

MyString& MyString::operator+=(const MyString& rhs)
{
    if (this->string == nullptr)
    {
        *this = rhs;
        return *this;
    }
    char* buffer = new (std::nothrow) char[length + rhs.length+1];
    if (buffer != nullptr)
    {
        strcpy(buffer, this->string);
        strcat(buffer, rhs.string);
        MyString newString(buffer);
        delete[] buffer;
        *this = newString;
    }
    return *this;
}

MyString MyString::operator+(char c) const
{
    MyString newString(this->string);
    newString += c;
    return newString;
}

MyString MyString::operator+(const MyString& rhs) const
{
    MyString newString = this->string;
    newString += rhs;
    return newString;
}

const char* MyString::c_str() const
{
    return this->string;
}

bool MyString::operator==(const MyString& rhs) const
{
    if (strcmp(this->string, rhs.string) == 0)
    {
        return true;
    }
    return false;
}

bool MyString::operator<(const MyString& rhs) const
{
    if (strcmp(this->string, rhs.string) < 0)
    {
        return true;
    }
    return false;
}