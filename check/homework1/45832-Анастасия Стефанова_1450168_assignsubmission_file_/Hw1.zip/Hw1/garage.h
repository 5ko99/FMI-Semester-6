#ifndef GARAGE_H_HEADER
#define GARAGE_H_HEADER
#include "mystring.h"
#include "vehicle.cpp"

class Garage
{
    private:
    std::size_t capacity;
    MyString* regNum;
    MyString* descriptions;
    std::size_t takenSpace;
    std::size_t spaces;
    std::size_t cars;

    public:
    Garage(std::size_t size);
    Garage(const Garage &newGarage);
    ~Garage();
    Garage &operator=(const Garage &other);
    void insert(Vehicle& v);
    void erase(const char* registration);
    const Vehicle &at(std::size_t pos) const;
    const Vehicle &operator[](std::size_t pos) const;
    bool empty() const;
    std::size_t size() const;
    void clear();
    const Vehicle* find(const char* registration) const;
};

#endif