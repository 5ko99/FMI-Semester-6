#include <iostream>
#include "vehicle.cpp"
#include "garage.h"
#include "garage.cpp"

int main()
{
    cout <<"Haljs"<<endl;
}