#include <iostream>
#include <assert.h>
#include "garage.h"

Garage::Garage(std::size_t size)
{
    this->capacity = size;
    this->regNum = new MyString[capacity];
    this->descriptions = new MyString[capacity];
    this->takenSpace = new std::size_t[capacity];
    this->spaces = capacity;
    this->cars = 0;
}
Garage::Garage(const Garage &newGarage)
{
    if(newGarage.regNum)
    {
        this->regNum = new MyString[newGarage.capacity];
        this->descriptions = new MyString[newGarage.capacity];
        this->takenSpace = new std::size_t[newGarage.capacity];
        this->spaces = newGarage.spaces;
        this->cars = newGarage.cars;
        for(int i = 0; i < cars; i++)
        {
            this->regNum[i] = newGarage.regNum[i];
            this->descriptions[i] = newGarage.descriptions[i];
            this->takenSpace[i] = newGarage.takenSpace[i];
        }
        this->capacity = newGarage.capacity;
    }
    else
    {
        regNum = nullptr;
        descriptions = nullptr;
        takenSpace = nullptr;
        capacity = 0;
        cars = 0;
        spaces = 0;
    }
}

Garage::~Garage()
{
    delete[] this->regNum;
    delete[] this->descriptions;
    delete[] this->takenSpace;
}

Garage &Garage::operator=(const Garage &other)
{
    if(this != &other)
    {
        delete[] this->regNum;
        this->regNum = nullptr;
        delete[] this->descriptions;
        this->descriptions = nullptr;
        delete[] this->takenSpace;
        this->takenSpace = nullptr;

        if(other.regNum)
        {
            this->regNum = new MyString[other.capacity];
            this->descriptions = new MyString[other.capacity];
            this->takenSpace = new std::size_t[other.capacity];
            this->spaces = other.spaces;
            this->cars = other.cars;
            for(int i = 0; i < cars; i++)
            {
                this->regNum[i] = other.regNum[i];
                this->descriptions[i] = other.descriptions[i];
                this->takenSpace[i] = other.takenSpace[i];
            }
            this->capacity = other.capacity;
        }
        else
        {
            regNum = nullptr;
            descriptions = nullptr;
            takenSpace = nullptr;
            capacity = 0;
            cars = 0;
            spaces = 0;
        }
    }
    return *this
}

void Garage::insert(Vehicle& v)
{
    if(spaces < v.space())
    {
        throw "No space for current vehicle in the garage.";
    }

    for(int i=0; i < capacity; i++)
    {
        if(MyString(v.registration()) == regNum[i])
        {
            throw "Current vihicle already exists in the garage"
        }
    }

    this->regNum[cars] = v.registration();
    this->descriptions[cars] = v.description();
    this->takenSpace[cars] = v.space();
    this->cars++;
    this->capacity -= v.space();
}

void Garage::erase(const char* registration)
{

}

const Vehicle &Garage::at(std::size_t pos) const
{
    if(cars < pos)
    {
        throw std::out_of_range("No vehicle on that position");
    }
    else
    {
        Vehicle *v = new Vehicle(regNum[pos].c_str(), descriptions[pos].c_str(), takenSpace[pos]);
        return *v;
    }
}

const Vehicle &Garage::operator[](std::size_t pos) const
{
    assert (cars > pos);
    return at(pos);
}

bool Garage::empty() const
{
    if(cars == 0)
    {
        return true;
    }
    return false;
}

std::size_t Garage::size() const
{
    return cars;
}

void Garage::clear()
{
    delete[] this->regNum;
    this->regNum = nullptr;
    delete[] this->descriptions;
    this->descriptions = nullptr;
    delete[] this->takenSpace;
    this->takenSpace = nullptr;
    this->cars = 0;
    this->spaces = capacity;

}

const Vehicle* Garage::find(const char* registration) const
{
    for (int i = 0; i < cars; i++)
    {
        if(regNum[i].c_str() == registration)
        {
           return new Vehicle(regNum[i].c_str(), descriptions[i].c_str(), takenSpace[i]);
        }
    }
}