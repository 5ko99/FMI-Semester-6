#pragma once
#include <iostream>
#include "MyString.h"
using std::size_t;
class Vehicle
{
private:
    MyString m_Registration;
    MyString m_Description;
    std::size_t m_Space;

public:
    Vehicle(const char *registration, const char *description, std::size_t);
    const char *registration() const;
    const char *description() const;
    std::size_t space() const;
};