#pragma once
#include "Vehicle.h"
#include <iostream>
class Garage
{
private:
    unsigned int m_Capacity;
    Vehicle **m_Vehicles; 
    std::size_t num_Vehicles;

    void deallocate();

public:
    Garage(std::size_t size);
    Garage(const Garage &other);
    ~Garage();
    void insert(Vehicle &v);
    void erase(const char *registration);
    const Vehicle &at(std::size_t pos) const;
    const Vehicle& operator[](std::size_t pos) const;
    bool empty() const;
    std::size_t size() const;
    void clear();
    const Vehicle *find(const char *registration) const;
};
