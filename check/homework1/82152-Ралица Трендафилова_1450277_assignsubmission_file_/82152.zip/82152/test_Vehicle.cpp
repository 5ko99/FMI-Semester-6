#include "catch2.hpp"
#include "Vehicle.h"
#define CATCH_CONFIG_MAIN

TEST_CASE("Constructor test")
{
    Vehicle car("0147", "honda", 2);
    {
        
        REQUIRE(strcmp(car.registration(),"0147") == 0);
    }
    SECTION("Description")
    {
        
        REQUIRE(strcmp(car.description(),"honda") == 0);
    }
    SECTION("Space")
    {
        REQUIRE(car.space() == 2);
    }
}
