#include <cassert>
#include <cstring>
#include "Garage.h"
using std::cout;
using std::endl;
Garage::Garage(std::size_t size) : m_Capacity(size), m_Vehicles(nullptr), num_Vehicles(0) {}
Garage::Garage(const Garage &other)
{
    num_Vehicles = other.num_Vehicles;
    m_Vehicles = new Vehicle *[num_Vehicles];

    for (std::size_t i = 0; i < num_Vehicles; i++)
    {
        m_Vehicles[i] = other.m_Vehicles[i];
    }
}
Garage::~Garage()
{
    clear();
    num_Vehicles = 0;
}
void Garage::insert(Vehicle &v)
{
    if (m_Capacity >= v.space())
    {
        Vehicle **m_NewVehicles = new (std::nothrow) Vehicle *[num_Vehicles + 1];
        if (m_NewVehicles == nullptr)
            cout << "Error: memory could not be allocated" << endl;
        else
        {
            std::size_t m_NewSize = num_Vehicles + 1;
            std::size_t j = 0;
            for (std::size_t i = 0; i < num_Vehicles; i++)
            {
                if (strcmp(m_Vehicles[i][0].registration(), v.registration()) != 0)
                {
                    m_NewVehicles[j] = m_Vehicles[i];
                    j++;
                }
                else
                    throw std::invalid_argument("Registration is already used!");
            }
            m_NewVehicles[num_Vehicles] = &v;
            deallocate();
            m_Vehicles = m_NewVehicles;
            num_Vehicles = m_NewSize;
            m_Capacity -= v.space();
        }
    }
    else
        throw std::out_of_range("There is not enough space!");
}
void Garage::erase(const char *registration)
{
    Vehicle **m_NewVehicles = new Vehicle *[num_Vehicles - 1];
    std::size_t j = 0;
    for (std::size_t i = 0; i < num_Vehicles; i++)
    {
        if (strcmp(m_Vehicles[i][0].registration(), registration) != 0)
        {
            m_NewVehicles[j] = m_Vehicles[i];
            j++;
        }
        else
            m_Capacity += m_Vehicles[i][0].space();
    }
    deallocate();
    m_Vehicles = m_NewVehicles;
    num_Vehicles--;
}
const Vehicle &Garage::at(std::size_t pos) const
{
    if (pos >= num_Vehicles)
        throw std::out_of_range("The position is out of the range!");
    else
        return m_Vehicles[pos][0];
}
const Vehicle &Garage::operator[](std::size_t pos) const
{
    assert(pos < num_Vehicles);
    return m_Vehicles[pos][0];
}
bool Garage::empty() const
{
    if (num_Vehicles == 0)
        return true;
    else
        return false;
}
std::size_t Garage::size() const
{
    return num_Vehicles;
}
void Garage::clear()
{
    deallocate();
    num_Vehicles = 0;
}
void Garage::deallocate()
{
    for (std::size_t i = 0; i < num_Vehicles; i++)
        m_Vehicles[i] = nullptr;
    delete[] m_Vehicles;
}
const Vehicle *Garage::find(const char *registration) const
{
    for (std::size_t i = 0; i < num_Vehicles; i++)
    {
        if (strcmp(m_Vehicles[i][0].registration(), registration) == 0)
        {
            return m_Vehicles[i];
        }
    }
    return nullptr;
}