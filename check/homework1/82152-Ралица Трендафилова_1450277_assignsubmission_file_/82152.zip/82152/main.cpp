#include <iostream>
#include <cstring>
#include "Garage.h"
using std::cin;
using std::cout;
using std::endl;
void print_Garage(Garage &garage);
void add_Vehicle(Garage &garage, const char *registration, const char *description, std::size_t space);
void erase_Vehicle(Garage &garage, const char *registration);

int main()
{
    cout << "Enter size of garage:" << endl;
    unsigned short command;
    unsigned int size_Garage;
    cin >> size_Garage;
    Garage garage(size_Garage);

    while (true)
    {
        cout << "Enter command: 0.Exit programm  1.Print garage  2.Insert vehicle  3.Delete vehicle" << endl;
        cin >> command;
        if (command == 0)
        {
            break;
        }
        else if (command == 1)
        {
            print_Garage(garage);
        }
        else if (command == 2)
        {
            char reg[32];
            char descr[254];
            std::size_t space;
            cout << "Enter registration:" << endl;
            std::cin >> reg;
            cout << "Enter description:" << endl;
            std::cin >> descr;
            cout << "Enter space:" << endl;
            std::cin >> space;
            add_Vehicle(garage, reg, descr, space);
        }
        else if (command == 3)
        {
            char reg[32];
            cout << "Enter registration:" << endl;
            std::cin >> reg;
            erase_Vehicle(garage, reg);
        }
        cin.clear();
        cin.ignore();
    }
    return 0;
}

void print_Garage(Garage &garage)
{
    for (std::size_t i = 0; i < garage.size(); i++)
    {
        cout << "Registration: " << garage[i].registration() << endl
             << "Description: " << garage[i].description() << endl
             << "Space: " << garage[i].space() << endl;
        cout << "----------------------------------------------------------" << endl;
    }
}
void add_Vehicle(Garage &garage, const char *registration, const char *description, std::size_t space)
{
    try
    {
        Vehicle *vehicle = new Vehicle(registration, description, space);
        garage.insert(*vehicle);
    }
    catch (const std::exception &e)
    {
        std::cerr << e.what() << '\n';
    }
}
void erase_Vehicle(Garage &garage, const char *registration)
{
    garage.erase(registration);
}
