#include "Vehicle.h"
Vehicle::Vehicle(const char *registration, const char *description, std::size_t space)
{
        m_Registration = registration;
        m_Description = description;
        m_Space = space;
    
}
const char *Vehicle::registration() const
{
    return m_Registration.c_str();
}
const char *Vehicle::description() const
{
    return m_Description.c_str();
}
std::size_t Vehicle::space() const
{
    return m_Space;
}