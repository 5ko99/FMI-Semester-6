#include "catch2.hpp"
#include "Garage.h"
#define CATCH_CONFIG_MAIN

TEST_CASE("AT_function")
{
    Garage garage(10);
    Vehicle mazda("V9876OP", "Mazda", 3);
    garage.insert(mazda);
    Vehicle bmw("V0123HH", "BMW", 2);
    garage.insert(bmw);
    Vehicle honda("H9875UU", "Honda", 2);
    garage.insert(honda);
    REQUIRE(strcmp(garage.at(1).registration(), "V0123HH") == 0);
}
TEST_CASE("EMPTY_function")
{
    Garage garage(3);
    Vehicle vehicle("V9876OP", "Mazda", 3);
    garage.insert(vehicle);
    REQUIRE(garage.empty() == false);
}
TEST_CASE("SIZE_function")
{
    Garage garage(10);
    Vehicle mazda("V9876OP", "Mazda", 3);
    garage.insert(mazda);
    Vehicle bmw("V0123HH", "BMW", 2);
    garage.insert(bmw);
    Vehicle honda("H9875UU", "Honda", 2);
    garage.insert(honda);
    REQUIRE(garage.size() == 3);
}
TEST_CASE("FIND_function")
{
    Garage garage(10);
    Vehicle mazda("V9876OP", "Mazda", 3);
    garage.insert(mazda);
    Vehicle bmw("V0123HH", "BMW", 2);
    garage.insert(bmw);
    Vehicle honda("H9875UU", "Honda", 2);
    garage.insert(honda);
    REQUIRE(strcmp(garage.find("H9875UU")->registration(), "H9875UU") == 0);
}