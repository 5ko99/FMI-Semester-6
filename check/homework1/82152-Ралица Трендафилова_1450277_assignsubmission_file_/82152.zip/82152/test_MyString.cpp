#include "catch2.hpp"
#include "MyString.h"
#define CATCH_CONFIG_MAIN


TEST_CASE("AT_function")
{
    MyString car("Toyota");
    REQUIRE(car.at(3) == 'o');
    REQUIRE_THROWS_AS(car.at(8),std::out_of_range);
}
TEST_CASE("FRONT_function")
{
    MyString car("Honda");
    REQUIRE(car.front() == 'H');
}
TEST_CASE("BACK_function")
{
    MyString car("Honda");
    REQUIRE(car.back() == 'a');
}
TEST_CASE("EMPTY_function")
{
    MyString car("Honda");
    MyString str("");
    REQUIRE(car.empty() == 0);
    REQUIRE(str.empty() == 1);
}
TEST_CASE("PUSH_BACK_function")
{
    MyString car("Hond");
    car.push_back('a');
    REQUIRE(strcmp(car.c_str(),"Honda") == 0);
}
TEST_CASE("POP_BACK_function")
{
    MyString car("Hondas");
    car.pop_back();
    REQUIRE(strcmp(car.c_str(), "Honda") == 0);
}
TEST_CASE("Operator[]")
{
    MyString car("Honda");
    REQUIRE(car[3] == 'd');
}
TEST_CASE("SIZE_function")
{
    MyString car("Honda");
    MyString str("");
    REQUIRE(car.size() == 5);
    REQUIRE(str.size() == 0);
}
TEST_CASE("Operator+=")
{
    MyString car("Hond");
    REQUIRE(strcmp((car+='a').c_str(),"Honda") == 0);
}
TEST_CASE("Operator+")
{
    MyString car("Hond");
    REQUIRE(strcmp((car+'a').c_str() ,"Honda") == 0);
}
TEST_CASE("Operator==")
{
    MyString str1("blue");
    MyString str2("pink");
    MyString str3("pink");
    MyString str4("pin");
    REQUIRE((str1 == str2) == 0);
    REQUIRE((str3 == str2) == 1);
    REQUIRE((str3 == str4) == 0);
}
TEST_CASE("Operator<")
{
    MyString str1("blue");
    MyString str2("pink");
    MyString str3("pink");
    MyString str4("pin");
    REQUIRE((str1 < str2) == 1);
    REQUIRE((str3 < str4) == 0);
    REQUIRE((str4 < str3) == 1);
}
