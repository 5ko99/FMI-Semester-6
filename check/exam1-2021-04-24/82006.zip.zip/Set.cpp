//
// Created by User on 4/24/2021.
//

#include "Set.h"

Set::Set():used_space(0),elements(2){}

void Set::insert(int value) {
    if(contains(value))return;
    if(used_space==elements.size()){
        if (used_space==1410065407)throw std::bad_alloc();
        IntBuffer new_buff(elements.size()*2,elements);
        elements=new_buff;
        elements[used_space]=value;
        used_space++;

        sort();
    }else{
        elements[used_space]=value;
        used_space++;
//        std::cout<<"tyk2";
        sort();
    }
}

bool Set::contains(int value) const {
    for(int i=0;i<used_space;i++)
    {
        if (elements[i]==value) return true;
    }
    return false;
}

std::size_t Set::size() const {
    return this->used_space;
}
void swap_(int &first,int &second)
{
    int temp=first;
    first=second;
    second=temp;
}
void Set::sort() {
for(int i=0;i<used_space-1;i++)
{
    for(int j=0;j<used_space-i-1;j++)
    {
        if(elements[j]>elements[j+1])
        {
            swap_(elements[j],elements[j+1]);
        }
    }
}

}

void Set::print() {
    for(int i=0;i<used_space;i++)
    {
        std::cout<<elements[i]<<" ";
    }

}




