
#include "IntBuffer.h"
#include<stdexcept>

void swap(IntBuffer& first,IntBuffer& second)
{
    using std::swap;

    swap(first.size_,second.size_);
    swap(first.buffer,second.buffer);
}

IntBuffer::IntBuffer(std::size_t size)
{
    if(size<=0) throw std::bad_alloc();
    else{
        this->size_=size;
        this->buffer=new int[size];
    }
}

IntBuffer::IntBuffer(std::size_t size, const IntBuffer &other) {
    if(size<=0) throw std::bad_alloc();
    else{
        if(size<=other.size_) {
            for (int i = 0; i < size; i++){
                this->buffer[i]=other.buffer[i];
            }
            this->size_=other.size_;
        }else{
            for(int i=0;i<other.size_;i++)
            {
                this->buffer[i]=other.buffer[i];
            }
            this->size_=other.size_;
            //...
        }
    }
}
IntBuffer::IntBuffer(const IntBuffer &other) {
this->size_=other.size_;
this->buffer=new int[size_];
    for (int i=0;i<size_;i++)this->buffer[i]=other.buffer[i];
}
IntBuffer::~IntBuffer() {
delete [] this->buffer;
this->size_=0;
}

IntBuffer &IntBuffer::operator=(const IntBuffer &other) {
    IntBuffer temp(other);

    swap(*this,temp);
    return *this;
}

int &IntBuffer::at(std::size_t index) {
    if(index>=0 && index<this->size_)return this->buffer[index];
    else throw std::out_of_range("invalid index");
}

const int &IntBuffer::at(std::size_t index) const {
    if(index>=0 && index<this->size_)return this->buffer[index];
    else throw std::out_of_range("invalid index");
}

int &IntBuffer::operator[](std::size_t index) {
    return this->buffer[index];
}

const int &IntBuffer::operator[](std::size_t index) const {
    return this->buffer[index];
}

std::size_t IntBuffer::size() const {
    return this->size_;
}

void IntBuffer::copy_from(const IntBuffer &other, std::size_t count) {
    if(count>other.size_ || count>this->size_) throw std::out_of_range("invalid number for count");
    else{
        for(int i=0;i<count;i++)
        {
            this->buffer[i]=other.buffer[i];
        }
    }
}

bool IntBuffer::operator==(const IntBuffer &other) const {
    if(this->size_==other.size_){
        for(int i=0;i<this->size_;i++)
        {
            if(this->buffer[i]!= other.buffer[i])return false;
        }
        return true;
    }else return false;

}

bool IntBuffer::operator<(const IntBuffer &other) const {
    if(&buffer<&other.buffer) return true;
    else return false;
}



