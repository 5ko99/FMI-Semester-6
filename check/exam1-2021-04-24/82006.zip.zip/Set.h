

#ifndef KONTROLNAOOP_24_04_SET_H
#define KONTROLNAOOP_24_04_SET_H
#include "IntBuffer.h"

class Set {
private:
    int used_space;
    IntBuffer elements;
    void sort();
public:
    Set();
    void insert(int value);
    bool contains(int value) const;
    std::size_t size() const;
    void print();
};


#endif //KONTROLNAOOP_24_04_SET_H
