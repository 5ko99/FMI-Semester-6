
#ifndef KONTROLNAOOP_24_04_INTBUFFER_H
#define KONTROLNAOOP_24_04_INTBUFFER_H
#include <iostream>

class IntBuffer {
private:
    std::size_t size_;
    int* buffer;
public:
    IntBuffer(std::size_t size);
    IntBuffer(std::size_t size, const IntBuffer& other);
    IntBuffer(const IntBuffer& other);
    ~IntBuffer();
    IntBuffer& operator=(const IntBuffer& other);

    int& at(std::size_t index);
    const int& at(std::size_t index) const;
    int& operator[](std::size_t index);
    const int& operator[](std::size_t index) const;
    std::size_t size() const;
    void copy_from(const IntBuffer& other, std::size_t count);
    bool operator==(const IntBuffer& other) const;
    bool operator<(const IntBuffer& other) const;

    friend void swap(IntBuffer& first,IntBuffer& second);
};


#endif //KONTROLNAOOP_24_04_INTBUFFER_H
