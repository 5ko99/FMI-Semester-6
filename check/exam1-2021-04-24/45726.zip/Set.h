#pragma once
#include"IntBuffer.h"

class Set
{
private:
	IntBuffer* elements = nullptr;
	size_t capacity;
	size_t used;

public:
	Set();
	Set(size_t capacity);
	void insert(int value);
	bool contains(int value) const;
	size_t size() const;

};

