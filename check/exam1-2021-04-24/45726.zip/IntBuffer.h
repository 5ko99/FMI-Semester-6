#pragma once
#include <cassert>
#include <cstring>
#include <iostream>
#include <string>
#include<cstddef>
#include<cstdlib>
#include<stdexcept>
using namespace std;

class IntBuffer
{
private:
	int* int_elements = nullptr;
	size_t size_int = 0;

public:
	IntBuffer(size_t size);
	IntBuffer(size_t size, const IntBuffer& other);
	IntBuffer& operator=(const IntBuffer& other);
	~IntBuffer();
	void clear();
	int& at(size_t index);
	const int& at(size_t index) const;
	int& operator[](size_t index);
	const int& operator[](size_t index) const;
	size_t size() const;
	void copy_from(const IntBuffer& other, size_t count);
	bool operator==(const IntBuffer& other) const;
	bool operator<(const IntBuffer& other) const;
};

