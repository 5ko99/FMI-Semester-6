#include "Set.h"

Set::Set()
{
	elements = new IntBuffer(0);
	this->capacity = 2;
	this->used = 0;
}

Set::Set(size_t capacity) : capacity(capacity), used(used)
{
	for (int i = 0; i < capacity; i++)
	{
		//IntBuffer tempt = new IntBuffer(elements[i].size());
		//elements[i] = tempt;

	}
}

bool Set::contains(int value) const
{
	for (int i = 0; i < used; i++)
	{

	}
}

size_t Set::size() const
{
	return used;
}
