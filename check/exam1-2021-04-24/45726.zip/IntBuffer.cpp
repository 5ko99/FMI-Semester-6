#include "IntBuffer.h"

IntBuffer::IntBuffer(size_t size)
{
	int_elements = new int[size];
	if (int_elements == nullptr)
	{
		throw bad_alloc();
	}

	this->size_int = size;
}

IntBuffer::IntBuffer(size_t size, const IntBuffer& other)
{
	size_t temp_size;
	if (this != &other)
	{
		int_elements = new int[size];
		if (int_elements == nullptr)
		{
			throw bad_alloc();
		}

		if (size >= other.size_int)
		{
			temp_size = other.size_int;
		}
		else
		{
			temp_size = size;
		}

		for (int i = 0; i < temp_size; i++)
		{
			int_elements[i] = other.int_elements[i];
		}
		this->size_int = other.size_int;
	}
}

IntBuffer& IntBuffer::operator=(const IntBuffer& other)
{
	if (this != &other)
	{
		clear();
		int_elements = new int[other.size_int];
		for (int i = 0; i < other.size_int; i++)
		{
			int_elements[i] = other.int_elements[i];
		}
		this->size_int = other.size_int;
	}
	return *this;
}

IntBuffer::~IntBuffer()
{
	clear();
}

void IntBuffer::clear()
{
	delete[] int_elements;
}

int& IntBuffer::at(size_t index)
{
	if (index >= size())
	{
		throw out_of_range("Invalid index!");
	}
	else
	{
		return int_elements[index];
	}
}

const int& IntBuffer::at(size_t index) const
{
	return at(index);
}

int& IntBuffer::operator[](size_t index)
{
	return int_elements[index];
}

const int& IntBuffer::operator[](size_t index) const
{
	return int_elements[index];
}

size_t IntBuffer::size() const
{
	return size_int;
}

void IntBuffer::copy_from(const IntBuffer& other, size_t count)
{
	int_elements = new int[count];
	if (int_elements == nullptr)
	{
		throw bad_alloc();
	}

	if (count >= other.size_int || count >= size_int)
	{
		throw out_of_range("Out of range!");
	}

	for (int i = 0; i < count; i++)
	{
		int_elements[i] = other.int_elements[i];
	}
	this->size_int = count;

}

bool IntBuffer::operator==(const IntBuffer& other) const
{
	bool check = false;
	if (size_int == other.size_int)
	{
		for (int i = 0; i < size_int; i++)
		{
			if (int_elements[i] != other.int_elements[i])
			{
				return check;
			}
		}
		check = true;
	}
	return check;
}

bool IntBuffer::operator<(const IntBuffer& other) const
{
	if (size_int < other.size_int)
	{
		return true;
	}
	else if (other.size_int < size_int)
	{
		return false;
	}
	else
	{
		for (int i = 0; i < size_int; i++)
		{
			if (int_elements[i] < other.int_elements[i])
			{
				return true;
			}
			else if (int_elements[i] > other.int_elements[i])
			{
				return false;
			}
		}
		return false;
	}
}
