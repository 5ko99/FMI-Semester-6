#pragma once

class IntBuffer
{
private:
	int* m_array = nullptr;
	std::size_t m_size = 0;

public:
	IntBuffer(std::size_t size);

	IntBuffer(const IntBuffer& other);

	IntBuffer& operator=(const IntBuffer& other);

	IntBuffer(const std::size_t size, const IntBuffer& other);

	int& at(std::size_t index);

	const int& at(std::size_t index) const;

	int& operator[](std::size_t index);

	const int& operator[](std::size_t index) const;

	std::size_t size() const;

	void copy_from(const IntBuffer& other, std::size_t count);

	bool operator==(const IntBuffer& other) const;

	bool operator<(const IntBuffer& other) const;

	int getSize();

	int* getArray();

	void setSize(int size);

	~IntBuffer();
};

class Set
{
private:
	IntBuffer elements;
	
	void sort(IntBuffer& array);

public:

	void insert(int value);

	~Set();
};