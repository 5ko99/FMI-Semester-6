#pragma once
#define _CRT_SECURE_NO_WARNINGS 
#include<iostream>
#include"IntBuffer.h"
#include<cstdlib>

class Set : public IntBuffer {
public:
	static Set& i();

	Set();
	Set(const Set& other);
	Set& operator=(const Set& other);
	~Set();

	void resize();
	void sort(int* arr, int Size);
	std::size_t SearchForDublicates(int* arr, int Size);
	void insert(int value);
	bool contains(int value) const;
	std::size_t size() const;
	void run();
	
protected:
	void clear();
	void copy(const Set& other);

protected:
	int* elements;
	std::size_t elCapacity;
};