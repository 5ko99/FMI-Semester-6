#include "IntBuffer.h"

IntBuffer::IntBuffer(const int m_size)
	: Size(m_size)
	, arr(nullptr)
{
}

IntBuffer::IntBuffer(const IntBuffer& other)
{
	copy(other);
}

IntBuffer& IntBuffer::operator=(const IntBuffer& other)
{
	if (this != &other) {
		clear();
		copy(other);
	}
	return *this;
}

IntBuffer::~IntBuffer()
{
	clear();
}

IntBuffer::IntBuffer(std::size_t size)
{
	arr = new int[Size];
	if (!arr) {
		std::bad_alloc;
	}
}

int& IntBuffer::at(std::size_t index)
{
	if (index <= Size) {
		return arr[index];
	}
	else {
		std::out_of_range;
	}
}

const int& IntBuffer::at(std::size_t index) const
{
	if (index <= Size) {
		return arr[index];
	}
	else {
		std::out_of_range;
	}
}

int& IntBuffer::operator[](std::size_t index)
{
	return arr[index];
}

const int& IntBuffer::operator[](std::size_t index) const
{
	return arr[index];
}

std::size_t IntBuffer::size() const
{
	return Size;
}

bool IntBuffer::operator==(const IntBuffer& other) const
{
	int cnt = 0;
	if (Size == other.Size) {
		for (int i = 0; i < Size; i++) {
			if (arr[i] == other.arr[i]) {
				cnt++;
			}
		}
	}
	if (cnt == Size) {
		return true;
	}
	else {
		return false;
	}
}

bool IntBuffer::operator<(const IntBuffer& other) const
{
	if (Size < other.Size) {
		return true;
	}
	return false;
}

void IntBuffer::clear()
{
	delete[] arr;
	arr = nullptr;
}

void IntBuffer::copy(const IntBuffer& other)
{
	Size = other.Size;
}
