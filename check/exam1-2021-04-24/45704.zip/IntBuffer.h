#pragma once
#define _CRT_SECURE_NO_WARNINGS 
#include<iostream>

class IntBuffer {
public:
	IntBuffer(const int m_size = 0);
	IntBuffer(const IntBuffer& other);
	IntBuffer& operator=(const IntBuffer& other);
	~IntBuffer();

	IntBuffer(std::size_t size);
	int& at(std::size_t index);
	const int& at(std::size_t index) const;
	int& operator[](std::size_t index);
	const int& operator[](std::size_t index) const;
	std::size_t size() const;
	bool operator==(const IntBuffer& other) const;
	bool operator<(const IntBuffer& other) const;

protected:
	void clear();
	void copy(const IntBuffer& other);

protected:
	int* arr;
	std::size_t Size;
	
};
