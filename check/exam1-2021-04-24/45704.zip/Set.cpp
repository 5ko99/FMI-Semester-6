#include "Set.h"

Set& Set::i()
{
	static Set a;
	return a;
}

Set::Set()
	: elCapacity(2)
	, elements(new int[elCapacity])
{
}

Set::Set(const Set& other)
{
	copy(other);
}

Set& Set::operator=(const Set& other)
{
	if (this != &other) {
		clear();
		copy(other);
	}
	return *this;
}

Set::~Set()
{
	clear();
}

void Set::resize()
{
	if (Size >= elCapacity) {
		int* a = new int[2 * elCapacity];
		for (int i = 0; i < elCapacity; i++) {
			a[i] = arr[i];
		}
		elCapacity = 2 * elCapacity;
		delete[] arr;
		arr = nullptr;
		arr = a;
		delete[] a;
		a = nullptr;
	}
}

void Set::sort(int* arr, int Size)
{
	for (int i = 0; i < Size - 1; i++) {
		for (int j = i + 1; j < Size; j++) {
			if (arr[i] > arr[j]) {
				std::swap(arr[i], arr[j]);
			}
		}
	}
}

std::size_t Set::SearchForDublicates(int* arr, int Size)
{
	std::size_t newSize = Size;
	for (int i = 1; i < Size; i++) {
		if (arr[i - 1] == arr[i]) {
			for (int j = i; j < Size; j++) {
				std::swap(arr[i], arr[j]);
				newSize--;
			}
		}
	}
	Size = newSize;
	return Size;
}

void Set::insert(int value)
{
	bool flag = false;
	for (int i = 0; i < Size; i++) {
		if (arr[i] == value) {
			flag = true;
		}
	}
	if (flag == true) {
		return;
	}
	else {
		if (Size >= elCapacity) {
			resize();
			if (!arr) {
				std::bad_alloc;
			}
		}
		arr[Size] = value;
		Size++;
	}
	sort(arr, Size);
}

bool Set::contains(int value) const
{
	std::size_t newSize = Size / 2;
	int mid = arr[newSize];
	if (mid == value) {
		return true;
	}
	else if (mid > value) {
		for (int i = newSize; i < Size; i++) {
			if (arr[i] == value) {
				return true;
			}
		}
		return false;
	}
	else if (mid < value) {
		for (int i = 0; i < newSize; i++) {
			if (arr[i] == value) {
				return true;
			}
		}
		return false;
	}
	
}

std::size_t Set::size() const
{
	return Size;
}

void Set::run()
{
	std::size_t N;
	std::cout << "Enter N: ";
	std::cin >> N;
	int* generated = new int[N];
	if (!generated) {
		std::bad_alloc;
	}
	for (int i = 0; i < N; i++) {
		generated[i] = std::rand() % 100;
	}
	sort(generated, N);
	SearchForDublicates(generated, N);
	int* result = new int[N];
	if (!result) {
		std::bad_alloc;
	}
	int num;
	int cnt = 0;
	while (cnt != N) {
		bool f = false;
		std::cout << "Enter a number: ";
		std::cin >> num;
		for (int i = 0; i < N; i++) {
			if (generated[i] == num) {
				result[i] = num;
				std::cout << "Your answer is correct!" << std::endl;
				f = true;
				cnt++;
				continue;
			}			
		}
		if (f == false) {
			std::cout << "Your answer is wrong!" << std::endl;
		}
	}
}

void Set::clear()
{
	delete[] elements;
	elements = nullptr;
}

void Set::copy(const Set& other)
{
	elCapacity = other.elCapacity;
	elements = new int[elCapacity];
	for (int i = 0; i < Size; i++) {
		elements[i] = other.elements[i];
	}
}
