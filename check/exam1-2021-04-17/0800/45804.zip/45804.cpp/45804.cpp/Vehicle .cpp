#include"Vehicle.h"


Vehicle::Vehicle(Registration reg) {
	regnum = reg;
}

Vehicle::Vehicle(const char* regnum, const char* description) {
	this->regnum = regnum;
	this->description = description;
}