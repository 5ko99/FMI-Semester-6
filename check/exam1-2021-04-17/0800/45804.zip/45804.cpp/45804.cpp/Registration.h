#pragma once
#include<iostream>
#include<cctype>
#include<string>;

class Registration {
private:
	char infromation[9];
	bool reg_check(const char* str);

public:
	Registration(const char* str);
	Registration& operator=(const char* str);
	bool operator==(const char* str) const;
	const char* toString() const;

};