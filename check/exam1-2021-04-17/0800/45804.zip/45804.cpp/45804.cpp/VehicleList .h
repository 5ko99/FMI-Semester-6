#pragma once
#include"Vehicle.h"


class VehicleList {
private:
	size_t cpcty;
	Vehicle** list;
	size_t vehicle_counter;
public:
	VehicleList(std::size_t capacity);
	VehicleList(const VehicleList& old_list);
	~VehicleList();
	void insert(const char* regnum, const char* description);
	const Vehicle& at(std::size_t index) const;
	const Vehicle& operator[](std::size_t index) const;
	bool empty() const;
	std::size_t capacity() const;
	std::size_t size() const;
	const Vehicle* find(const char* regnum) const;
};