#include "Registration.h"





bool Registration::reg_check(const char* str) {
	size_t size = strlen(str);
	if (size == 7) {
		for (size_t i = 0; i < size; i++) {
			if (i == 0)
			{
				if (isdigit(str[i])) {
					return 0;
				}
				else {
					continue;
				}
			}
			if (i > 0 && i < 5) {
				if (isalpha(str[i])) {
					return 0;
				}
				else {
					continue;
				}
			}
			if (i >= 5) {
				if (isdigit(str[i])) {
					return 0;
				}
				else {
					continue;
				}
			}
		}
	}
	else if (size == 8) {
		for (size_t i = 0; i < size; i++) {
			if (i >= 0 && i < 2)
			{
				if (isdigit(str[i])) {
					return 0;
				}
				else {
					continue;
				}
			}
			if (i >=2 && i < size - 1) {
				if (isalpha(str[i])) {
					return 0;
				}
				else {
					continue;
				}
			}
			if (i >= size - 1) {
				if (isdigit(str[i])) {
					return 0;
				}
				else {
					continue;
				}
			}
		}
	}
	return 1;
}

Registration::Registration(const char* str) {
	size_t sz = strlen(str);
	if (reg_check(str) == 0) {
		std::exception;
	}
	else {
		for (size_t i = 0; i <= sz; i++) {
			this->infromation[i] = str[i];
		}
	}
	
	
}


Registration& Registration:: operator=(const char* str) {
	size_t size = strlen(str);
	if (reg_check(str) == 0) {
		std::exception;
	}
	else {
		for (size_t i = 0; i <= size; i++) {
			this->infromation[i] = '\0';
		}
		for (size_t i = 0; i <= size; i++) {
			this->infromation[i] = str[i];
		}
	}
	return *this;
}

bool Registration:: operator==(const char* str) const {
	if (strcmp(str, this->infromation) == 0) {
		return true;
	}
	else {
		return false;
	}
}


const char* Registration::toString() const {
	return this->infromation;
}