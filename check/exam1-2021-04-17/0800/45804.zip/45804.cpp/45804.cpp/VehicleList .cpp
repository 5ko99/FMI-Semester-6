#include"VehicleList .h"



VehicleList::VehicleList(std::size_t capacity) {
	this->cpcty = capacity;
	this->list = new Vehicle * [capacity];
	this->vehicle_counter = 0;
	for (size_t i = 0; i < capacity; i++) {
		list[i] = nullptr;
	}
	
}

VehicleList::VehicleList(const VehicleList& old_list) {
	this->cpcty = old_list.cpcty;
	this->vehicle_counter = old_list.vehicle_counter;
	for (size_t i = 0; i < cpcty; i++) {
		this->list[i] = old_list.list[i];
	}
}


VehicleList:: ~VehicleList() {
	for (size_t i = 0; i < this->cpcty; i++) {
		delete[] list[i];
	}
	delete[] this->list;
}



void VehicleList:: insert(const char* regnum, const char* description) {
	if (this->vehicle_counter + 1 > this->cpcty) {
		std::exception;
	}
	for (size_t i = 0; i < this->cpcty; i++) {
		if (list[i] == &Vehicle(regnum, description)) {
			std::exception;
		}
	}
	
	this->list[vehicle_counter] = &Vehicle(regnum, description);
	vehicle_counter += 1;
}


const Vehicle& VehicleList::at(std::size_t index) const {
	if (cpcty < index || index < 0) {
		throw "out of range";
	}
	else {
		return *list[index];
	}
}

const Vehicle& VehicleList::operator[](std::size_t index) const {
	return *this->list[index];
}


bool VehicleList:: empty() const {
	if (vehicle_counter == 0) {
		return 1;
	}
	else {
		return 0;
	}
}


std::size_t VehicleList:: capacity() const {
	return cpcty;
}


std::size_t  VehicleList ::size() const {
	return this->vehicle_counter;
}

//const Vehicle* VehicleList::find(const char* regnum) const {
//	for (size_t i = 0; i < vehicle_counter; i++) {
//		if (list[i] == regnum) {
//			return list[i];
//		}
//	}
//}