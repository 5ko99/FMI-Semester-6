#pragma once
#include"Registration.h"


class Vehicle{
private:
	Registration regnum();
	std::string description;
public:
	Vehicle(const char* regnum, const char* description);
};