#include "registration.h"
#include <cassert>
#include <cstring>
#include <iostream>
#include <string>
#include <cctype>

using namespace std;
Registration::Registration(const char* s) {
	size_t len = strlen(s);

	if (len != 8 && len != 7) {
		throw std::exception("Invalid input");
	}

	if (len == 8)
	{
		for (size_t i = 0; i < 2; i++) {
			if (isalpha(s[0]) == 0) {
				throw std::exception("Invalid registration");
			}
		}

		for (size_t i = 2; i < 5; i++) {
			if (isdigit(s[i]) == 0) {
				throw std::exception("Invalid registration");
			}
		}

		for (size_t i = 5; i < 7; i++) {
			if (isalpha(s[i]) == 0) {
				throw std::exception("invalid registration");
			}
		}
	}

	if (len == 7) {

		if (isalpha(s[0]) == 0) {
			throw std::exception("Invalid registration");
		}


		for (size_t i = 1; i < 4; i++) {
			if (isdigit(s[i]) == 0) {
				throw std::exception("Invalid registration");
			}
		}

		for (size_t i = 4; i < 6; i++) {
			if (isalpha(s[i]) == 0) {
				throw std::exception("Invalid registration");
			}
		}


	}

	for (size_t i = 0; i < 9; i++) {
		this->registration[i] = s[i];
	}

}

Registration& Registration::operator=(const char* s) {

	size_t len = strlen(s);
	if (len != 9) {
		throw _exception();
	}
	for (size_t i = 0; i < 9; i++) {
		this->registration[i] = s[i];
	}
	return *this;
}

bool Registration::operator==(const char* str)const {
	size_t len = strlen(str);
	if (len != 9) {
		return 0;
	}

	for (size_t i = 0; i < 9; i++) {
		if (this->registration[i] != str[i]) {
			return 0;
		}
	}
	return 1;
}

const char* Registration::toString() const {
	char* str = new char[10];
	for (size_t i = 0; i < 9; i++) {
		str[i] = this->registration[i];
	}
	str[9] = '\0';
	return str;
}

