#include"Vehicle.h"

Vehicle::Vehicle(const char* regnum, const char* description) {
	size_t len = strlen(description);
	this->regnum.operator=(regnum);
	this->description = description;
}

Vehicle::Vehicle(const char* regnum, const char* description) {
	size_t len = strlen(description);
	this->regnum.operator=(regnum);
	this->description = description;
}








