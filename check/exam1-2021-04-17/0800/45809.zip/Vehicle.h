#pragma once
#include"registration.h"
#include<cstring>
#include<iostream>
#include<string>
using namespace std;
class Vehicle {
private:
	Registration regnum = nullptr;;
	string description;
public:

	Vehicle(const char* regnum, const char* description);
	Vehicle(const char& regnum, const char& description);
	Vehicle& operator=(const char& regnum);



};