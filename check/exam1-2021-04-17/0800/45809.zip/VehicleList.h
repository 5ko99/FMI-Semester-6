#pragma once
#include<iostream>
#include"Vehicle.h"
#include"cassert"
using namespace std;
class VehicleList {
private:
	size_t capacity = 0;
	Vehicle** vehicles;
	size_t amount_vehicles = 0;
	Vehicle entity;

public:

	friend istream& operator>>(istream& input, VehicleList& v) {
		input >> v.capacity;
		return input;
	}

	VehicleList(size_t capacity) {
		vehicles = new Vehicle * [capacity];
		for (size_t i = 0; i < capacity; i++) {
			vehicles[i] = nullptr;
		}

	}
	void insert(const char* regnum, const char* description) {
		if (capacity == 0) {
			throw std::exception("Not enough space in the list");
		}
		vehicles[amount_vehicles]->Vehicle::Vehicle(regnum, description);
		this->amount_vehicles += 1;
		this->capacity -= 1;
	}

	const Vehicle& at(size_t index)const {
		if (index > amount_vehicles || index < 0) {
			throw std::exception("Invalid input");
		}
		return *vehicles[index];
	}

	const Vehicle& operator[](std::size_t index) const {
		assert(index < amount_vehicles || index>0);

		return *vehicles[index];
	}

	bool empty() const {
		if (amount_vehicles == 0) {
			return 1;
		}
		return 0;
	}

	size_t capacity() const {
		return this->capacity;
	}

	size_t size() const {
		return this->amount_vehicles;
	}

	const Vehicle* find(const char* regnum) const {
		for (size_t i = 0; i < amount_vehicles; i++) {
			if (vehicles[i].regnum == regnum) {
				return vehicles[i].regnum;
			}
		}
	}






};