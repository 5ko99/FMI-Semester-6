#ifndef Vehicle_H
#define Vehicle_H

class Vehicle{

public:
    const char* description();

private:
    const char* ragnum();

};


#endif // Vehicle_H
