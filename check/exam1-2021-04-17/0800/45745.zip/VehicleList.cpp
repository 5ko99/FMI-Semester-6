#include <iostream>
#include "VehicleList.hpp"

using namespace std;

bool VehicleList::empty()
{
    if (size==0){
        cout<<"Empty"<<endl;
    }
}

void VehicleList :: VehicleList(std::size_t capacity)
{
    size=0;
    for( int i=0; i<capacity; i++)
    {
        cout<<size[i]<<endl;
    }
}
 const VehicleList:: find(const char* regnum)
{

}
