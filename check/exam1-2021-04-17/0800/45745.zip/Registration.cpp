#include <iostream>
#include <stdexcept>
#include "Registration.hpp"
#include "Vehicle.hpp"

using namespace std;

char Registration::Registration(const char* str)
{

}
bool Registration::operator==(const char* str) const
{

}
