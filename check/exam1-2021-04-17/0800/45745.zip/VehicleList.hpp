#ifndef VehicleList_H
#define VehicleLIst_H


class VehicleList{


public:
    void VehicleList(std::size_t capacity);

    void insert(const char* regnum, const char* description);

    const Vehicle& at(std::size_t index) const;

    const Vehicle& operator[](std::size_t index) const;

    bool empty() const;

    std::size_t size() const;

    const Vehicle* find(const char* regnum) const;

private:
    std::size_t capacity() const;


};
#endif // VehicleList_H
