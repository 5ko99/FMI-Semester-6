#include <stdexcept>

#include "RegistrationList.h"

RegistrationList::RegistrationList(std::size_t capacity) {
    this->capacity = capacity;
    this->size = 0;
    this->registrations = new Registration *[capacity];
}

RegistrationList::RegistrationList(const RegistrationList &rhs) {
    this->copyFrom(rhs);
}

RegistrationList::~RegistrationList() {
    this->releaseMemory();
}

size_t RegistrationList::getCapacity() const {
    return this->capacity;
}

size_t RegistrationList::getSize() const {
    return this->size;
}

void RegistrationList::insert(const std::string &id, const Date &date) {
    if (this->size == this->capacity) {
        throw std::invalid_argument("Registrations are full!");
    }

    int index;
    Registration *registration = new Registration(id, date);

    if (!this->validateIsUnique(*registration)) {
        throw std::invalid_argument("Registrations already exists!");
    }

    index = findPosition(*registration);

    for (int i = this->size; i > index; --i) {
        this->registrations[i] = this->registrations[i - 1];
    }
    this->registrations[index] = registration;

    this->size++;
}

const Registration &RegistrationList::at(std::size_t index) const {
    if (index >= this->size) {
        throw std::out_of_range("Invalid index");
    }

    return *this->registrations[index];
}

bool RegistrationList::empty() const {
    return (this->size == 0);
}

RegistrationList &RegistrationList::operator=(const RegistrationList &rhs) {
    if (this != &rhs) {
        this->releaseMemory();
        this->copyFrom(rhs);
    }

    return *this;
}

int RegistrationList::findPosition(const Registration &rhs) const {
    int index = 0;
    while (index < this->size && *(this->registrations[index]) < rhs) {
        index++;
    }

    return index;
}

bool RegistrationList::validateIsUnique(const Registration &rhs) const {
    for (int i = 0; i < this->size; ++i) {
        if (*(this->registrations[i]) == rhs) {
            return false;
        }
    }

    return true;
}

void RegistrationList::releaseMemory() {
    for (int i = 0; i < this->size; ++i) {
        delete this->registrations[i];
    }

    delete[] this->registrations;
}

void RegistrationList::copyFrom(const RegistrationList &rhs) {
    this->capacity = rhs.capacity;
    this->size = rhs.size;
    this->registrations = new Registration *[rhs.capacity];

    for (int i = 0; i < rhs.size; ++i) {
        this->registrations[i] = rhs.registrations[i];
    }
}