#pragma once

#include <string>

#include "Date.h"

class Registration {
private:
    std::string id;
    const Date *date;


public:
    Registration(const std::string &id, const Date &date);

    Registration(const Registration &rhs);

    ~Registration();

    const std::string &getId() const;

    const Date *getDate() const;

public:
    Registration &operator=(const Registration &rhs);

    bool operator==(const Registration &rhs) const;

    bool operator<(const Registration &rhs) const;
};
