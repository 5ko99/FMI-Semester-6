// 
// СУ "Св. Климент Охридски"
// Факултет по математика и информатика
// Курс Обектно-ориентирано програмиране 2020/21
// Контролно 1
// 
// Име: Йордан Йорданов
// ФН: 82159
// Специалност: Компютърни науки
// Курс: I-ви
// Административна група: 2-ра
// Ден, в който се явявате на контролното: 17.04.21
// Начален час на контролното: 10:30
// Кой компилатор използвате: GCC
//

#define _CRT_SECURE_NO_WARNINGS

#include <cassert>
#include <cstring>
#include <iostream>
#include <stdexcept>

#include "RegistrationList.h"

using std::cout;
using std::cin;
using std::endl;
using std::string;

int main() {
    int capacity;
    cin>>capacity;
    RegistrationList rl(capacity);

    rl.insert(string("abv"), Date(1, 1, 2021));
    rl.insert(string("bac"), Date(1, 1, 2021));
    rl.insert(string("bba"), Date(2, 1, 2021));
    rl.insert(string("aab"), Date(1, 1, 2021));


    RegistrationList rl1(rl);
    RegistrationList rl2 = rl1;

    for (int i = 0; i < rl1.getSize(); ++i) {
        cout<<rl1.at(i).getId()<<std::endl;
        cout<<rl1.at(i).getDate()->getDay()<<" " << rl1.at(i).getDate()->getMonth()<<" "<< rl1.at(i).getDate()->getYear()<<" "<<std::endl;
    }

    return 0;
}