#include "Date.h"

#include <stdexcept>

Date::Date(unsigned int day, unsigned int month, unsigned int year) {
    if(!validate(day, month, year)){
        throw std::invalid_argument("Incorrect date");
    }

    this->day = day;
    this->month = month;
    this->year = year;
}

unsigned int Date::getDay() const {
    return this->day;
}

unsigned int Date::getMonth() const {
    return this->month;
}

unsigned int Date::getYear() const {
    return this->year;
}

bool Date::operator==(const Date &rhs) const {

    if (this->day == rhs.day && this->month == rhs.month && this->year == rhs.year){
        return true;
    }

   /* if (this->day != rhs.day) {
        return false;
    }

    if (this->month != rhs.month) {
        return false;
    }

    if (this->year != rhs.year) {
        return false;
    }*/

    return false;
}

bool Date::operator<(const Date &rhs) const {
    if (this->year > rhs.year) {
        return false;
    } else if (this->year == rhs.year) {
        if (this->month > rhs.month) {
            return false;
        } else if (this->month == rhs.month) {
            if (this->day > rhs.day) {
                return false;
            } else if (this->day == rhs.day) {
                return false;
            }
        }
    }

    return true;
}

bool Date::validate(int day, int month, int year) const {
    if (day <= 0 || day > 31 || month <= 0 || month > 12) {
        return false;
    }

    switch (month) {
        case 2:
            if (isLeapYear(year)) {
                if (day > 29) {
                    return false;
                }
            } else {
                if (day > 28) {
                    return false;
                }
            }
            break;
        case 4:
        case 6:
        case 9:
        case 11:
            if (day > 30) {
                return false;
            }
            break;

        default:
            break;
    }

    return true;
}

bool Date::isLeapYear(int year) const {
    if (year % 4 != 0) {
        return false;
    } else if (year % 100 != 0) {
        return true;
    } else if (year % 400 != 0) {
        return false;
    }

    return true;
}