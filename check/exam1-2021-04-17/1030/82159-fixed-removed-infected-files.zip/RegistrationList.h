#pragma once

#include <cstddef>

#include "Registration.h"

class RegistrationList {
private:
    size_t capacity;
    size_t size;
    Registration **registrations;

public:
    size_t getCapacity() const;

    size_t getSize() const;

public:
    RegistrationList(std::size_t capacity);

    RegistrationList(const RegistrationList &rhs);

    ~RegistrationList();

public:
    void insert(const std::string &id, const Date &date);

    const Registration &at(std::size_t index) const;

    bool empty() const;

private:
    bool validateIsUnique(const Registration& rhs) const;
    int findPosition(const Registration& rhs) const;
    void releaseMemory();
    void copyFrom(const RegistrationList& rhs);

public:
    RegistrationList &operator=(const RegistrationList &rhs);
};


