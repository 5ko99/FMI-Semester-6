#include "Registration.h"

Registration::Registration(const std::string &id, const Date &date) {
    this->date = &date;
    this->id = id;
}

Registration::Registration(const Registration &rhs) {
    this->id = rhs.id;
    this->date = rhs.date;
}

Registration::~Registration() {
    this->date = nullptr;
}

Registration &Registration::operator=(const Registration &rhs) {
    if (this != &rhs) {
        this->date = nullptr;

        this->id = rhs.id;
        this->date = rhs.date;
    }

    return *this;
}

bool Registration::operator==(const Registration &rhs) const {
    if (this->id == rhs.id) {
        if (this->date == rhs.date) {
            return true;
        }
    }

    return false;
}

bool Registration::operator<(const Registration &rhs) const {
    if (this->date > rhs.date) {
        return false;
    }

    if (this->id > rhs.id) {
        return false;
    }

    return true;
}

const std::string &Registration::getId() const {
    return id;
}

const Date *Registration::getDate() const {
    return date;
}
