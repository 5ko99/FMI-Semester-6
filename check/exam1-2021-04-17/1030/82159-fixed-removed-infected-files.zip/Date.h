#pragma once

#include <cstdint>

class Date {
private:
    std::uint8_t day;
    std::uint8_t month;
    std::uint16_t year;

public:
    Date(unsigned int day, unsigned int month, unsigned int year);

public:
    unsigned int getDay() const;

    unsigned int getMonth() const;

    unsigned int getYear() const;

private:
    bool validate(int day, int month, int year) const;

    bool isLeapYear(int year) const;

public:
    bool operator==(const Date &rhs) const;

    bool operator<(const Date &rhs) const;
};
