// СУ "Св. Климент Охридски"
// Факултет по математика и информатика
// Курс Обектно-ориентирано програмиране 2020/21
// Контролно 1
//
// Име:Димитър Стефанов
// ФН:82149
// Специалност:КН
// Курс:1
// Административна група:група 2
// Ден, в който се явявате на контролното:събота 17.04.2021г.
// Начален час на контролното: 10:30
// Кой компилатор използвате: <посочете едно от Visual C++, GCC или Clang>
//

#include <cassert>
#include <cstring>
#include <iostream>
#include <string>
#include <cstdint>
#include"date.h"


//    std::uint8_t _date;
  //  std::uint8_t _month;
    //std::uint16_t _year;

    Date::Date(unsigned int day, unsigned int month, unsigned int year)
    {
        _date = day;
        _month = month;
        _year = year;
    }
    unsigned int Date::day() const
    {
        return _date;
    }
    unsigned int Date::month() const
    {
        return _month;
    }
    unsigned int Date::year() const
    {
        return _year;
    }
    bool Date::operator==(const Date& rhs) const
    {
        if(_date == rhs._date && _month == rhs._month && _year == rhs._year)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    bool Date::operator<(const Date& rhs) const
    {
        if(_year < rhs._year)
        {return true;}
        else if(_year == rhs._year && _month < rhs._month)
        {return true;}
        else if(_year == rhs._year && _month == rhs._month && _date < rhs._date)
        {return true;}
        else
        {return false;}
    }




