// СУ "Св. Климент Охридски"
// Факултет по математика и информатика
// Курс Обектно-ориентирано програмиране 2020/21
// Контролно 1
//
// Име:Димитър Стефанов
// ФН:82149
// Специалност:КН
// Курс:1
// Административна група:група 2
// Ден, в който се явявате на контролното:събота 17.04.2021г.
// Начален час на контролното: 10:30
// Кой компилатор използвате: <посочете едно от Visual C++, GCC или Clang>
//

#include <cassert>
#include <cstring>
#include <iostream>
#include <string>
#include <cstdint>
/*
#include <cassert>
#include <cstring>
#include <iostream>
#include <string>
#include <cstdint>

#pragma once
class RegistrationList
{
    private:
    size_t used;
    size_t capacity;

    public:
    RegistrationList(std::size_t _capacity);
    void insert(const std::string& id, const Date& date);
    const Registration& at(std::size_t index) const;
    const Registration& operator[](std::size_t index) const;
    bool empty() const;
    std::size_t capacity() const;
    std::size_t size() const;

}
////////////////////////////////////////////////////////////////////////////////
class Registration
{

public:
    std::string id;
    Date date;

    Registration(const std::string& _id, const Date& _date);
    bool operator==(const Registration& rhs) const;
    bool operator<(const Registration& rhs) const;


}
////////////////////////////////////////////////////////////////////////////////
Registration::Registration(const std::string& DATE, const Date& DATE)
{
    id = ID;
    date = DATE;
}

bool Registration::operator==(const Registration& rhs) const
{
    if(id == rhs.id && date == rhs.date)
    {
        return true;
    }
    else
    {
        return false;
    }

}
bool Registration::operator<(const Registration& rhs) const
{
    if(_date < rhs.date)
    {
        return true;
    }
    else if(date == rhs.date && strcmp(id, rhs.id) < 0)
    {
        return true;
    }
    else
    {
    return false;
    }
}
///////
class Date
{
private:
    std::uint8_t _date;
    std::uint8_t _month;
    std::uint16_t _year;

public:
    Date(unsigned int day, unsigned int month, unsigned int year);
    unsigned int day() const;
    unsigned int month() const;
    unsigned int year() const;
    bool operator==(const Date& rhs) const;
    bool operator<(const Date& rhs) const;
};
///////////////////////////////
 Date::Date(unsigned int day, unsigned int month, unsigned int year)
    {
        _date = day;
        _month = month;
        _year = year;
    }
    unsigned int Date::day() const
    {
        return _date;
    }
    unsigned int Date::month() const
    {
        return _month;
    }
    unsigned int Date::year() const
    {
        return _year;
    }
    bool Date::operator==(const Date& rhs) const
    {
        if(_date == rhs._date && _month == rhs._month && _year == rhs._year)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    bool Date::operator<(const Date& rhs) const
    {
        if(_year < rhs._year)
        {return true;}
        else if(_year == rhs._year && _month < rhs._month)
        {return true;}
        else if(_year == rhs._year && _month == rhs._month && _date < rhs._date)
        {return true;}
        else
        {return false;}
    }


*/

#include"Registration.h"

    RegistrationList::RegistrationList(std::size_t _capacity)
    {
        used = 0;
        capacity = _capacity;
        Registration *a[capacity];
    }

    RegistrationList* RegistrationList::copy(const RegistrationList& other)
    {
        RegistrationList newrgl (other.capacity);
        for(size_t i=0;i<other.used;i++)
        {
            newrgl[i] = other[i];
        }
        return &newrgl;
    }

    RegistrationList::~RegistrationList()
    {
        for(size_t i=0;i<used;i++)
        {
            delete *a[i];
        }
        delete[] a;
    }


    void RegistrationList::insert(const std::string& id, const Date& date)
    {
        if(used == capacity)
        {
            capacity*=2;
            Registration *b[capacity];
            for(size_t i=0;i<used;i++)
            {
                b[i] = a[i];
            }
            delete[] a;
            a = b;
        }
        (a[used]->id) = _id;
        (a[used]->date) = _date;
        ++used;
    }

    const Registration& RegistrationList::at(std::size_t index) const
    {
        return a[index];
    }
    const Registration& RegistrationList::operator[](std::size_t index) const
    {
        return a[index];
    }
    bool RegistrationList::empty() const
    {
        if(used == 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    std::size_t RegistrationList::capacity() const
    {
        return capacity;
    }
    std::size_t RegistrationList::size() const
    {
        return used;
    }











