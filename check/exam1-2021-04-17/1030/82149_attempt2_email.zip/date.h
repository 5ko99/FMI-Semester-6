// СУ "Св. Климент Охридски"
// Факултет по математика и информатика
// Курс Обектно-ориентирано програмиране 2020/21
// Контролно 1
//
// Име:Димитър Стефанов
// ФН:82149
// Специалност:КН
// Курс:1
// Административна група:група 2
// Ден, в който се явявате на контролното:събота 17.04.2021г.
// Начален час на контролното: 10:30
// Кой компилатор използвате: <посочете едно от Visual C++, GCC или Clang>
//

#include <cassert>
#include <cstring>
#include <iostream>
#include <string>
#include <cstdint>

#pragma once

class Date
{
private:
    std::uint8_t _date;
    std::uint8_t _month;
    std::uint16_t _year;

public:
    Date(unsigned int day, unsigned int month, unsigned int year);
    unsigned int day() const;
    unsigned int month() const;
    unsigned int year() const;
    bool operator==(const Date& rhs) const;
    bool operator<(const Date& rhs) const;
};


















