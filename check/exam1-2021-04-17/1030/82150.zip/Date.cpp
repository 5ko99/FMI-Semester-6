#include "Date.h"
#include <stdexcept>

Date::Date(unsigned int day, unsigned int month, unsigned int year) : day(day_), month(month_), year(year_) {
    bool valid = true;
    if (month < 1 || month > 12)
        valid = false;
    if (day < 1 || day > 31)
        valid = false;
    if (((month <= 7 && month%2 == 0) || (month > 7 && month%2 != 0)) && day > 30) 
        valid = false;
    if (month == 2 && day > 29)
       valid = false; 
    if (month == 2 && leap() && day > 29)
       valid = false; 
    if (!valid)
        throw std::invalid_argument("Invalid day specified!");
}

unsigned int day() const {
    return day_;
}

unsigned int month() const {
    return month_;
}

unsigned int year() const {
    return year_;
}

bool Date::operator==(const Date& rhs) const {
    return (day_ == rhs.day && month_ == rhs.month && year_ == rhs.year_);
}

bool operator<(const Date& rhs) const {
    if (year_ < rhs.year_)
        return true;
    if (year_ > rhs.year_)
        return false;
    if (month_ < rhs.month_)
        return true;
    if (month_ > rhs.month_)
        return false;
    if (day_ < rhs.day_)
        return true;
    return false;
}

bool Date::leap() const {
    if (year_%4 != 0)
        return false;
    if (year_%400 == 0)
        return true;
    if (year_%100 == 0)
        return false;
    return true;
}
