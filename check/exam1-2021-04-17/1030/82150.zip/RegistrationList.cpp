#include "RegistrationList.h"
#include <utility> // for swap
#include <stdexcept>
#include <cassert>


RegistrationList::RegistrationList(size_t capacity) : list(new Registration*[capacity]()), capacity_(capacity), added(0) {
}

RegistrationList::~RegistrationList() {
    for (size_t i = 0; i < added; i++)
        list[i]->~Registration();
    delete[] list;
}

RegistrationList::RegistrationList(const RegistrationList& other) : 
    list(new Registration*[other.capacity()]()), capacity_(capacity), added(other.added) {
    for (size_t i = 0; i < added; ++i)
        *list[i] = other[i];
}

void RegistrationList::swap(RegistrationList&& other) {
    std::swap(list, other.list);
    std::swap(capacity_, other.capacity_);
    std::swap(added, other.added);
}

RegistrationList::RegistrationList(RegistrationList&& other) {
    swap(other);
}

RegistrationList& operator=(RegistrationList rhs) {
    swap(std::move(rhs));
    return *this;
}

void RegistrationList::insert(const std::string& id, const Date& date) {
    if (added == capacity()) 
        throw std::logic_error("Not enough space!");

    Registration* new_reg = new Registration(id, date);
    list[added++] = new_reg;

    size_t index = added-1;
    while (index && *list[index] < *list[index-1]) {
        std::swap(list[index], list[index-1]);
        --index;
    }
}

const Registration& RegistrationList::at(size_t index) const {
    if (index < 0 || index >= added)
        throw std::out_of_range("Index is out of range!");
    return *list[index];
}

const Registration& RegistrationList::operator[](size_t index) const {
#ifdef DEBUG
    assert(index >= 0 && index < added);
#endif
    return *list[index];
}

bool RegistrationList::empty() const {
    return added;
}

size_t RegistrationList::capacity() const {
    return capacity_;
}

size_t RegistrationList::size() const {
    return added;
}
