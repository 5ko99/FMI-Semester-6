#include <iostream>
#include <string>
#include "RegistrationList.h"
#include "Registration.h"
#include "Date.h"
#include <cstddef>

using std::size_t;

int main() {
    size_t n;
    cin >> n;

    RegistrationList list(n);

    while (n--) {
        std::string id;
        Date date;
        std::cin >> id;
        unsigned int day, month, year;
        Date* d;
        bool try_again = false;
        do {
            std::cin >> day >> month >> year;
            try {
                d = new Date(day, month, year);
            } catch (const std::exception& error) {
                std::cerr << error.what() << std::endl;
                std::cout << "Try again." << std::endl;
                try_again = true;
            }
        } while (try_again);
    }

    for (size_t i = 0; i < list.size(); ++i) {
        std::cout << list[i].id << " " << list[i].date << std::endl;
    }
}
