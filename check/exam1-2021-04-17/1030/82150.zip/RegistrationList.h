#include <cstddef>
#include <string>
#include "Date.h"
#include "Registration.h"

using std::size_t;

class RegistrationList {
public:
    RegistrationList(size_t capacity);
    RegistrationList(const RegistrationList& other);
    void swap(RegistrationList&& other);
    RegistrationList(RegistrationList&& other);
    RegistrationList& operator=(RegistrationList rhs);

    void insert(const std::string& id, const Date& date);
    const Registration& at(size_t index) const;
    const Registration& operator[](size_t index) const;
    bool empty() const;
    size_t capacity() const;
    size_t size() const;
private:
    Registration** list;
    size_t capacity_;
    size_t added;
};
