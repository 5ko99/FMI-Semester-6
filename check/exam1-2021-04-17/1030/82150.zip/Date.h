#include <cstdint>

class Date {
public:
    Date(unsigned int day, unsigned int month, unsigned int year);
    unsigned int day() const;
    unsigned int month() const;
    unsigned int year() const;
    bool operator==(const Date& rhs) const;
    bool operator<(const Date& rhs) const;

private:
    uint8_t date;
    uint8_t month;
    uint16_t year;

    bool leap() const;
};
