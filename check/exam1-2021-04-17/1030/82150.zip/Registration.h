#include <string>
#include "Date.h"

class Registration {
public:
    std::string id;
    Date date;

    Registration(const std::string& id, const Date& date) : id(id), date(date) {}

    bool operator==(const Registration& rhs) const {
        return id == rhs.id && date == rhs.date;
    }

    bool operator<(const Registration& rhs) const {
        if (date < rhs.date)
            return true;
        if (date > rhs.date)
            return false;
        if (id < rhs.id)
            return true;
        return false;
    }
};
