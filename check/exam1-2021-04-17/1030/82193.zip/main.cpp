#include<iostream>
#include<string>
#include<cstdint>
#include<stdexcept>
#include<cstddef>

int main() {
    return 0;
}