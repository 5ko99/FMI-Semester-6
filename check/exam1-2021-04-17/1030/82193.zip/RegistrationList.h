#include"Registration.h"
#include"Date.h"
#include<iostream>
#include<string>
#include<cstdint>
#include<stdexcept>
#include<cstddef>

#ifndef REGISTRATIONLIST_H
#define REGISTRATIONLIST_H

class RegistrationList {
    private:
        std::size_t cap;
        Registration registrations[];
    public:
        RegistrationList(std::size_t capacity);
        ~RegistrationList();
        void insert(const std::string& id, const Date& date);
        const Registration& at(std::size_t index) const;
        const Registration& operator[](std::size_t index) const;
        bool empty() const;
        std::size_t capacity() const;
        std::size_t size() const;
};

#endif
