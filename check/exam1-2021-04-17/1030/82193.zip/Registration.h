#include"Date.h"
#include<iostream>
#include<string>
#include<cstdint>
#include<stdexcept>
#include<cstddef>

#ifndef REGISTRATION_H
#define REGISTRATION_H

class Registration {
    public:
        std::string id;
        Date date = Date(1, 1, 1);
        Registration();
        Registration(const std::string& id, const Date& date);
        bool operator==(const Registration& rhs) const;
        bool operator<(const Registration& rhs) const;
};

#endif
