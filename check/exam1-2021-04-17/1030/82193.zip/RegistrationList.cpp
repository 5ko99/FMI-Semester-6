#include"Registration.h"
#include"RegistrationList.h"
#include"Date.h"
#include<iostream>
#include<string>
#include<cstdint>
#include<stdexcept>
#include<cstddef>

RegistrationList::RegistrationList(std::size_t capacity) {
    cap = capacity;
    registrations = new Registration[cap];
}

RegistrationList::~RegistrationList() {
    delete [] registrations;
}

const Registration& RegistrationList::at(std::size_t index) const {
    if(index < 0 || index > cap) {
        throw std::out_of_range("Index out of range exception.");
    }

    return registrations[index];
}

bool RegistrationList::empty() const {
    return registrations[0].id == nullptr;
}

std::size_t RegistrationList::capacity() const {
    return cap;
}

std::size_t RegistrationList::size() const {
    for (int iterator = 0; iterator < cap; iterator++)
    {
        if(registrations[iterator] == nullptr) {
            return iterator + 1;
        }
    }
    
    return 0;
}
