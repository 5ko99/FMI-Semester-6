#include "Date.h"
#include "Registration.h"
#include<iostream>
#include<string>
#include<cstdint>
#include<stdexcept>
#include<cstddef>

Registration::Registration() {
    this->id = nullptr;
    this->date = Date(1, 1, 1);
}

Registration::Registration(const std::string& id, const Date& date) {
    this->id = id;
    this->date = Date(date.day(), date.month(), date.year());
}

bool Registration::operator==(const Registration& rhs) const {
    if(id == rhs.id && date == rhs.date) {
        return true;
    }

    return false;
}

/*
Проверява дали текущата регистрация предхожда тази в rhs. 
Считаме, че една регистрация A предхожда друга регистрация
B или (1) ако датата на A е преди тази на B, или (2) ако 
двете дати съвпадат, но регистрационният номер на A предхожда 
лексикографски този на B.
*/
bool Registration::operator<(const Registration& rhs) const {
    if(date < rhs.date) {
        return true;
    }
    else if(date == rhs.date) {
        if(id < rhs.id) {
            return true;
        }
        else {
            return false;
        }
    }

    return false;
}
