#include<iostream>
#include<string>
#include<cstdint>
#include<stdexcept>
#include<cstddef>

#ifndef DATE_H
#define DATE_H

class Date {
    private:
        std::uint8_t dateDay;
        std::uint8_t dateMonth;
        std::uint16_t dateYear;
    public:
        Date(unsigned int day, unsigned int month, unsigned int year);
        unsigned int day() const;
        unsigned int month() const;
        unsigned int year() const;
        bool operator==(const Date& rhs) const;
        bool operator<(const Date& rhs) const;
};

#endif
