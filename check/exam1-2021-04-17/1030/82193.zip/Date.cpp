#include "Date.h"
#include<iostream>
#include<string>
#include<cstdint>
#include<stdexcept>
#include<cstddef>

/*
    Ако годината не е кратна на 4, значи НЕ Е високосна.
    В противен случай, ако НЕ Е кратна на 100, значи е високосна.
    Ако е кратна и на 4, и на 100, но НЕ Е кратна на 400, значи НЕ Е високосна.
    В противен случай е високосна година
*/
bool isLeapYear(int year) {
    if(year % 4 != 0) {
        return false;
    }
    else if(year % 100 != 0) {
        return true;
    }
    else if(year % 400 != 0) {
        return false;
    }
    else {
        return true;
    }
}

/*
    Месецът е стойност между 1 и 12.
    Денят не може да бъде 0.
    Ако месецът е януари(1), март(3), май(5), юли(7), август(8), октомври(10) или декември(12), денят е ≤ 31
    Ако месецът е април(4), юни(6), септември(9) или ноември(11), денят е ≤ 30
    Ако месецът е февруари(2) и годината е високосна, денят е ≤ 29
    Ако месецът е февруари(2) и годината НЕ Е високосна, денят е ≤ 28
*/
bool isValidDate(int day, int month, int year) {
    if(month < 1 || month > 12) {
        throw std::invalid_argument("Month's value should be between 1 and 12.");
    }
    else if(day < 0) {
        throw std::invalid_argument("Days's value should be higher than 0.");
    }
    else if((month <= 7 && month % 2 != 0) || (month >= 8 && month % 2 == 0)) {
        if(day > 31) {
            throw std::invalid_argument("Days's value should be less than 31.");
        }
    }
    else if(month == 4 || month == 6 || month == 9 || month == 11) {
        if(day > 30) {
            throw std::invalid_argument("Days's value should be less than 30.");
        }
    }
    else if(month == 2) {
        if(isLeapYear(year)) {
            if(day > 29) {
                throw std::invalid_argument("Days's value should be less than 29.");
            }
        }
        else {
            if(day > 28) {
                throw std::invalid_argument("Days's value should be less than 28.");
            }
        }
    }

    return true;
}

Date::Date(unsigned int day, unsigned int month, unsigned int year) {
    if(isValidDate(day, month, year)) {
        dateDay = day;
        dateMonth = month;
        dateYear = year;
    }
}

unsigned int Date::day() const {
    return dateDay;
}

unsigned int Date::month() const {
    return dateMonth;
}

unsigned int Date::year() const {
    return dateYear;
}

bool Date::operator==(const Date& rhs) const {
    if(rhs.day() == dateDay && rhs.month() == dateMonth && rhs.year() == dateYear) {
        return true;
    }

    return false;
}

bool Date::operator<(const Date& rhs) const {
    if(dateYear < rhs.year()) {
        return true;
    }
    else if (dateYear > rhs.year()) {
        return false;
    }
    else {
        if(dateMonth < rhs.month()) {
            return true;
        }
        else if (dateMonth > rhs.month()) {
            return false;
        }
        else {
            if(dateDay < rhs.day()) {
                return true;
            }
            else if (dateDay >= rhs.day()) {
                return false;
            }
        }
    }
    
    return false;
}
